//! Online aircraft details — type, operator, route and a photo.
//!
//! This is the second internet touch in the program, and it is held to the
//! same rule as the OpenSky overlay: it is clearly *not* something the
//! antenna heard. ADS-B gives an address and a callsign; everything richer —
//! what the aircraft actually is, who flies it, where this flight is going,
//! what it looks like — lives in databases, not in the signal. This fetches
//! that, on demand, for the one aircraft you have selected.
//!
//! Source is [adsbdb](https://api.adsbdb.com) for the metadata and route
//! (it also hands back a photo URL sourced from planespotters.net), then one
//! more GET for the photo bytes. All of it runs on a background thread so a
//! slow reply never stalls the display, and results are cached per aircraft
//! so a selection is looked up once.

use std::io::Read;
use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::thread;
use std::time::Duration;

/// Everything the lookup found for one aircraft. Every field is optional:
/// a private aircraft may have no database entry, a positioning flight no
/// route, an obscure tail no photo.
#[derive(Clone, Default)]
pub struct AcInfo {
    pub hex: String,
    pub registration: Option<String>,
    pub kind: Option<String>, // "Boeing 737-800"
    pub operator: Option<String>,
    pub route: Option<String>, // "CYYZ Toronto → CYVR Vancouver"
    pub photo: Option<Vec<u8>>, // raw JPEG/PNG bytes, decoded by the UI
    pub photographer: Option<String>,
    pub note: String, // shown when nothing was found or a fetch failed
}

impl AcInfo {
    fn is_empty(&self) -> bool {
        self.registration.is_none()
            && self.kind.is_none()
            && self.operator.is_none()
            && self.route.is_none()
            && self.photo.is_none()
    }
}

pub enum Reply {
    Ok(AcInfo),
    Failed(String),
}

struct Query {
    hex: String,
    callsign: Option<String>,
}

/// A background lookup worker. Mirrors the OpenSky client: one request at a
/// time, replies polled from the UI thread.
pub struct Lookup {
    tx: Sender<Query>,
    rx: Receiver<Reply>,
    pub in_flight: bool,
}

impl Lookup {
    pub fn start() -> Self {
        let (tx, q_rx) = mpsc::channel::<Query>();
        let (r_tx, rx) = mpsc::channel::<Reply>();
        thread::spawn(move || {
            let agent = ureq::AgentBuilder::new()
                .timeout_connect(Duration::from_secs(10))
                .timeout_read(Duration::from_secs(20))
                .build();
            while let Ok(q) = q_rx.recv() {
                let reply = match fetch(&agent, &q) {
                    Ok(i) => Reply::Ok(i),
                    Err(e) => Reply::Failed(e),
                };
                if r_tx.send(reply).is_err() {
                    break;
                }
            }
        });
        Lookup {
            tx,
            rx,
            in_flight: false,
        }
    }

    /// Ask for one aircraft, unless a request is already running. Returns
    /// whether the request was sent.
    pub fn request(&mut self, hex: String, callsign: Option<String>) -> bool {
        if self.in_flight {
            return false;
        }
        if self.tx.send(Query { hex, callsign }).is_err() {
            return false;
        }
        self.in_flight = true;
        true
    }

    /// Non-blocking; `None` until a reply is ready.
    pub fn poll(&mut self) -> Option<Reply> {
        match self.rx.try_recv() {
            Ok(r) => {
                self.in_flight = false;
                Some(r)
            }
            Err(TryRecvError::Empty) => None,
            Err(TryRecvError::Disconnected) => {
                self.in_flight = false;
                None
            }
        }
    }
}

fn get_json(agent: &ureq::Agent, url: &str) -> Option<serde_json::Value> {
    let body = agent
        .get(url)
        .set("User-Agent", "sweep-sdr/0.1 (hobby ADS-B receiver)")
        .call()
        .ok()?
        .into_string()
        .ok()?;
    serde_json::from_str(&body).ok()
}

fn fetch(agent: &ureq::Agent, q: &Query) -> Result<AcInfo, String> {
    let hex = q.hex.to_ascii_lowercase();
    let mut info = AcInfo {
        hex: hex.clone(),
        ..Default::default()
    };

    // --- aircraft metadata + photo URL ---------------------------------
    let mut photo_url: Option<String> = None;
    if let Some(v) = get_json(agent, &format!("https://api.adsbdb.com/v0/aircraft/{hex}")) {
        if let Some(ac) = v.get("response").and_then(|r| r.get("aircraft")) {
            let s = |k: &str| ac.get(k).and_then(|x| x.as_str()).map(str::to_string);
            info.registration = s("registration");
            let kind = s("type");
            let man = s("manufacturer");
            info.kind = match (man, kind) {
                (Some(m), Some(t)) => Some(format!("{m} {t}")),
                (None, Some(t)) => Some(t),
                (Some(m), None) => Some(m),
                _ => None,
            };
            info.operator = s("registered_owner");
            photo_url = s("url_photo_thumbnail").or_else(|| s("url_photo"));
        }
    }

    // --- route from the callsign ---------------------------------------
    if let Some(cs) = q.callsign.as_deref() {
        let cs = cs.trim();
        if cs.len() >= 3 && cs.chars().all(|c| c.is_ascii_alphanumeric()) {
            if let Some(v) = get_json(agent, &format!("https://api.adsbdb.com/v0/callsign/{cs}")) {
                if let Some(fr) = v.get("response").and_then(|r| r.get("flightroute")) {
                    let endpoint = |k: &str| -> Option<String> {
                        let e = fr.get(k)?;
                        let icao = e.get("icao_code").and_then(|x| x.as_str()).unwrap_or("");
                        let muni = e
                            .get("municipality")
                            .and_then(|x| x.as_str())
                            .unwrap_or("");
                        Some(format!("{icao} {muni}").trim().to_string())
                    };
                    if let (Some(o), Some(d)) = (endpoint("origin"), endpoint("destination")) {
                        info.route = Some(format!("{o} → {d}"));
                    }
                }
            }
        }
    }

    // --- the photo bytes -----------------------------------------------
    if let Some(src) = &photo_url {
        if let Ok(resp) = agent.get(src).call() {
            let mut bytes = Vec::new();
            if resp
                .into_reader()
                .take(3_000_000)
                .read_to_end(&mut bytes)
                .is_ok()
                && bytes.len() > 256
            {
                info.photo = Some(bytes);
                // adsbdb's photo comes from planespotters; credit them.
                info.photographer = Some("planespotters.net".to_string());
            }
        }
    }

    if info.is_empty() {
        return Err("no online details for this aircraft".to_string());
    }
    Ok(info)
}
