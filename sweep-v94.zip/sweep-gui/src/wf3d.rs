//! The waterfall, as a surface you look across rather than down at.
//!
//! The flat waterfall is a heat map: time down, frequency across, strength
//! as colour. This takes the same history and tilts it into a perspective
//! heightfield — the newest sweep across the front, older sweeps receding
//! toward a horizon, and signal strength lifted into the third dimension so
//! a strong carrier stands up as a ridge running back in time. Colour still
//! carries strength as well, so the surface reads whether or not the relief
//! is obvious.
//!
//! It is drawn as a single coloured mesh: a grid of quads, two triangles
//! each, one vertex per (row, column) with its own colour. egui has no
//! depth buffer, so the rows are emitted back-to-front — the nearest sweep
//! is drawn last and sits on top, which is the only ordering that looks
//! right.
//!
//! This is display only. Nothing here is a measurement the flat waterfall
//! does not already show; it is the same data, stood up.

use eframe::egui;

/// How many frequency columns the surface is built from.
///
/// The incoming spectrum is ~768 bins; drawing a vertex per bin per row is
/// tens of thousands of triangles a frame for detail no one can see in
/// perspective. The history is reduced to this many columns before it gets
/// here.
pub const COLS: usize = 144;

/// Draw the surface into `rect`.
///
/// `rows` is newest-first: `rows[0]` is the most recent sweep and draws
/// across the front, `rows.back()` is the oldest and sits at the horizon.
/// Each row is a slice of dBFS values, already reduced to [`COLS`] columns.
/// `floor`/`ceil` are the same dB window the flat waterfall uses, so the
/// two always agree on what counts as hot.
pub fn draw(
    painter: &egui::Painter,
    rect: egui::Rect,
    rows: &std::collections::VecDeque<Vec<f32>>,
    floor: f32,
    ceil: f32,
) {
    // Backdrop — a hair darker than a panel, so the surface floats.
    painter.rect_filled(rect, egui::Rounding::same(6.0), egui::Color32::from_rgb(10, 12, 8));

    let r = rows.len();
    if r < 2 {
        return;
    }
    let cols = rows.iter().map(|v| v.len()).min().unwrap_or(0);
    if cols < 2 {
        return;
    }

    // Perspective. The front edge spans almost the full width low in the
    // box; the back edge is narrower and high, leaving headroom for the
    // tallest near ridges to rise into. These are the only knobs that
    // matter for how "3D" it feels.
    let span = (ceil - floor).max(1.0);
    let front_margin = rect.width() * 0.02;
    let back_margin = rect.width() * 0.30; // how much each side pulls in at the horizon
    let top = rect.top() + rect.height() * 0.14; // horizon
    let base = rect.bottom() - rect.height() * 0.06; // the nearest row's baseline
    let rise = rect.height() * 0.42; // how far a full-scale signal lifts, at the front

    // Depth parameter d in [0,1]: 0 = front (newest), 1 = horizon (oldest).
    let depth = |ri: usize| ri as f32 / (r - 1) as f32;
    // Rows crowd toward the horizon — a square-root easing spreads the
    // nearest sweeps out and compresses the distant ones, the way real
    // perspective does, instead of spacing them evenly.
    let row_y = |d: f32| {
        let e = d.sqrt();
        base + (top - base) * e
    };
    let row_scale = |d: f32| {
        let e = d.sqrt();
        1.0 - e * (1.0 - back_margin * 2.0 / rect.width())
    };

    let cx = rect.center().x;
    let project = |ri: usize, ci: usize, level: f32| -> (egui::Pos2, f32) {
        let d = depth(ri);
        let t = ((level - floor) / span).clamp(0.0, 1.0);
        let scale = row_scale(d);
        let usable = rect.width() - front_margin * 2.0;
        let x = cx + (ci as f32 / (cols - 1) as f32 - 0.5) * usable * scale;
        // Distant relief is foreshortened along with everything else.
        let y = row_y(d) - t * rise * scale;
        (egui::pos2(x, y), t)
    };

    let mut mesh = egui::Mesh::default();
    // Vertices, back-to-front so the newest row's indices are highest and
    // its triangles are added last.
    for ri in (0..r).rev() {
        let rowv = &rows[ri];
        for ci in 0..cols {
            let (p, t) = project(ri, ci, rowv[ci]);
            let col = shade(crate::waterfall::colormap(rowv[ci], floor, ceil), t, depth(ri));
            mesh.colored_vertex(p, col);
        }
    }
    // The vertex for (ri, ci) sits at offset: rows were pushed in reverse,
    // so row ri occupies block (r-1-ri).
    let idx = |ri: usize, ci: usize| ((r - 1 - ri) * cols + ci) as u32;
    // Triangles between consecutive rows, far pair first.
    for ri in (1..r).rev() {
        let near = ri - 1; // nearer (drawn later within this loop order)
        let far = ri;
        for ci in 0..cols - 1 {
            let a = idx(far, ci);
            let b = idx(far, ci + 1);
            let c = idx(near, ci);
            let d = idx(near, ci + 1);
            mesh.add_triangle(a, b, c);
            mesh.add_triangle(b, d, c);
        }
    }
    painter.add(egui::Shape::mesh(mesh));

    // A bright rule along the very front edge — the "now" line — so the eye
    // knows which end is live.
    let front: Vec<egui::Pos2> = (0..cols)
        .map(|ci| project(0, ci, rows[0][ci]).0)
        .collect();
    painter.add(egui::Shape::line(
        front,
        egui::Stroke::new(1.4_f32, crate::theme::live().gamma_multiply(0.9)),
    ));
}

/// Lift a colormap colour toward white with height, and dim it with
/// distance, so near ridges read as lit and the horizon falls into haze.
fn shade(c: egui::Color32, t: f32, d: f32) -> egui::Color32 {
    // Height highlight: the top of a ridge catches a little light.
    let hi = 0.20 * t;
    // Distance: the back of the field dims and desaturates toward the
    // backdrop, which reads as depth.
    let dim = 1.0 - 0.45 * d;
    let mix = |ch: u8| {
        let lit = ch as f32 + (255.0 - ch as f32) * hi;
        (lit * dim).clamp(0.0, 255.0) as u8
    };
    egui::Color32::from_rgb(mix(c.r()), mix(c.g()), mix(c.b()))
}

/// Reduce a full-resolution spectrum row to [`COLS`] columns by taking the
/// strongest bin in each group — a peak, never a mean, so a narrow carrier
/// still stands up in the surface instead of being averaged flat.
pub fn reduce(bins: &[f32]) -> Vec<f32> {
    if bins.is_empty() {
        return vec![-120.0; COLS];
    }
    let mut out = Vec::with_capacity(COLS);
    for g in 0..COLS {
        let a = g * bins.len() / COLS;
        let b = (((g + 1) * bins.len()) / COLS).max(a + 1).min(bins.len());
        let mut m = f32::NEG_INFINITY;
        for &v in &bins[a..b] {
            if v > m {
                m = v;
            }
        }
        out.push(if m.is_finite() { m } else { -120.0 });
    }
    out
}
