//! "What is this frequency" — three tiers, most specific first:
//!
//! 1. An exact match in the loaded repeater/station list (from
//!    `repeaters_on.rs`, sourced from the user's own RepeaterBook export —
//!    this is the only tier backed by a real, named station).
//! 2. The scanner's own built-in bands (aviation, marine, weather, etc.),
//!    via `sweep_core::rules::identify` — the same table `scan.rs` already
//!    tunes with.
//! 3. US amateur band segments, transcribed from the ARRL band chart. These
//!    are allocation edges, not a claim about what's actually transmitting —
//!    two bands (Marine VHF / Railway VHF) overlap in the source data too,
//!    so treat this as "closest known band," not a certain identification.
//!
//! What this deliberately does NOT attempt: the full NTIA spectrum wall
//! chart. That table has thousands of narrow federal/non-federal
//! allocations across kHz–300 GHz, transcribed from a chart image — hand-
//! encoding it accurately isn't something I can vouch for, and a wrong
//! label stated with confidence is worse than no label. It's still a good
//! reference to keep next to the radio; it just isn't wired into this
//! lookup.

use crate::stations::Station;

/// (low_mhz, high_mhz, label) — from the ARRL US Amateur Radio Bands chart.
/// Only bands NOT already in sweep-core's own table (2m, 70cm) are listed
/// here to avoid two sources of truth for the same range.
const HAM_BANDS_MHZ: &[(f64, f64, &str)] = &[
    (0.1357, 0.1378, "2200m amateur"),
    (0.472, 0.479, "630m amateur"),
    (1.800, 2.000, "160m amateur"),
    (3.500, 4.000, "80m amateur"),
    (5.3305, 5.4035, "60m amateur (channelized)"),
    (7.000, 7.300, "40m amateur"),
    (10.100, 10.150, "30m amateur"),
    (14.000, 14.350, "20m amateur"),
    (18.068, 18.168, "17m amateur"),
    (21.000, 21.450, "15m amateur"),
    (24.890, 24.990, "12m amateur"),
    (28.000, 29.700, "10m amateur"),
    (50.0, 54.0, "6m amateur"),
    (219.0, 220.0, "1.25m amateur (digital)"),
    (222.0, 225.0, "1.25m amateur"),
    (902.0, 928.0, "33cm amateur"),
    (1240.0, 1300.0, "23cm amateur"),
];

/// Best available label for `freq_mhz`, or `None` if nothing matches.
pub fn identify_frequency(freq_mhz: f64, stations: &[Station]) -> Option<String> {
    const STATION_TOLERANCE_MHZ: f64 = 0.01;
    if let Some(st) = stations
        .iter()
        .find(|s| (s.freq_mhz - freq_mhz).abs() <= STATION_TOLERANCE_MHZ)
    {
        return Some(st.name.clone());
    }
    if let Some(band) = sweep_core::rules::identify(freq_mhz) {
        return Some(band.to_string());
    }
    HAM_BANDS_MHZ
        .iter()
        .find(|(lo, hi, _)| freq_mhz >= *lo && freq_mhz <= *hi)
        .map(|(_, _, label)| label.to_string())
}
