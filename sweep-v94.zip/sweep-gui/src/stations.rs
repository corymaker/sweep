//! A single RTL-SDR with a whip antenna cannot tell you where a signal
//! physically comes from — that needs multiple receivers doing TDOA, or a
//! directional antenna swept for bearing. Neither exists here.
//!
//! What *is* real: some bands are fixed infrastructure with publicly
//! documented sites (weather radio, a marine VHF coast station, a repeater
//! you've identified by callsign). If you already know where a frequency's
//! transmitter sits, this shows you the bearing and range from your own
//! position — a compass, not a locator. The list ships empty on purpose;
//! filling in a station's coordinates from memory would be a guess wearing
//! the costume of a measurement. Add sites you've confirmed yourself, e.g.
//! from weatherradio.net, ISED's spectrum database, or radioreference.com.

#[derive(Clone)]
pub struct Station {
    pub name: String,
    pub freq_mhz: f64,
    pub lat: f64,
    pub lon: f64,
}

/// Initial great-circle bearing from (lat0,lon0) to (lat1,lon1), in degrees,
/// 0 = north, clockwise.
pub fn bearing_deg(lat0: f64, lon0: f64, lat1: f64, lon1: f64) -> f64 {
    let (lat0, lon0, lat1, lon1) = (
        lat0.to_radians(),
        lon0.to_radians(),
        lat1.to_radians(),
        lon1.to_radians(),
    );
    let dlon = lon1 - lon0;
    let y = dlon.sin() * lat1.cos();
    let x = lat0.cos() * lat1.sin() - lat0.sin() * lat1.cos() * dlon.cos();
    (y.atan2(x).to_degrees() + 360.0) % 360.0
}

/// Great-circle distance in km, haversine.
pub fn distance_km(lat0: f64, lon0: f64, lat1: f64, lon1: f64) -> f64 {
    const R_KM: f64 = 6371.0;
    let (lat0r, lat1r) = (lat0.to_radians(), lat1.to_radians());
    let dlat = (lat1 - lat0).to_radians();
    let dlon = (lon1 - lon0).to_radians();
    let a = (dlat / 2.0).sin().powi(2) + lat0r.cos() * lat1r.cos() * (dlon / 2.0).sin().powi(2);
    2.0 * R_KM * a.sqrt().asin()
}

/// Closest known station to `freq_mhz` within `tolerance_mhz`, if any.
pub fn find_station<'a>(
    stations: &'a [Station],
    freq_mhz: f64,
    tolerance_mhz: f64,
) -> Option<&'a Station> {
    stations
        .iter()
        .filter(|s| (s.freq_mhz - freq_mhz).abs() <= tolerance_mhz)
        .min_by(|a, b| {
            (a.freq_mhz - freq_mhz)
                .abs()
                .partial_cmp(&(b.freq_mhz - freq_mhz).abs())
                .unwrap()
        })
}

/// The seven Weatheradio Canada / NOAA Weather Radio channels. Canada's
/// network (Environment and Climate Change Canada) was fully decommissioned
/// March 31, 2026 — these frequencies now carry nothing in Canada, though a
/// nearby NOAA (US) transmitter may still be reachable close to the border.
pub const WEATHER_FREQS_MHZ: [f64; 7] = [
    162.400, 162.425, 162.450, 162.475, 162.500, 162.525, 162.550,
];

pub fn is_decommissioned_weather_channel(freq_mhz: f64) -> bool {
    WEATHER_FREQS_MHZ
        .iter()
        .any(|f| (f - freq_mhz).abs() < 0.006)
}
