//! A second opinion on what is in the sky.
//!
//! Everything else in this program is what your own antenna heard. This is
//! the one exception: a read-only query to the OpenSky Network, which
//! aggregates ADS-B from thousands of volunteer receivers worldwide and
//! publishes the result.
//!
//! It exists for one reason — to tell you whether a quiet map means quiet
//! skies or a bad antenna. Those look identical from inside the receiver,
//! and no amount of DSP work distinguishes them. Side by side they are
//! obvious: eleven aircraft overhead and two decoded is an antenna problem;
//! two overhead and two decoded means the sky is just empty.
//!
//! What this is *not*: a source of positions to display as if they were
//! received here. Overlay contacts are drawn hollow and are always
//! distinguishable from your own decodes, because otherwise the map would
//! quietly become an internet flight tracker wearing a radio's costume.
//!
//! Anonymous access is rate limited to 400 credits a day per IP address, so
//! the overlay is off by default, refreshes no faster than every five
//! minutes, and counts what it has spent.

use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::thread;
use std::time::{Duration, Instant};

/// Floor on query spacing, whatever the user asks for. Anonymous access is
/// 400 credits a day per IP; at 15 seconds that budget is gone in under two
/// hours, which is a choice someone can reasonably make for a session but
/// not one to allow by accident.
pub const MIN_INTERVAL: Duration = Duration::from_secs(15);

/// What the refresh control defaults to: often enough that the picture
/// feels live, slow enough to run for hours inside the free budget.
pub const DEFAULT_INTERVAL_S: f32 = 60.0;

/// Credits a day at a given spacing, for showing the cost honestly next to
/// the control that sets it.
pub fn queries_per_day(interval_s: f32) -> f32 {
    86_400.0 / interval_s.max(1.0)
}

/// One aircraft as the network reports it.
#[derive(Clone)]
pub struct Contact {
    /// Lower-case hex, same 24-bit address our own decoder reports — which
    /// is what lets the two lists be matched against each other.
    pub icao24: String,
    pub callsign: Option<String>,
    /// The state's country of registration as the network reports it —
    /// not where the aircraft is, but whose registry the tail number is on.
    pub origin_country: Option<String>,
    pub lat: f64,
    pub lon: f64,
    pub alt_ft: Option<i32>,
    pub speed_kt: Option<f32>,
    pub heading_deg: Option<f32>,
    /// Climb/descent rate in feet per minute, signed.
    pub vert_rate_fpm: Option<i32>,
    /// Transponder squawk, when the state carries one.
    pub squawk: Option<String>,
    pub on_ground: bool,
    /// When this position was fetched, so the display can carry it forward
    /// between queries.
    pub fetched: Instant,
}

impl Contact {
    /// Where this aircraft has got to since the fetch, assuming it held its
    /// reported course and speed.
    ///
    /// This is dead reckoning, not observation, and it is why the overlay
    /// moves smoothly on a five-minute refresh instead of teleporting. It
    /// is deliberately capped: past a few minutes an aircraft has had time
    /// to turn, and a confidently wrong position is worse than a stale one,
    /// so the estimate stops advancing rather than drifting off.
    pub fn position_now(&self) -> (f64, f64) {
        const MAX_COAST_S: f64 = 240.0;
        let dt = self.fetched.elapsed().as_secs_f64().min(MAX_COAST_S);
        let (kt, hdg) = match (self.speed_kt, self.heading_deg) {
            (Some(k), Some(h)) if k > 1.0 => (k as f64, (h as f64).to_radians()),
            _ => return (self.lat, self.lon),
        };
        let km = kt * 1.852 * dt / 3600.0;
        let dlat = km / 111.32 * hdg.cos();
        let dlon = km / (111.32 * self.lat.to_radians().cos().abs().max(0.05)) * hdg.sin();
        (self.lat + dlat, self.lon + dlon)
    }
}

pub enum Reply {
    Ok(Vec<Contact>),
    Failed(String),
}

struct Query {
    lat: f64,
    lon: f64,
    radius_km: f64,
}

/// A background thread that fetches on request. Kept off the UI thread
/// because a stalled HTTPS connection would otherwise freeze the display
/// for however long the timeout runs.
pub struct OpenSky {
    tx: Sender<Query>,
    rx: Receiver<Reply>,
    /// Queries actually issued this session — one anonymous credit each at
    /// the box sizes this asks for.
    pub queries: u32,
    pub in_flight: bool,
    pub last_fetch: Option<Instant>,
}

impl OpenSky {
    pub fn start() -> Self {
        let (tx, q_rx) = mpsc::channel::<Query>();
        let (r_tx, rx) = mpsc::channel::<Reply>();
        thread::spawn(move || {
            let agent = ureq::AgentBuilder::new()
                .timeout_connect(Duration::from_secs(10))
                .timeout_read(Duration::from_secs(25))
                .build();
            while let Ok(q) = q_rx.recv() {
                let reply = match fetch(&agent, &q) {
                    Ok(v) => Reply::Ok(v),
                    Err(e) => Reply::Failed(e),
                };
                if r_tx.send(reply).is_err() {
                    break;
                }
            }
        });
        OpenSky {
            tx,
            rx,
            queries: 0,
            in_flight: false,
            last_fetch: None,
        }
    }

    /// Ask for everything within `radius_km` of a point, unless a request
    /// is already running or the last one was too recent.
    pub fn request(
        &mut self,
        lat: f64,
        lon: f64,
        radius_km: f64,
        interval: Duration,
        force: bool,
    ) -> bool {
        if self.in_flight {
            return false;
        }
        let gap = interval.max(MIN_INTERVAL);
        if let Some(t) = self.last_fetch {
            // Even a forced refresh respects the floor — the button should
            // not be a way to spend the day's credits in a minute.
            let need = if force { MIN_INTERVAL } else { gap };
            if t.elapsed() < need {
                return false;
            }
        }
        if self
            .tx
            .send(Query {
                lat,
                lon,
                radius_km,
            })
            .is_err()
        {
            return false;
        }
        self.in_flight = true;
        self.queries += 1;
        true
    }

    /// Non-blocking. `None` means nothing has come back yet.
    pub fn poll(&mut self) -> Option<Reply> {
        match self.rx.try_recv() {
            Ok(r) => {
                self.in_flight = false;
                self.last_fetch = Some(Instant::now());
                Some(r)
            }
            Err(TryRecvError::Empty) => None,
            Err(TryRecvError::Disconnected) => {
                self.in_flight = false;
                None
            }
        }
    }

    /// How long until a manual refresh is allowed.
    pub fn cooldown(&self) -> Duration {
        match self.last_fetch {
            Some(t) => MIN_INTERVAL.saturating_sub(t.elapsed()),
            None => Duration::ZERO,
        }
    }
}

fn fetch(agent: &ureq::Agent, q: &Query) -> Result<Vec<Contact>, String> {
    // A degree of latitude is very nearly constant; a degree of longitude
    // shrinks with the cosine of latitude, so the box has to be widened
    // east-west or it covers less ground than asked at northern latitudes.
    let dlat = q.radius_km / 111.32;
    let dlon = q.radius_km / (111.32 * q.lat.to_radians().cos().abs().max(0.05));
    let url = format!(
        "https://opensky-network.org/api/states/all?lamin={:.4}&lomin={:.4}&lamax={:.4}&lomax={:.4}",
        (q.lat - dlat).clamp(-90.0, 90.0),
        (q.lon - dlon).clamp(-180.0, 180.0),
        (q.lat + dlat).clamp(-90.0, 90.0),
        (q.lon + dlon).clamp(-180.0, 180.0),
    );

    let body = agent
        .get(&url)
        .set("User-Agent", "sweep-sdr/0.1 (hobby ADS-B receiver)")
        .call()
        .map_err(|e| match e {
            // 429 is the one worth naming outright: it means the day's
            // anonymous credits are gone, and no amount of retrying helps
            // until the quota resets.
            ureq::Error::Status(429, _) => {
                "OpenSky rate limit reached — anonymous access allows 400 queries a day per \
                 IP address, and this one is out until it resets"
                    .to_string()
            }
            ureq::Error::Status(code, _) => format!("OpenSky returned HTTP {code}"),
            other => format!("could not reach OpenSky: {other}"),
        })?
        .into_string()
        .map_err(|e| format!("OpenSky response unreadable: {e}"))?;

    let root: serde_json::Value =
        serde_json::from_str(&body).map_err(|e| format!("OpenSky sent malformed JSON: {e}"))?;

    // `states` is null rather than an empty list when the box is empty,
    // which is a perfectly good answer and not an error.
    let states = match root.get("states") {
        Some(serde_json::Value::Array(a)) => a,
        _ => return Ok(Vec::new()),
    };

    // Each state is a bare array, documented by position rather than by
    // name: 0 address, 1 callsign, 5 longitude, 6 latitude, 7 barometric
    // altitude in metres, 8 on-ground, 9 speed in m/s, 10 track, 13
    // geometric altitude.
    let mut out = Vec::with_capacity(states.len());
    for s in states {
        let f = match s.as_array() {
            Some(a) if a.len() >= 11 => a,
            _ => continue,
        };
        let (lon, lat) = match (f[5].as_f64(), f[6].as_f64()) {
            (Some(lo), Some(la)) => (lo, la),
            // No position is common — the aircraft was heard but not
            // located. Nothing to plot, so drop it.
            _ => continue,
        };
        let alt_m = f
            .get(13)
            .and_then(|v| v.as_f64())
            .or_else(|| f[7].as_f64());
        let callsign = f[1]
            .as_str()
            .map(|c| c.trim().to_string())
            .filter(|c| !c.is_empty());
        // Fields past 10 are optional in practice — some states carry a
        // squawk, some do not — so each is read defensively with `get`.
        // 2 origin country, 11 vertical rate in m/s (signed), 14 squawk.
        let origin_country = f
            .get(2)
            .and_then(|v| v.as_str())
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty());
        let vert_rate_fpm = f
            .get(11)
            .and_then(|v| v.as_f64())
            .map(|v| (v * 196.850_4) as i32);
        let squawk = f
            .get(14)
            .and_then(|v| v.as_str())
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty());
        out.push(Contact {
            icao24: f[0].as_str().unwrap_or("").to_ascii_lowercase(),
            callsign,
            origin_country,
            lat,
            lon,
            alt_ft: alt_m.map(|m| (m * 3.280_84) as i32),
            speed_kt: f[9].as_f64().map(|v| (v * 1.943_84) as f32),
            heading_deg: f[10].as_f64().map(|v| v as f32),
            vert_rate_fpm,
            squawk,
            on_ground: f[8].as_bool().unwrap_or(false),
            fetched: Instant::now(),
        });
    }
    Ok(out)
}
