//! Geography for the aircraft display.
//!
//! Two parts, and the split matters.
//!
//! The **graticule** — parallels and meridians — is computed, not looked up.
//! It is correct anywhere on earth with no data file, and it is what turns
//! a blank dial into something you can read a position off.
//!
//! **Coastlines and borders** are not shipped. There is no small, accurate
//! outline of the Great Lakes that I could write down from memory, and a
//! shoreline drawn from a vague recollection would be worse than none — it
//! would put an aircraft over water that is actually over land and look
//! authoritative doing it. So this loads whatever GeoJSON you drop into a
//! `map/` folder next to the executable. Natural Earth publishes exactly
//! the right files, free and public domain; the app tells you which ones.
//!
//! Projection is azimuthal equidistant centred on the receiver: distance
//! from the centre of the screen is proportional to real distance on the
//! ground, in every direction. That is the projection a radar display
//! already implies, so the range rings stay honest once there is a
//! coastline underneath them — a ring labelled 100 km crosses the shore at
//! the places that really are 100 km away.

use std::path::{Path, PathBuf};

/// What a run of points represents, so it can be drawn as the thing it is
/// rather than as undifferentiated grey.
///
/// Inferred from the file name, which is crude but is the only signal a
/// plain GeoJSON gives — Natural Earth's own naming is consistent enough
/// that it works, and a wrong guess only picks the wrong colour.
#[derive(Clone, Copy, PartialEq)]
pub enum Kind {
    Water,
    Coast,
    Border,
}

/// One unbroken run of points — a stretch of shoreline, a border segment,
/// or the outline of a lake.
pub struct Polyline {
    pub pts: Vec<(f64, f64)>, // (lat, lon)
    pub kind: Kind,
    /// True when the run closes on itself, which means it encloses an area
    /// and can be filled. GeoJSON says so by repeating the first point at
    /// the end; a coastline, which is just a line, does not.
    pub closed: bool,
}

fn kind_of(file: &str) -> Kind {
    let f = file.to_ascii_lowercase();
    if f.contains("lake") || f.contains("ocean") || f.contains("river") || f.contains("water") {
        Kind::Water
    } else if f.contains("coast") {
        Kind::Coast
    } else {
        Kind::Border
    }
}

#[derive(Default)]
pub struct GeoMap {
    pub lines: Vec<Polyline>,
    pub loaded_from: Vec<String>,
    pub note: String,
}

/// Where map files are looked for, next to the executable.
pub fn map_dir() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.join("map")))
        .unwrap_or_else(|| PathBuf::from("map"))
}

impl GeoMap {
    /// Read every `.geojson` in `map/`, keeping only what falls near the
    /// receiver.
    ///
    /// The clip is not an optimisation detail — a world coastline file is
    /// several hundred thousand points, and projecting all of them every
    /// frame to draw the twenty that are on screen would cost more than the
    /// entire rest of the program.
    pub fn load(dir: &Path, lat0: f64, lon0: f64, radius_km: f64) -> GeoMap {
        let mut out = GeoMap::default();
        let rd = match std::fs::read_dir(dir) {
            Ok(r) => r,
            Err(_) => {
                out.note = format!(
                    "No map folder yet. Create {} and drop GeoJSON files in it — see the \
                     button below for where to get them.",
                    dir.display()
                );
                return out;
            }
        };

        // Generous margin: a shoreline that leaves the box and comes back
        // should not be chopped into disconnected fragments.
        let dlat = (radius_km * 1.6) / 111.32;
        let dlon = (radius_km * 1.6) / (111.32 * lat0.to_radians().cos().abs().max(0.05));
        let (lat_lo, lat_hi) = (lat0 - dlat, lat0 + dlat);
        let (lon_lo, lon_hi) = (lon0 - dlon, lon0 + dlon);

        // Look one level into subfolders as well as directly in map/.
        //
        // People drop a downloaded folder in here rather than its contents,
        // and a copy command that nests the folder inside itself is easy to
        // run by accident. Finding the files anyway costs one extra
        // directory read and saves a confusing empty map.
        let mut files: Vec<PathBuf> = Vec::new();
        let is_geo = |p: &Path| {
            p.extension()
                .and_then(|e| e.to_str())
                .map(|e| e.eq_ignore_ascii_case("geojson") || e.eq_ignore_ascii_case("json"))
                .unwrap_or(false)
        };
        for entry in rd.flatten() {
            let path = entry.path();
            if path.is_dir() {
                if let Ok(sub) = std::fs::read_dir(&path) {
                    for e in sub.flatten() {
                        let p = e.path();
                        if p.is_file() && is_geo(&p) {
                            files.push(p);
                        }
                    }
                }
            } else if is_geo(&path) {
                files.push(path);
            }
        }
        files.sort();

        if files.is_empty() {
            out.note = format!(
                "{} exists but has no .geojson files in it.",
                dir.display()
            );
            return out;
        }

        for path in files {
            let text = match std::fs::read_to_string(&path) {
                Ok(t) => t,
                Err(e) => {
                    out.note = format!("{}: {e}", path.display());
                    continue;
                }
            };
            let v: serde_json::Value = match serde_json::from_str(&text) {
                Ok(v) => v,
                Err(e) => {
                    out.note = format!("{}: not valid GeoJSON ({e})", path.display());
                    continue;
                }
            };
            let before = out.lines.len();
            let kind = kind_of(
                path.file_name().and_then(|n| n.to_str()).unwrap_or(""),
            );
            collect(&v, &mut |ring| {
                // Keep a run only if some part of it is in view, then keep
                // the whole run — clipping exactly would need proper
                // polygon clipping, and the margin above already bounds
                // how much extra comes along.
                if ring.iter().any(|&(la, lo)| {
                    la >= lat_lo && la <= lat_hi && lo >= lon_lo && lo <= lon_hi
                }) {
                    let closed = ring.len() > 3
                        && (ring[0].0 - ring[ring.len() - 1].0).abs() < 1e-9
                        && (ring[0].1 - ring[ring.len() - 1].1).abs() < 1e-9;
                    out.lines.push(Polyline {
                        pts: ring,
                        kind,
                        closed,
                    });
                }
            });
            let added = out.lines.len() - before;
            out.loaded_from.push(format!(
                "{} — {added} feature(s) nearby",
                path.file_name()
                    .and_then(|n| n.to_str())
                    .unwrap_or("?")
            ));
        }
        if out.lines.is_empty() && out.note.is_empty() {
            out.note =
                "Map files loaded, but nothing in them is near your position — check your \
                 latitude and longitude in Settings."
                    .into();
        }
        out
    }
}

/// Walk any GeoJSON shape and hand every coordinate run to `emit`.
///
/// Deliberately tolerant: FeatureCollection, Feature, GeometryCollection,
/// or a bare geometry all work, and an unrecognised type is skipped rather
/// than treated as an error. Files people download are rarely the shape you
/// expected.
fn collect(v: &serde_json::Value, emit: &mut impl FnMut(Vec<(f64, f64)>)) {
    match v.get("type").and_then(|t| t.as_str()) {
        Some("FeatureCollection") => {
            if let Some(fs) = v.get("features").and_then(|f| f.as_array()) {
                for f in fs {
                    collect(f, emit);
                }
            }
        }
        Some("Feature") => {
            if let Some(g) = v.get("geometry") {
                collect(g, emit);
            }
        }
        Some("GeometryCollection") => {
            if let Some(gs) = v.get("geometries").and_then(|g| g.as_array()) {
                for g in gs {
                    collect(g, emit);
                }
            }
        }
        Some(t) => {
            let c = match v.get("coordinates") {
                Some(c) => c,
                None => return,
            };
            // Nesting depth is the only real difference between these:
            // a LineString is one run, a Polygon is a list of runs, a
            // MultiPolygon a list of those.
            match t {
                "LineString" => {
                    if let Some(r) = run(c) {
                        emit(r);
                    }
                }
                "MultiLineString" | "Polygon" => {
                    if let Some(a) = c.as_array() {
                        for r in a {
                            if let Some(r) = run(r) {
                                emit(r);
                            }
                        }
                    }
                }
                "MultiPolygon" => {
                    if let Some(a) = c.as_array() {
                        for poly in a {
                            if let Some(rings) = poly.as_array() {
                                for r in rings {
                                    if let Some(r) = run(r) {
                                        emit(r);
                                    }
                                }
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        None => {}
    }
}

/// GeoJSON writes coordinates longitude-first; everything else in this
/// program is latitude-first, and getting that backwards puts Ontario in
/// the Indian Ocean.
fn run(v: &serde_json::Value) -> Option<Vec<(f64, f64)>> {
    let a = v.as_array()?;
    let mut out = Vec::with_capacity(a.len());
    for p in a {
        let p = p.as_array()?;
        if p.len() < 2 {
            continue;
        }
        let lon = p[0].as_f64()?;
        let lat = p[1].as_f64()?;
        out.push((lat, lon));
    }
    if out.len() < 2 {
        None
    } else {
        Some(out)
    }
}

/// Azimuthal-equidistant projection to a unit disc: returns the offset from
/// the centre in units of `radius_km`, so `(0,0)` is the receiver and a
/// magnitude of 1.0 sits on the outer range ring.
///
/// `x` is east, `y` is north. The caller flips `y` for screen coordinates.
pub fn project(
    lat0: f64,
    lon0: f64,
    lat: f64,
    lon: f64,
    radius_km: f64,
) -> (f32, f32) {
    let d = crate::stations::distance_km(lat0, lon0, lat, lon) / radius_km;
    let b = crate::stations::bearing_deg(lat0, lon0, lat, lon).to_radians();
    ((d * b.sin()) as f32, (d * b.cos()) as f32)
}

/// Parallels and meridians covering the visible area.
///
/// Spacing adapts to the zoom so the grid stays readable: whole degrees
/// when looking at a province, tenths when looking at a town.
pub fn graticule(lat0: f64, lon0: f64, radius_km: f64) -> (Vec<Polyline>, f64) {
    let span_deg = (radius_km / 111.32) * 2.0;
    // Aim for five to eight lines across the view. Coarser than that and
    // the grid stops being usable for reading a position off; finer and it
    // competes with the coastline for attention.
    let step = if span_deg > 8.0 {
        2.0
    } else if span_deg > 4.0 {
        1.0
    } else if span_deg > 1.6 {
        0.5
    } else if span_deg > 0.8 {
        0.25
    } else {
        0.1
    };

    let dlat = radius_km / 111.32 * 1.1;
    let dlon = radius_km / (111.32 * lat0.to_radians().cos().abs().max(0.05)) * 1.1;
    let mut out = Vec::new();

    let first_lat = (((lat0 - dlat) / step).ceil()) * step;
    let mut la = first_lat;
    while la <= lat0 + dlat {
        let mut pts = Vec::new();
        let mut lo = lon0 - dlon;
        while lo <= lon0 + dlon {
            pts.push((la, lo));
            lo += dlon / 24.0;
        }
        out.push(Polyline { pts, kind: Kind::Border, closed: false });
        la += step;
    }

    let first_lon = (((lon0 - dlon) / step).ceil()) * step;
    let mut lo = first_lon;
    while lo <= lon0 + dlon {
        let mut pts = Vec::new();
        let mut la = lat0 - dlat;
        while la <= lat0 + dlat {
            pts.push((la, lo));
            la += dlat / 24.0;
        }
        out.push(Polyline { pts, kind: Kind::Border, closed: false });
        lo += step;
    }
    (out, step)
}

/// Where to get real geography, shown in the UI so the answer travels with
/// the program rather than living in a chat log.
pub const MAP_HELP: &str = "\
Sweep draws whatever GeoJSON it finds in the map/ folder next to the \
executable. Nothing is bundled, because an outline drawn from memory would \
put aircraft over the wrong side of a shoreline.

Natural Earth publishes what you want, free and public domain, at \
naturalearthdata.com — or as ready-made GeoJSON in the nvkelso/\
natural-earth-vector repository on GitHub, under geojson/.

Two files cover most of it:
  ne_50m_coastline.geojson
  ne_50m_admin_1_states_provinces_lines.geojson

Drop them in map/ and press Reload. Use the 10m versions instead if you \
want finer detail close in; they are larger but load once.";
