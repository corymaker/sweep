//! Line-art icons drawn as vector strokes.
//!
//! Deliberately not font glyphs: egui's bundled fonts have patchy emoji
//! coverage, so anything past the basic symbol blocks risks rendering as an
//! empty box on some machines. Drawing them means they look identical
//! everywhere and scale cleanly.

use eframe::egui;

#[derive(Clone, Copy, PartialEq)]
pub enum Icon {
    Radio,
    Aircraft,
    Anchor,
    Cloud,
    Antenna,
    Waves,
    Walkie,
    Truck,
    Train,
    Key,
    Scanner,
    Star,
    Speaker,
    Drone,
}

/// Draws `icon` centred in `rect`, sized to fit.
pub fn draw(p: &egui::Painter, rect: egui::Rect, icon: Icon, color: egui::Color32) {
    let c = rect.center();
    let s = rect.width().min(rect.height()) * 0.5; // half-extent
    let st = egui::Stroke::new((s * 0.15).max(1.9), color);
    let pt = |dx: f32, dy: f32| egui::pos2(c.x + dx * s, c.y + dy * s);
    let line = |a: (f32, f32), b: (f32, f32)| {
        p.line_segment([pt(a.0, a.1), pt(b.0, b.1)], st);
    };
    let poly = |v: &[(f32, f32)]| {
        for w in v.windows(2) {
            p.line_segment([pt(w[0].0, w[0].1), pt(w[1].0, w[1].1)], st);
        }
    };
    // A concentric-arc "broadcast" motif, reused by several icons.
    let arcs = |cx: f32, cy: f32, n: usize| {
        for i in 1..=n {
            let r = s * 0.28 * i as f32;
            let mut prev: Option<egui::Pos2> = None;
            let steps = 14;
            for k in 0..=steps {
                let a = -std::f32::consts::PI * 0.85 + std::f32::consts::PI * 0.7 * k as f32 / steps as f32;
                let q = egui::pos2(c.x + cx * s + a.cos() * r, c.y + cy * s + a.sin() * r);
                if let Some(pv) = prev {
                    p.line_segment([pv, q], st);
                }
                prev = Some(q);
            }
        }
    };

    match icon {
        Icon::Radio => {
            // A dot with broadcast arcs above it.
            p.circle_filled(pt(0.0, 0.45), s * 0.13, color);
            arcs(0.0, 0.45, 3);
        }
        Icon::Aircraft => {
            // Plan view: fuselage, swept wings, tailplane.
            line((0.0, -0.85), (0.0, 0.85));
            poly(&[(-0.85, 0.15), (0.0, -0.2), (0.85, 0.15)]);
            poly(&[(-0.35, 0.8), (0.0, 0.6), (0.35, 0.8)]);
        }
        Icon::Anchor => {
            p.circle_stroke(pt(0.0, -0.6), s * 0.18, st);
            line((0.0, -0.42), (0.0, 0.7));
            line((-0.45, -0.1), (0.45, -0.1));
            // Flukes.
            poly(&[(-0.7, 0.25), (-0.55, 0.6), (0.0, 0.8)]);
            poly(&[(0.7, 0.25), (0.55, 0.6), (0.0, 0.8)]);
        }
        Icon::Cloud => {
            p.circle_stroke(pt(-0.3, -0.1), s * 0.32, st);
            p.circle_stroke(pt(0.25, -0.15), s * 0.38, st);
            line((-0.6, 0.2), (0.6, 0.2));
            // Rain.
            line((-0.35, 0.45), (-0.45, 0.75));
            line((0.05, 0.45), (-0.05, 0.75));
            line((0.45, 0.45), (0.35, 0.75));
        }
        Icon::Antenna => {
            // Mast with cross elements — a yagi seen side-on.
            line((0.0, -0.85), (0.0, 0.85));
            line((-0.5, -0.5), (0.5, -0.5));
            line((-0.65, -0.1), (0.65, -0.1));
            line((-0.4, 0.3), (0.4, 0.3));
        }
        Icon::Waves => {
            p.circle_filled(c, s * 0.13, color);
            for i in 1..=3 {
                p.circle_stroke(c, s * 0.28 * i as f32, st);
            }
        }
        Icon::Walkie => {
            // Handheld body with a stub antenna.
            p.rect_stroke(
                egui::Rect::from_min_max(pt(-0.4, -0.35), pt(0.4, 0.85)),
                egui::Rounding::same(s * 0.14),
                st,
            );
            line((0.2, -0.35), (0.45, -0.85));
            line((-0.2, 0.0), (0.2, 0.0));
        }
        Icon::Truck => {
            p.rect_stroke(
                egui::Rect::from_min_max(pt(-0.85, -0.35), pt(0.15, 0.4)),
                egui::Rounding::ZERO,
                st,
            );
            poly(&[(0.15, -0.05), (0.55, -0.05), (0.85, 0.4), (0.15, 0.4)]);
            p.circle_stroke(pt(-0.5, 0.6), s * 0.2, st);
            p.circle_stroke(pt(0.5, 0.6), s * 0.2, st);
        }
        Icon::Train => {
            p.rect_stroke(
                egui::Rect::from_min_max(pt(-0.6, -0.7), pt(0.6, 0.45)),
                egui::Rounding::same(s * 0.12),
                st,
            );
            line((-0.6, -0.1), (0.6, -0.1));
            p.circle_stroke(pt(-0.3, 0.68), s * 0.16, st);
            p.circle_stroke(pt(0.3, 0.68), s * 0.16, st);
        }
        Icon::Key => {
            p.circle_stroke(pt(-0.4, -0.2), s * 0.3, st);
            line((-0.18, 0.0), (0.75, 0.7));
            line((0.45, 0.4), (0.62, 0.24));
            line((0.62, 0.57), (0.78, 0.42));
        }
        Icon::Scanner => {
            // A spectrum trace inside a frame.
            p.rect_stroke(
                egui::Rect::from_min_max(pt(-0.85, -0.6), pt(0.85, 0.6)),
                egui::Rounding::same(s * 0.1),
                st,
            );
            poly(&[
                (-0.6, 0.3), (-0.4, 0.3), (-0.3, -0.2), (-0.15, 0.3),
                (0.05, 0.3), (0.2, -0.35), (0.35, 0.3), (0.6, 0.3),
            ]);
        }
        Icon::Star => {
            let mut v = Vec::new();
            for i in 0..11 {
                let a = -std::f32::consts::FRAC_PI_2
                    + i as f32 * std::f32::consts::PI / 5.0;
                let r = if i % 2 == 0 { 0.85 } else { 0.38 };
                v.push((a.cos() * r, a.sin() * r));
            }
            poly(&v);
        }
        Icon::Speaker => {
            poly(&[(-0.75, -0.25), (-0.35, -0.25), (0.05, -0.75), (0.05, 0.75), (-0.35, 0.25), (-0.75, 0.25), (-0.75, -0.25)]);
            arcs(0.15, 0.0, 2);
        }
        Icon::Drone => {
            // Four arms from a body, with a rotor disc at each corner.
            line((-0.8, -0.8), (-0.25, -0.25));
            line((0.8, -0.8), (0.25, -0.25));
            line((-0.8, 0.8), (-0.25, 0.25));
            line((0.8, 0.8), (0.25, 0.25));
            p.rect_stroke(
                egui::Rect::from_min_max(pt(-0.3, -0.3), pt(0.3, 0.3)),
                egui::Rounding::same(s * 0.12),
                st,
            );
            for (dx, dy) in [(-0.8, -0.8), (0.8, -0.8), (-0.8, 0.8), (0.8, 0.8)] {
                p.circle_stroke(pt(dx, dy), s * 0.22, st);
            }
        }
    }
}
