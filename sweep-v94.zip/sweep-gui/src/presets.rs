//! Curated "things worth listening to" — the stuff people actually go
//! looking for, pre-loaded so you don't have to hunt for frequencies.
//!
//! Everything here is receivable on an RTL-SDR V4 without direct sampling,
//! i.e. above about 24 MHz. HF material (shortwave broadcast, WEFAX, number
//! stations, ham HF SSB) is deliberately absent — it needs direct-sampling
//! mode, which isn't wired up yet, so listing it would just be a set of
//! frequencies that produce silence.
//!
//! Where something is regional or defunct, the note says so rather than
//! leaving you to wonder why nothing is there.

pub struct Preset {
    pub name: &'static str,
    pub freq_mhz: f64,
    pub mode: &'static str,
    /// What you'd actually hear, and anything that affects whether you can
    /// hear it at all.
    pub note: &'static str,
}

pub struct PresetGroup {
    pub title: &'static str,
    pub presets: &'static [Preset],
}

pub const GROUPS: &[PresetGroup] = &[
    PresetGroup {
        title: "Signal hunting",
        presets: &[
            Preset {
                name: "Hydrogen line (radio astronomy)",
                freq_mhz: 1420.406,
                mode: "NFM",
                note: "Neutral hydrogen in our own galaxy — genuinely receivable on this dongle, but it needs a dish or horn antenna and long integration. Won't show on a whip.",
            },
            Preset {
                name: "GPS L1",
                freq_mhz: 1575.42,
                mode: "NFM",
                note: "Satellite navigation. Below the noise floor by design — you'll see a faint wideband rise, not a peak. Decoding needs a full GNSS receiver.",
            },
            Preset {
                name: "Radiosonde (400-406 band)",
                freq_mhz: 403.000,
                mode: "NFM",
                note: "Weather balloons, launched around 00:00 and 12:00 UTC. Carrier is audible during a flight; decoding the telemetry needs a sonde decoder.",
            },
            Preset {
                name: "800 MHz control channel",
                freq_mhz: 851.0125,
                mode: "NFM",
                note: "Trunked system control channels sound like a constant data buzz. Following the voice traffic needs a trunk-tracking decoder, which isn't built.",
            },
            Preset {
                name: "900 MHz ISM",
                freq_mhz: 915.000,
                mode: "NFM",
                note: "Smart meters, industrial telemetry, sensors. Busy almost everywhere — a good band for spotting unidentified digital bursts on the waterfall.",
            },
            Preset {
                name: "VOR navaid",
                freq_mhz: 113.000,
                mode: "AM",
                note: "Aviation navigation beacons — a steady tone plus a Morse identifier every few seconds. Receivable well past 100 km since they're high-power and line-of-sight.",
            },
        ],
    },
    PresetGroup {
        title: "Satellites & space",
        presets: &[
            Preset {
                name: "ISS voice downlink",
                freq_mhz: 145.800,
                mode: "NFM",
                note: "Astronaut voice contacts and school events. Only during a pass, and only when a contact is actually scheduled — usually silent.",
            },
            Preset {
                name: "ISS APRS digipeater",
                freq_mhz: 145.825,
                mode: "NFM",
                note: "Packet bursts relayed by the ISS. Sounds like short data chirps. Needs a pass overhead.",
            },
            Preset {
                name: "SO-50 amateur satellite",
                freq_mhz: 436.795,
                mode: "NFM",
                note: "A working FM repeater in orbit — hams talking through it. Doppler shifts the frequency several kHz across a pass.",
            },
            Preset {
                name: "NOAA 18 (APT, dead)",
                freq_mhz: 137.9125,
                mode: "NFM",
                note: "Weather satellite image downlink. NOAA shut the APT service down in 2025 — this is here for completeness, nothing transmits on it now.",
            },
        ],
    },
    PresetGroup {
        title: "Aviation",
        presets: &[
            Preset {
                name: "Airband emergency (guard)",
                freq_mhz: 121.500,
                mode: "AM",
                note: "International aviation distress. Quiet by design — occasional tests and misdirected calls.",
            },
            Preset {
                name: "UNICOM (uncontrolled fields)",
                freq_mhz: 122.800,
                mode: "AM",
                note: "Pilots at small airports announcing position and intentions. Busy near any general-aviation field.",
            },
            Preset {
                name: "Toronto Pearson ATIS",
                freq_mhz: 133.100,
                mode: "AM",
                note: "Looping recorded airport weather and runway info. Continuous, so it's a good test signal — if you can hear this, your airband setup works.",
            },
        ],
    },
    PresetGroup {
        title: "Marine & weather",
        presets: &[
            Preset {
                name: "Marine Ch 16 (distress)",
                freq_mhz: 156.800,
                mode: "NFM",
                note: "International hailing and distress. The busiest marine channel near any waterway.",
            },
            Preset {
                name: "Marine Ch 13 (bridge-to-bridge)",
                freq_mhz: 156.650,
                mode: "NFM",
                note: "Ship-to-ship navigation safety. Active around commercial shipping.",
            },
            Preset {
                name: "AIS ship transponders A",
                freq_mhz: 161.975,
                mode: "NFM",
                note: "Ship position beacons — data, not voice. Sounds like rapid chirping; decoding it needs an AIS decoder (not built yet).",
            },
            Preset {
                name: "Weatheradio Canada (dead)",
                freq_mhz: 162.475,
                mode: "NFM",
                note: "Environment Canada decommissioned the whole network on 31 March 2026. US NOAA stations still run, so this may work near the border.",
            },
        ],
    },
    PresetGroup {
        title: "Amateur radio",
        presets: &[
            Preset {
                name: "2m FM calling",
                freq_mhz: 146.520,
                mode: "NFM",
                note: "The national simplex calling frequency — hams making initial contact before moving off.",
            },
            Preset {
                name: "70cm FM calling",
                freq_mhz: 446.000,
                mode: "NFM",
                note: "The 70cm equivalent of 146.520.",
            },
            Preset {
                name: "APRS packet",
                freq_mhz: 144.390,
                mode: "NFM",
                note: "Position and weather beacons from stations and vehicles. Constant short data bursts in populated areas.",
            },
            Preset {
                name: "2m SSB calling",
                freq_mhz: 144.200,
                mode: "USB",
                note: "Weak-signal SSB work. A good way to test the USB demodulator on something reachable without HF.",
            },
        ],
    },
    PresetGroup {
        title: "Everyday radio",
        presets: &[
            Preset {
                name: "FRS/GMRS Ch 1",
                freq_mhz: 462.5625,
                mode: "NFM",
                note: "Consumer walkie-talkies — families at parks, stores, ski hills. Often the easiest real voice traffic to find.",
            },
            Preset {
                name: "GMRS repeater output",
                freq_mhz: 462.675,
                mode: "NFM",
                note: "GMRS Ch 20, commonly used as a repeater output and for travel/emergency chat.",
            },
            Preset {
                name: "CB Ch 19 (truckers)",
                freq_mhz: 27.185,
                mode: "AM",
                note: "The classic highway channel. Best near a major road; propagation opens up dramatically during solar peaks.",
            },
            Preset {
                name: "CB Ch 9 (emergency)",
                freq_mhz: 27.065,
                mode: "AM",
                note: "Traditional CB emergency channel.",
            },
        ],
    },
    PresetGroup {
        title: "Oddities",
        presets: &[
            Preset {
                name: "ISM 433 devices",
                freq_mhz: 433.920,
                mode: "NFM",
                note: "Garage remotes, weather sensors, tyre monitors, doorbells. Short bursts whenever a neighbour presses something.",
            },
            Preset {
                name: "Wireless sensors 915",
                freq_mhz: 915.000,
                mode: "NFM",
                note: "North American ISM band — smart meters, sensors, telemetry. Data bursts, not voice.",
            },
            Preset {
                name: "Radiosonde (weather balloon)",
                freq_mhz: 403.000,
                mode: "NFM",
                note: "Balloons launched twice daily by weather services, telemetering upward. Decoding needs a sonde decoder (not built yet), but the carrier is audible during a flight.",
            },
        ],
    },
];
