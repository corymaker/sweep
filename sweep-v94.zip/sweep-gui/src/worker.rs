//! The GUI never touches the dongle directly. This thread owns it, runs the
//! same plan → scheduler → spectrum/demod pipeline as `sweep-rtl`'s `scan`
//! example, and reports over a channel instead of printing to a terminal.
//!
//! One command channel lets the UI swap the running plan (a typed band name
//! or frequency) without restarting the thread or losing the open device.

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use rustfft::num_complex::Complex32;
use std::collections::{HashMap, VecDeque};
use std::fs::File;
use std::io::{BufWriter, Write};
use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

use sweep_core::adsb::{AdsbDemod, AircraftTable, ADSB_FREQ_HZ, ADSB_RATE};
use sweep_core::ais::{AisDemod, VesselTable, AIS_A_HZ, AIS_B_HZ};
use sweep_core::aprs::{Afsk1200, StationTable, APRS_HZ};
use sweep_core::acars::{AcarsDemod, AcarsLog, ACARS_HZ};
use sweep_core::sstv::{Event as SstvEvent, SstvDecoder};
use sweep_core::demod::{AmChannel, CwChannel, Discriminator, EnvelopeDetector, LowpassDecimator, NfmChannel, SsbChannel};
use sweep_core::detect::{Detector, NoiseFloor, Squelch, SquelchState};
use sweep_core::drone::{self, BandMap, Stare};
use sweep_core::ism::{self, BurstDetector};
use sweep_core::pocsag::{self, PagerChannel, Reading};
use sweep_core::plan::Demod;
use sweep_core::rds::RdsDecoder;
use sweep_core::resolve::resolve;
use sweep_core::rules;
use sweep_core::scheduler::{Mode as SchedMode, Scheduler, Task};
use sweep_core::source::{IqSource, TunerGain};
use sweep_core::spectrum::{Integrator, Spectrum};
use sweep_core::voice::VoiceDetector;
use sweep_rtl::{DirectSampling, RtlSdr};

pub const IF_RATE: u32 = 2_400_000;
pub const FFT_N: usize = 1024;
const INTEGRATE_FRAMES: u32 = 4;
const READ_CHUNK: usize = 32768;

/// RF gain for the drone survey, in tenths of a dB.
///
/// Fixed, not AGC, and that is the whole point. A band map is a comparison
/// between one frequency and another; with tuner AGC running, each window
/// gets a different amount of gain depending on what happened to be in it,
/// and the levels across the band stop meaning anything relative to each
/// other. A middle setting on the R828D gives enough sensitivity for the
/// ISM bands without folding a strong pager or FM station back in. The RF
/// GAIN control still overrides it.
const DRONE_GAIN: i32 = 300;

/// Guard band blanked around the receiver's DC spur, in Hz.
///
/// The spur sits at the centre of every tuner window and would otherwise be
/// written into the band map as a signal once per window, right across the
/// band. It is blanked to a non-finite level rather than to a floor value,
/// because `BandMap::ingest` treats non-finite as "no measurement here" and
/// skips it — recording it as *quiet* instead would punch a hole through
/// any wide carrier and split it into fragments.
///
/// Kept narrow (about thirteen bins) so it stays well inside
/// `sweep_core::drone::BRIDGE_BINS`, which is what lets a signature step
/// over the gap.
const DRONE_DC_GUARD_HZ: f64 = 12_000.0;

/// How far a parked measurement offsets the tuner from its target, in Hz.
///
/// A measurement is pointed at the strongest thing in sight; centring the
/// tuner on it would put the DC spur exactly on top of it, and the blanked
/// guard band would then delete the very signal being measured. Offsetting
/// keeps the target well clear of DC and still inside the usable 1.8 MHz.
const DRONE_STARE_OFFSET_HZ: f64 = 400_000.0;

/// How many groups each drone band is reduced to before being sent to the
/// UI. Comfortably more than a screen has pixels and small enough to send
/// twice a second.
const DRONE_PROFILE: usize = 1024;

/// Replace blanked bins with a level, for anything that has to draw them.
///
/// The band map wants the blanked DC guard left as "no measurement", but the
/// spectrum trace and waterfall colour-map an array of numbers and would
/// make nonsense of a negative infinity. Substituting the noise floor draws
/// the gap as quiet, which is wrong by a few pixels in one place and right
/// everywhere else — and the honest version of the gap is in the band map,
/// which is what the verdicts are computed from.
fn finite_for_display(src: &[f32], floor: f32) -> Vec<f32> {
    src.iter()
        .map(|v| if v.is_finite() { *v } else { floor })
        .collect()
}

/// Reduce a per-bin array to `out_n` groups. `take_max` is for levels (a
/// narrow carrier must survive the reduction, so a mean would hide it);
/// averaging is for the noise floor, where the mean is what is wanted.
/// Bins that have never been measured come back as `absent`.
fn profile(src: &[f32], out_n: usize, take_max: bool, absent: f32) -> Vec<f32> {
    if src.is_empty() || out_n == 0 {
        return Vec::new();
    }
    let n = out_n.min(src.len());
    let mut out = Vec::with_capacity(n);
    for g in 0..n {
        let a = g * src.len() / n;
        let b = (((g + 1) * src.len()) / n).max(a + 1).min(src.len());
        let mut acc = if take_max { f32::NEG_INFINITY } else { 0.0 };
        let mut count = 0u32;
        for &v in &src[a..b] {
            if !v.is_finite() {
                continue;
            }
            if take_max {
                if v > acc {
                    acc = v;
                }
            } else {
                acc += v;
            }
            count += 1;
        }
        out.push(if count == 0 {
            absent
        } else if take_max {
            acc
        } else {
            acc / count as f32
        });
    }
    out
}

/// What the worker tells the UI.
pub enum UiMsg {
    Device(DeviceStatus),
    Random(String), // hex string
    Rds {
        ps: String,
        radiotext: String,
        pty: Option<u8>,
    },
    PlanLoaded {
        name: String,
        windows: usize,
        channels: usize,
        single_window: bool,
    },
    PlanError(String),
    WindowTick {
        window: usize,
        windows: usize,
        center_mhz: f64,
    },
    Spectrum {
        bins: Vec<f32>,
        floor: Vec<f32>,
        center_hz: f64,
    },
    SignalFound {
        freq_mhz: f64,
        snr_db: f32,
        label: String,
    },
    SignalEnded,
    /// One refresh of the ADS-B picture. Sent a few times a second while
    /// the radio is parked on 1090 MHz, and not at all otherwise.
    Adsb {
        aircraft: Vec<AircraftView>,
        frames_ok: u64,
        frames_bad: u64,
        /// Verified frames per minute, averaged over the last while — the
        /// honest measure of how well the antenna is doing at 1090 MHz.
        frames_per_min: f32,
        /// Bursts that looked like a preamble, per second. Pure noise
        /// produces a steady few hundred of these and no valid frames; a
        /// real aircraft adds to the count AND produces frames. The two
        /// numbers together say whether nothing is arriving or whether
        /// something is arriving too weak to decode.
        preambles_per_s: f32,
        /// Mean and peak sample magnitude over the last capture, in dB
        /// relative to the ADC's full scale. Tells you whether the front
        /// end is seeing anything at all at 1090 MHz.
        mean_dbfs: f32,
        peak_dbfs: f32,
    },
    /// A slow-scan picture as it arrives, line by line. Sent while
    /// anything is being received and once more when it finishes.
    Sstv {
        width: usize,
        height: usize,
        rgb: Vec<u8>,
        lines_done: usize,
        mode: String,
    },
    /// Something happened on the SSTV channel that is worth saying out
    /// loud — a picture started, finished, or arrived in a mode this
    /// cannot decode.
    SstvEvent(String),
    /// One ACARS block, as it is decoded. Unlike the position decoders
    /// there is no picture to refresh — each message is an event, and the
    /// log is the point.
    AcarsBlock {
        when: String,
        registration: String,
        flight: Option<String>,
        label: String,
        label_text: &'static str,
        text: String,
        crc_ok: bool,
        more: bool,
    },
    /// Periodic ACARS counters and level.
    AcarsStatus {
        blocks: u64,
        bad_parity: u64,
        aircraft: usize,
        mean_dbfs: f32,
        peak_dbfs: f32,
        channel_hz: f64,
    },
    /// One refresh of the APRS picture, while parked on 144.390 MHz.
    Aprs {
        stations: Vec<StationView>,
        packets: u64,
        mean_dbfs: f32,
        peak_dbfs: f32,
    },
    /// One refresh of the AIS picture, while parked between the two
    /// marine data channels.
    Ais {
        vessels: Vec<VesselView>,
        frames_ok: u64,
        mean_dbfs: f32,
        peak_dbfs: f32,
    },
    /// One ISM burst, analysed. An event, like a page, so the log is the
    /// point. Everything here is measured from the signal — nothing is a
    /// device name or a sensor reading, because those cannot be known from
    /// the bits without a device database this does not have.
    IsmBurst {
        when: String,
        /// Line coding, as a word for the UI.
        coding: &'static str,
        /// The two timing clusters, microseconds — the fingerprint.
        short_us: f32,
        long_us: f32,
        bits: u32,
        /// Raw payload, hex. Empty when the coding could not be read.
        hex: String,
        /// A standard CRC-8 closes over the bytes — evidence the bits are
        /// right and it is a framed packet, not an identification.
        crc_ok: bool,
        /// How many times this exact packet repeated back to back.
        repeats: u32,
        /// Peak amplitude over the noise floor, dB.
        snr_db: f32,
    },
    /// Periodic ISM counters and level.
    IsmStatus {
        bursts: u64,
        decoded: u64,
        with_crc: u64,
        mean_dbfs: f32,
        peak_dbfs: f32,
        channel_hz: f64,
    },
    /// One decoded page. Like ACARS, each message is an event rather than
    /// a refresh of a picture, so the log is the point.
    PagerPage {
        when: String,
        /// The pager's address. All that identifies a recipient — there is
        /// no name in the protocol.
        ric: u32,
        func: u8,
        /// The reading to show. `None` for a tone-only page.
        text: Option<String>,
        numeric: String,
        /// Which reading the decoder believes, as a word for the UI.
        reading: &'static str,
        /// Both readings are plausible, so both should be shown.
        ambiguous: bool,
        codewords: u32,
        repaired_one: u32,
        repaired_two: u32,
        dropped: u32,
        baud: f32,
        inverted: bool,
    },
    /// Periodic paging counters and level.
    PagerStatus {
        pages: u64,
        syncs: u64,
        codewords_ok: u64,
        codewords_repaired: u64,
        codewords_dropped: u64,
        mean_dbfs: f32,
        peak_dbfs: f32,
        channel_hz: f64,
        /// Sync words seen per (baud, inverted) lane. The lane with a
        /// count is the one actually in use, which turns "nothing decoded"
        /// into a diagnosis instead of a shrug.
        lanes: Vec<(f32, bool, u64)>,
    },
    /// One refresh of the drone-band survey, while sweeping.
    DroneSweep {
        bands: Vec<DroneBandView>,
        signatures: Vec<DroneSigView>,
        /// Narrow bursts scattered across a band, when there are enough of
        /// them spread widely enough to be worth naming.
        hop: Option<String>,
        /// Where the tuner is right now, so the display can show the sweep
        /// walking across the band.
        scanning_mhz: f64,
        /// Seconds for one full pass of everything enabled. The honest
        /// answer to "how often does it look here".
        pass_secs: f32,
    },
    /// One refresh of a parked drone-band measurement.
    DroneStareMsg(DroneStareView),
    Listening {
        center_mhz: f64,
        label: String,
        snr_db: f32,
        audio_peak: f32,
    },
    Log(String),
}

/// One aircraft, flattened for the UI. The tracker's own `Aircraft` carries
/// `Instant`s and CPR state the display has no use for; this is just the
/// numbers, with ages already worked out.
#[derive(Clone)]
pub struct AircraftView {
    pub hex_id: String,
    pub callsign: Option<String>,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub alt_ft: Option<i32>,
    pub speed_kt: Option<f32>,
    pub heading_deg: Option<f32>,
    pub vert_rate_fpm: Option<i32>,
    pub rssi_db: f32,
    pub messages: u32,
    pub age_s: f32,
}

/// One vessel, flattened for the UI.
#[derive(Clone)]
pub struct VesselView {
    pub mmsi: u32,
    pub label: String,
    pub name: Option<String>,
    pub callsign: Option<String>,
    pub flag: &'static str,
    pub kind: &'static str,
    pub status: &'static str,
    pub destination: Option<String>,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub sog_kt: Option<f32>,
    pub cog_deg: Option<f32>,
    pub heading_deg: Option<f32>,
    pub class_b: bool,
    pub messages: u32,
    pub age_s: f32,
}

/// One APRS station, flattened for the UI.
#[derive(Clone)]
pub struct StationView {
    pub call: String,
    pub kind: &'static str,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub course_deg: Option<f32>,
    pub speed_kt: Option<f32>,
    pub altitude_ft: Option<i32>,
    pub comment: String,
    pub via: String,
    pub packets: u32,
    pub age_s: f32,
}

/// One drone band's accumulated picture, reduced for the display.
///
/// The underlying map has a bin every 2.34 kHz — 119,000 of them across the
/// 1.2 GHz band — which is far more than any screen can show and far too
/// much to send several times a second. These are max-held groups.
#[derive(Clone)]
pub struct DroneBandView {
    pub key: String,
    pub name: &'static str,
    pub f0_mhz: f64,
    pub f1_mhz: f64,
    /// Strongest level seen in each group, dBFS.
    pub peak: Vec<f32>,
    /// Noise estimate for each group, dBFS.
    pub floor: Vec<f32>,
    /// Fraction of looks in which each group was occupied, or -1 where the
    /// sweep has not looked often enough to say.
    pub occupancy: Vec<f32>,
    /// Completed passes across this band.
    pub passes: u32,
}

/// One run of occupied spectrum, flattened for the UI.
#[derive(Clone)]
pub struct DroneSigView {
    pub band_key: String,
    pub band_name: &'static str,
    pub center_mhz: f64,
    pub bw_khz: f64,
    pub peak_db: f32,
    pub snr_db: f32,
    pub occupancy: Option<f32>,
    pub looks: u32,
    pub kind: &'static str,
    pub verdict: &'static str,
    pub drone_shaped: bool,
}

/// What a parked measurement found. Unlike a sweep's verdict the timing
/// here is real — see `sweep_core::drone::Stare`.
#[derive(Clone)]
pub struct DroneStareView {
    pub center_mhz: f64,
    pub target_lo_mhz: f64,
    pub target_hi_mhz: f64,
    pub bw_khz: f64,
    /// True when the signal runs off an edge of the 1.8 MHz window, so
    /// `bw_khz` is a floor rather than a figure.
    pub bw_is_lower_bound: bool,
    pub duty: f32,
    pub burst_ms: Option<f32>,
    pub gap_ms: Option<f32>,
    pub rate_hz: Option<f32>,
    pub peak_mhz: Option<f64>,
    pub peak_db: f32,
    pub floor_db: f32,
    pub frames: u32,
    pub seconds: f32,
    pub kind: &'static str,
    pub verdict: &'static str,
}

pub enum DeviceStatus {
    Searching,
    Ready(String),
    Error(String),
}

/// What the UI tells the worker.
pub enum Cmd {
    /// Tune to a band or frequency. `mode`, when set, overrides the plan's
    /// default demodulation for every channel in it — this is what the
    /// mode buttons in the UI drive.
    Tune { utterance: String, mode: Option<Demod> },
    /// `None` = tuner AGC. `Some(tenths_db)` = manual gain, in tenths of a
    /// dB, as librtlsdr expects.
    SetGain(Option<i32>),
    /// Crystal frequency correction, in parts per million.
    SetPpm(i32),
    /// Powers an external LNA over the coax (RTL-SDR Blog V3/V4 boards).
    SetBiasTee(bool),
    /// Start/stop writing demodulated audio to a WAV file.
    SetRecordAudio(bool),
    /// Start/stop writing raw IQ to a `.cu8` file. This fills up fast —
    /// roughly 4.8 MB/s at the scanner's 2.4 MS/s capture rate.
    SetRecordIq(bool),
    /// When on, a locked signal is abandoned after a fixed dwell even if
    /// it's still transmitting — otherwise a continuously-transmitting
    /// station (broadcast FM, for instance) would hold the scanner forever
    /// since squelch never closes on its own.
    SetAutoScan(bool),
    /// Abandon whatever's currently locked and resume sweeping right now,
    /// regardless of auto-scan or squelch state.
    SkipSignal,
    /// Output volume multiplier. 1.0 = unity (whatever the demod chain
    /// actually produced); this only affects what reaches the speakers —
    /// recordings capture the unscaled signal regardless of this setting.
    SetVolume(f32),
    /// When on, a locked signal is dropped unless it turns out to be
    /// speech — so the scanner stops on people talking and walks past
    /// carriers, data bursts, and open-squelch noise.
    SetVoiceOnly(bool),
    /// Push a synthesized 1 kHz tone straight into the audio ring,
    /// bypassing the dongle, the demodulator, everything. If this sounds
    /// clean, the audio output path is fine and any static is coming from
    /// RF or demod. If this *also* sounds bad, the problem is the sound
    /// device path itself — sample rate, channel layout, or buffering —
    /// and no amount of DSP work will help.
    TestTone,
    /// Draw `n` bytes of whitened randomness from raw ADC noise — see
    /// `von_neumann_bytes` for the actual extraction.
    GenerateRandom(usize),
    /// Squelch threshold in dB over the noise floor. sweep-core validates
    /// this to 3-30 dB, so the UI clamps to that range.
    SetSquelch(f64),
    /// Alternate between tracking aircraft on 1090 MHz and scanning the
    /// aviation voice band.
    ///
    /// One dongle can only be on one frequency, so "both at once" is not
    /// available at any price. Taking turns is, and for this purpose it
    /// works: aircraft positions are still valid a few seconds after they
    /// arrive, and a voice transmission you miss was going to be missed
    /// anyway while the radio sat on 1090.
    SetTrackAndListen(bool),
    /// IF bandwidth override in kHz, or `None` to use each mode's default.
    /// Takes effect on the next retune, since the filter taps are built
    /// when a demod channel is constructed.
    SetBandwidthKhz(Option<f32>),
    /// Which of the reachable drone bands to include in the survey, by
    /// `sweep_core::drone::Band::key`. An empty list leaves the survey with
    /// nothing to do, so the worker refuses it and keeps the last set.
    DroneBands(Vec<String>),
    /// How far above the local noise a bin must sit to count as occupied,
    /// in dB. Clamped to 4-40.
    DroneSnr(f32),
    /// Park on one frequency range and measure it properly, or `None` to
    /// go back to sweeping.
    ///
    /// Sweeping and measuring are mutually exclusive on one dongle, and
    /// that is not a limitation worth hiding: a sweep revisits a frequency
    /// every few seconds, which is useless for timing a 5 ms packet, and a
    /// stare sees one 1.8 MHz window and nothing else in the band.
    DroneStare(Option<(f64, f64)>),
    /// Forget everything the survey has accumulated and start the picture
    /// again. Worth having as a button: a single strong transient leaves a
    /// mark that takes a while to decay on its own.
    DroneClear,
    /// Centre frequency for the ISM burst survey, in Hz. The two useful
    /// spots are 433.92 and 915 MHz; this is how the UI switches between
    /// them, or parks on anything else the person types.
    IsmTune(f64),
}

/// One demodulator, whichever kind the locked channel actually needs.
/// NFM/WFM and anything not yet implemented (USB/LSB/CW) fall back to the FM
/// chain — see the mode buttons in the UI, which grey those out rather than
/// claim they work.
/// A parallel tap on the same IQ a WFM audio channel is already
/// demodulating — RDS needs the *wideband* discriminator output (up to
/// ~60 kHz, to reach the 57 kHz subcarrier), not the narrow, de-emphasized
/// audio the normal chain produces, so this runs its own lighter-weight
/// discriminator rather than reusing NfmChannel.
struct RdsTap {
    wide: LowpassDecimator,
    disc: Discriminator,
    rds: RdsDecoder,
    scratch: Vec<Complex32>,
    scratch2: Vec<f32>,
}

impl RdsTap {
    fn new(if_rate: f32) -> Self {
        let mid_rate = 240_000.0_f32.min(if_rate);
        let factor = (if_rate / mid_rate).round().max(1.0) as usize;
        let actual_rate = if_rate / factor as f32;
        RdsTap {
            wide: LowpassDecimator::new(100_000.0, if_rate, factor, 63),
            disc: Discriminator::new(75_000.0, actual_rate),
            rds: RdsDecoder::new(actual_rate),
            scratch: Vec::new(),
            scratch2: Vec::new(),
        }
    }

    fn process(&mut self, iq: &[Complex32]) {
        self.scratch.clear();
        self.wide.process(iq, &mut self.scratch);
        self.scratch2.clear();
        self.disc.process(&self.scratch, &mut self.scratch2);
        self.rds.process(&self.scratch2);
    }
}


/// One AIS channel, from raw capture to decoded frames.
///
/// Both channels are received at once. They sit 50 kHz apart, and the
/// dongle's 2.4 MHz window covers that with room to spare, so the tuner
/// parks between them and each tap mixes its own channel down to baseband.
/// Listening to only one would halve what you hear, because ships alternate
/// between A and B on purpose.
///
/// Decimation is in two stages. One stage from 2.4 MS/s to 48 kHz would
/// need roughly 570 taps to keep the stopband clean, and running that at
/// the full capture rate costs more than the rest of this mode put
/// together; 10:1 then 5:1 does the same job for about a sixth of the
/// arithmetic.
struct AisTap {
    mixer: Mixer,
    stage1: LowpassDecimator,
    stage2: LowpassDecimator,
    disc: Discriminator,
    demod: AisDemod,
    a: Vec<Complex32>,
    b: Vec<Complex32>,
    audio: Vec<f32>,
}

impl AisTap {
    fn new(offset_hz: f32, if_rate: f32) -> Self {
        AisTap {
            mixer: Mixer::new(offset_hz, if_rate),
            stage1: LowpassDecimator::new(90_000.0, if_rate, 10, 81),
            stage2: LowpassDecimator::new(10_000.0, if_rate / 10.0, 5, 63),
            // AIS deviation is ±2400 Hz. The discriminator only needs to
            // scale the result sensibly — the bit slicer cares about sign,
            // not amplitude.
            disc: Discriminator::new(2_400.0, if_rate / 50.0),
            demod: AisDemod::new(if_rate / 50.0),
            a: Vec::new(),
            b: Vec::new(),
            audio: Vec::new(),
        }
    }

    fn process(&mut self, iq: &[Complex32], out: &mut Vec<sweep_core::ais::Frame>) {
        self.a.clear();
        self.a.extend_from_slice(iq);
        self.mixer.shift(&mut self.a);
        self.b.clear();
        self.stage1.process(&self.a, &mut self.b);
        self.a.clear();
        self.stage2.process(&self.b, &mut self.a);
        self.audio.clear();
        self.disc.process(&self.a, &mut self.audio);
        self.demod.process(&self.audio, out);
    }
}

/// APRS: one narrow FM channel, demodulated to audio and handed to a Bell
/// 202 modem.
///
/// Unlike AIS this is an ordinary voice-bandwidth FM signal — the same
/// chain any handheld uses — so the only unusual part is that the audio
/// goes to a modem instead of a speaker.
struct AprsTap {
    mixer: Mixer,
    stage1: LowpassDecimator,
    stage2: LowpassDecimator,
    disc: Discriminator,
    modem: Afsk1200,
    a: Vec<Complex32>,
    b: Vec<Complex32>,
    audio: Vec<f32>,
}

/// Paging channel tap: 25 kHz NFM down to a discriminator output, then
/// every bit rate and polarity at once.
///
/// Wider than the APRS tap on purpose. POCSAG channels are 25 kHz with
/// ±4.5 kHz deviation, against APRS's 12.5 kHz and ±3 kHz, so the
/// discriminator needs the headroom or the peaks clip and the slicer sees a
/// squared-off waveform with its zero crossings in the wrong places.
struct PagerTap {
    mixer: Mixer,
    stage1: LowpassDecimator,
    stage2: LowpassDecimator,
    disc: Discriminator,
    channel: PagerChannel,
    a: Vec<Complex32>,
    b: Vec<Complex32>,
    audio: Vec<f32>,
}

impl PagerTap {
    fn new(offset_hz: f32, if_rate: f32) -> Self {
        let audio_rate = if_rate / 50.0;
        PagerTap {
            mixer: Mixer::new(offset_hz, if_rate),
            stage1: LowpassDecimator::new(20_000.0, if_rate, 10, 81),
            // 10 kHz passes the whole occupied bandwidth of a 2400 baud
            // channel — about 11 kHz — while still rejecting the next
            // channel 25 kHz away.
            stage2: LowpassDecimator::new(10_000.0, if_rate / 10.0, 5, 63),
            disc: Discriminator::new(6_000.0, audio_rate),
            channel: PagerChannel::new(audio_rate),
            a: Vec::new(),
            b: Vec::new(),
            audio: Vec::new(),
        }
    }

    fn process(&mut self, iq: &[Complex32], out: &mut Vec<pocsag::Page>) {
        self.a.clear();
        self.a.extend_from_slice(iq);
        self.mixer.shift(&mut self.a);
        self.b.clear();
        self.stage1.process(&self.a, &mut self.b);
        self.a.clear();
        self.stage2.process(&self.b, &mut self.a);
        self.audio.clear();
        self.disc.process(&self.a, &mut self.audio);
        self.channel.process(&self.audio, &mut |p| out.push(p));
    }

    fn audio(&self) -> &[f32] {
        &self.audio
    }
}

/// ISM burst tap: an AM envelope at a modest rate, feeding the OOK burst
/// detector.
///
/// Wide on purpose. OOK devices do not sit on an exact channel and their
/// pulses have fast edges, so the chain keeps a wide passband — about
/// 120 kHz — and does not try to be a narrow receiver. The output is sample
/// *magnitude*, which is what on-off keying lives in; the burst detector
/// reads presence and absence of energy from it.
struct IsmTap {
    stage1: LowpassDecimator,
    rate: f32,
    mag: Vec<f32>,
    b: Vec<Complex32>,
}

impl IsmTap {
    /// Decimate by 10, to 240 kHz — fine enough to measure a 100 µs pulse
    /// to a few percent, coarse enough that a burst is a few thousand
    /// samples rather than tens of thousands.
    const DECIM: usize = 10;

    fn new(if_rate: f32) -> Self {
        IsmTap {
            stage1: LowpassDecimator::new(120_000.0, if_rate, Self::DECIM, 63),
            rate: if_rate / Self::DECIM as f32,
            mag: Vec::new(),
            b: Vec::new(),
        }
    }

    fn rate(&self) -> f32 {
        self.rate
    }

    /// Decimate, then take magnitude. The caller feeds the magnitude to a
    /// `BurstDetector`.
    fn process(&mut self, iq: &[Complex32]) -> &[f32] {
        self.b.clear();
        self.stage1.process(iq, &mut self.b);
        self.mag.clear();
        self.mag.extend(self.b.iter().map(|c| (c.re * c.re + c.im * c.im).sqrt()));
        &self.mag
    }
}

impl AprsTap {
    fn new(offset_hz: f32, if_rate: f32) -> Self {
        AprsTap {
            mixer: Mixer::new(offset_hz, if_rate),
            stage1: LowpassDecimator::new(20_000.0, if_rate, 10, 81),
            stage2: LowpassDecimator::new(7_500.0, if_rate / 10.0, 5, 63),
            disc: Discriminator::new(3_000.0, if_rate / 50.0),
            modem: Afsk1200::new(if_rate / 50.0),
            a: Vec::new(),
            b: Vec::new(),
            audio: Vec::new(),
        }
    }

    fn process(&mut self, iq: &[Complex32], out: &mut Vec<sweep_core::aprs::Frame>) {
        self.a.clear();
        self.a.extend_from_slice(iq);
        self.mixer.shift(&mut self.a);
        self.b.clear();
        self.stage1.process(&self.a, &mut self.b);
        self.a.clear();
        self.stage2.process(&self.b, &mut self.a);
        self.audio.clear();
        self.disc.process(&self.a, &mut self.audio);
        self.modem.process(&self.audio, out);
    }

    /// The demodulated audio, so the packet channel can be listened to as
    /// well as decoded — APRS bursts are a distinctive sound and hearing
    /// them is the quickest confirmation the radio is on the right spot.
    fn audio(&self) -> &[f32] {
        &self.audio
    }
}

/// ACARS: one AM channel, envelope-detected and handed to a 2400-baud
/// modem.
///
/// The only decoder here whose front end is an envelope detector rather
/// than a discriminator — aviation uses AM, for the same reason the voice
/// band does: two aircraft transmitting at once produce a heterodyne you
/// can hear, rather than one of them capturing the receiver and the other
/// vanishing.
struct AcarsTap {
    mixer: Mixer,
    stage1: LowpassDecimator,
    stage2: LowpassDecimator,
    env: EnvelopeDetector,
    demod: AcarsDemod,
    a: Vec<Complex32>,
    b: Vec<Complex32>,
    audio: Vec<f32>,
}

impl AcarsTap {
    fn new(offset_hz: f32, if_rate: f32) -> Self {
        AcarsTap {
            mixer: Mixer::new(offset_hz, if_rate),
            stage1: LowpassDecimator::new(20_000.0, if_rate, 10, 81),
            // An ACARS channel is about 8 kHz wide; filtering tighter than
            // that costs nothing and keeps the neighbours out.
            stage2: LowpassDecimator::new(5_000.0, if_rate / 10.0, 5, 63),
            env: EnvelopeDetector::new(if_rate / 50.0),
            demod: AcarsDemod::new(if_rate / 50.0),
            a: Vec::new(),
            b: Vec::new(),
            audio: Vec::new(),
        }
    }

    fn process(&mut self, iq: &[Complex32], out: &mut Vec<sweep_core::acars::Block>) {
        self.a.clear();
        self.a.extend_from_slice(iq);
        self.mixer.shift(&mut self.a);
        self.b.clear();
        self.stage1.process(&self.a, &mut self.b);
        self.a.clear();
        self.stage2.process(&self.b, &mut self.a);
        self.audio.clear();
        self.env.process(&self.a, &mut self.audio);
        self.demod.process(&self.audio, out);
    }

    fn audio(&self) -> &[f32] {
        &self.audio
    }
}

/// Shifts a signal that sits at some offset from the tuner's centre down to
/// baseband.
///
/// This is not optional plumbing. `avoid_dc` in sweep-core deliberately
/// parks the tuner at least 30 kHz away from any channel, so the dongle's
/// DC spike never lands on a signal — which means the channel you actually
/// want is never at baseband. The demod chain's first stage is a lowpass
/// centred on zero, so without this shift it demodulates the empty gap the
/// tuner is pointed at instead of the station, which sounds like static
/// with a hint of the real signal bleeding through.
///
/// Phase is kept across calls: restarting it every buffer would put a
/// discontinuity into the signal at every block boundary.
struct Mixer {
    /// Current oscillator phasor and the per-sample rotation applied to it.
    ///
    /// Stepping by complex multiply rather than calling sin_cos per sample
    /// matters a lot here: this runs at the full 2.4 MS/s capture rate, and
    /// transcendental calls at that rate were a significant part of why the
    /// worker struggled to stay ahead of real time — which the audio buffer
    /// then paid for in dropouts.
    phasor: Complex32,
    step: Complex32,
    offset: f32,
    /// Rounding walks the phasor off the unit circle over millions of
    /// steps, so renormalise periodically.
    since_norm: u32,
}

impl Mixer {
    fn new(offset_hz: f32, sample_rate: f32) -> Self {
        // Negative: to bring a signal sitting *above* centre down to zero,
        // rotate the opposite way.
        let w = -std::f32::consts::TAU * offset_hz / sample_rate;
        Mixer {
            phasor: Complex32::new(1.0, 0.0),
            step: Complex32::new(w.cos(), w.sin()),
            offset: offset_hz,
            since_norm: 0,
        }
    }

    fn offset_hz(&self, _sample_rate: f32) -> f32 {
        self.offset
    }

    fn shift(&mut self, iq: &mut Vec<Complex32>) {
        for s in iq.iter_mut() {
            *s *= self.phasor;
            self.phasor *= self.step;
            self.since_norm += 1;
            if self.since_norm >= 4096 {
                self.since_norm = 0;
                let m = (self.phasor.re * self.phasor.re
                    + self.phasor.im * self.phasor.im)
                    .sqrt();
                if m > 1e-6 {
                    self.phasor /= m;
                }
            }
        }
    }
}

enum AnyChannel {
    Nfm(NfmChannel),
    Am(AmChannel),
    Ssb(SsbChannel),
    Cw(CwChannel),
}

impl AnyChannel {
    fn new(demod: Demod, if_rate: f32, audio_rate: f32, bw_hz: f32) -> Self {
        match demod {
            Demod::Am => AnyChannel::Am(AmChannel::new(if_rate, audio_rate, bw_hz)),
            Demod::Wfm => AnyChannel::Nfm(
                NfmChannel::new(if_rate, audio_rate, bw_hz, 75_000.0)
                    .with_deemphasis_us(75.0, audio_rate),
            ),
            Demod::Usb => AnyChannel::Ssb(SsbChannel::new(if_rate, audio_rate, bw_hz, true)),
            Demod::Lsb => AnyChannel::Ssb(SsbChannel::new(if_rate, audio_rate, bw_hz, false)),
            Demod::Cw => AnyChannel::Cw(CwChannel::new(if_rate, audio_rate, bw_hz, 700.0)),
            _ => AnyChannel::Nfm(NfmChannel::new(if_rate, audio_rate, bw_hz, 2_500.0)),
        }
    }

    fn process(&mut self, iq: &[Complex32], out: &mut Vec<f32>) {
        match self {
            AnyChannel::Nfm(c) => c.process(iq, out),
            AnyChannel::Am(c) => c.process(iq, out),
            AnyChannel::Ssb(c) => c.process(iq, out),
            AnyChannel::Cw(c) => c.process(iq, out),
        }
    }
}

pub fn spawn_worker(initial: String) -> (Receiver<UiMsg>, Sender<Cmd>) {
    let (ui_tx, ui_rx) = mpsc::channel();
    let (cmd_tx, cmd_rx) = mpsc::channel();
    thread::spawn(move || run(initial, ui_tx, cmd_rx));
    (ui_rx, cmd_tx)
}

/// Per-window detection state — one `NoiseFloor` per tuner window, same
/// reasoning as `scan.rs`: a busy repeater sub-band and a quiet aircraft
/// sub-band are not equally loud, and sharing history would poison both.
struct WindowWatch {
    floor: NoiseFloor,
    integ: Integrator,
    last_spectrum: Vec<f32>,
}

impl WindowWatch {
    fn new() -> Self {
        WindowWatch {
            floor: NoiseFloor::new(FFT_N),
            integ: Integrator::new(FFT_N, INTEGRATE_FRAMES),
            last_spectrum: vec![-140.0; FFT_N],
        }
    }
}

/// Local time of day, for stamping a message log. Only the clock face is
/// wanted here, not a date.
fn clock_time() -> String {
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let t = secs % 86_400;
    format!("{:02}:{:02}:{:02}", t / 3600, (t % 3600) / 60, t % 60)
}

fn timestamp() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

/// One analysed ISM burst, before repeat-grouping.
struct IsmEvent {
    coding: &'static str,
    short_us: f32,
    long_us: f32,
    bits: u32,
    hex: String,
    crc_ok: bool,
    snr_db: f32,
}

/// A burst being held to see whether the device repeats it. ISM devices
/// almost always send a packet several times in a row, and logging each
/// copy would bury the one real event under its own echoes.
struct PendingBurst {
    ev: IsmEvent,
    repeats: u32,
    since: std::time::Instant,
}

/// Fold an identical consecutive packet into the pending one, or flush the
/// pending and start a new group. A packet with no bits (energy only) never
/// matches, so each is its own event.
fn emit_ism(ui_tx: &Sender<UiMsg>, pending: &mut Option<PendingBurst>, ev: IsmEvent) {
    if let Some(p) = pending.as_mut() {
        if !ev.hex.is_empty() && p.ev.hex == ev.hex {
            p.repeats += 1;
            p.since = std::time::Instant::now();
            return;
        }
        flush_ism(ui_tx, pending);
    }
    *pending = Some(PendingBurst {
        ev,
        repeats: 1,
        since: std::time::Instant::now(),
    });
}

/// Send a held burst to the UI, with its repeat count.
fn flush_ism(ui_tx: &Sender<UiMsg>, pending: &mut Option<PendingBurst>) {
    if let Some(p) = pending.take() {
        let _ = ui_tx.send(UiMsg::IsmBurst {
            when: clock_time(),
            coding: p.ev.coding,
            short_us: p.ev.short_us,
            long_us: p.ev.long_us,
            bits: p.ev.bits,
            hex: p.ev.hex,
            crc_ok: p.ev.crc_ok,
            repeats: p.repeats,
            snr_db: p.ev.snr_db,
        });
    }
}

/// Opens a new timestamped WAV file in `recordings/` (created if missing),
/// mono 16-bit at the audio pipeline's own sample rate.
fn start_audio_writer(audio_rate: f32) -> Result<(hound::WavWriter<BufWriter<File>>, String), String> {
    std::fs::create_dir_all("recordings").map_err(|e| e.to_string())?;
    let path = format!("recordings/audio_{}.wav", timestamp());
    let spec = hound::WavSpec {
        channels: 1,
        sample_rate: audio_rate as u32,
        bits_per_sample: 16,
        sample_format: hound::SampleFormat::Int,
    };
    let writer = hound::WavWriter::create(&path, spec).map_err(|e| e.to_string())?;
    Ok((writer, path))
}

/// Opens a new timestamped raw-IQ file in `recordings/` — interleaved
/// unsigned 8-bit I/Q, the same `.cu8` layout `rtl_sdr` itself writes.
fn start_iq_writer() -> Result<(BufWriter<File>, String), String> {
    std::fs::create_dir_all("recordings").map_err(|e| e.to_string())?;
    let path = format!("recordings/iq_{}.cu8", timestamp());
    let file = File::create(&path).map_err(|e| e.to_string())?;
    Ok((BufWriter::new(file), path))
}

/// Draws `nbytes` of whitened random bytes from raw ADC noise, regardless
/// of what's currently tuned — thermal and quantization noise dominate the
/// least-significant bit of every 8-bit sample either way. A von Neumann
/// extractor removes bias: look at consecutive bit pairs, `01`→0, `10`→1,
/// discard `00`/`11` (a biased coin still gives P(01)=P(10), so this
/// recovers unbiased bits even from an imperfect noise source).
///
/// Honest caveat: this hasn't been run through a statistical test suite
/// (dieharder, NIST STS) — a reasonable hobbyist entropy source, not
/// something to treat as vetted for cryptographic key generation.
fn von_neumann_bytes(reader: &Reader, nbytes: usize) -> Vec<u8> {
    let mut out_bits: Vec<u8> = Vec::with_capacity(nbytes * 8);
    let mut prev: Option<u8> = None;
    while out_bits.len() < nbytes * 8 {
        let raw = reader.take(8192);
        if raw.is_empty() {
            break;
        }
        for &b in &raw {
            let bit = b & 1;
            match prev.take() {
                None => prev = Some(bit),
                Some(p) => {
                    if p != bit {
                        out_bits.push(p);
                    }
                }
            }
            if out_bits.len() >= nbytes * 8 {
                break;
            }
        }
    }
    out_bits
        .chunks(8)
        .filter(|c| c.len() == 8)
        .map(|c| c.iter().enumerate().fold(0u8, |acc, (i, &bit)| acc | (bit << i)))
        .take(nbytes)
        .collect()
}

/// Keeps the dongle drained continuously.
///
/// This exists because of a hard architectural problem: the dongle streams
/// at 2.4 MS/s whether or not anyone is listening, and `read_sync` has no
/// queue behind it — whatever arrives while nobody is reading is discarded
/// by USB. The old loop read a slice, then spent tens of milliseconds
/// filtering and demodulating it with nothing draining the device, so
/// roughly a third of the stream was thrown away and every audio buffer
/// had a discontinuity spliced into it. That is not something buffering or
/// filter tuning can repair; the samples were already gone.
///
/// So: one thread does nothing but read, continuously, into a bounded
/// queue. The worker consumes from that queue and can take as long as it
/// likes without the capture stream suffering.
struct Reader {
    /// Captured bytes waiting to be demodulated.
    queue: Arc<Mutex<VecDeque<u8>>>,
}

impl Reader {
    fn start(dev: Arc<Mutex<RtlSdr>>) -> Self {
        let queue: Arc<Mutex<VecDeque<u8>>> = Arc::new(Mutex::new(VecDeque::new()));
        let q = queue.clone();
        thread::spawn(move || {
            let mut scratch = vec![0u8; READ_CHUNK];
            loop {
                let got = {
                    // Held only for the read itself, so a retune never
                    // waits long for the device.
                    let mut d = match dev.lock() {
                        Ok(d) => d,
                        Err(_) => break,
                    };
                    d.read(&mut scratch).unwrap_or(0)
                };
                if got == 0 {
                    thread::sleep(Duration::from_millis(2));
                    continue;
                }
                if let Ok(mut buf) = q.lock() {
                    // Bounded: if the worker falls badly behind, drop the
                    // oldest data rather than growing without limit. Better
                    // to lose old audio than to drift further from live.
                    const MAX: usize = 2_400_000 * 2; // ~1 s of IQ
                    if buf.len() + got > MAX {
                        // Worked out before the drain call: evaluating
                        // buf.len() inside it would borrow buf again while
                        // drain already holds it mutably.
                        let overflow = buf.len() + got - MAX;
                        let drop_n = overflow.min(buf.len());
                        buf.drain(..drop_n);
                    }
                    buf.extend(&scratch[..got]);
                }
            }
        });
        Reader { queue }
    }

    /// Throws away anything captured before a retune.
    fn flush(&self) {
        if let Ok(mut b) = self.queue.lock() {
            b.clear();
        }
    }

    /// Waits for `n` bytes of capture and returns them.
    fn take(&self, n: usize) -> Vec<u8> {
        let mut out = Vec::with_capacity(n);
        let deadline = std::time::Instant::now() + Duration::from_millis(2000);
        while out.len() < n {
            let mut got_any = false;
            if let Ok(mut buf) = self.queue.lock() {
                let want = n - out.len();
                let have = buf.len().min(want);
                if have > 0 {
                    out.extend(buf.drain(..have));
                    got_any = true;
                }
            }
            if out.len() >= n {
                break;
            }
            if std::time::Instant::now() > deadline {
                break;
            }
            if !got_any {
                thread::sleep(Duration::from_millis(1));
            }
        }
        out
    }
}


fn run(initial: String, ui_tx: Sender<UiMsg>, cmd_rx: Receiver<Cmd>) {
    macro_rules! send {
        ($msg:expr) => {{
            let _ = ui_tx.send($msg);
        }};
    }

    send!(UiMsg::Device(DeviceStatus::Searching));

    // Retry opening the dongle rather than giving up — the person may launch
    // the GUI before plugging the RTL-SDR in, and there's no reason to make
    // them restart the app once they do.
    let mut dev = loop {
        match RtlSdr::open(0) {
            Ok(d) => break d,
            Err(e) => {
                send!(UiMsg::Device(DeviceStatus::Error(e.to_string())));
                thread::sleep(Duration::from_millis(1500));
            }
        }
    };
    if let Err(e) = dev.set_sample_rate(IF_RATE) {
        send!(UiMsg::Device(DeviceStatus::Error(format!(
            "set_sample_rate failed: {e}"
        ))));
        return;
    }
    // Start in tuner AGC rather than a fixed high gain. Near-max manual
    // gain (the R828D tops out around 49.6 dB) saturates the front end on
    // strong local signals — the meter pins and everything demodulates as
    // static no matter what you tune to. AGC is the safe default; the UI
    // exposes manual gain for when it's genuinely wanted.
    let _ = dev.set_gain(TunerGain::Auto);

    // From here the device is shared with the reader thread, which keeps it
    // drained continuously. Everything below locks it only for short
    // control operations (retune, gain, ppm); the bulk reading happens
    // there, not here.
    let dev = Arc::new(Mutex::new(dev));
    let reader = Reader::start(dev.clone());
    send!(UiMsg::Device(DeviceStatus::Ready(
        "RTL-SDR V4 — R828D".to_string()
    )));

    // --- audio out, same pattern as scan.rs ---------------------------------
    let host = cpal::default_host();
    let out_dev = match host.default_output_device() {
        Some(d) => d,
        None => {
            send!(UiMsg::Log("no audio output device found".into()));
            return;
        }
    };
    let default_cfg = match out_dev.default_output_config() {
        Ok(c) => c,
        Err(e) => {
            send!(UiMsg::Log(format!("no audio output config: {e}")));
            return;
        }
    };

    // Ask for 48 kHz specifically rather than taking whatever the card
    // defaults to.
    //
    // The whole decimation chain is derived from this number, and 2.4 MS/s
    // divides into 48 kHz exactly (50:1). At 44.1 kHz the nearest integer
    // split lands on 44444 Hz — a 0.8% surplus, so samples pile up faster
    // than they're played until the buffer hits its cap and discards a
    // chunk. That is audible as periodic breakup no matter how correct the
    // filters are. 192 kHz is worse still, at 4.2%.
    const WANT_RATE: u32 = 48_000;
    let channels_out = default_cfg.channels() as usize;
    let supports_48k = out_dev
        .supported_output_configs()
        .map(|mut it| {
            it.any(|r| {
                r.min_sample_rate().0 <= WANT_RATE
                    && r.max_sample_rate().0 >= WANT_RATE
                    && r.channels() as usize == channels_out
            })
        })
        .unwrap_or(false);

    let stream_config: cpal::StreamConfig = if supports_48k {
        cpal::StreamConfig {
            channels: default_cfg.channels(),
            sample_rate: cpal::SampleRate(WANT_RATE),
            buffer_size: cpal::BufferSize::Default,
        }
    } else {
        default_cfg.config()
    };
    let audio_rate = stream_config.sample_rate.0 as f32;
    let msg = format!(
        "audio out: {:.0} Hz, {} channel(s){}",
        audio_rate,
        channels_out,
        if supports_48k {
            ""
        } else {
            "  [card would not take 48 kHz — rate mismatch possible]"
        }
    );
    // Also to the terminal: the in-app log scrolls and is easy to miss,
    // and this line matters for diagnosing audio problems.
    eprintln!("{msg}");
    send!(UiMsg::Log(msg));

    let ring: Arc<Mutex<VecDeque<f32>>> = Arc::new(Mutex::new(VecDeque::with_capacity(48_000)));
    let ring_cb = ring.clone();
    // Playback state shared with the callback.
    //
    // The worker produces audio in ~100 ms bursts and has to read that much
    // IQ in real time before it can process any of it, so production always
    // trails playback slightly and the ring empties often. Writing 0.0 on
    // every empty slot turns each of those gaps into a hard step to
    // silence — hundreds of clicks a second, which sounds like heavy static
    // no matter how clean the demodulator is.
    //
    // Two fixes: wait for a cushion before starting (so short stalls drain
    // slack rather than the stream), and on underrun decay smoothly from
    // the last sample instead of stepping to zero.
    let primed = Arc::new(Mutex::new(false));
    let primed_cb = primed.clone();
    const PRIME_SAMPLES: usize = 4800; // ~100 ms at 48 kHz — enough to start smoothly
    let mut last_sample = 0.0f32;

    let stream = out_dev.build_output_stream(
        &stream_config,
        move |data: &mut [f32], _| {
            let mut buf = match ring_cb.lock() {
                Ok(b) => b,
                Err(_) => {
                    data.fill(0.0);
                    return;
                }
            };
            let mut ready = primed_cb.lock().map(|g| *g).unwrap_or(false);
            if !ready && buf.len() >= PRIME_SAMPLES {
                ready = true;
                if let Ok(mut g) = primed_cb.lock() {
                    *g = true;
                }
            }
            if !ready {
                // Still filling the cushion — decay to silence rather than
                // snapping, so priming itself doesn't click.
                for frame in data.chunks_mut(channels_out) {
                    last_sample *= 0.999;
                    for o in frame.iter_mut() {
                        *o = last_sample;
                    }
                }
                return;
            }
            for frame in data.chunks_mut(channels_out) {
                let s = match buf.pop_front() {
                    Some(v) => {
                        last_sample = v;
                        v
                    }
                    None => {
                        // Underrun: ease toward zero from wherever the
                        // signal was. Inaudible, where a step to zero is a
                        // click.
                        //
                        // Deliberately *not* re-priming here. An earlier
                        // version did, and every brief stall then cost a
                        // full cushion's worth of silence — turning small
                        // gaps into a regular, very audible pause. Riding
                        // through with a decay and picking straight back up
                        // when samples arrive is far less disruptive.
                        last_sample *= 0.995;
                        last_sample
                    }
                };
                for o in frame.iter_mut() {
                    *o = s;
                }
            }
        },
        move |err| eprintln!("audio stream error: {err}"),
        None,
    );
    let stream = match stream {
        Ok(s) => s,
        Err(e) => {
            send!(UiMsg::Log(format!("failed to build audio stream: {e}")));
            return;
        }
    };
    if stream.play().is_err() {
        send!(UiMsg::Log("failed to start audio stream".into()));
    }

    let mut spec = Spectrum::new(FFT_N);
    let usable = spec.usable();
    let mut frame_db = vec![0.0f32; FFT_N];
    let mut utterance = initial;
    let mut pending_mode: Option<Demod> = None;
    let mut audio_writer: Option<hound::WavWriter<BufWriter<File>>> = None;
    let mut iq_writer: Option<BufWriter<File>> = None;
    let mut auto_scan = false;
    let mut volume: f32 = 1.0;
    let mut squelch_override: Option<f64> = None;
    let mut bw_override_khz: Option<f32> = None;
    let mut skip_requested = false;
    let mut voice_only = false;
    let mut hf_mode = false;
    let mut adsb_active = false;
    let mut drone_active = false;
    // Which reachable bands the survey covers. 868 MHz is left out by
    // default: it is the European allocation, and sweeping it in North
    // America spends time on an empty band. The UI can switch it on.
    let mut drone_bands: Vec<String> =
        vec!["ism433".into(), "ism915".into(), "fpv12".into()];
    let mut drone_snr: f32 = 10.0;
    /// Band maps live out here so the accumulated picture survives a
    /// setting change — `continue 'outer` rebuilds the sweep plan, and
    /// losing a minute of survey every time a checkbox moves would make the
    /// controls unusable.
    let mut drone_maps: Vec<BandMap> = Vec::new();
    let mut drone_stare_target: Option<(f64, f64)> = None;
    // Where the ISM survey is parked. 433.92 by default — the busiest of
    // the two bands in most places.
    let mut ism_hz: f64 = ism::ISM_433_HZ;
    // Track-and-listen: which half of the turn we are in, and since when.
    let mut dual = false;
    let mut dual_since = std::time::Instant::now();
    /// Seconds on 1090 MHz before handing the radio to the voice band.
    const TRACK_SECS: u64 = 12;
    /// Seconds scanning for voice before handing it back. A transmission
    /// in progress is never cut off part-way — this is the limit on
    /// *looking*, not on listening.
    const LISTEN_SECS: u64 = 25;
    // What the gain was before a mode that sets its own. ADS-B wants all the
    // gain the tuner has; the drone survey wants a *fixed* gain so levels
    // are comparable from one end of a band to the other. Every other mode
    // wants neither, and leaving 49.6 dB set on the way out would overload
    // the front end on the next strong station and sound exactly like the
    // static this whole program has been fighting.
    //
    // One slot, not one per mode: no two of these modes can be active at
    // once, and two slots means one of them goes stale and puts back a gain
    // from several modes ago.
    let mut gain_saved: Option<Option<i32>> = None;
    let mut current_gain: Option<i32> = None;
    let mut voice_ms: u32 = 0;
    let mut voice_confirmed = false;
    let mut rds_slice: u32 = 0;
    let mut vad = VoiceDetector::new(audio_rate);

    // Defined here, after every variable it touches already exists — local
    // variables referenced inside a macro_rules! body resolve at the
    // macro's *definition* point, not its call site, so this has to sit
    // after `dev`, `audio_rate`, `pending_mode`, `utterance`,
    // `audio_writer`, and `iq_writer` are all in scope, not before.
    macro_rules! write_iq {
        ($raw:expr) => {{
            if let Some(w) = iq_writer.as_mut() {
                let _ = w.write_all(&$raw);
            }
        }};
    }
    macro_rules! write_audio {
        ($audio:expr) => {{
            if let Some(w) = audio_writer.as_mut() {
                for &s in $audio.iter() {
                    let amp = (s.clamp(-1.0, 1.0) * i16::MAX as f32) as i16;
                    let _ = w.write_sample(amp);
                }
            }
        }};
    }

    'outer: loop {
        // Labels, like local variables, resolve at a macro's *definition*
        // point — `'outer` doesn't exist until the line above runs, so
        // `handle_cmd!` (the only one of these that does `continue 'outer`)
        // has to be defined in here, not above with the other two.
        macro_rules! handle_cmd {
            ($cmd:expr) => {{
                match $cmd {
                    Cmd::Tune { utterance: u, mode } => {
                        pending_mode = mode;
                        utterance = u;
                        send!(UiMsg::SignalEnded);
                        continue 'outer;
                    }
                    Cmd::SetGain(g) => {
                        current_gain = g;
                        // A gain the person chose while a mode had its own
                        // gain set is theirs to keep, so stop planning to
                        // undo it on the way out.
                        gain_saved = None;
                        let res = match g {
                            Some(t) => dev.lock().unwrap().set_gain(TunerGain::Manual(t)),
                            None => dev.lock().unwrap().set_gain(TunerGain::Auto),
                        };
                        if let Err(e) = res {
                            send!(UiMsg::Log(format!("gain set failed: {e}")));
                        }
                        if drone_active {
                            // A band map is a comparison of one frequency
                            // against another, and that only holds while the
                            // gain stays put. Half a map measured at 30 dB
                            // and half at 45 would show a step in the middle
                            // of the band that is not in the air.
                            for m in drone_maps.iter_mut() {
                                m.clear();
                            }
                            send!(UiMsg::Log(
                                "gain changed — survey restarted so the band map stays \
                                 comparable end to end"
                                    .into()
                            ));
                        }
                    }
                    Cmd::SetPpm(ppm) => {
                        if let Err(e) = dev.lock().unwrap().set_ppm(ppm) {
                            send!(UiMsg::Log(format!("ppm set failed: {e}")));
                        } else {
                            send!(UiMsg::Log(format!("frequency correction: {ppm} ppm")));
                        }
                    }
                    Cmd::SetBiasTee(on) => match dev.lock().unwrap().set_bias_tee(on) {
                        Ok(()) => send!(UiMsg::Log(format!(
                            "bias tee {}",
                            if on { "ON" } else { "OFF" }
                        ))),
                        Err(e) => send!(UiMsg::Log(format!("bias tee: {e}"))),
                    },
                    Cmd::SetRecordAudio(on) => {
                        if on {
                            match start_audio_writer(audio_rate) {
                                Ok((w, path)) => {
                                    audio_writer = Some(w);
                                    send!(UiMsg::Log(format!("recording audio -> {path}")));
                                }
                                Err(e) => {
                                    send!(UiMsg::Log(format!("audio recording failed: {e}")))
                                }
                            }
                        } else if let Some(w) = audio_writer.take() {
                            let _ = w.finalize();
                            send!(UiMsg::Log("audio recording stopped".into()));
                        }
                    }
                    Cmd::SetRecordIq(on) => {
                        if on {
                            match start_iq_writer() {
                                Ok((w, path)) => {
                                    iq_writer = Some(w);
                                    send!(UiMsg::Log(format!("recording IQ -> {path}")));
                                }
                                Err(e) => send!(UiMsg::Log(format!("IQ recording failed: {e}"))),
                            }
                        } else if iq_writer.take().is_some() {
                            send!(UiMsg::Log("IQ recording stopped".into()));
                        }
                    }
                    Cmd::SetAutoScan(on) => {
                        auto_scan = on;
                        send!(UiMsg::Log(format!(
                            "auto-scan {}",
                            if on { "ON" } else { "OFF" }
                        )));
                    }
                    Cmd::SkipSignal => {
                        // The bare-sweep listen loop intercepts this before
                        // it gets here, but channelized bands (FM, marine,
                        // weather...) listen via Task::Listen instead — for
                        // those this flag is what actually releases the
                        // lock and returns to sweeping.
                        skip_requested = true;
                    }
                    Cmd::SetTrackAndListen(on) => {
                        dual = on;
                        dual_since = std::time::Instant::now();
                        send!(UiMsg::Log(
                            if on {
                                "track and listen: taking turns between 1090 MHz and the \
                                 aviation band"
                            } else {
                                "track and listen off"
                            }
                            .to_string()
                        ));
                        if on && utterance.trim().eq_ignore_ascii_case("adsb") {
                            // Start the clock from now rather than waiting
                            // out whatever is left of the current dwell.
                            continue 'outer;
                        }
                    }
                    Cmd::SetVoiceOnly(on) => {
                        voice_only = on;
                        send!(UiMsg::Log(format!(
                            "voice-only scanning {}",
                            if on { "ON" } else { "OFF" }
                        )));
                    }
                    Cmd::TestTone => {
                        let n = (audio_rate * 2.0) as usize;
                        let mut buf = ring.lock().unwrap();
                        buf.clear();
                        for i in 0..n {
                            let t = i as f32 / audio_rate;
                            buf.push_back(
                                (t * 1000.0 * std::f32::consts::TAU).sin() * 0.3 * volume,
                            );
                        }
                        send!(UiMsg::Log(format!(
                            "test tone: 1 kHz, 2 s — audio device is {:.0} Hz, {} ch",
                            audio_rate, channels_out
                        )));
                    }
                    Cmd::SetVolume(v) => {
                        volume = v;
                    }
                    Cmd::SetSquelch(db) => {
                        squelch_override = Some(db.clamp(3.0, 30.0));
                        send!(UiMsg::Log(format!("squelch {db:.0} dB")));
                        continue 'outer;
                    }
                    Cmd::SetBandwidthKhz(bw) => {
                        bw_override_khz = bw;
                        match bw {
                            Some(k) => send!(UiMsg::Log(format!("IF bandwidth {k:.1} kHz"))),
                            None => send!(UiMsg::Log("IF bandwidth: mode default".into())),
                        }
                        continue 'outer;
                    }
                    Cmd::DroneBands(keys) => {
                        // An empty set would leave the survey spinning with
                        // nothing to tune to, so keep the last one and say
                        // why rather than appearing to accept it.
                        let valid: Vec<String> = keys
                            .into_iter()
                            .filter(|k| drone::band(k).is_some())
                            .collect();
                        if valid.is_empty() {
                            send!(UiMsg::Log(
                                "drone survey needs at least one band — keeping the \
                                 current selection"
                                    .into()
                            ));
                        } else {
                            drone_bands = valid;
                            let names: Vec<&str> = drone_bands
                                .iter()
                                .filter_map(|k| drone::band(k).map(|b| b.name))
                                .collect();
                            send!(UiMsg::Log(format!(
                                "drone survey bands: {}",
                                names.join(", ")
                            )));
                            if drone_active {
                                continue 'outer;
                            }
                        }
                    }
                    Cmd::DroneSnr(db) => {
                        drone_snr = db.clamp(4.0, 40.0);
                        send!(UiMsg::Log(format!(
                            "drone survey threshold {:.0} dB over noise",
                            drone_snr
                        )));
                        if drone_active {
                            // Restart rather than carry on: counters built
                            // at the old threshold mixed with counters
                            // built at the new one are a duty cycle of
                            // nothing in particular.
                            for m in drone_maps.iter_mut() {
                                m.clear();
                            }
                            continue 'outer;
                        }
                    }
                    Cmd::DroneStare(target) => {
                        drone_stare_target = target;
                        match target {
                            Some((lo, hi)) => send!(UiMsg::Log(format!(
                                "staring at {:.3}–{:.3} MHz — the rest of the band is \
                                 not being watched while this runs",
                                lo, hi
                            ))),
                            None => send!(UiMsg::Log("back to sweeping the bands".into())),
                        }
                        if drone_active {
                            continue 'outer;
                        }
                    }
                    Cmd::DroneClear => {
                        for m in drone_maps.iter_mut() {
                            m.clear();
                        }
                        send!(UiMsg::Log("drone survey cleared".into()));
                    }
                    Cmd::IsmTune(hz) => {
                        ism_hz = hz;
                        send!(UiMsg::Log(format!(
                            "ISM survey: {:.4} MHz",
                            hz / 1e6
                        )));
                        // Retune now if the survey is what is running.
                        let on_ism = {
                            let u = utterance.trim().to_ascii_lowercase();
                            u == "sensors" || u.starts_with("sensors ")
                        };
                        if on_ism {
                            continue 'outer;
                        }
                    }
                    Cmd::GenerateRandom(n) => {
                        let bytes = von_neumann_bytes(&reader, n);
                        let hex: String = bytes.iter().map(|b| format!("{b:02x}")).collect();
                        if std::fs::create_dir_all("recordings").is_ok() {
                            let path = format!("recordings/random_{}.hex", timestamp());
                            if std::fs::write(&path, &hex).is_ok() {
                                send!(UiMsg::Log(format!("random bytes -> {path}")));
                            }
                        }
                        send!(UiMsg::Random(hex));
                    }
                }
            }};
        }

        // Leaving a mode that set its own gain or capture rate has to happen
        // *before* any mode claims them again. ADS-B is handled in its own
        // block below, immediately before it re-enters; the drone survey's
        // block is further down, so its exit is hoisted up here.
        //
        // Without this, going straight from the survey to the aircraft map
        // skips the survey's exit entirely, and ADS-B then saves the
        // survey's own fixed gain as "what the gain was before" — so the
        // setting the person actually chose is gone for the rest of the
        // session.
        let wants_drone = {
            let u = utterance.trim();
            u.eq_ignore_ascii_case("drone")
                || u.eq_ignore_ascii_case("drones")
                || u.eq_ignore_ascii_case("drone scan")
                || u.eq_ignore_ascii_case("fpv")
        };
        if drone_active && !wants_drone {
            let mut d = dev.lock().unwrap();
            if let Some(prev) = gain_saved.take() {
                let _ = match prev {
                    Some(t) => d.set_gain(TunerGain::Manual(t)),
                    None => d.set_gain(TunerGain::Auto),
                };
                current_gain = prev;
            }
            let _ = d.set_sample_rate(IF_RATE);
            let _ = d.reset_buffer();
            drop(d);
            reader.flush();
            drone_active = false;
            send!(UiMsg::Log("left the drone survey — RF gain restored".into()));
        }

        // --- ADS-B ----------------------------------------------------------
        //
        // Intercepted before the planner, because none of what follows
        // applies: there is no band to sweep, no squelch to open, and no
        // audio. The radio sits on 1090 MHz and stays there.
        let wants_adsb = {
            let u = utterance.trim();
            u.eq_ignore_ascii_case("adsb")
                || u.eq_ignore_ascii_case("ads-b")
                || u.eq_ignore_ascii_case("aircraft positions")
        };
        if adsb_active && !wants_adsb {
            // Put the capture rate back before the scanner's decimation
            // chain, which is derived from it, gets to run again.
            let mut d = dev.lock().unwrap();
            let _ = d.set_sample_rate(IF_RATE);
            if let Some(prev) = gain_saved.take() {
                let _ = match prev {
                    Some(t) => d.set_gain(TunerGain::Manual(t)),
                    None => d.set_gain(TunerGain::Auto),
                };
                current_gain = prev;
            }
            let _ = d.reset_buffer();
            drop(d);
            reader.flush();
            adsb_active = false;
            send!(UiMsg::Log(
                "left ADS-B — capture rate and RF gain restored".into()
            ));
        }
        if wants_adsb {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            if !adsb_active {
                let mut d = dev.lock().unwrap();
                // The bit slicer assumes exactly two samples per
                // microsecond. Nothing here is tolerant of a different
                // rate, so a failure to set it is fatal to the mode.
                if let Err(e) = d.set_sample_rate(ADSB_RATE) {
                    drop(d);
                    send!(UiMsg::PlanError(format!(
                        "ADS-B needs a {} S/s capture rate and the dongle refused it: {e}",
                        ADSB_RATE
                    )));
                    loop {
                        match cmd_rx.recv() {
                            Ok(cmd) => handle_cmd!(cmd),
                            Err(_) => break 'outer,
                        }
                    }
                }
                let _ = d.set_center_hz(ADSB_FREQ_HZ);
                // ADS-B is short, weak pulses with no carrier to average.
                // Tuner AGC has nothing to settle on between bursts and
                // ends up well below what the frames need, so this mode
                // starts at the R828D's top gain. The RF GAIN control still
                // overrides it afterwards, and whatever was set before is
                // put back on the way out.
                gain_saved = Some(current_gain);
                let _ = d.set_gain(TunerGain::Manual(496));
                let _ = d.reset_buffer();
                drop(d);
                reader.flush();
                adsb_active = true;
                send!(UiMsg::PlanLoaded {
                    name: "ADS-B — 1090 MHz".to_string(),
                    windows: 1,
                    channels: 1,
                    single_window: true,
                });
                send!(UiMsg::Log(format!(
                    "ADS-B: parked on 1090.000 MHz, {} S/s, gain 49.6 dB",
                    ADSB_RATE
                )));
                send!(UiMsg::Log(
                    "1090 MHz is well above a TV yagi's band — a quarter-wave \
                     whip (69 mm) will usually hear more aircraft than the roof \
                     antenna here."
                        .into()
                ));
            }

            let mut demod = AdsbDemod::new();
            let mut table = AircraftTable::new();
            let mut frames: Vec<sweep_core::adsb::Frame> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let started = std::time::Instant::now();
            // Level meter over the raw capture. Without this, "nothing
            // decoded" is indistinguishable between an antenna that hears
            // no aircraft and a decoder that is wrong, which is exactly the
            // question that needs answering first.
            let mut mean_mag = 0.0f32;
            let mut peak_mag = 0.0f32;
            // The ADS-B loop never fed the spectrum display, so the
            // waterfall froze the moment this mode started. It is worth
            // feeding: ADS-B bursts show up as short vertical flecks right
            // at the centre, which means you can *see* whether anything is
            // arriving at 1090 MHz instead of inferring it from a frame
            // count that stays at zero either way.
            let mut last_spec = std::time::Instant::now();
            let mut adsb_floor = vec![-110.0f32; FFT_N];

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }

                // Large reads: at 2 MS/s this is about 65 ms of capture,
                // enough that the per-call overhead is negligible and short
                // enough that the UI still feels live.
                let raw = reader.take(READ_CHUNK * 8);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                // Sample the level rather than measuring every sample: one
                // in sixteen is plenty for a meter and keeps this off the
                // critical path.
                let mut sum = 0.0f32;
                let mut n = 0u32;
                let mut pk = 0.0f32;
                for pair in raw.chunks_exact(2).step_by(16) {
                    let i = (pair[0] as f32 - 127.5) * (1.0 / 127.5);
                    let q = (pair[1] as f32 - 127.5) * (1.0 / 127.5);
                    let m = (i * i + q * q).sqrt();
                    sum += m;
                    if m > pk {
                        pk = m;
                    }
                    n += 1;
                }
                if n > 0 {
                    let m = sum / n as f32;
                    // Smoothed, because a bare per-buffer figure flickers
                    // too fast to read.
                    mean_mag = if mean_mag == 0.0 { m } else { mean_mag * 0.8 + m * 0.2 };
                    peak_mag = peak_mag.max(pk) * 0.98;
                }

                if raw.len() >= FFT_N * 2
                    && last_spec.elapsed() >= Duration::from_millis(110)
                {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    // A flat floor from the frame's own median. There is no
                    // sweep here and no per-window history to average, and
                    // the median of a mostly-empty band is a perfectly good
                    // estimate of where the noise sits.
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted
                        .get(sorted.len() / 2)
                        .copied()
                        .unwrap_or(-110.0);
                    for v in adsb_floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: adsb_floor[usable.clone()].to_vec(),
                        center_hz: ADSB_FREQ_HZ,
                    });
                }

                frames.clear();
                demod.process_u8(&raw, &mut frames);
                for f in frames.iter() {
                    table.ingest(f);
                }

                // Half the turn is up: give the radio to the voice band.
                if dual && dual_since.elapsed() >= Duration::from_secs(TRACK_SECS) {
                    dual_since = std::time::Instant::now();
                    utterance = "aviation".to_string();
                    send!(UiMsg::Log(
                        "listening on the aviation band — aircraft positions are paused".into()
                    ));
                    continue 'outer;
                }

                if last_push.elapsed() >= Duration::from_millis(400) {
                    last_push = std::time::Instant::now();
                    table.expire();
                    let mins = started.elapsed().as_secs_f32() / 60.0;
                    let aircraft: Vec<AircraftView> = table
                        .snapshot()
                        .into_iter()
                        .map(|a| AircraftView {
                            hex_id: a.hex_id(),
                            callsign: a.callsign.clone(),
                            lat: a.lat,
                            lon: a.lon,
                            alt_ft: a.alt_ft,
                            speed_kt: a.speed_kt,
                            heading_deg: a.heading_deg,
                            vert_rate_fpm: a.vert_rate_fpm,
                            rssi_db: a.rssi_db,
                            messages: a.messages,
                            age_s: a.age().as_secs_f32(),
                        })
                        .collect();
                    let secs = started.elapsed().as_secs_f32().max(0.001);
                    send!(UiMsg::Adsb {
                        aircraft,
                        frames_ok: demod.frames_ok,
                        frames_bad: demod.frames_bad,
                        frames_per_min: if mins > 0.05 {
                            demod.frames_ok as f32 / mins
                        } else {
                            0.0
                        },
                        preambles_per_s: demod.preambles as f32 / secs,
                        mean_dbfs: 20.0 * mean_mag.max(1e-6).log10(),
                        peak_dbfs: 20.0 * peak_mag.max(1e-6).log10(),
                    });
                }
            }
        }

        // --- Drone bands ------------------------------------------------
        //
        // A survey, not a decoder. Nothing here is demodulated: the output
        // is where energy is, how wide it is, and how often it is there.
        //
        // The reason it is a survey and not an identification is in
        // `sweep_core::drone` — the one signal that carries a drone's
        // identity is Remote ID at 2.4 and 5.8 GHz, and the R828D stops at
        // 1766 MHz. What is below that ceiling is some long-range control
        // and telemetry, and analogue FPV video at 1.2/1.3 GHz, none of
        // which is decodable without a binding phrase we do not have. So:
        // shapes.
        if wants_drone {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            if !drone_active {
                let mut d = dev.lock().unwrap();
                if let Err(e) = d.set_sample_rate(IF_RATE) {
                    drop(d);
                    send!(UiMsg::PlanError(format!(
                        "the drone survey needs a {IF_RATE} S/s capture rate and the \
                         dongle refused it: {e}"
                    )));
                    loop {
                        match cmd_rx.recv() {
                            Ok(cmd) => handle_cmd!(cmd),
                            Err(_) => break 'outer,
                        }
                    }
                }
                gain_saved = Some(current_gain);
                let _ = d.set_gain(TunerGain::Manual(DRONE_GAIN));
                current_gain = Some(DRONE_GAIN);
                let _ = d.reset_buffer();
                drop(d);
                reader.flush();
                drone_active = true;
                send!(UiMsg::Log(format!(
                    "drone survey: fixed RF gain {:.1} dB so levels are comparable \
                     across each band",
                    DRONE_GAIN as f32 / 10.0
                )));
                // Said once, out loud, every time the mode starts. The
                // limitation is the most important fact about this screen.
                send!(UiMsg::Log(
                    "Remote ID is at 2.4/5.8 GHz and this tuner stops at 1766 MHz — \
                     no drone identity, serial number or operator position is \
                     available from this hardware at any setting."
                        .into()
                ));
            }

            // One map per enabled band, keeping any that already exist so
            // toggling one band does not wipe the others' history.
            let bin_hz = IF_RATE as f64 / FFT_N as f64;
            let span_hz = bin_hz * usable.len() as f64;
            drone_maps.retain(|m| drone_bands.iter().any(|k| k == m.key));
            for key in drone_bands.iter() {
                if !drone_maps.iter().any(|m| m.key == key.as_str()) {
                    if let Some(b) = drone::band(key) {
                        drone_maps.push(BandMap::new(b, bin_hz));
                    }
                }
            }
            // Sweep order: band by band, low to high within each.
            let mut plan: Vec<(usize, f64)> = Vec::new();
            for (mi, m) in drone_maps.iter().enumerate() {
                if let Some(b) = drone::band(m.key) {
                    for c in b.windows(span_hz) {
                        plan.push((mi, c));
                    }
                }
            }
            if plan.is_empty() {
                send!(UiMsg::PlanError(
                    "no drone bands selected — nothing to sweep".into()
                ));
                loop {
                    match cmd_rx.recv() {
                        Ok(cmd) => handle_cmd!(cmd),
                        Err(_) => break 'outer,
                    }
                }
            }
            let staring = drone_stare_target.is_some();
            send!(UiMsg::PlanLoaded {
                name: if staring {
                    "Drone survey — staring".to_string()
                } else {
                    format!("Drone survey — {} windows", plan.len())
                },
                windows: plan.len(),
                channels: 0,
                single_window: staring,
            });

            // --- parked measurement ---------------------------------
            //
            // Split off from the sweep rather than folded into it,
            // because they want opposite things from the radio: the
            // sweep wants to move, this wants to sit still and count
            // frames. One dongle cannot do both, so the UI makes it a
            // choice and this is the other half of it.
            if let Some((lo_mhz, hi_mhz)) = drone_stare_target {
                // Centre the window on the target. When the target is wider
                // than one window — a 10 MHz video carrier, say — centring
                // is all that can be done and the measurement covers the
                // 1.8 MHz that fits, which is enough for duty cycle but
                // understates the width. `Stare::set_target` clamps.
                let target_hz = (lo_mhz + hi_mhz) / 2.0 * 1e6;
                let center = target_hz + DRONE_STARE_OFFSET_HZ;
                {
                    let mut d = dev.lock().unwrap();
                    let _ = d.set_center_hz(center);
                    let _ = d.reset_buffer();
                    drop(d);
                }
                reader.flush();
                // The first chunk after a retune can still hold samples
                // captured at the old frequency, so it is thrown away
                // rather than measured.
                let _ = reader.take(READ_CHUNK);
                let frame_s = FFT_N as f32 / IF_RATE as f32;
                // The floor comes from the sweep, which measured where the
                // band's noise actually sits across every window. Deriving
                // it from this one window would put it on top of whatever
                // is being measured — see `drone::Stare::floor_db`.
                let swept_floor = drone_maps
                    .iter()
                    .find(|m| target_hz >= m.f0_hz && target_hz <= m.f1_hz)
                    .map(|m| m.floor_est)
                    .filter(|f| f.is_finite());
                let floor_db = match swept_floor {
                    Some(f) => f,
                    None => {
                        // No sweep has run here yet. Fall back to this
                        // window's own median, which is right as long as
                        // the window is mostly empty, and say so.
                        let probe = reader.take(FFT_N * 2);
                        if probe.len() >= FFT_N * 2 {
                            spec.process_u8(&probe[..FFT_N * 2], &mut frame_db);
                            spec.blank_dc(
                                &mut frame_db,
                                IF_RATE,
                                DRONE_DC_GUARD_HZ,
                                f32::NEG_INFINITY,
                            );
                            let f = drone::window_floor(&frame_db[usable.clone()]);
                            send!(UiMsg::Log(format!(
                                "no swept noise floor for this band yet — measuring                                  against this window's own median, {f:.0} dBFS"
                            )));
                            f
                        } else {
                            -110.0
                        }
                    }
                };
                let mut st =
                    Stare::new(center, bin_hz, usable.len(), frame_s, floor_db);
                st.set_target(lo_mhz * 1e6, hi_mhz * 1e6);
                let started = std::time::Instant::now();
                let mut last_push = std::time::Instant::now();
                let mut last_spec = std::time::Instant::now();
                let mut window_db = vec![0.0f32; usable.len()];
                loop {
                    match cmd_rx.try_recv() {
                        Ok(cmd) => handle_cmd!(cmd),
                        Err(TryRecvError::Disconnected) => break 'outer,
                        Err(TryRecvError::Empty) => {}
                    }
                    let raw = reader.take(READ_CHUNK * 2);
                    if raw.len() < FFT_N * 2 {
                        thread::sleep(Duration::from_millis(5));
                        continue;
                    }
                    write_iq!(raw);
                    for chunk in raw.chunks_exact(FFT_N * 2) {
                        spec.process_u8(chunk, &mut frame_db);
                        spec.blank_dc(
                            &mut frame_db,
                            IF_RATE,
                            DRONE_DC_GUARD_HZ,
                            f32::NEG_INFINITY,
                        );
                        window_db.copy_from_slice(&frame_db[usable.clone()]);
                        st.frame(&window_db, drone_snr);
                    }
                    if last_spec.elapsed() >= Duration::from_millis(110) {
                        last_spec = std::time::Instant::now();
                        let floor = vec![st.floor_db; usable.len()];
                        send!(UiMsg::Spectrum {
                            bins: finite_for_display(&window_db, st.floor_db),
                            floor,
                            center_hz: center,
                        });
                    }
                    if last_push.elapsed() >= Duration::from_millis(400) {
                        last_push = std::time::Instant::now();
                        let kind = st.kind(drone_snr);
                        let peak = st.peak_db[st.lo_bin..st.hi_bin]
                            .iter()
                            .cloned()
                            .filter(|v| v.is_finite())
                            .fold(f32::NEG_INFINITY, f32::max);
                        send!(UiMsg::DroneStareMsg(DroneStareView {
                            center_mhz: center / 1e6,
                            target_lo_mhz: lo_mhz,
                            target_hi_mhz: hi_mhz,
                            bw_khz: st.bw_khz(drone_snr),
                            bw_is_lower_bound: st.bw_is_lower_bound(drone_snr),
                            duty: st.duty(),
                            burst_ms: st.burst_ms(),
                            gap_ms: st.gap_ms(),
                            rate_hz: st.rate_hz(),
                            peak_mhz: st.peak_mhz(),
                            peak_db: if peak.is_finite() { peak } else { -140.0 },
                            floor_db: st.floor_db,
                            frames: st.frames,
                            seconds: started.elapsed().as_secs_f32(),
                            kind: kind.label(),
                            verdict: kind.consistent_with(),
                        }));
                    }
                }
            }

            // --- sweeping -------------------------------------------
            let mut idx = 0usize;
            let mut last_push = std::time::Instant::now();
            // Measured, not assumed: how long a full pass actually takes
            // decides whether an occupancy figure means anything, so it is
            // timed and reported rather than estimated from window count.
            let mut pass_started = std::time::Instant::now();
            let mut pass_secs = 0.0f32;
            let mut window_db = vec![0.0f32; usable.len()];
            let mut peak_db = vec![0.0f32; usable.len()];
            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }

                let (mi, center) = plan[idx];
                {
                    let mut d = dev.lock().unwrap();
                    let _ = d.set_center_hz(center);
                    let _ = d.reset_buffer();
                }
                reader.flush();
                // Discard one chunk: the reader thread may have been
                // mid-read when the tuner moved, so the first bytes after a
                // retune can belong to the previous window. Writing those
                // into the band map smears each signal into its neighbour's
                // slot, which is exactly the kind of quiet wrongness that
                // makes a survey useless.
                let _ = reader.take(READ_CHUNK);

                let raw = reader.take(FFT_N * 2 * 8);
                if raw.len() >= FFT_N * 2 {
                    write_iq!(raw);
                    // Max-hold across the frames in this dwell. A mean
                    // would average a 2 ms burst away into the noise; the
                    // question being asked is "was anything here", and the
                    // maximum is the answer to that question.
                    peak_db.iter_mut().for_each(|v| *v = f32::NEG_INFINITY);
                    let mut frames = 0u32;
                    for chunk in raw.chunks_exact(FFT_N * 2) {
                        spec.process_u8(chunk, &mut frame_db);
                        // The DC spur sits at the centre of every window.
                        // Blanked to a non-finite level, which the band map
                        // reads as "no measurement" rather than as quiet —
                        // see DRONE_DC_GUARD_HZ.
                        spec.blank_dc(
                            &mut frame_db,
                            IF_RATE,
                            DRONE_DC_GUARD_HZ,
                            f32::NEG_INFINITY,
                        );
                        for (o, &v) in peak_db.iter_mut().zip(frame_db[usable.clone()].iter()) {
                            if v > *o {
                                *o = v;
                            }
                        }
                        frames += 1;
                    }
                    if frames > 0 {
                        window_db.copy_from_slice(&peak_db);
                        drone_maps[mi].ingest(center, span_hz, &window_db, drone_snr);
                        // The band's floor, which is what `ingest` actually
                        // compared against — not this window's own median,
                        // which sits on top of anything wide enough to fill
                        // the window.
                        let med = if drone_maps[mi].floor_est.is_finite() {
                            drone_maps[mi].floor_est
                        } else {
                            -110.0
                        };
                        let floor = vec![med; usable.len()];
                        send!(UiMsg::Spectrum {
                            bins: finite_for_display(&window_db, med),
                            floor,
                            center_hz: center,
                        });
                    }
                }

                idx += 1;
                if idx >= plan.len() {
                    idx = 0;
                    pass_secs = pass_started.elapsed().as_secs_f32();
                    pass_started = std::time::Instant::now();
                    for m in drone_maps.iter_mut() {
                        m.passes = m.passes.saturating_add(1);
                    }
                }

                if last_push.elapsed() >= Duration::from_millis(500) {
                    last_push = std::time::Instant::now();
                    let mut sigs: Vec<DroneSigView> = Vec::new();
                    let mut bands: Vec<DroneBandView> = Vec::new();
                    let mut all: Vec<drone::Signature> = Vec::new();
                    for m in drone_maps.iter() {
                        let b = match drone::band(m.key) {
                            Some(b) => b,
                            None => continue,
                        };
                        // Occupancy as a display row: -1 marks "not looked
                        // at often enough", which the UI draws differently
                        // rather than as zero. Zero and unknown are not the
                        // same answer.
                        let occ: Vec<f32> = (0..m.len())
                            .map(|i| m.occupancy(i).unwrap_or(-1.0))
                            .collect();
                        bands.push(DroneBandView {
                            key: m.key.to_string(),
                            name: b.name,
                            f0_mhz: b.f0_mhz,
                            f1_mhz: b.f1_mhz,
                            peak: profile(&m.peak_db, DRONE_PROFILE, true, -140.0),
                            floor: profile(&m.floor_db, DRONE_PROFILE, false, -140.0),
                            occupancy: profile(&occ, DRONE_PROFILE, true, -1.0),
                            passes: m.passes,
                        });
                        let mut found = m.signatures(drone_snr, 2);
                        all.append(&mut found);
                    }
                    let hop = drone::hop_evidence(&all).map(|e| {
                        format!(
                            "{} narrow bursts spread over {:.1} MHz ({:.3}–{:.3}) — \
                             consistent with a frequency-hopping link, and equally \
                             consistent with a band full of unrelated burst devices.",
                            e.bursts, e.spread_mhz, e.lowest_mhz, e.highest_mhz
                        )
                    });
                    // Drone-shaped first, then strongest. The ordering is a
                    // hint about where to look, not a ranking of certainty.
                    all.sort_by(|a, b| {
                        b.kind
                            .drone_shaped()
                            .cmp(&a.kind.drone_shaped())
                            .then_with(|| {
                                b.snr_db
                                    .partial_cmp(&a.snr_db)
                                    .unwrap_or(std::cmp::Ordering::Equal)
                            })
                    });
                    for s in all.iter().take(60) {
                        let name = drone::band(s.band_key).map(|b| b.name).unwrap_or("");
                        sigs.push(DroneSigView {
                            band_key: s.band_key.to_string(),
                            band_name: name,
                            center_mhz: s.center_mhz,
                            bw_khz: s.bw_khz,
                            peak_db: s.peak_db,
                            snr_db: s.snr_db,
                            occupancy: s.occupancy,
                            looks: s.looks,
                            kind: s.kind.label(),
                            verdict: s.kind.consistent_with(),
                            drone_shaped: s.kind.drone_shaped(),
                        });
                    }
                    send!(UiMsg::DroneSweep {
                        bands,
                        signatures: sigs,
                        hop,
                        scanning_mhz: center / 1e6,
                        pass_secs,
                    });
                }
            }
        }

        // --- SSTV -------------------------------------------------------
        //
        // The only decoder whose output is a picture. It is also the only
        // one that can sit on either HF or VHF, so the demodulator is
        // chosen by where it is pointed: below 30 MHz is single sideband,
        // above it is FM.
        let wants_sstv = {
            let u = utterance.trim().to_ascii_lowercase();
            u == "sstv" || u == "slow-scan images" || u.starts_with("sstv ")
        };
        if wants_sstv {
            let tune_hz = utterance
                .trim()
                .split_whitespace()
                .nth(1)
                .and_then(|t| t.parse::<f64>().ok())
                .map(|m| m * 1e6)
                .unwrap_or(14_230_000.0);
            let hf = tune_hz < 24_000_000.0;
            if hf != hf_mode {
                let m = if hf {
                    DirectSampling::QBranch
                } else {
                    DirectSampling::Off
                };
                if dev.lock().unwrap().set_direct_sampling(m).is_ok() {
                    hf_mode = hf;
                }
            }
            // SSB needs the carrier off centre anyway; 20 kHz keeps the
            // audio passband clear of the DC spike either way.
            let offset = 20_000.0f64;
            {
                let mut d = dev.lock().unwrap();
                let _ = d.set_center_hz(tune_hz - offset);
                let _ = d.reset_buffer();
            }
            reader.flush();
            send!(UiMsg::PlanLoaded {
                name: format!("SSTV — {:.3} MHz", tune_hz / 1e6),
                windows: 1,
                channels: 1,
                single_window: true,
            });
            send!(UiMsg::Log(format!(
                "SSTV: {:.3} MHz, {}",
                tune_hz / 1e6,
                if hf { "upper sideband" } else { "FM" }
            )));

            let mut mixer = Mixer::new(offset as f32, IF_RATE as f32);
            let mut chan = AnyChannel::new(
                if hf { Demod::Usb } else { Demod::Nfm },
                IF_RATE as f32,
                audio_rate,
                3_000.0,
            );
            let mut sstv = SstvDecoder::new(audio_rate);
            let mut iq: Vec<Complex32> = Vec::new();
            let mut audio: Vec<f32> = Vec::new();
            let mut events: Vec<SstvEvent> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let mut last_spec = std::time::Instant::now();
            let mut floor = vec![-110.0f32; FFT_N];
            let mut last_lines = usize::MAX;

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }
                let raw = reader.take(READ_CHUNK * 4);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                iq.clear();
                iq.reserve(raw.len() / 2);
                for b in raw.chunks_exact(2) {
                    iq.push(Complex32::new(
                        (b[0] as f32 - 127.4) / 127.5,
                        (b[1] as f32 - 127.4) / 127.5,
                    ));
                }
                mixer.shift(&mut iq);
                audio.clear();
                chan.process(&iq, &mut audio);

                events.clear();
                sstv.process(&audio, &mut events);
                for e in events.iter() {
                    let line = match e {
                        SstvEvent::Started(m) => format!(">> SSTV picture starting — {m}"),
                        SstvEvent::Unsupported(m) => format!(
                            "! heard {m}, which this cannot decode — the picture is being \
                             skipped rather than guessed at"
                        ),
                        SstvEvent::Finished => ">> SSTV picture complete".to_string(),
                    };
                    send!(UiMsg::Log(line.clone()));
                    send!(UiMsg::SstvEvent(line));
                }

                // The audio is the picture, so hearing it is how you know
                // the tuning is right — SSTV has an unmistakable warble.
                write_audio!(audio);
                {
                    let mut buf = ring.lock().unwrap();
                    for &v in audio.iter() {
                        buf.push_back((v * volume).clamp(-1.0, 1.0));
                    }
                    let cap = (audio_rate as usize) * 2;
                    if buf.len() > cap {
                        let drop_n = buf.len() - cap;
                        buf.drain(..drop_n);
                    }
                }

                if raw.len() >= FFT_N * 2 && last_spec.elapsed() >= Duration::from_millis(110) {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted.get(sorted.len() / 2).copied().unwrap_or(-110.0);
                    for v in floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: floor[usable.clone()].to_vec(),
                        center_hz: tune_hz - offset,
                    });
                }

                // A quarter of a megabyte a frame, so only when the picture
                // has actually grown and never faster than twice a second.
                if last_push.elapsed() >= Duration::from_millis(500) {
                    last_push = std::time::Instant::now();
                    if let Some(p) = &sstv.picture {
                        if p.lines_done != last_lines {
                            last_lines = p.lines_done;
                            send!(UiMsg::Sstv {
                                width: p.width,
                                height: p.height,
                                rgb: p.rgb.clone(),
                                lines_done: p.lines_done,
                                mode: p.mode.to_string(),
                            });
                        }
                    }
                }
            }
        }

        // --- ACARS ------------------------------------------------------
        //
        // A text decoder rather than a position one, so there is nothing to
        // plot: each block is an event, reported as it arrives. The channel
        // is selectable because there are five of them and only one radio.
        let wants_acars = {
            let u = utterance.trim().to_ascii_lowercase();
            u == "acars" || u == "aircraft datalink" || u.starts_with("acars ")
        };
        if wants_acars {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            // "acars 130.025" picks a channel; bare "acars" takes the
            // primary one.
            let chan_hz = utterance
                .trim()
                .split_whitespace()
                .nth(1)
                .and_then(|t| t.parse::<f64>().ok())
                .map(|m| m * 1e6)
                .unwrap_or(ACARS_HZ);
            let offset = 60_000.0f64;
            {
                let mut d = dev.lock().unwrap();
                let _ = d.set_center_hz(chan_hz - offset);
                let _ = d.reset_buffer();
            }
            reader.flush();
            send!(UiMsg::PlanLoaded {
                name: format!("ACARS — {:.3} MHz", chan_hz / 1e6),
                windows: 1,
                channels: 1,
                single_window: true,
            });

            let mut tap = AcarsTap::new(offset as f32, IF_RATE as f32);
            let mut log = AcarsLog::new();
            let mut iq: Vec<Complex32> = Vec::new();
            let mut blocks: Vec<sweep_core::acars::Block> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let mut last_spec = std::time::Instant::now();
            let mut floor = vec![-110.0f32; FFT_N];
            let mut mean_mag = 0.0f32;
            let mut peak_mag = 0.0f32;

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }
                let raw = reader.take(READ_CHUNK * 4);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                iq.clear();
                iq.reserve(raw.len() / 2);
                let mut sum = 0.0f32;
                let mut pk = 0.0f32;
                for b in raw.chunks_exact(2) {
                    let i = (b[0] as f32 - 127.4) / 127.5;
                    let q = (b[1] as f32 - 127.4) / 127.5;
                    iq.push(Complex32::new(i, q));
                    let m = i * i + q * q;
                    sum += m;
                    if m > pk {
                        pk = m;
                    }
                }
                if !iq.is_empty() {
                    let m = (sum / iq.len() as f32).sqrt();
                    mean_mag = if mean_mag == 0.0 { m } else { mean_mag * 0.8 + m * 0.2 };
                    peak_mag = peak_mag.max(pk.sqrt()) * 0.98;
                }

                blocks.clear();
                tap.process(&iq, &mut blocks);
                for b in blocks.iter() {
                    log.ingest(b);
                    send!(UiMsg::AcarsBlock {
                        when: clock_time(),
                        registration: b.registration.clone(),
                        flight: b.flight.clone(),
                        label: b.label.clone(),
                        label_text: sweep_core::acars::label_text(&b.label),
                        text: b.text.clone(),
                        crc_ok: b.crc_ok,
                        more: b.more_to_come,
                    });
                }

                write_audio!(tap.audio());
                {
                    let mut buf = ring.lock().unwrap();
                    for &v in tap.audio() {
                        buf.push_back((v * 1.5 * volume).clamp(-1.0, 1.0));
                    }
                    let cap = (audio_rate as usize) * 2;
                    if buf.len() > cap {
                        let drop_n = buf.len() - cap;
                        buf.drain(..drop_n);
                    }
                }

                if raw.len() >= FFT_N * 2 && last_spec.elapsed() >= Duration::from_millis(110) {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted.get(sorted.len() / 2).copied().unwrap_or(-110.0);
                    for v in floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: floor[usable.clone()].to_vec(),
                        center_hz: chan_hz - offset,
                    });
                }

                if last_push.elapsed() >= Duration::from_millis(600) {
                    last_push = std::time::Instant::now();
                    log.expire();
                    send!(UiMsg::AcarsStatus {
                        blocks: tap.demod.frames_ok,
                        bad_parity: tap.demod.bad_parity,
                        aircraft: log.len(),
                        mean_dbfs: 20.0 * mean_mag.max(1e-6).log10(),
                        peak_dbfs: 20.0 * peak_mag.max(1e-6).log10(),
                        channel_hz: chan_hz,
                    });
                }
            }
        }

        // --- ISM burst survey -------------------------------------------
        //
        // Not a device decoder. The 433 and 915 MHz bands carry hundreds of
        // undocumented formats, and inventing their bit layouts would be the
        // fabrication this program refuses everywhere else. So this stops at
        // what the signal itself proves: that a transmission happened, its
        // timing fingerprint, its line coding where that is unambiguous, the
        // raw bits, how many times it repeated, and whether a standard CRC
        // closes over the bytes. All measured, none invented. See
        // `sweep_core::ism`.
        let wants_ism = {
            let u = utterance.trim().to_ascii_lowercase();
            u == "sensors" || u.starts_with("sensors ")
        };
        if wants_ism {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            // "sensors 915" or "sensors 915.0" overrides the stored centre.
            if let Some(mhz) = utterance
                .trim()
                .split_whitespace()
                .nth(1)
                .and_then(|t| t.parse::<f64>().ok())
            {
                ism_hz = mhz * 1e6;
            }
            // Park 80 kHz low so the DC spike is clear of the activity, and
            // mix back to baseband.
            let offset = 80_000.0f64;
            {
                let mut d = dev.lock().unwrap();
                let _ = d.set_center_hz(ism_hz - offset);
                let _ = d.reset_buffer();
            }
            reader.flush();
            send!(UiMsg::PlanLoaded {
                name: format!("ISM survey — {:.4} MHz", ism_hz / 1e6),
                windows: 1,
                channels: 1,
                single_window: true,
            });
            send!(UiMsg::Log(format!(
                "ISM: parked on {:.4} MHz, analysing OOK bursts (timing, bits, CRC) — \
                 nothing here is a device name or a sensor reading",
                ism_hz / 1e6
            )));

            let mut tap = IsmTap::new(IF_RATE as f32);
            let det_rate = tap.rate();
            let mut det = BurstDetector::new(det_rate, 5000.0);
            let mut mixer = Mixer::new(offset as f32, IF_RATE as f32);
            let mut iq: Vec<Complex32> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let mut last_spec = std::time::Instant::now();
            let mut floor = vec![-110.0f32; FFT_N];
            let mut mean_mag = 0.0f32;
            let mut peak_mag = 0.0f32;
            let mut bursts: u64 = 0;
            let mut decoded: u64 = 0;
            let mut with_crc: u64 = 0;
            // Repeats: a device sends the same packet several times in a
            // row. Hold the last decode briefly and fold a matching one
            // into it rather than logging it again.
            let mut pending: Option<PendingBurst> = None;

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }
                let raw = reader.take(READ_CHUNK * 4);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                iq.clear();
                iq.reserve(raw.len() / 2);
                let mut sum = 0.0f32;
                let mut pk = 0.0f32;
                for b in raw.chunks_exact(2) {
                    let i = (b[0] as f32 - 127.4) / 127.5;
                    let q = (b[1] as f32 - 127.4) / 127.5;
                    iq.push(Complex32::new(i, q));
                    let m = i * i + q * q;
                    sum += m;
                    if m > pk {
                        pk = m;
                    }
                }
                if !iq.is_empty() {
                    let m = (sum / iq.len() as f32).sqrt();
                    mean_mag = if mean_mag == 0.0 { m } else { mean_mag * 0.8 + m * 0.2 };
                    peak_mag = peak_mag.max(pk.sqrt()) * 0.98;
                }
                mixer.shift(&mut iq);
                let mag = tap.process(&iq);
                det.process(mag, &mut |b| {
                    bursts += 1;
                    let a = ism::analyse(&b, det_rate);
                    let snr_db = 20.0 * b.snr.max(1.0).log10();
                    if a.coding == sweep_core::ism::Coding::Unknown || a.bits.is_empty() {
                        // Energy was there but no two-level structure could
                        // be read — an FSK device, or OOK this cannot slice.
                        // Reported as a burst with no bits rather than
                        // dropped, so "something transmitted" is still true.
                        emit_ism(
                            &ui_tx,
                            &mut pending,
                            IsmEvent {
                                coding: "energy only (FSK or unsliceable)",
                                short_us: 0.0,
                                long_us: 0.0,
                                bits: 0,
                                hex: String::new(),
                                crc_ok: false,
                                snr_db,
                            },
                        );
                        return;
                    }
                    decoded += 1;
                    if a.crc8_ok {
                        with_crc += 1;
                    }
                    emit_ism(
                        &ui_tx,
                        &mut pending,
                        IsmEvent {
                            coding: a.coding.label(),
                            short_us: a.short_us,
                            long_us: a.long_us,
                            bits: a.bits.len() as u32,
                            hex: a.hex.clone(),
                            crc_ok: a.crc8_ok,
                            snr_db,
                        },
                    );
                });

                if raw.len() >= FFT_N * 2 && last_spec.elapsed() >= Duration::from_millis(110) {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted.get(sorted.len() / 2).copied().unwrap_or(-110.0);
                    for v in floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: floor[usable.clone()].to_vec(),
                        center_hz: ism_hz - offset,
                    });
                }

                // Flush a held repeat group once its quiet period passes.
                if let Some(p) = pending.as_ref() {
                    if p.since.elapsed() >= Duration::from_millis(600) {
                        flush_ism(&ui_tx, &mut pending);
                    }
                }

                if last_push.elapsed() >= Duration::from_millis(500) {
                    last_push = std::time::Instant::now();
                    send!(UiMsg::IsmStatus {
                        bursts,
                        decoded,
                        with_crc,
                        mean_dbfs: 20.0 * mean_mag.max(1e-6).log10(),
                        peak_dbfs: 20.0 * peak_mag.max(1e-6).log10(),
                        channel_hz: ism_hz,
                    });
                }
            }
        }

        // --- Pagers (POCSAG) --------------------------------------------
        //
        // One narrow FM channel, decoded and listenable at the same time.
        //
        // The thing worth knowing about this mode is that it brute-forces
        // what it cannot know. There is nothing in a paging transmission
        // that announces its bit rate, and polarity depends on the receive
        // chain rather than on the standard — so six decoders run over the
        // same audio, one per bit rate and polarity, and the BCH check
        // decides which of them is right. A wrong lane produces nothing at
        // all rather than producing rubbish, which is what makes the
        // brute force safe as well as cheap.
        let wants_pager = {
            let u = utterance.trim().to_ascii_lowercase();
            u == "pager"
                || u == "pagers"
                || u == "pocsag"
                || u.starts_with("pager ")
                || u.starts_with("pocsag ")
        };
        if wants_pager {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            // "pager 931.9375" parks on that channel; bare "pager" uses the
            // first of the four channels shared Canada-wide and US-wide,
            // which is the likeliest to carry anything anywhere.
            let chan_hz = utterance
                .trim()
                .split_whitespace()
                .nth(1)
                .and_then(|t| t.parse::<f64>().ok())
                .map(|m| m * 1e6)
                .unwrap_or(pocsag::NATIONWIDE_HZ[0]);
            // Park 60 kHz low so the dongle's DC spike never lands on the
            // channel, then mix it back to baseband.
            let offset = 60_000.0f64;
            {
                let mut d = dev.lock().unwrap();
                let _ = d.set_center_hz(chan_hz - offset);
                let _ = d.reset_buffer();
            }
            reader.flush();
            send!(UiMsg::PlanLoaded {
                name: format!("Pagers — {:.4} MHz", chan_hz / 1e6),
                windows: 1,
                channels: 1,
                single_window: true,
            });
            send!(UiMsg::Log(format!(
                "POCSAG: parked on {:.4} MHz, decoding 512/1200/2400 baud in both \
                 polarities at once",
                chan_hz / 1e6
            )));

            let mut tap = PagerTap::new(offset as f32, IF_RATE as f32);
            let mut iq: Vec<Complex32> = Vec::new();
            let mut pages: Vec<pocsag::Page> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let mut last_spec = std::time::Instant::now();
            let mut floor = vec![-110.0f32; FFT_N];
            let mut mean_mag = 0.0f32;
            let mut peak_mag = 0.0f32;
            let mut got: u64 = 0;
            // Pagers repeat a page across several batches, and the same
            // page decoded twice is one event, not two. Keyed on address
            // and content rather than on time, because a genuine repeat
            // minutes later is also one event as far as a log is concerned
            // and showing it twice reads as two incidents.
            let mut recent: VecDeque<(u32, String)> = VecDeque::new();

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }
                let raw = reader.take(READ_CHUNK * 4);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                iq.clear();
                iq.reserve(raw.len() / 2);
                let mut sum = 0.0f32;
                let mut pk = 0.0f32;
                for b in raw.chunks_exact(2) {
                    let i = (b[0] as f32 - 127.4) / 127.5;
                    let q = (b[1] as f32 - 127.4) / 127.5;
                    iq.push(Complex32::new(i, q));
                    let m = i * i + q * q;
                    sum += m;
                    if m > pk {
                        pk = m;
                    }
                }
                if !iq.is_empty() {
                    let m = (sum / iq.len() as f32).sqrt();
                    mean_mag = if mean_mag == 0.0 { m } else { mean_mag * 0.8 + m * 0.2 };
                    peak_mag = peak_mag.max(pk.sqrt()) * 0.98;
                }

                pages.clear();
                tap.process(&iq, &mut pages);
                for p in pages.iter() {
                    let m = &p.message;
                    let body = m.best().to_string();
                    let key = (m.ric, body.clone());
                    if recent.contains(&key) {
                        continue;
                    }
                    if recent.len() >= 64 {
                        recent.pop_front();
                    }
                    recent.push_back(key);
                    got += 1;
                    let reading = match m.reading {
                        Reading::Text => "text",
                        Reading::Numeric => "numeric",
                        Reading::Ambiguous => "unclear",
                    };
                    send!(UiMsg::Log(format!(
                        ">> pager {}  {}",
                        m.ric,
                        if m.tone_only() {
                            "(tone only)".to_string()
                        } else {
                            body.clone()
                        }
                    )));
                    send!(UiMsg::PagerPage {
                        when: clock_time(),
                        ric: m.ric,
                        func: m.func,
                        text: m.text.clone(),
                        numeric: m.numeric.clone(),
                        reading,
                        ambiguous: m.reading == Reading::Ambiguous,
                        codewords: m.codewords,
                        repaired_one: m.repaired_one,
                        repaired_two: m.repaired_two,
                        dropped: m.dropped,
                        baud: p.baud,
                        inverted: p.inverted,
                    });
                }

                // Audio through, so the channel can be heard as well as
                // read. POCSAG sounds like a short harsh warble; it is not
                // pleasant, but hearing it is the fastest way to know the
                // radio is on a live channel.
                write_audio!(tap.audio());
                {
                    let mut buf = ring.lock().unwrap();
                    for &v in tap.audio() {
                        buf.push_back((v * 0.25 * volume).clamp(-1.0, 1.0));
                    }
                    let cap = (audio_rate as usize) * 2;
                    if buf.len() > cap {
                        let drop_n = buf.len() - cap;
                        buf.drain(..drop_n);
                    }
                }

                if raw.len() >= FFT_N * 2 && last_spec.elapsed() >= Duration::from_millis(110) {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted.get(sorted.len() / 2).copied().unwrap_or(-110.0);
                    for v in floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: floor[usable.clone()].to_vec(),
                        center_hz: chan_hz - offset,
                    });
                }

                if last_push.elapsed() >= Duration::from_millis(500) {
                    last_push = std::time::Instant::now();
                    let (syncs, ok, repaired, dropped) = tap.channel.totals();
                    send!(UiMsg::PagerStatus {
                        pages: got,
                        syncs,
                        codewords_ok: ok,
                        codewords_repaired: repaired,
                        codewords_dropped: dropped,
                        mean_dbfs: 20.0 * mean_mag.max(1e-6).log10(),
                        peak_dbfs: 20.0 * peak_mag.max(1e-6).log10(),
                        channel_hz: chan_hz,
                        lanes: tap.channel.lane_syncs(),
                    });
                }
            }
        }

        // --- APRS -------------------------------------------------------
        //
        // One narrow FM channel, so unlike AIS and ADS-B this one can be
        // listened to as well as decoded: packet bursts have a distinctive
        // chirp, and hearing them is the fastest confirmation the radio is
        // in the right place.
        let wants_aprs = {
            let u = utterance.trim();
            u.eq_ignore_ascii_case("aprs") || u.eq_ignore_ascii_case("ham position beacons")
        };
        if wants_aprs {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            // Park 60 kHz low so the dongle's DC spike never lands on the
            // channel, then mix it back to baseband — the same reason the
            // scanner's own planner avoids centre.
            let offset = 60_000.0f64;
            {
                let mut d = dev.lock().unwrap();
                let _ = d.set_center_hz(APRS_HZ - offset);
                let _ = d.reset_buffer();
            }
            reader.flush();
            send!(UiMsg::PlanLoaded {
                name: "APRS — 144.390 MHz".to_string(),
                windows: 1,
                channels: 1,
                single_window: true,
            });
            send!(UiMsg::Log("APRS: parked on 144.390 MHz".into()));

            let mut tap = AprsTap::new(offset as f32, IF_RATE as f32);
            let mut table = StationTable::new();
            let mut iq: Vec<Complex32> = Vec::new();
            let mut frames: Vec<sweep_core::aprs::Frame> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let mut last_spec = std::time::Instant::now();
            let mut floor = vec![-110.0f32; FFT_N];
            let mut mean_mag = 0.0f32;
            let mut peak_mag = 0.0f32;
            let mut got: u64 = 0;

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }
                let raw = reader.take(READ_CHUNK * 4);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                iq.clear();
                iq.reserve(raw.len() / 2);
                let mut sum = 0.0f32;
                let mut pk = 0.0f32;
                for b in raw.chunks_exact(2) {
                    let i = (b[0] as f32 - 127.4) / 127.5;
                    let q = (b[1] as f32 - 127.4) / 127.5;
                    iq.push(Complex32::new(i, q));
                    let m = i * i + q * q;
                    sum += m;
                    if m > pk {
                        pk = m;
                    }
                }
                if !iq.is_empty() {
                    let m = (sum / iq.len() as f32).sqrt();
                    mean_mag = if mean_mag == 0.0 { m } else { mean_mag * 0.8 + m * 0.2 };
                    peak_mag = peak_mag.max(pk.sqrt()) * 0.98;
                }

                frames.clear();
                tap.process(&iq, &mut frames);
                for f in frames.iter() {
                    if let Some(p) = sweep_core::aprs::parse_ax25(&f.bytes) {
                        let call = table.ingest(&p);
                        got += 1;
                        send!(UiMsg::Log(format!(">> {call}  {}", p.info.trim())));
                    }
                }

                // Audio straight through, so the channel can be monitored.
                write_audio!(tap.audio());
                {
                    let mut buf = ring.lock().unwrap();
                    for &v in tap.audio() {
                        buf.push_back((v * 0.25 * volume).clamp(-1.0, 1.0));
                    }
                    let cap = (audio_rate as usize) * 2;
                    if buf.len() > cap {
                        let drop_n = buf.len() - cap;
                        buf.drain(..drop_n);
                    }
                }

                if raw.len() >= FFT_N * 2 && last_spec.elapsed() >= Duration::from_millis(110) {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted.get(sorted.len() / 2).copied().unwrap_or(-110.0);
                    for v in floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: floor[usable.clone()].to_vec(),
                        center_hz: APRS_HZ - offset,
                    });
                }

                if last_push.elapsed() >= Duration::from_millis(500) {
                    last_push = std::time::Instant::now();
                    table.expire();
                    let stations: Vec<StationView> = table
                        .snapshot()
                        .into_iter()
                        .map(|s| StationView {
                            call: s.call.clone(),
                            kind: s.kind(),
                            lat: s.lat,
                            lon: s.lon,
                            course_deg: s.course_deg,
                            speed_kt: s.speed_kt,
                            altitude_ft: s.altitude_ft,
                            comment: s.comment.clone(),
                            via: s.via.clone(),
                            packets: s.packets,
                            age_s: s.age().as_secs_f32(),
                        })
                        .collect();
                    send!(UiMsg::Aprs {
                        stations,
                        packets: got,
                        mean_dbfs: 20.0 * mean_mag.max(1e-6).log10(),
                        peak_dbfs: 20.0 * peak_mag.max(1e-6).log10(),
                    });
                }
            }
        }

        // --- AIS --------------------------------------------------------
        //
        // Like ADS-B, this is data rather than audio and the planner has
        // nothing useful to say about it. Unlike ADS-B it needs no change
        // of sample rate: both channels fit inside one 2.4 MHz window, so
        // the tuner parks between them and each is mixed down in turn.
        let wants_ais = {
            let u = utterance.trim();
            u.eq_ignore_ascii_case("ais") || u.eq_ignore_ascii_case("ship positions")
        };
        if wants_ais {
            if hf_mode {
                if dev
                    .lock()
                    .unwrap()
                    .set_direct_sampling(DirectSampling::Off)
                    .is_ok()
                {
                    hf_mode = false;
                }
            }
            let centre = (AIS_A_HZ + AIS_B_HZ) / 2.0;
            {
                let mut d = dev.lock().unwrap();
                let _ = d.set_center_hz(centre);
                let _ = d.reset_buffer();
            }
            reader.flush();
            send!(UiMsg::PlanLoaded {
                name: "AIS — 161.975 / 162.025 MHz".to_string(),
                windows: 1,
                channels: 2,
                single_window: true,
            });
            send!(UiMsg::Log(
                "AIS: both channels at once, parked on 162.000 MHz".into()
            ));

            let half = ((AIS_B_HZ - AIS_A_HZ) / 2.0) as f32;
            let mut taps = [
                AisTap::new(-half, IF_RATE as f32),
                AisTap::new(half, IF_RATE as f32),
            ];
            let mut table = VesselTable::new();
            let mut iq: Vec<Complex32> = Vec::new();
            let mut frames: Vec<sweep_core::ais::Frame> = Vec::new();
            let mut last_push = std::time::Instant::now();
            let mut last_spec = std::time::Instant::now();
            let mut ais_floor = vec![-110.0f32; FFT_N];
            let mut mean_mag = 0.0f32;
            let mut peak_mag = 0.0f32;
            let mut got: u64 = 0;

            loop {
                match cmd_rx.try_recv() {
                    Ok(cmd) => handle_cmd!(cmd),
                    Err(TryRecvError::Disconnected) => break 'outer,
                    Err(TryRecvError::Empty) => {}
                }
                let raw = reader.take(READ_CHUNK * 8);
                if raw.is_empty() {
                    thread::sleep(Duration::from_millis(5));
                    continue;
                }
                write_iq!(raw);

                iq.clear();
                iq.reserve(raw.len() / 2);
                let mut sum = 0.0f32;
                let mut pk = 0.0f32;
                for b in raw.chunks_exact(2) {
                    let i = (b[0] as f32 - 127.4) / 127.5;
                    let q = (b[1] as f32 - 127.4) / 127.5;
                    iq.push(Complex32::new(i, q));
                    let m = i * i + q * q;
                    sum += m;
                    if m > pk {
                        pk = m;
                    }
                }
                if !iq.is_empty() {
                    let m = (sum / iq.len() as f32).sqrt();
                    mean_mag = if mean_mag == 0.0 { m } else { mean_mag * 0.8 + m * 0.2 };
                    peak_mag = peak_mag.max(pk.sqrt()) * 0.98;
                }

                for t in taps.iter_mut() {
                    frames.clear();
                    t.process(&iq, &mut frames);
                    for f in frames.iter() {
                        if let Some(m) = sweep_core::ais::decode(f.payload()) {
                            table.ingest(&m);
                            got += 1;
                        }
                    }
                }

                if raw.len() >= FFT_N * 2 && last_spec.elapsed() >= Duration::from_millis(110) {
                    last_spec = std::time::Instant::now();
                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                    let mut sorted: Vec<f32> = frame_db[usable.clone()].to_vec();
                    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                    let med = sorted.get(sorted.len() / 2).copied().unwrap_or(-110.0);
                    for v in ais_floor.iter_mut() {
                        *v = med;
                    }
                    send!(UiMsg::Spectrum {
                        bins: frame_db[usable.clone()].to_vec(),
                        floor: ais_floor[usable.clone()].to_vec(),
                        center_hz: centre,
                    });
                }

                if last_push.elapsed() >= Duration::from_millis(500) {
                    last_push = std::time::Instant::now();
                    table.expire();
                    let vessels: Vec<VesselView> = table
                        .snapshot()
                        .into_iter()
                        .map(|v| VesselView {
                            mmsi: v.mmsi,
                            label: v.label(),
                            name: v.name.clone(),
                            callsign: v.callsign.clone(),
                            flag: v.flag(),
                            kind: sweep_core::ais::ship_type_text(v.ship_type),
                            status: v
                                .nav_status
                                .map(sweep_core::ais::nav_status_text)
                                .unwrap_or(""),
                            destination: v.destination.clone(),
                            lat: v.lat,
                            lon: v.lon,
                            sog_kt: v.sog_kt,
                            cog_deg: v.cog_deg,
                            heading_deg: v.heading_deg,
                            class_b: v.class_b,
                            messages: v.messages,
                            age_s: v.age().as_secs_f32(),
                        })
                        .collect();
                    send!(UiMsg::Ais {
                        vessels,
                        frames_ok: got,
                        mean_dbfs: 20.0 * mean_mag.max(1e-6).log10(),
                        peak_dbfs: 20.0 * peak_mag.max(1e-6).log10(),
                    });
                }
            }
        }

        let mut plan = match rules::parse(&utterance) {
            Some(p) => p,
            None => {
                send!(UiMsg::PlanError(format!(
                    "didn't understand \"{utterance}\" — try a band name (aviation, \
                     marine, weather, 2m, 70cm, frs, fm) or a frequency like 146.520"
                )));
                loop {
                    match cmd_rx.recv() {
                        Ok(cmd) => handle_cmd!(cmd),
                        Err(_) => break 'outer,
                    }
                }
            }
        };
        if let Some(m) = pending_mode {
            plan.demod = m;
        }
        if let Some(sq) = squelch_override {
            plan.squelch_db = sq;
        }
        // Anything below the R828D's ~24 MHz tuning floor can only be
        // reached through the direct-sampling path, which bypasses the
        // tuner and samples the ADC directly. The V4 is wired for Q-branch.
        let wants_hf = plan
            .channels
            .iter()
            .map(|c| c.freq_mhz)
            .chain(plan.windows.iter().map(|w| w.f0))
            .any(|f| f < 24.0);
        if wants_hf != hf_mode {
            let mode = if wants_hf {
                DirectSampling::QBranch
            } else {
                DirectSampling::Off
            };
            match dev.lock().unwrap().set_direct_sampling(mode) {
                Ok(()) => {
                    hf_mode = wants_hf;
                    send!(UiMsg::Log(
                        if wants_hf {
                            "HF direct sampling ON — tuner bypassed".to_string()
                        } else {
                            "HF direct sampling off — normal tuner path".to_string()
                        }
                    ));
                }
                Err(e) => send!(UiMsg::Log(format!("direct sampling: {e}"))),
            }
        }
        let run = match resolve(&plan, wants_hf) {
            Ok(r) => r,
            Err(e) => {
                send!(UiMsg::PlanError(format!("plan rejected: {e}")));
                loop {
                    match cmd_rx.recv() {
                        Ok(cmd) => handle_cmd!(cmd),
                        Err(_) => break 'outer,
                    }
                }
            }
        };
        send!(UiMsg::PlanLoaded {
            name: plan.name.clone(),
            windows: run.windows.len(),
            channels: run.channels.len(),
            single_window: run.is_single_window(),
        });

        let mut sched = Scheduler::new(run.clone());
        // A one-channel plan means the person deliberately tuned to a
        // frequency rather than asking for a search. Sweep mode would
        // observe it first and only open if measured SNR clears squelch —
        // so a station plainly visible on the spectrum stays silent
        // whenever the floor estimate is off. Park instead: tuning a radio
        // to a frequency should just play it.
        if run.channels.len() == 1 {
            sched.set_mode(SchedMode::Park(0));
            send!(UiMsg::Log("parked — audio on, squelch bypassed".into()));
        }
        let mut watches: HashMap<usize, WindowWatch> = HashMap::new();
        let mut demods: HashMap<usize, AnyChannel> = HashMap::new();
        let mut sweep_demods: HashMap<i64, AnyChannel> = HashMap::new();
        let mut mixers: HashMap<usize, Mixer> = HashMap::new();
        let mut rds_taps: HashMap<usize, RdsTap> = HashMap::new();
        let mut rds_sweep_taps: HashMap<i64, RdsTap> = HashMap::new();
        // Frequencies (in kHz) locked onto recently. Keeps the sweep from
        // re-selecting the same dominant station on every pass and never
        // reaching the weaker ones sharing its window. Per-plan, so
        // switching bands starts fresh.
        let mut recent_locks: VecDeque<i64> = VecDeque::new();
        let mut current_center: Option<f64> = None;
        let mut last_window_reported = usize::MAX;

        loop {
            match cmd_rx.try_recv() {
                Ok(cmd) => handle_cmd!(cmd),
                Err(TryRecvError::Disconnected) => break 'outer,
                Err(TryRecvError::Empty) => {}
            }

            // The other half of the turn. A transmission in progress is
            // never cut off: the scheduler is only in Sweep mode when
            // nothing is open, so checking that is what makes the handover
            // wait for a quiet moment rather than clipping somebody
            // mid-sentence.
            if dual
                && utterance.trim().eq_ignore_ascii_case("aviation")
                && dual_since.elapsed() >= Duration::from_secs(LISTEN_SECS)
                && matches!(sched.mode(), SchedMode::Sweep)
            {
                dual_since = std::time::Instant::now();
                utterance = "adsb".to_string();
                send!(UiMsg::Log("back to tracking aircraft on 1090 MHz".into()));
                continue 'outer;
            }

            let task = sched.next();
            let center_hz = task.center_mhz() * 1e6;
            if current_center != Some(center_hz) {
                {
                    let mut d = dev.lock().unwrap();
                    d.set_center_hz(center_hz).ok();
                    d.reset_buffer().ok();
                }
                // Anything already captured belongs to the old frequency.
                reader.flush();
                current_center = Some(center_hz);
            }

            match task {
                Task::Observe { window, .. } => {
                    if window != last_window_reported {
                        send!(UiMsg::WindowTick {
                            window,
                            windows: run.windows.len(),
                            center_mhz: task.center_mhz(),
                        });
                        last_window_reported = window;
                    }

                    let watch = watches.entry(window).or_insert_with(WindowWatch::new);
                    let min_bytes = FFT_N * 2 * INTEGRATE_FRAMES as usize;
                    let raw = reader.take(min_bytes);
                    write_iq!(raw);

                    for chunk in raw.chunks_exact(FFT_N * 2) {
                        spec.process_u8(chunk, &mut frame_db);
                        if watch.integ.push_db(&frame_db) {
                            watch.integ.take(&mut watch.last_spectrum);
                            spec.blank_dc(&mut watch.last_spectrum, IF_RATE, 30_000.0, -140.0);
                            watch.floor.update(&watch.last_spectrum);
                            send!(UiMsg::Spectrum {
                                bins: watch.last_spectrum[usable.clone()].to_vec(),
                                floor: watch.floor.get()[usable.clone()].to_vec(),
                                center_hz: task.center_mhz() * 1e6,
                            });
                        }
                    }

                    let bin_hz = IF_RATE as f64 / FFT_N as f64;
                    let f0 = task.center_mhz() * 1e6 - IF_RATE as f64 / 2.0;
                    let mut matched_channel = false;
                    // A per-bin adaptive floor works when a band is mostly
                    // Detection reference for a channelized band.
                    //
                    // Estimating "the noise floor" is the wrong tool here.
                    // The adaptive estimator assumes whatever is
                    // persistently present is noise — true in a quiet band,
                    // false in FM broadcast where the persistent thing IS
                    // the stations, so the floor climbs onto them and every
                    // channel measures near 0 dB.
                    //
                    // Instead compare each channel against the other
                    // channels in the same window. In any real band most
                    // channels are empty, so the median channel level is a
                    // direct measurement of "what an empty channel looks
                    // like right now" — self-calibrating, no noise model,
                    // and it tracks gain changes for free. Squelch then
                    // means what it should: how far above an empty channel
                    // is worth stopping for.
                    let chan_levels: Vec<(usize, f32)> = run.windows[window]
                        .channels
                        .iter()
                        .filter_map(|&ci| {
                            let ch = &run.channels[ci];
                            let bin =
                                (((ch.freq_mhz * 1e6) - f0) / bin_hz).round() as isize;
                            if bin < 0 || bin as usize >= FFT_N {
                                return None;
                            }
                            Some((ci, watch.last_spectrum[bin as usize]))
                        })
                        .collect();

                    // Falls back to the old percentile-of-spectrum when a
                    // window has too few channels for a median to mean
                    // anything.
                    let reference = if chan_levels.len() >= 4 {
                        let mut lv: Vec<f32> = chan_levels.iter().map(|(_, v)| *v).collect();
                        lv.sort_by(|a, b| a.partial_cmp(b).unwrap());
                        lv[lv.len() / 2]
                    } else {
                        let mut s: Vec<f32> = watch.last_spectrum.clone();
                        s.sort_by(|a, b| a.partial_cmp(b).unwrap());
                        s[s.len() / 5]
                    };

                    // Report the strongest channel in this window even when
                    // nothing opens. Without this a silent scanner is
                    // indistinguishable from a broken one — this says
                    // whether signal is being seen at all, and how far off
                    // squelch it is.
                    let mut best_seen: Option<(f64, f32)> = None;
                    for &(ci, level) in &chan_levels {
                        let ch = &run.channels[ci];
                        let snr = level - reference;
                        if best_seen.map_or(true, |(_, s)| snr > s) {
                            best_seen = Some((ch.freq_mhz, snr));
                        }
                        if recent_locks.contains(&((ch.freq_mhz * 1000.0).round() as i64)) {
                            continue;
                        }
                        if snr >= sched.plan().squelch_db as f32 && !ch.locked_out {
                            send!(UiMsg::SignalFound {
                                freq_mhz: ch.freq_mhz,
                                snr_db: snr,
                                label: ch.label.clone(),
                            });
                            send!(UiMsg::Log(format!(
                                ">> {} ({:.4} MHz) — {:.0} dB over floor",
                                ch.label, ch.freq_mhz, snr
                            )));
                            vad.reset();
                            voice_ms = 0;
                            voice_confirmed = false;
                            sched.stop_and_listen(ci);
                            matched_channel = true;
                            break;
                        }
                    }
                    if !matched_channel {
                        if let Some((f, s)) = best_seen {
                            send!(UiMsg::Log(format!(
                                "· best in window: {f:.3} MHz at {s:.0} dB (squelch {:.0})",
                                sched.plan().squelch_db
                            )));
                        }
                    }

                    // Bare sweep, no predefined channel list: work through
                    // everything the detector finds in this window.
                    if !matched_channel && run.windows[window].channels.is_empty() {
                        let det = Detector::default();
                        let mut dets =
                            det.scan(&watch.last_spectrum, watch.floor.get(), f0, bin_hz);
                        dets.retain(|d| d.snr_db >= sched.plan().squelch_db as f32);
                        dets.sort_by(|a, b| b.snr_db.partial_cmp(&a.snr_db).unwrap());

                        // Every hit gets reported, so the found-list and the
                        // BACK history actually reflect what's on the air —
                        // previously only the single loudest per window was
                        // ever surfaced, which is why a band full of
                        // stations looked like two or three.
                        for d in &dets {
                            send!(UiMsg::SignalFound {
                                freq_mhz: d.center_hz / 1e6,
                                snr_db: d.snr_db,
                                label: "SIGNAL".into(),
                            });
                            send!(UiMsg::Log(format!(
                                ">> signal at {:.4} MHz — {:.0} dB over floor",
                                d.center_hz / 1e6,
                                d.snr_db
                            )));
                        }

                        // Listen to the strongest one we haven't just been
                        // sitting on. Without this the sweep re-locks the
                        // same dominant station every pass and never reaches
                        // the weaker ones sharing the window.
                        // Copied out rather than held as a reference — the
                        // closure below borrows `recent_locks`, which gets
                        // mutated a few lines down.
                        let pick: Option<f64> = dets
                            .iter()
                            .find(|d| {
                                let k = (d.center_hz / 1000.0).round() as i64;
                                !recent_locks.contains(&k)
                            })
                            .map(|d| d.center_hz);
                        if let Some(found_hz) = pick {
                            let key = (found_hz / 1000.0).round() as i64;
                            recent_locks.push_back(key);
                            while recent_locks.len() > 12 {
                                recent_locks.pop_front();
                            }
                            {
                                let mut d = dev.lock().unwrap();
                                d.set_center_hz(found_hz).ok();
                                d.reset_buffer().ok();
                            }
                            reader.flush();

                            let mut sq = Squelch::new(
                                sched.plan().squelch_db as f32,
                                sched.plan().hang_ms,
                            );
                            sq.update(sched.plan().squelch_db as f32 + 5.0, 0);
                            let mut locked_ms: u32 = 0;
                            const AUTO_SCAN_DWELL_MS: u32 = 8_000;

                                loop {
                                    match cmd_rx.try_recv() {
                                        Ok(Cmd::SkipSignal) => {
                                            send!(UiMsg::SignalEnded);
                                            send!(UiMsg::Log("↷ skipped, resuming sweep".into()));
                                            break;
                                        }
                                        Ok(cmd) => handle_cmd!(cmd),
                                        Err(_) => {}
                                    }

                                    let ms = 100u32;
                                    let min_bytes =
                                        (ms as usize * (IF_RATE as usize / 1000)) * 2;
                                    let raw = reader.take(min_bytes);
                                    write_iq!(raw);
                                    let iq: Vec<Complex32> = raw
                                        .chunks_exact(2)
                                        .map(|b| {
                                            Complex32::new(
                                                (b[0] as f32 - 127.4) / 127.5,
                                                (b[1] as f32 - 127.4) / 127.5,
                                            )
                                        })
                                        .collect();

                                    let demod = sweep_demods.entry(key).or_insert_with(|| {
                                        AnyChannel::new(
                                            plan.demod,
                                            IF_RATE as f32,
                                            audio_rate,
                                            bw_override_khz.map(|k| k * 1000.0).unwrap_or_else(|| {
                                                run.channels
                                                    .first()
                                                    .map(|c| c.bw_khz as f32 * 1000.0)
                                                    .unwrap_or(
                                                        plan.demod.default_bw_khz() as f32 * 1000.0,
                                                    )
                                            }),
                                        )
                                    });
                                    let mut audio = Vec::new();
                                    demod.process(&iq, &mut audio);
                                    write_audio!(audio);
                                    if plan.demod == Demod::Wfm {
                                        let tap = rds_sweep_taps
                                            .entry(key)
                                            .or_insert_with(|| RdsTap::new(IF_RATE as f32));
                                        tap.process(&iq);
                                        if tap.rds.locked {
                                            send!(UiMsg::Rds {
                                                ps: tap.rds.data.ps_string(),
                                                radiotext: tap.rds.data.radiotext_string(),
                                                pty: tap.rds.data.pty,
                                            });
                                        }
                                    }
                                    let peak =
                                        audio.iter().cloned().fold(0.0f32, |a, b| a.max(b.abs()));
                                    {
                                        let mut buf = ring.lock().unwrap();
                                        while buf.len() + audio.len() > 240_000 {
                                            buf.pop_front();
                                        }
                                        buf.extend(audio.iter().map(|&s| (s * volume).clamp(-1.0, 1.0)));
                                    }

                                    let snr = if raw.len() >= FFT_N * 2 {
                                        spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                                        watch.floor.update(&frame_db);
                                        frame_db[FFT_N / 2] - watch.floor.get()[FFT_N / 2]
                                    } else {
                                        0.0
                                    };

                                    send!(UiMsg::Listening {
                                        center_mhz: found_hz / 1e6,
                                        label: "SIGNAL".into(),
                                        snr_db: snr,
                                        audio_peak: peak,
                                    });

                                    if sq.update(snr, ms) == SquelchState::Closed {
                                        send!(UiMsg::SignalEnded);
                                        send!(UiMsg::Log(
                                            "<< signal ended, resuming sweep".into()
                                        ));
                                        break;
                                    }
                                    locked_ms += ms;
                                    if auto_scan && locked_ms >= AUTO_SCAN_DWELL_MS {
                                        send!(UiMsg::SignalEnded);
                                        send!(UiMsg::Log(
                                            "↻ auto-scan: dwell elapsed, resuming sweep".into()
                                        ));
                                        break;
                                    }
                                }
                                current_center = None; // force a retune back into the sweep
                        }
                    }
                }

                Task::Listen {
                    channel, window, ms, ..
                } => {
                    let ch = &run.channels[channel];
                    let min_bytes = (ms as usize * (IF_RATE as usize / 1000)) * 2;
                    let raw = reader.take(min_bytes);
                    write_iq!(raw);
                    let mut iq: Vec<Complex32> = raw
                        .chunks_exact(2)
                        .map(|b| {
                            Complex32::new(
                                (b[0] as f32 - 127.4) / 127.5,
                                (b[1] as f32 - 127.4) / 127.5,
                            )
                        })
                        .collect();

                    // The tuner is parked on the window centre, which
                    // avoid_dc keeps clear of every channel — so the wanted
                    // signal sits at an offset and must be translated down
                    // to zero before the demod chain's baseband lowpass can
                    // see it.
                    let offset_hz =
                        (ch.freq_mhz * 1e6 - task.center_mhz() * 1e6) as f32;
                    let mixer = mixers.entry(channel).or_insert_with(|| {
                        Mixer::new(offset_hz, IF_RATE as f32)
                    });
                    // Rebuild if the plan moved this channel into a
                    // differently-centred window.
                    if (mixer.offset_hz(IF_RATE as f32) - offset_hz).abs() > 1.0 {
                        *mixer = Mixer::new(offset_hz, IF_RATE as f32);
                    }
                    mixer.shift(&mut iq);

                    let demod = demods.entry(channel).or_insert_with(|| {
                        let bw = bw_override_khz
                            .map(|k| k * 1000.0)
                            .unwrap_or(ch.demod.default_bw_khz() as f32 * 1000.0);
                        AnyChannel::new(ch.demod, IF_RATE as f32, audio_rate, bw)
                    });
                    let mut audio = Vec::new();
                    demod.process(&iq, &mut audio);
                    write_audio!(audio);
                    if voice_only {
                        vad.push(&audio);
                        voice_ms += ms;
                        let v = vad.verdict();
                        // Two things matter here, and the first version got
                        // both wrong:
                        //
                        // 1. Judge only after a real stretch of audio.
                        //    Syllable rhythm needs more than a fraction of
                        //    a second to show up; judging at 0.4 s rejected
                        //    speech that simply hadn't got going yet.
                        //
                        // 2. Latch a positive verdict. Speech pauses —
                        //    between words, between sentences — and
                        //    re-judging every slice meant a gap flipped the
                        //    verdict and the scanner bailed mid-sentence.
                        // Per-mode pass mark. The detector's own 0.55 is
                        // tuned for clean narrowband FM; AM aviation voice
                        // comes through an envelope detector full of hiss,
                        // which inflates the zero-crossing rate and drags a
                        // perfectly good transmission down to the low 0.4s —
                        // which is exactly how a real pilot call was getting
                        // thrown out as "not speech". AM gets a much lower
                        // bar; a steady carrier or a data burst still scores
                        // well under it (~0.2), so carriers are still walked
                        // past.
                        let voice_thresh = if ch.demod == Demod::Am { 0.36 } else { 0.50 };
                        if v.score >= voice_thresh {
                            voice_confirmed = true;
                        }
                        if !voice_confirmed && voice_ms >= 1_500 && v.score < voice_thresh {
                            recent_locks.push_back((ch.freq_mhz * 1000.0).round() as i64);
                            while recent_locks.len() > 12 {
                                recent_locks.pop_front();
                            }
                            vad.reset();
                            voice_ms = 0;
                            voice_confirmed = false;
                            sched.set_mode(SchedMode::Sweep);
                            send!(UiMsg::SignalEnded);
                            send!(UiMsg::Log(format!(
                                "⇢ {:.4} MHz not speech (score {:.2}), skipping",
                                ch.freq_mhz, v.score
                            )));
                            current_center = None;
                            continue;
                        }
                    }
                    // RDS runs its own mixer and wideband filter at the full
                    // 2.4 MS/s rate — more expensive than the audio chain it
                    // sits beside. Station name and text only need to
                    // arrive every few seconds, so run it on a duty cycle
                    // and leave the CPU to the audio, which is what
                    // dropouts come out of.
                    rds_slice = rds_slice.wrapping_add(1);
                    if ch.demod == Demod::Wfm && rds_slice % 4 == 0 {
                        let tap = rds_taps
                            .entry(channel)
                            .or_insert_with(|| RdsTap::new(IF_RATE as f32));
                        tap.process(&iq);
                        if tap.rds.locked {
                            send!(UiMsg::Rds {
                                ps: tap.rds.data.ps_string(),
                                radiotext: tap.rds.data.radiotext_string(),
                                pty: tap.rds.data.pty,
                            });
                        }
                    }
                    let peak = audio.iter().cloned().fold(0.0f32, |a, b| a.max(b.abs()));
                    {
                        let mut buf = ring.lock().unwrap();
                        while buf.len() + audio.len() > 240_000 {
                            buf.pop_front();
                        }
                        buf.extend(audio.iter().map(|&s| (s * volume).clamp(-1.0, 1.0)));
                    }

                    let mut snr = 0.0f32;
                    // In park mode no Observe task ever runs for this
                    // window, so `watches` would have no entry and SNR
                    // silently stayed 0 — an S0 reading on a station that's
                    // plainly playing. Create it on demand.
                    {
                        let watch = watches.entry(window).or_insert_with(WindowWatch::new);
                        let bin_hz = IF_RATE as f64 / FFT_N as f64;
                        let f0 = task.center_mhz() * 1e6 - IF_RATE as f64 / 2.0;
                        let bin = (((ch.freq_mhz * 1e6) - f0) / bin_hz).round() as isize;
                        if raw.len() >= FFT_N * 2 && bin >= 0 && (bin as usize) < FFT_N {
                            spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                            watch.floor.update(&frame_db);
                            // Same reference the scan path uses — the median
                            // of the other channels in this window, which
                            // measures an empty channel directly rather than
                            // estimating a noise floor. Using a different
                            // reference here would make the S-meter disagree
                            // with the SNR that opened squelch.
                            let mut lv: Vec<f32> = run.windows[window]
                                .channels
                                .iter()
                                .filter_map(|&ci| {
                                    let c = &run.channels[ci];
                                    let b = (((c.freq_mhz * 1e6) - f0) / bin_hz).round() as isize;
                                    if b < 0 || b as usize >= FFT_N {
                                        return None;
                                    }
                                    Some(frame_db[b as usize])
                                })
                                .collect();
                            let reference = if lv.len() >= 4 {
                                lv.sort_by(|a, b| a.partial_cmp(b).unwrap());
                                lv[lv.len() / 2]
                            } else {
                                let mut s = frame_db.clone();
                                s.sort_by(|a, b| a.partial_cmp(b).unwrap());
                                s[s.len() / 5]
                            };
                            let bin = bin as usize;
                            snr = frame_db[bin] - reference;

                            // Keep the display alive while parked — the
                            // waterfall would otherwise freeze, since only
                            // Observe tasks were feeding it.
                            spec.blank_dc(&mut frame_db, IF_RATE, 30_000.0, -140.0);
                            send!(UiMsg::Spectrum {
                                bins: frame_db[usable.clone()].to_vec(),
                                floor: watch.floor.get()[usable.clone()].to_vec(),
                                center_hz: task.center_mhz() * 1e6,
                            });
                        }
                    }
                    if skip_requested {
                        skip_requested = false;
                        // Remember it briefly, or the very next Observe
                        // pass sees the same strong carrier and locks
                        // straight back onto what was just skipped.
                        recent_locks.push_back((ch.freq_mhz * 1000.0).round() as i64);
                        while recent_locks.len() > 12 {
                            recent_locks.pop_front();
                        }
                        sched.set_mode(SchedMode::Sweep);
                        send!(UiMsg::SignalEnded);
                        send!(UiMsg::Log(format!(
                            "↷ skipped {:.4} MHz, resuming sweep",
                            ch.freq_mhz
                        )));
                        current_center = None;
                        continue;
                    }
                    sched.report_snr(snr, ms);
                    send!(UiMsg::Listening {
                        center_mhz: ch.freq_mhz,
                        label: ch.label.clone(),
                        snr_db: snr,
                        audio_peak: peak,
                    });
                }
            }
        }
    }
}
