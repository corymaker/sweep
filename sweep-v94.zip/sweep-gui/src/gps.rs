//! Bridges to the two other boxes on the bench: a Garmin handheld GPS and a
//! Baofeng handheld transceiver.
//!
//! None of this is a live link. The Garmin and the Baofeng are their own
//! radios; Sweep receives through the dongle and has nothing to say to them
//! over a wire. What it *can* do is move files, which is all these bridges
//! are:
//!
//! * **Garmin → Sweep.** A Garmin mounts as a USB drive with its waypoints
//!   as GPX. [`find_garmin_waypoints`] finds that drive and
//!   [`parse_waypoints`] reads it, so a spot you marked in the field can set
//!   Sweep's receiver position — which every map and every bearing depends
//!   on, and which otherwise just sits at a default.
//! * **Sweep → Garmin.** [`write_gpx`] turns the aircraft, ships and APRS
//!   stations Sweep has decoded into GPX waypoints to drop back on the
//!   Garmin and see on its own map.
//! * **Sweep → Baofeng.** [`write_chirp_csv`] writes the frequencies you
//!   have saved as a CHIRP CSV, which CHIRP imports and writes to the
//!   handheld — so Sweep finds a channel and the Baofeng ends up tuned to
//!   it.
//!
//! Everything here is plain `std`: a small GPX reader and writer and a CSV
//! writer. No XML library, because GPX waypoints are simple enough to scan
//! directly and a dependency that has to be fetched and linked is a cost
//! this does not need.

use std::fmt::Write as _;
use std::path::PathBuf;

/// A point read from, or written to, a GPS.
#[derive(Clone, Debug, PartialEq)]
pub struct Waypoint {
    pub name: String,
    pub lat: f64,
    pub lon: f64,
    /// Free-text note. Empty when there is nothing to say.
    pub desc: String,
}

/// Pull the value of an XML attribute out of a tag's opening text.
///
/// `tag` is everything between `<wpt` and the first `>`. Attribute order is
/// not fixed in GPX — some writers put `lon` before `lat` — so each is found
/// by name rather than by position. Accepts single or double quotes.
fn attr(tag: &str, name: &str) -> Option<f64> {
    // Look for `name=` not preceded by another letter, so `lat` does not
    // match inside some longer attribute.
    let mut from = 0;
    while let Some(rel) = tag[from..].find(name) {
        let at = from + rel;
        let before_ok = at == 0 || !tag.as_bytes()[at - 1].is_ascii_alphanumeric();
        let after = &tag[at + name.len()..];
        let after = after.trim_start();
        if before_ok && after.starts_with('=') {
            let after = after[1..].trim_start();
            let quote = after.chars().next()?;
            if quote == '"' || quote == '\'' {
                let rest = &after[1..];
                if let Some(end) = rest.find(quote) {
                    return rest[..end].trim().parse().ok();
                }
            }
        }
        from = at + name.len();
    }
    None
}

/// Text between the first `<tag>` and its `</tag>`, unescaped.
fn element<'a>(block: &'a str, tag: &str) -> Option<String> {
    let open = format!("<{tag}");
    let start = block.find(&open)?;
    let gt = block[start..].find('>')? + start + 1;
    let close = format!("</{tag}>");
    let end = block[gt..].find(&close)? + gt;
    Some(unescape(block[gt..end].trim()))
}

fn unescape(s: &str) -> String {
    s.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
}

fn escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

/// Read every `<wpt>` out of GPX text.
///
/// Tolerant by design: it scans for waypoint blocks and reads the two
/// attributes and the name it needs, and ignores everything else a Garmin
/// writes (elevation, time, symbol, extensions). A waypoint with no usable
/// coordinates is skipped rather than guessed at.
pub fn parse_waypoints(gpx: &str) -> Vec<Waypoint> {
    let mut out = Vec::new();
    let mut from = 0;
    while let Some(rel) = gpx[from..].find("<wpt") {
        let start = from + rel;
        // The end of this waypoint: the next </wpt>, or a self-closing
        // <wpt .../>, whichever comes first.
        let gt = match gpx[start..].find('>') {
            Some(g) => start + g,
            None => break,
        };
        let tag = &gpx[start..gt]; // the opening tag's attributes
        let self_closing = gpx.as_bytes().get(gt.wrapping_sub(1)) == Some(&b'/');
        let (block, next) = if self_closing {
            (&gpx[start..=gt], gt + 1)
        } else if let Some(c) = gpx[gt..].find("</wpt>") {
            let end = gt + c + "</wpt>".len();
            (&gpx[start..end], end)
        } else {
            (&gpx[start..], gpx.len())
        };
        from = next;

        let lat = attr(tag, "lat");
        let lon = attr(tag, "lon");
        if let (Some(lat), Some(lon)) = (lat, lon) {
            if (-90.0..=90.0).contains(&lat) && (-180.0..=180.0).contains(&lon) {
                let name = element(block, "name").unwrap_or_default();
                let desc = element(block, "desc")
                    .or_else(|| element(block, "cmt"))
                    .unwrap_or_default();
                out.push(Waypoint {
                    name: if name.is_empty() {
                        format!("{lat:.4},{lon:.4}")
                    } else {
                        name
                    },
                    lat,
                    lon,
                    desc,
                });
            }
        }
    }
    out
}

/// Drive letters whose `Garmin\GPX` folder exists, each returned with the
/// GPX files found under it. Windows only in practice — a Garmin mounts as a
/// removable drive — but written so the scan simply finds nothing elsewhere.
pub fn find_garmin_waypoints() -> Vec<PathBuf> {
    let mut files = Vec::new();
    // Removable drives: D: through Z:. A Garmin puts its waypoints under
    // \Garmin\GPX (sometimes in a Waypoints subfolder, sometimes loose).
    for letter in b'D'..=b'Z' {
        let root = format!("{}:\\Garmin\\GPX", letter as char);
        collect_gpx(std::path::Path::new(&root), &mut files);
    }
    // Also a plain `gps/` folder next to the executable, so a GPX exported
    // by any program can be dropped in without hunting for the drive.
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            collect_gpx(&dir.join("gps"), &mut files);
        }
    }
    files
}

fn collect_gpx(dir: &std::path::Path, out: &mut Vec<PathBuf>) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for e in entries.flatten() {
        let p = e.path();
        if p.is_dir() {
            // One level down covers Garmin's Waypoints subfolder without
            // walking a whole card.
            if let Ok(sub) = std::fs::read_dir(&p) {
                for se in sub.flatten() {
                    let sp = se.path();
                    if is_gpx(&sp) {
                        out.push(sp);
                    }
                }
            }
        } else if is_gpx(&p) {
            out.push(p);
        }
    }
}

fn is_gpx(p: &std::path::Path) -> bool {
    p.extension()
        .and_then(|e| e.to_str())
        .map(|e| e.eq_ignore_ascii_case("gpx"))
        .unwrap_or(false)
}

/// A position Sweep decoded, to write out as a GPX waypoint.
pub struct Contact {
    pub name: String,
    pub lat: f64,
    pub lon: f64,
    pub desc: String,
    /// A Garmin symbol name, e.g. "Airport", "Boat", "Flag, Blue".
    pub sym: &'static str,
}

/// Build GPX 1.1 text from a set of contacts. Returns `None` when there is
/// nothing with a position to write, so the caller can say so rather than
/// writing an empty file.
pub fn write_gpx(contacts: &[Contact]) -> Option<String> {
    if contacts.is_empty() {
        return None;
    }
    let mut s = String::new();
    s.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    s.push_str(
        "<gpx version=\"1.1\" creator=\"Sweep SDR\" \
         xmlns=\"http://www.topografix.com/GPX/1/1\">\n",
    );
    for c in contacts {
        let _ = write!(s, "  <wpt lat=\"{:.6}\" lon=\"{:.6}\">\n", c.lat, c.lon);
        let _ = write!(s, "    <name>{}</name>\n", escape(&c.name));
        if !c.desc.is_empty() {
            let _ = write!(s, "    <desc>{}</desc>\n", escape(&c.desc));
        }
        let _ = write!(s, "    <sym>{}</sym>\n", c.sym);
        s.push_str("  </wpt>\n");
    }
    s.push_str("</gpx>\n");
    Some(s)
}

/// A memory to export to the handheld: a label and a frequency in MHz.
pub struct Channel {
    pub name: String,
    pub freq_mhz: f64,
}

/// Decide a channel's mode letter for CHIRP from its frequency.
///
/// A Baofeng is an FM-only radio; it cannot demodulate AM, so even an
/// airband frequency is written as narrow FM (the radio will at least open
/// on it). Broadcast FM is wide; everything else is narrow, which is right
/// for the voice channels a handheld is actually used on.
fn chirp_mode(freq_mhz: f64) -> &'static str {
    if (88.0..108.0).contains(&freq_mhz) {
        "FM" // wide
    } else {
        "NFM"
    }
}

/// Write a CHIRP-importable CSV from saved channels.
///
/// The header is CHIRP's full column set so the file imports without
/// complaint; the columns that matter — location index, name, frequency,
/// simplex duplex, mode, tuning step — are filled and the rest left at
/// their defaults. Names are trimmed to CHIRP's 16-character limit and
/// stripped of commas so a name can never break the row.
pub fn write_chirp_csv(channels: &[Channel]) -> String {
    let mut s = String::new();
    s.push_str(
        "Location,Name,Frequency,Duplex,Offset,Tone,rToneFreq,cToneFreq,\
         DtcsCode,DtcsPolarity,RxDtcsCode,CrossMode,Mode,TStep,Skip,Power,\
         Comment,URCALL,RPT1CALL,RPT2CALL,DVCODE\n",
    );
    for (i, c) in channels.iter().enumerate() {
        let name: String = c
            .name
            .chars()
            .filter(|ch| *ch != ',' && *ch != '"')
            .take(16)
            .collect();
        let _ = write!(
            s,
            "{},{},{:.6},,0.000000,,88.5,88.5,023,NN,023,Tone->Tone,{},5.00,,,,,,,\n",
            i,
            name,
            c.freq_mhz,
            chirp_mode(c.freq_mhz),
        );
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    const GARMIN_SAMPLE: &str = r#"<?xml version="1.0" encoding="UTF-8"?>
<gpx xmlns="http://www.topografix.com/GPX/1/1" creator="Garmin GPSMAP 64st">
  <wpt lat="43.771200" lon="-79.258300">
    <ele>120.5</ele>
    <time>2026-10-18T18:00:00Z</time>
    <name>HOME</name>
    <sym>Residence</sym>
  </wpt>
  <wpt lon="-79.400000" lat="43.650000">
    <name>SHACK &amp; TOWER</name>
    <desc>antenna site</desc>
  </wpt>
  <wpt lat="200.0" lon="0.0"><name>BOGUS</name></wpt>
</gpx>"#;

    #[test]
    fn reads_garmin_waypoints_with_either_attribute_order() {
        let w = parse_waypoints(GARMIN_SAMPLE);
        assert_eq!(w.len(), 2, "bogus coords should have been dropped: {w:?}");
        assert_eq!(w[0].name, "HOME");
        assert!((w[0].lat - 43.7712).abs() < 1e-6);
        assert!((w[0].lon - -79.2583).abs() < 1e-6);
        // Second waypoint has lon before lat, and an escaped ampersand.
        assert_eq!(w[1].name, "SHACK & TOWER");
        assert!((w[1].lat - 43.65).abs() < 1e-6);
        assert!((w[1].lon - -79.4).abs() < 1e-6);
        assert_eq!(w[1].desc, "antenna site");
    }

    #[test]
    fn a_self_closing_waypoint_is_read() {
        let gpx = r#"<gpx><wpt lat="45.0" lon="-80.0" /></gpx>"#;
        let w = parse_waypoints(gpx);
        assert_eq!(w.len(), 1);
        assert!((w[0].lat - 45.0).abs() < 1e-9);
        // No name element, so it falls back to the coordinates.
        assert_eq!(w[0].name, "45.0000,-80.0000");
    }

    #[test]
    fn empty_or_junk_gpx_yields_nothing() {
        assert!(parse_waypoints("").is_empty());
        assert!(parse_waypoints("<gpx></gpx>").is_empty());
        assert!(parse_waypoints("not xml at all").is_empty());
        // A waypoint missing a coordinate is skipped, not guessed.
        assert!(parse_waypoints(r#"<wpt lat="43.0"><name>X</name></wpt>"#).is_empty());
    }

    /// What we write, we must be able to read back — the round trip is the
    /// proof the two halves agree.
    #[test]
    fn gpx_round_trips() {
        let contacts = vec![
            Contact {
                name: "AC123".into(),
                lat: 43.9,
                lon: -79.1,
                desc: "35000 ft".into(),
                sym: "Airport",
            },
            Contact {
                name: "M/V <Test> & Co".into(),
                lat: 43.2,
                lon: -79.5,
                desc: String::new(),
                sym: "Boat",
            },
        ];
        let gpx = write_gpx(&contacts).expect("some contacts");
        let back = parse_waypoints(&gpx);
        assert_eq!(back.len(), 2);
        assert_eq!(back[0].name, "AC123");
        assert!((back[0].lat - 43.9).abs() < 1e-6);
        // The name with XML-special characters survived escaping and
        // unescaping intact.
        assert_eq!(back[1].name, "M/V <Test> & Co");
    }

    #[test]
    fn write_gpx_declines_an_empty_set() {
        assert!(write_gpx(&[]).is_none());
    }

    #[test]
    fn chirp_csv_has_a_header_and_one_row_per_channel() {
        let chans = vec![
            Channel {
                name: "Weather, Env Canada!".into(),
                freq_mhz: 162.550,
            },
            Channel {
                name: "CJRT FM".into(),
                freq_mhz: 91.1,
            },
        ];
        let csv = write_chirp_csv(&chans);
        let lines: Vec<&str> = csv.lines().collect();
        assert_eq!(lines.len(), 3, "header + two rows");
        assert!(lines[0].starts_with("Location,Name,Frequency,"));
        // Row 0: name had a comma and is over 16 chars → stripped and cut.
        let f0: Vec<&str> = lines[1].split(',').collect();
        assert_eq!(f0[0], "0");
        assert!(!f0[1].contains(','), "comma leaked into the name field");
        assert!(f0[1].len() <= 16, "name not trimmed to 16: {:?}", f0[1]);
        assert_eq!(f0[2], "162.550000");
        assert_eq!(f0[12], "NFM", "line {:?}", lines[1]);
        // Row 1: broadcast FM is wide.
        let f1: Vec<&str> = lines[2].split(',').collect();
        assert_eq!(f1[2], "91.100000");
        assert_eq!(f1[12], "FM");
    }

    #[test]
    fn attr_does_not_match_inside_a_longer_name() {
        // `lat` must not be found inside `platform="..."`.
        let tag = r#"wpt platform="x" lon="-80" lat="45""#;
        assert_eq!(attr(tag, "lat"), Some(45.0));
        assert_eq!(attr(tag, "lon"), Some(-80.0));
    }
}
