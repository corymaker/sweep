//! Visual theme — two palettes, switched at runtime.
//!
//! **Night** is the default: a field-radio instrument in the dark, gunmetal
//! olive with phosphor-green and dial-lamp amber readouts. A waterfall has
//! to be dark for its colormap to read, and this is an application people
//! leave running at night.
//!
//! **Day** is for using it outdoors, in the sun, where a dark screen is
//! unreadable. It inverts the chrome to black-on-light at the highest
//! contrast that is still easy on the eye — the readouts darken so they
//! stand on a pale panel instead of glowing on a dark one. The plots (the
//! waterfall, the maps) stay dark, because their colour *is* the data and
//! that only reads against black; the rest of the instrument goes light
//! around them, the way a real set has a pale bezel around a dark screen.
//!
//! One rule survives both: **colour is data, grey is interface.** Every
//! coloured pixel in a plot already means something, so the chrome is kept
//! neutral and hue is spent inside the plots — with one exception, `live`,
//! the "here" marker, which is the one accent allowed on chrome.
//!
//! The palette is chosen through [`set_day`]; every colour below is a
//! function that returns the right value for the current mode, so a toggle
//! re-colours the whole program on the next frame. Call [`apply`] after a
//! switch to move egui's own widget visuals with it.

use eframe::egui;
use std::sync::atomic::{AtomicBool, Ordering};

static DAY: AtomicBool = AtomicBool::new(false);

/// Switch between the night (default) and day palettes.
pub fn set_day(day: bool) {
    DAY.store(day, Ordering::Relaxed);
}

/// Whether the daylight palette is active.
pub fn is_day() -> bool {
    DAY.load(Ordering::Relaxed)
}

/// Pick the night or day value for the current mode.
#[inline]
fn pick(night: egui::Color32, day: egui::Color32) -> egui::Color32 {
    if is_day() {
        day
    } else {
        night
    }
}

// Surfaces. In night mode four dark steps of gunmetal olive; in day mode
// four light steps of warm sand, running the other way (the base is the
// darkest light value, cards and controls get lighter) so depth still reads.
pub fn ink() -> egui::Color32 {
    pick(egui::Color32::from_rgb(12, 17, 15), egui::Color32::from_rgb(217, 216, 204))
}
pub fn surface() -> egui::Color32 {
    pick(egui::Color32::from_rgb(18, 25, 23), egui::Color32::from_rgb(232, 231, 221))
}
pub fn raised() -> egui::Color32 {
    pick(egui::Color32::from_rgb(26, 34, 31), egui::Color32::from_rgb(244, 243, 236))
}
pub fn line() -> egui::Color32 {
    pick(egui::Color32::from_rgb(40, 50, 46), egui::Color32::from_rgb(191, 189, 173))
}

// Text. Warm off-white on dark; near-black on light, for maximum contrast
// in the sun.
pub fn text() -> egui::Color32 {
    pick(egui::Color32::from_rgb(216, 222, 212), egui::Color32::from_rgb(25, 28, 20))
}
pub fn mute() -> egui::Color32 {
    pick(egui::Color32::from_rgb(126, 138, 128), egui::Color32::from_rgb(89, 96, 76))
}

/// Now. The tuned marker, the active band, the selected contact — and
/// nothing else. A dial-lamp amber on dark; a darker burnt amber on light,
/// because bright amber vanishes against a pale panel.
pub fn live() -> egui::Color32 {
    pick(egui::Color32::from_rgb(255, 184, 56), egui::Color32::from_rgb(175, 98, 0))
}

/// Reserved for the data plots: the spectrum trace and an aircraft this
/// radio actually decoded. Night-optics phosphor green on dark; a deep
/// forest green on light, which is the darkest green that still reads as
/// green and stands against a pale background.
pub fn signal() -> egui::Color32 {
    pick(egui::Color32::from_rgb(116, 222, 126), egui::Color32::from_rgb(44, 122, 30))
}

/// Failures only. Hazard red-orange on dark; a deeper red on light.
pub fn alert() -> egui::Color32 {
    pick(egui::Color32::from_rgb(255, 91, 70), egui::Color32::from_rgb(192, 39, 26))
}

pub fn grid() -> egui::Color32 {
    pick(
        egui::Color32::from_rgba_premultiplied(90, 104, 88, 70),
        egui::Color32::from_rgba_premultiplied(90, 96, 70, 70),
    )
}

/// The display family — Chakra Petch, the squared technical face used for the
/// wordmark and panel legends. Registered by [`install_fonts`].
pub fn display(size: f32) -> egui::FontId {
    egui::FontId::new(size, egui::FontFamily::Name("display".into()))
}

/// Embed the three faces and wire them into egui's families. Called once at
/// startup, before `apply`. IBM Plex Sans becomes the proportional default,
/// IBM Plex Mono the monospace default, and Chakra Petch a named "display"
/// family. egui's own fonts stay on as fallback.
pub fn install_fonts(ctx: &egui::Context) {
    let mut fonts = egui::FontDefinitions::default();
    fonts.font_data.insert(
        "plex_sans".to_owned(),
        egui::FontData::from_static(include_bytes!("../fonts/IBMPlexSans-Regular.ttf")),
    );
    fonts.font_data.insert(
        "plex_mono".to_owned(),
        egui::FontData::from_static(include_bytes!("../fonts/IBMPlexMono-Medium.ttf")),
    );
    fonts.font_data.insert(
        "chakra".to_owned(),
        egui::FontData::from_static(include_bytes!("../fonts/ChakraPetch-SemiBold.ttf")),
    );
    if let Some(p) = fonts.families.get_mut(&egui::FontFamily::Proportional) {
        p.insert(0, "plex_sans".to_owned());
    }
    if let Some(m) = fonts.families.get_mut(&egui::FontFamily::Monospace) {
        m.insert(0, "plex_mono".to_owned());
    }
    fonts.families.insert(
        egui::FontFamily::Name("display".into()),
        vec!["chakra".to_owned(), "plex_sans".to_owned()],
    );
    ctx.set_fonts(fonts);
}

pub fn apply(ctx: &egui::Context) {
    let day = is_day();
    let mut v = if day {
        egui::Visuals::light()
    } else {
        egui::Visuals::dark()
    };
    v.override_text_color = Some(text());
    v.panel_fill = ink();
    v.window_fill = surface();
    v.extreme_bg_color = if day {
        egui::Color32::from_rgb(250, 249, 244)
    } else {
        egui::Color32::from_rgb(10, 13, 17)
    };
    v.faint_bg_color = surface();

    // 3px radius reads as a machined edge rather than a pill — the right
    // register for an instrument.
    let r = egui::Rounding::same(3.0);
    v.widgets.noninteractive.rounding = r;
    v.widgets.inactive.rounding = r;
    v.widgets.hovered.rounding = r;
    v.widgets.active.rounding = r;
    v.window_rounding = egui::Rounding::same(6.0);

    // Instrument-panel register: every control sits inside a hairline edge,
    // the way buttons and keys are bezelled on a real set. The selected or
    // pressed state switches that edge to amber so "live" reads at a glance
    // on every tab.
    v.widgets.noninteractive.bg_stroke = egui::Stroke::new(1.0_f32, line());
    v.widgets.noninteractive.fg_stroke = egui::Stroke::new(1.0_f32, mute());
    v.widgets.inactive.bg_fill = raised();
    v.widgets.inactive.weak_bg_fill = raised();
    v.widgets.inactive.fg_stroke = egui::Stroke::new(1.0_f32, text());
    v.widgets.inactive.bg_stroke = egui::Stroke::new(1.0_f32, line());
    let hover = if day {
        egui::Color32::from_rgb(224, 223, 212)
    } else {
        egui::Color32::from_rgb(52, 58, 40)
    };
    v.widgets.hovered.bg_fill = hover;
    v.widgets.hovered.weak_bg_fill = hover;
    v.widgets.hovered.fg_stroke = egui::Stroke::new(1.0_f32, text());
    v.widgets.hovered.bg_stroke = egui::Stroke::new(1.0_f32, line());
    let active = if day {
        egui::Color32::from_rgb(246, 224, 180)
    } else {
        egui::Color32::from_rgb(66, 54, 22)
    };
    v.widgets.active.bg_fill = active;
    v.widgets.active.weak_bg_fill = active;
    v.widgets.active.fg_stroke = egui::Stroke::new(1.0_f32, live());
    v.widgets.active.bg_stroke = egui::Stroke::new(1.0_f32, live());
    v.selection.bg_fill = active;
    v.selection.stroke = egui::Stroke::new(1.0_f32, live());
    v.window_stroke = egui::Stroke::new(1.0_f32, line());
    v.window_shadow = egui::epaint::Shadow {
        offset: egui::vec2(0.0, 6.0),
        blur: 20.0,
        spread: 0.0,
        color: egui::Color32::from_black_alpha(if day { 50 } else { 140 }),
    };
    ctx.set_visuals(v);

    let mut s = (*ctx.style()).clone();
    // Hack for anything numeric, Ubuntu for anything verbal — a frequency
    // readout that re-flows as its digits change is unreadable, and
    // monospace digits are all one width.
    s.text_styles
        .insert(egui::TextStyle::Heading, display(15.0));
    s.text_styles
        .insert(egui::TextStyle::Body, egui::FontId::proportional(13.0));
    s.text_styles
        .insert(egui::TextStyle::Button, egui::FontId::proportional(12.0));
    s.text_styles
        .insert(egui::TextStyle::Small, egui::FontId::proportional(11.0));
    s.text_styles
        .insert(egui::TextStyle::Monospace, egui::FontId::monospace(12.0));
    s.spacing.item_spacing = egui::vec2(8.0, 6.0);
    s.spacing.button_padding = egui::vec2(9.0, 4.0);
    s.spacing.slider_width = 130.0;
    s.spacing.interact_size.y = 22.0;
    ctx.set_style(s);
}

/// A quiet label over a group of controls: stencil register — uppercase,
/// lightly tracked, in mute, with a short amber tick in front of it, like a
/// legend silk-screened next to a knob.
pub fn section(ui: &mut egui::Ui, text_in: &str) {
    ui.add_space(2.0);
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 5.0;
        ui.label(egui::RichText::new("▮").size(9.0).color(live().gamma_multiply(0.85)));
        ui.label(egui::RichText::new(stencil(text_in)).font(display(10.5)).color(mute()));
    });
}

/// Spaced-out uppercase, the way a legend is printed on a panel.
fn stencil(s: &str) -> String {
    s.to_uppercase()
        .chars()
        .flat_map(|c| [c, '\u{2009}']) // hair space between letters
        .collect()
}

/// A flat panel behind a group. No outline — the fill step is the edge.
pub fn card(painter: &egui::Painter, rect: egui::Rect) {
    painter.rect_filled(rect, egui::Rounding::same(4.0), surface());
}

/// Corner brackets around a plot — the targeting-reticle motif. Four
/// L-shaped marks at the corners, nothing on the edges, so the frame reads
/// without boxing the data in. `len` is the arm length in pixels.
pub fn bracket_frame(painter: &egui::Painter, rect: egui::Rect, color: egui::Color32, len: f32) {
    let st = egui::Stroke::new(1.3_f32, color);
    let l = len.max(4.0);
    let (x0, y0, x1, y1) = (rect.left(), rect.top(), rect.right(), rect.bottom());
    let corner = |a: egui::Pos2, hx: f32, hy: f32| {
        painter.line_segment([a, egui::pos2(a.x + hx, a.y)], st);
        painter.line_segment([a, egui::pos2(a.x, a.y + hy)], st);
    };
    corner(egui::pos2(x0, y0), l, l);
    corner(egui::pos2(x1, y0), -l, l);
    corner(egui::pos2(x0, y1), l, -l);
    corner(egui::pos2(x1, y1), -l, -l);
}

/// Formerly a faint scanline texture over the waterfall. Removed: it
/// darkened real data to imitate a CRT.
pub fn scanlines(_painter: &egui::Painter, _rect: egui::Rect) {}

/// Signal strength as a horizontal bar. `db` is SNR over the noise floor;
/// the scale runs to 40 dB, past which more signal makes no practical
/// difference.
pub fn level_bar(painter: &egui::Painter, rect: egui::Rect, db: f32, is_live: bool) {
    painter.rect_filled(rect, egui::Rounding::same(2.0), raised());
    let f = (db / 40.0).clamp(0.0, 1.0);
    if f > 0.0 {
        let w = rect.width() * f;
        painter.rect_filled(
            egui::Rect::from_min_size(rect.min, egui::vec2(w, rect.height())),
            egui::Rounding::same(2.0),
            if is_live { live() } else { mute() },
        );
    }
    for k in 1..4 {
        let x = rect.left() + rect.width() * k as f32 / 4.0;
        painter.line_segment(
            [egui::pos2(x, rect.top()), egui::pos2(x, rect.bottom())],
            egui::Stroke::new(1.0_f32, egui::Color32::from_black_alpha(90)),
        );
    }
}
