//! Sweep GUI — a military-HUD-styled waterfall front end for the sweep-rtl
//! scanner. Type a band name or a bare frequency into the console at the
//! top; everything below it (spectrum trace, waterfall, status readouts,
//! signal log) is driven by the worker thread in `worker.rs`, which owns
//! the actual dongle and audio stream.
//!
//!     cargo run --release -p sweep-gui

mod bands;
mod geomap;
mod icons;
mod opensky;
mod acinfo;
mod presets;
mod repeaters_on;
mod stations;
mod gps;
mod theme;
mod waterfall;
mod wf3d;
mod worker;

use eframe::egui;
use std::collections::VecDeque;
use std::sync::mpsc::{Receiver, Sender};
use stations::Station;
use sweep_core::plan::Demod;
use waterfall::{BandWaterfall, Waterfall};
use worker::{Cmd, DeviceStatus, UiMsg};

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1180.0, 780.0])
            .with_min_inner_size([860.0, 560.0])
            .with_title("SWEEP — SDR RECEIVER"),
        ..Default::default()
    };
    eframe::run_native(
        "SWEEP",
        options,
        Box::new(|cc| {
            let app = SweepApp::new(cc);
            Ok(Box::new(app))
        }),
    )
}

/// What sits beside the map.
#[derive(PartialEq, Clone, Copy)]
enum SidePane {
    /// Spectrum and waterfall: what the radio is actually receiving.
    Signal,
    /// The contact list and the selected contact's details.
    Contacts,
    /// Both, stacked, for a wide window.
    Both,
}

/// A received slow-scan picture.
#[derive(Clone)]
struct SstvImage {
    width: usize,
    height: usize,
    rgb: Vec<u8>,
    lines_done: usize,
    mode: String,
}

/// One analysed ISM burst, kept for the log. Everything here is measured
/// from the signal — there are no device names or sensor readings, because
/// those cannot be known from the bits without a device database.
#[derive(Clone)]
struct IsmLine {
    when: String,
    coding: &'static str,
    short_us: f32,
    long_us: f32,
    bits: u32,
    hex: String,
    crc_ok: bool,
    repeats: u32,
    snr_db: f32,
}

/// One decoded page, kept for the log.
#[derive(Clone)]
struct PagerLine {
    when: String,
    ric: u32,
    func: u8,
    text: Option<String>,
    numeric: String,
    reading: &'static str,
    ambiguous: bool,
    codewords: u32,
    repaired_one: u32,
    repaired_two: u32,
    dropped: u32,
    baud: f32,
    inverted: bool,
}

impl PagerLine {
    fn tone_only(&self) -> bool {
        self.codewords == 0
    }
    /// Anything that makes the text worth doubting.
    fn marginal(&self) -> bool {
        self.repaired_two > 0 || self.dropped > 0
    }
    fn body(&self) -> &str {
        match self.text.as_deref() {
            Some(t) => t,
            None => self.numeric.as_str(),
        }
    }
}

/// One decoded ACARS message, kept for the log.
#[derive(Clone)]
struct AcarsLine {
    when: String,
    registration: String,
    flight: Option<String>,
    label: String,
    label_text: &'static str,
    text: String,
    crc_ok: bool,
    more: bool,
}

#[derive(PartialEq, Clone, Copy)]
enum View { Home, Live, Band, Adsb, Marine, Aprs, Acars, Sstv, Drone, Pager, Ism, Antenna }

/// Write a device-bridge export into an `exports/` folder next to the
/// executable, returning where it landed. A free function rather than a
/// method so it doesn't hold a borrow of the app while the caller is still
/// reading other fields to build the content.
fn write_export_file(name: &str, content: &str) -> Option<std::path::PathBuf> {
    let dir = std::env::current_exe()
        .ok()
        .and_then(|e| e.parent().map(|p| p.to_path_buf()))
        .unwrap_or_default()
        .join("exports");
    std::fs::create_dir_all(&dir).ok()?;
    let path = dir.join(name);
    std::fs::write(&path, content).ok()?;
    Some(path)
}

/// Destination point from (lat0, lon0) travelling `dist_km` on `bearing_deg`.
/// Spherical earth — accurate to a few metres at radar ranges, well inside a
/// click's precision. Turns a click on the radar into a latitude/longitude.
fn dest_point(lat0: f64, lon0: f64, bearing_deg: f64, dist_km: f64) -> (f64, f64) {
    let r_earth = 6371.0;
    let ad = dist_km / r_earth;
    let br = bearing_deg.to_radians();
    let la1 = lat0.to_radians();
    let lo1 = lon0.to_radians();
    let la2 = (la1.sin() * ad.cos() + la1.cos() * ad.sin() * br.cos()).asin();
    let lo2 = lo1 + (br.sin() * ad.sin() * la1.cos()).atan2(ad.cos() - la1.sin() * la2.sin());
    (la2.to_degrees(), lo2.to_degrees())
}

/// Render the online aircraft details (type, operator, route) and the photo,
/// shared by the own-decode and OpenSky detail panels. A free function so it
/// borrows neither `self` nor the panel's `row` closure by ownership.
fn draw_online_ac(
    ui: &mut egui::Ui,
    row: &impl Fn(&mut egui::Ui, &str, String),
    online: Option<&acinfo::AcInfo>,
    photo: Option<&egui::TextureHandle>,
    pending: bool,
) {
    if let Some(info) = online {
        if let Some(k) = &info.kind {
            row(ui, "type", k.clone());
        }
        if let Some(o) = &info.operator {
            row(ui, "operator", o.clone());
        }
        if let Some(rt) = &info.route {
            row(ui, "route", rt.clone());
        }
        if !info.note.is_empty() {
            row(ui, "lookup", info.note.clone());
        }
    } else if pending {
        row(ui, "lookup", "fetching details…".to_string());
    }
    if let Some(tex) = photo {
        ui.add_space(6.0);
        let s = tex.size();
        let (tw, th) = (s[0] as f32, s[1] as f32);
        let scale = (260.0_f32 / tw.max(1.0)).min(1.0);
        let size = egui::vec2(tw * scale, th * scale);
        let (prect, _) = ui.allocate_exact_size(size, egui::Sense::hover());
        ui.painter().image(
            tex.id(),
            prect,
            egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)),
            egui::Color32::WHITE,
        );
        if let Some(ph) = online.and_then(|i| i.photographer.as_deref()) {
            ui.label(
                egui::RichText::new(format!("photo via {ph}"))
                    .small()
                    .color(theme::mute()),
            );
        }
    }
}

/// Where saved state lives — a plain text file next to the executable, the
/// same place recordings and exports go.
fn state_file_path() -> Option<std::path::PathBuf> {
    std::env::current_exe()
        .ok()
        .and_then(|e| e.parent().map(|p| p.to_path_buf()))
        .map(|p| p.join("sweep_state.txt"))
}

/// Serialise the parts worth keeping between sessions: your position and
/// your saved frequencies. A line-based format on purpose — a human can
/// read or fix it, and a corrupt line is skipped rather than fatal.
fn format_state(lat: f64, lon: f64, memories: &[(String, f64)]) -> String {
    let mut s = String::new();
    s.push_str(&format!("lat={lat:.6}\n"));
    s.push_str(&format!("lon={lon:.6}\n"));
    for (label, mhz) in memories {
        // The separator and newlines can't appear in a label or the line
        // won't parse back, so strip them rather than trust the input.
        let l: String = label
            .chars()
            .filter(|c| *c != '\n' && *c != '\r' && *c != '|')
            .collect();
        s.push_str(&format!("mem={mhz:.6}|{l}\n"));
    }
    s
}

/// Parse what [`format_state`] wrote. Every field is optional and every
/// value range-checked, so a truncated or hand-edited file loads what it
/// can and ignores the rest. Returns (lat, lon, memories).
fn parse_state(text: &str) -> (Option<f64>, Option<f64>, Vec<(String, f64)>) {
    let mut lat = None;
    let mut lon = None;
    let mut mems: Vec<(String, f64)> = Vec::new();
    for line in text.lines() {
        let line = line.trim();
        if let Some(v) = line.strip_prefix("lat=") {
            if let Ok(x) = v.parse::<f64>() {
                if (-90.0..=90.0).contains(&x) {
                    lat = Some(x);
                }
            }
        } else if let Some(v) = line.strip_prefix("lon=") {
            if let Ok(x) = v.parse::<f64>() {
                if (-180.0..=180.0).contains(&x) {
                    lon = Some(x);
                }
            }
        } else if let Some(v) = line.strip_prefix("mem=") {
            if let Some((f, l)) = v.split_once('|') {
                if let Ok(mhz) = f.parse::<f64>() {
                    if (0.1..=2000.0).contains(&mhz) && !l.is_empty() && mems.len() < 8 {
                        mems.push((l.to_string(), mhz));
                    }
                }
            }
        }
    }
    (lat, lon, mems)
}

struct SweepApp {
    ui_rx: Receiver<UiMsg>,
    cmd_tx: Sender<Cmd>,

    waterfall: Waterfall,
    wf_texture: Option<egui::TextureHandle>,
    spectrum_live: Vec<f32>,
    floor_live: Vec<f32>,
    center_hz: f64,

    /// Draw the waterfall as a 3D perspective surface instead of the flat
    /// heat map. Off by default — the flat view is easier to read a precise
    /// frequency from; the surface is for watching the band breathe.
    wf3d_on: bool,
    /// Recent spectrum sweeps, newest first, reduced to `wf3d::COLS`
    /// columns. Feeds the 3D surface. Kept whether or not 3D is showing, so
    /// toggling it on is instant rather than starting from a blank field.
    wf_hist: VecDeque<Vec<f32>>,

    plan_name: String,
    windows_total: usize,
    window_idx: usize,

    device_ok: bool,
    device_status: String,

    signal_active: bool,
    last_signal: String,
    last_snr: f32,
    audio_peak: f32,

    log: VecDeque<String>,
    command_input: String,

    floor_db: f32,
    ceil_db: f32,

    // Bearing/range compass — not detection, a lookup against sites the
    // person has confirmed themselves. See stations.rs.
    receiver_lat: f64,
    receiver_lon: f64,
    stations: Vec<Station>,
    new_station_name: String,
    new_station_freq: String,
    new_station_lat: String,
    new_station_lon: String,

    // Mode override, gain, and frequency memories — the parts of the Zeus
    // panel that map to real functionality on receive-only hardware.
    selected_mode: Option<Demod>,
    gain_auto: bool,
    gain_tenths_db: i32,
    memories: Vec<(String, f64)>, // (label, MHz)
    cursor_freq: Option<f64>,
    ppm: i32,
    bias_tee_on: bool,
    rec_audio_on: bool,
    rec_iq_on: bool,
    auto_scan: bool,
    voice_only: bool,
    band_wf: BandWaterfall,
    band_wf_texture: Option<egui::TextureHandle>,
    band_view: bool,
    view: View,
    plan_channels: usize,
    last_pass_ms: Option<u64>,
    pass_started: Option<std::time::Instant>,
    last_band_row: Option<std::time::Instant>,
    presets_open: bool,
    signal_history: Vec<f64>, // MHz, most recent last
    history_pos: Option<usize>,
    volume: f32,
    rds_ps: Option<String>,
    rds_radiotext: Option<String>,
    rds_pty: Option<u8>,
    random_hex: Option<String>,
    squelch_db: f64,
    bw_override_khz: Option<f32>,
    bw_slider_khz: f32,
    peak_hold: bool,
    peak_bins: Vec<f32>,

    // Antenna-tuning meter (View::Antenna). Everything here is derived from
    // the live FFT that every mode already produces, so it needs no new
    // worker path. The figure of merit is received SNR on whatever steady
    // signal you point at — the honest proxy for "is this antenna better?".
    antenna_snr_ema: Option<f32>,
    antenna_peak_snr: f32,
    antenna_ref: Option<f32>,
    antenna_snr_hist: VecDeque<f32>,
    antenna_freq: String,
    frozen_center_hz: Option<f64>,
    last_band_key: Option<String>,
    drag_freq: Option<f64>,
    last_drag_tune: Option<std::time::Instant>,
    freq_drag_accum: f32,
    settings_open: bool,
    /// Waypoints read off a connected Garmin, waiting to be picked as the
    /// receiver position.
    gps_waypoints: Vec<gps::Waypoint>,
    /// What the last device-bridge action did, shown under the buttons.
    gps_status: String,
    scan_results: Vec<(f64, String, f32)>,

    // ADS-B. Only populated while the radio is parked on 1090 MHz.
    adsb: Vec<worker::AircraftView>,
    adsb_frames_ok: u64,
    adsb_frames_bad: u64,
    adsb_per_min: f32,
    /// Radius of the radar plot, in km. Nothing to do with reception — it's
    /// the zoom control for the display.
    adsb_range_km: f32,
    adsb_selected: Option<String>,
    /// An OpenSky overlay contact the user clicked, by lower-case icao24.
    /// Separate from `adsb_selected` because the two detail panels show
    /// different things — one is our own decode, the other is the network's
    /// report of an aircraft we did not hear.
    adsb_os_selected: Option<String>,
    /// Where the map is centred, when the view has been dragged away from
    /// the receiver. `None` means centred on the receiver.
    adsb_view_center: Option<(f64, f64)>,
    /// When on, a click on the radar sets the receiver's own location to that
    /// point instead of selecting an aircraft.
    adsb_set_loc: bool,
    /// The rotating sonar sweep on the aircraft radar.
    adsb_sweep: bool,
    /// Online aircraft-detail lookup (type, operator, route, photo) for the
    /// selected aircraft. Started on first use; results cached per hex.
    ac_lookup: Option<acinfo::Lookup>,
    ac_cache: std::collections::HashMap<String, acinfo::AcInfo>,
    ac_textures: std::collections::HashMap<String, egui::TextureHandle>,
    ac_pending: Option<String>,
    /// Centre and radius the loaded geography was clipped to, so the view
    /// can move freely inside it without re-reading the files.
    geomap_window: Option<(f64, f64, f64)>,
    /// Seconds between automatic OpenSky refreshes.
    opensky_interval_s: f32,
    /// Cross-check against the OpenSky Network. Off unless asked for: it
    /// reaches the internet, which nothing else in this program does.
    adsb_overlay: bool,
    opensky: Option<opensky::OpenSky>,
    opensky_contacts: Vec<opensky::Contact>,
    opensky_status: String,
    /// Coastlines and borders, loaded from map/ next to the executable.
    /// `None` until the ADS-B view is first opened — parsing a world
    /// coastline is not work to do at startup for a feature nobody may use.
    geomap: Option<geomap::GeoMap>,
    geomap_note: String,
    geomap_help_open: bool,
    /// Longest range at which an aircraft has been decoded this session,
    /// which is the only real figure of merit for an antenna at 1090 MHz.
    adsb_best_km: f64,
    adsb_preambles_per_s: f32,
    // AIS. Populated only while parked between the two marine channels.
    ais: Vec<worker::VesselView>,
    ais_frames: u64,
    ais_mean_dbfs: f32,
    ais_peak_dbfs: f32,
    ais_selected: Option<u32>,
    aprs: Vec<worker::StationView>,
    aprs_packets: u64,
    aprs_mean_dbfs: f32,
    aprs_peak_dbfs: f32,
    aprs_selected: Option<String>,
    acars_msgs: VecDeque<AcarsLine>,
    acars_aircraft: usize,
    acars_bad_parity: u64,
    acars_mean_dbfs: f32,
    acars_peak_dbfs: f32,
    acars_channel_hz: f64,
    sstv_image: Option<SstvImage>,
    sstv_texture: Option<egui::TextureHandle>,
    sstv_status: String,
    /// Take turns between tracking aircraft and scanning their voice band.
    track_and_listen: bool,
    /// The last voice transmission heard, so its frequency can be saved
    /// after the fact — by the time you have decided it was worth keeping,
    /// the scanner has usually moved on.
    last_heard: Option<(f64, String)>,
    /// What the right-hand column of a map workspace shows. The map is the
    /// subject; this is the instrument you want beside it, and which one
    /// that is depends on what you are doing.
    side: SidePane,
    adsb_mean_dbfs: f32,
    adsb_peak_dbfs: f32,

    // --- Drone-band survey ------------------------------------------
    //
    // Not a decoder. There is nothing to decode: the one signal that
    // carries a drone's identity is Remote ID at 2.4/5.8 GHz, which is
    // above this tuner's 1766 MHz ceiling. What these hold is the shape of
    // whatever energy is in the reachable bands — see sweep_core::drone.
    /// Which bands the survey is covering, by key.
    drone_enabled: Vec<String>,
    drone_snr: f32,
    /// One accumulated picture per enabled band, reduced for display.
    drone_bands: Vec<worker::DroneBandView>,
    drone_sigs: Vec<worker::DroneSigView>,
    drone_hop: Option<String>,
    drone_scanning_mhz: f64,
    drone_pass_secs: f32,
    /// Live readout while parked on one range, measuring it properly.
    drone_stare: Option<worker::DroneStareView>,
    /// Centre frequency of the selected signature, so the selection
    /// survives the list being rebuilt twice a second.
    drone_selected: Option<f64>,
    /// The panel listing what this hardware cannot see.
    drone_limits_open: bool,

    // --- Pagers (POCSAG) --------------------------------------------
    pager_msgs: VecDeque<PagerLine>,
    pager_channel_hz: f64,
    pager_pages: u64,
    pager_syncs: u64,
    pager_cw_ok: u64,
    pager_cw_repaired: u64,
    pager_cw_dropped: u64,
    pager_mean_dbfs: f32,
    pager_peak_dbfs: f32,
    /// Sync count per (baud, inverted) lane — which bit rate and polarity
    /// the transmitter is actually using, discovered rather than chosen.
    pager_lanes: Vec<(f32, bool, u64)>,
    /// Hide tone-only pages, which on a busy system vastly outnumber the
    /// ones with text in them.
    pager_text_only: bool,

    // --- ISM burst survey -------------------------------------------
    ism_msgs: VecDeque<IsmLine>,
    ism_channel_hz: f64,
    ism_bursts: u64,
    ism_decoded: u64,
    ism_with_crc: u64,
    ism_mean_dbfs: f32,
    ism_peak_dbfs: f32,
    /// Hide bursts that carried no decodable bits (energy only), which on a
    /// busy band can be most of them.
    ism_decoded_only: bool,
}

impl SweepApp {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        theme::install_fonts(&cc.egui_ctx);
        theme::apply(&cc.egui_ctx);
        let initial = "listen to weather".to_string();
        let (ui_rx, cmd_tx) = worker::spawn_worker(initial.clone());
        let mut app = SweepApp {
            ui_rx,
            cmd_tx,
            waterfall: Waterfall::new(waterfall::WF_WIDTH, 220),
            wf_texture: None,
            spectrum_live: vec![-100.0; waterfall::WF_WIDTH],
            floor_live: vec![-100.0; waterfall::WF_WIDTH],
            wf3d_on: false,
            wf_hist: VecDeque::new(),
            center_hz: 162_475_000.0,
            plan_name: "—".into(),
            windows_total: 0,
            window_idx: 0,
            device_ok: false,
            device_status: "SEARCHING FOR DONGLE…".into(),
            signal_active: false,
            last_signal: "—".into(),
            last_snr: 0.0,
            audio_peak: 0.0,
            log: VecDeque::new(),
            command_input: initial,
            floor_db: -100.0,
            ceil_db: -20.0,
            // Approximate — Toronto city centre. Not precise; the person
            // should correct this to their actual location for the bearing
            // math to mean anything.
            receiver_lat: 43.6532,
            receiver_lon: -79.3832,
            stations: repeaters_on::built_in(),
            new_station_name: String::new(),
            new_station_freq: String::new(),
            new_station_lat: String::new(),
            new_station_lon: String::new(),
            selected_mode: None,
            gain_auto: true,
            gain_tenths_db: 200,
            memories: Vec::new(),
            cursor_freq: None,
            ppm: 0,
            bias_tee_on: false,
            rec_audio_on: false,
            rec_iq_on: false,
            auto_scan: false,
            voice_only: false,
            band_wf: BandWaterfall::new(1024, 200),
            band_wf_texture: None,
            band_view: false,
            view: View::Home,
            plan_channels: 0,
            last_pass_ms: None,
            pass_started: None,
            last_band_row: None,
            presets_open: false,
            signal_history: Vec::new(),
            history_pos: None,
            volume: 1.0,
            rds_ps: None,
            rds_radiotext: None,
            rds_pty: None,
            random_hex: None,
            squelch_db: 8.0,
            bw_override_khz: None,
            bw_slider_khz: 12.5,
            peak_hold: false,
            peak_bins: Vec::new(),
            antenna_snr_ema: None,
            antenna_peak_snr: 0.0,
            antenna_ref: None,
            antenna_snr_hist: VecDeque::new(),
            antenna_freq: String::new(),
            frozen_center_hz: None,
            last_band_key: Some("weather".to_string()),
            drag_freq: None,
            last_drag_tune: None,
            freq_drag_accum: 0.0,
            settings_open: false,
            gps_waypoints: Vec::new(),
            gps_status: String::new(),
            scan_results: Vec::new(),
            adsb: Vec::new(),
            adsb_frames_ok: 0,
            adsb_frames_bad: 0,
            adsb_per_min: 0.0,
            adsb_range_km: 150.0,
            adsb_selected: None,
            adsb_os_selected: None,
            adsb_view_center: None,
            adsb_set_loc: false,
            adsb_sweep: true,
            ac_lookup: None,
            ac_cache: std::collections::HashMap::new(),
            ac_textures: std::collections::HashMap::new(),
            ac_pending: None,
            geomap_window: None,
            opensky_interval_s: opensky::DEFAULT_INTERVAL_S,
            adsb_overlay: false,
            opensky: None,
            opensky_contacts: Vec::new(),
            opensky_status: String::new(),
            geomap: None,
            geomap_note: String::new(),
            geomap_help_open: false,
            adsb_best_km: 0.0,
            adsb_preambles_per_s: 0.0,
            ais: Vec::new(),
            ais_frames: 0,
            ais_mean_dbfs: -120.0,
            ais_peak_dbfs: -120.0,
            ais_selected: None,
            aprs: Vec::new(),
            aprs_packets: 0,
            aprs_mean_dbfs: -120.0,
            aprs_peak_dbfs: -120.0,
            aprs_selected: None,
            acars_msgs: VecDeque::new(),
            acars_aircraft: 0,
            acars_bad_parity: 0,
            acars_mean_dbfs: -120.0,
            acars_peak_dbfs: -120.0,
            acars_channel_hz: sweep_core::acars::ACARS_HZ,
            sstv_image: None,
            sstv_texture: None,
            sstv_status: String::new(),
            track_and_listen: false,
            last_heard: None,
            side: SidePane::Signal,
            adsb_mean_dbfs: -120.0,
            adsb_peak_dbfs: -120.0,
            drone_enabled: vec!["ism433".into(), "ism915".into(), "fpv12".into()],
            drone_snr: 10.0,
            drone_bands: Vec::new(),
            drone_sigs: Vec::new(),
            drone_hop: None,
            drone_scanning_mhz: 0.0,
            drone_pass_secs: 0.0,
            drone_stare: None,
            drone_selected: None,
            drone_limits_open: false,
            pager_msgs: VecDeque::new(),
            pager_channel_hz: sweep_core::pocsag::NATIONWIDE_HZ[0],
            pager_pages: 0,
            pager_syncs: 0,
            pager_cw_ok: 0,
            pager_cw_repaired: 0,
            pager_cw_dropped: 0,
            pager_mean_dbfs: -120.0,
            pager_peak_dbfs: -120.0,
            pager_lanes: Vec::new(),
            pager_text_only: false,
            ism_msgs: VecDeque::new(),
            ism_channel_hz: sweep_core::ism::ISM_433_HZ,
            ism_bursts: 0,
            ism_decoded: 0,
            ism_with_crc: 0,
            ism_mean_dbfs: -120.0,
            ism_peak_dbfs: -120.0,
            ism_decoded_only: false,
        };
        app.load_state();
        app
    }

    fn log_push(&mut self, s: String) {
        self.log.push_front(s);
        while self.log.len() > 14 {
            self.log.pop_back();
        }
    }

    fn drain_messages(&mut self) {
        for _ in 0..500 {
            match self.ui_rx.try_recv() {
                Ok(msg) => self.handle(msg),
                Err(_) => break,
            }
        }
    }

    fn handle(&mut self, msg: UiMsg) {
        match msg {
            UiMsg::Device(DeviceStatus::Searching) => {
                self.device_status = "SEARCHING FOR DONGLE…".into();
                self.device_ok = false;
            }
            UiMsg::Device(DeviceStatus::Ready(s)) => {
                self.device_status = format!("ONLINE — {s}");
                self.device_ok = true;
                self.log_push("device ready".into());
            }
            UiMsg::Device(DeviceStatus::Error(e)) => {
                self.device_status = format!("NO DEVICE — {e}");
                self.device_ok = false;
            }
            UiMsg::PlanLoaded {
                name,
                windows,
                channels,
                single_window,
            } => {
                self.plan_name = name.clone();
                self.windows_total = windows;
                self.window_idx = 0;
                self.plan_channels = channels;
                self.last_pass_ms = None;
                self.pass_started = None;
                self.log_push(format!(
                    "PLAN: {name} — {windows} window(s), {channels} channel(s){}",
                    if single_window {
                        "  [single-window, continuous]"
                    } else {
                        ""
                    }
                ));
            }
            UiMsg::PlanError(e) => self.log_push(format!("! {e}")),
            UiMsg::Sstv {
                width,
                height,
                rgb,
                lines_done,
                mode,
            } => {
                self.sstv_image = Some(SstvImage {
                    width,
                    height,
                    rgb,
                    lines_done,
                    mode,
                });
            }
            UiMsg::SstvEvent(s) => {
                self.sstv_status = s;
            }
            UiMsg::IsmBurst {
                when,
                coding,
                short_us,
                long_us,
                bits,
                hex,
                crc_ok,
                repeats,
                snr_db,
            } => {
                self.ism_msgs.push_back(IsmLine {
                    when,
                    coding,
                    short_us,
                    long_us,
                    bits,
                    hex,
                    crc_ok,
                    repeats,
                    snr_db,
                });
                while self.ism_msgs.len() > 500 {
                    self.ism_msgs.pop_front();
                }
            }
            UiMsg::IsmStatus {
                bursts,
                decoded,
                with_crc,
                mean_dbfs,
                peak_dbfs,
                channel_hz,
            } => {
                self.center_hz = channel_hz;
                self.ism_channel_hz = channel_hz;
                self.ism_bursts = bursts;
                self.ism_decoded = decoded;
                self.ism_with_crc = with_crc;
                self.ism_mean_dbfs = mean_dbfs;
                self.ism_peak_dbfs = peak_dbfs;
            }
            UiMsg::PagerPage {
                when,
                ric,
                func,
                text,
                numeric,
                reading,
                ambiguous,
                codewords,
                repaired_one,
                repaired_two,
                dropped,
                baud,
                inverted,
            } => {
                self.pager_msgs.push_back(PagerLine {
                    when,
                    ric,
                    func,
                    text,
                    numeric,
                    reading,
                    ambiguous,
                    codewords,
                    repaired_one,
                    repaired_two,
                    dropped,
                    baud,
                    inverted,
                });
                while self.pager_msgs.len() > 500 {
                    self.pager_msgs.pop_front();
                }
            }
            UiMsg::PagerStatus {
                pages,
                syncs,
                codewords_ok,
                codewords_repaired,
                codewords_dropped,
                mean_dbfs,
                peak_dbfs,
                channel_hz,
                lanes,
            } => {
                self.center_hz = channel_hz;
                self.pager_channel_hz = channel_hz;
                self.pager_pages = pages;
                self.pager_syncs = syncs;
                self.pager_cw_ok = codewords_ok;
                self.pager_cw_repaired = codewords_repaired;
                self.pager_cw_dropped = codewords_dropped;
                self.pager_mean_dbfs = mean_dbfs;
                self.pager_peak_dbfs = peak_dbfs;
                self.pager_lanes = lanes;
            }
            UiMsg::DroneSweep {
                bands,
                signatures,
                hop,
                scanning_mhz,
                pass_secs,
            } => {
                self.drone_bands = bands;
                self.drone_sigs = signatures;
                self.drone_hop = hop;
                self.drone_scanning_mhz = scanning_mhz;
                self.drone_pass_secs = pass_secs;
                // Sweeping and staring are mutually exclusive, so a sweep
                // refresh means the stare is over and its numbers are
                // history. Leaving them on screen would present a
                // measurement of a moment ago as the current state.
                self.drone_stare = None;
                self.center_hz = scanning_mhz * 1e6;
                // Drop a selection whose signature has faded out of the
                // list, so the detail pane never describes a contact the
                // survey no longer has.
                if let Some(f) = self.drone_selected {
                    if !self
                        .drone_sigs
                        .iter()
                        .any(|s| (s.center_mhz - f).abs() < 0.05)
                    {
                        self.drone_selected = None;
                    }
                }
            }
            UiMsg::DroneStareMsg(v) => {
                self.center_hz = v.center_mhz * 1e6;
                self.drone_stare = Some(v);
            }
            UiMsg::AcarsBlock {
                when,
                registration,
                flight,
                label,
                label_text,
                text,
                crc_ok,
                more,
            } => {
                self.acars_msgs.push_back(AcarsLine {
                    when,
                    registration,
                    flight,
                    label,
                    label_text,
                    text,
                    crc_ok,
                    more,
                });
                // A long session would otherwise grow without limit.
                while self.acars_msgs.len() > 400 {
                    self.acars_msgs.pop_front();
                }
            }
            UiMsg::AcarsStatus {
                blocks: _,
                bad_parity,
                aircraft,
                mean_dbfs,
                peak_dbfs,
                channel_hz,
            } => {
                self.center_hz = channel_hz;
                self.acars_channel_hz = channel_hz;
                self.acars_aircraft = aircraft;
                self.acars_bad_parity = bad_parity;
                self.acars_mean_dbfs = mean_dbfs;
                self.acars_peak_dbfs = peak_dbfs;
            }
            UiMsg::Aprs {
                stations,
                packets,
                mean_dbfs,
                peak_dbfs,
            } => {
                self.center_hz = sweep_core::aprs::APRS_HZ;
                self.aprs = stations;
                self.aprs_packets = packets;
                self.aprs_mean_dbfs = mean_dbfs;
                self.aprs_peak_dbfs = peak_dbfs;
            }
            UiMsg::Ais {
                vessels,
                frames_ok,
                mean_dbfs,
                peak_dbfs,
            } => {
                self.center_hz = (sweep_core::ais::AIS_A_HZ + sweep_core::ais::AIS_B_HZ) / 2.0;
                self.ais = vessels;
                self.ais_frames = frames_ok;
                self.ais_mean_dbfs = mean_dbfs;
                self.ais_peak_dbfs = peak_dbfs;
            }
            UiMsg::Adsb {
                aircraft,
                frames_ok,
                frames_bad,
                frames_per_min,
                preambles_per_s,
                mean_dbfs,
                peak_dbfs,
            } => {
                // The radio really is on 1090 MHz in this mode, and the
                // readout should say so rather than keeping whatever was
                // tuned before.
                self.center_hz = 1_090_000_000.0;
                self.adsb_preambles_per_s = preambles_per_s;
                self.adsb_mean_dbfs = mean_dbfs;
                self.adsb_peak_dbfs = peak_dbfs;
                // Track the furthest decode before replacing the list — a
                // fleeting contact at the edge of coverage would otherwise
                // vanish before anyone read it.
                if self.receiver_lat != 0.0 || self.receiver_lon != 0.0 {
                    for a in &aircraft {
                        if let (Some(lat), Some(lon)) = (a.lat, a.lon) {
                            let d = stations::distance_km(
                                self.receiver_lat,
                                self.receiver_lon,
                                lat,
                                lon,
                            );
                            if d > self.adsb_best_km && d < 700.0 {
                                self.adsb_best_km = d;
                            }
                        }
                    }
                }
                self.adsb = aircraft;
                self.adsb_frames_ok = frames_ok;
                self.adsb_frames_bad = frames_bad;
                self.adsb_per_min = frames_per_min;
            }
            UiMsg::WindowTick {
                window,
                windows,
                center_mhz,
            } => {
                // A full pass completes when the window index wraps back to
                // the start — time that, so the rate shown is measured
                // rather than theoretical.
                if window == 0 && self.window_idx != 0 {
                    if let Some(t0) = self.pass_started {
                        self.last_pass_ms = Some(t0.elapsed().as_millis() as u64);
                    }
                    self.pass_started = Some(std::time::Instant::now());
                } else if self.pass_started.is_none() {
                    self.pass_started = Some(std::time::Instant::now());
                }
                self.window_idx = window;
                self.windows_total = windows;
                self.center_hz = center_mhz * 1e6;
                self.signal_active = false;
                self.rds_ps = None;
                self.rds_radiotext = None;
                self.rds_pty = None;
            }
            UiMsg::Rds { ps, radiotext, pty } => {
                if !ps.is_empty() {
                    self.rds_ps = Some(ps);
                }
                if !radiotext.is_empty() {
                    self.rds_radiotext = Some(radiotext);
                }
                self.rds_pty = pty;
            }
            UiMsg::Spectrum {
                bins,
                floor,
                center_hz,
            } => {
                self.waterfall.push_row(&bins);
                // The 3D surface's own history. It scrolls continuously, the
                // same way the flat waterfall does — a new row is pushed on
                // every sweep regardless of frequency, and old rows recede
                // and fall off the back. It is deliberately NOT cleared when
                // the tuned frequency changes: doing that wiped the surface
                // every time the scanner locked onto a voice (a lock is a
                // retune), so the 3D view blanked out the instant someone
                // started talking. Old rows at a different frequency simply
                // scroll away, exactly as they do on the flat waterfall.
                self.wf_hist.push_front(wf3d::reduce(&bins));
                while self.wf_hist.len() > 90 {
                    self.wf_hist.pop_back();
                }
                // Peak hold accumulates the highest value each bin has
                // reached — but only within one tuned span. A retune means
                // the x-axis now covers different frequencies entirely, so
                // carrying the old envelope over would be meaningless.
                if self.peak_bins.len() != bins.len() || self.center_hz != center_hz {
                    self.peak_bins = bins.clone();
                } else if self.peak_hold {
                    for (p, &b) in self.peak_bins.iter_mut().zip(bins.iter()) {
                        if b > *p {
                            *p = b;
                        }
                    }
                }
                self.spectrum_live = bins;
                self.floor_live = floor;
                self.center_hz = center_hz;

                // Paint this window into the band-wide view. Rows commit on
                // a timer rather than per update, so one row ends up
                // representing roughly one pass across the band.
                let span_mhz = self.capture_rate() / 1e6;
                self.band_wf.floor_db = self.floor_db;
                self.band_wf.ceil_db = self.ceil_db;
                self.band_wf
                    .add_window(&self.spectrum_live, center_hz / 1e6, span_mhz);
                let now = std::time::Instant::now();
                let due = self
                    .last_band_row
                    .map_or(true, |t| now.duration_since(t).as_millis() >= 500);
                if due {
                    self.last_band_row = Some(now);
                    self.band_wf.commit_row();
                }
            }
            UiMsg::SignalFound {
                freq_mhz,
                snr_db,
                label,
            } => {
                self.signal_active = true;
                self.last_signal = label.clone();
                self.last_snr = snr_db;
                self.center_hz = freq_mhz * 1e6;
                self.last_heard = Some((freq_mhz, label));
                if self.signal_history.last().map_or(true, |&f| (f - freq_mhz).abs() > 0.001) {
                    self.signal_history.push(freq_mhz);
                    if self.signal_history.len() > 64 {
                        self.signal_history.remove(0);
                    }
                }
                self.history_pos = None;
                self.scan_results.retain(|(f, _, _)| (*f - freq_mhz).abs() > 0.001);
                self.scan_results.insert(0, (freq_mhz, self.last_signal.clone(), snr_db));
                self.scan_results.truncate(24);
            }
            UiMsg::SignalEnded => self.signal_active = false,
            UiMsg::Listening {
                center_mhz,
                label,
                snr_db,
                audio_peak,
            } => {
                self.signal_active = true;
                self.last_signal = label;
                self.last_snr = snr_db;
                self.audio_peak = audio_peak;
                self.center_hz = center_mhz * 1e6;
            }
            UiMsg::Log(s) => self.log_push(s),
            UiMsg::Random(hex) => self.random_hex = Some(hex),
        }
    }

    fn submit_command(&mut self, text: &str) {
        let text = text.trim().to_string();
        if text.is_empty() {
            return;
        }
        // Keep the view and the receiver pointed at the same thing.
        //
        // Without this the aircraft map stays on screen after you retune to
        // a band — still captioned 1090 MHz, still showing the last frame
        // counts — while the radio is somewhere else entirely. A display
        // that keeps reporting on a frequency the hardware has left is
        // worse than a blank one.
        let lower = text.to_ascii_lowercase();
        let to_adsb = matches!(lower.as_str(), "adsb" | "ads-b" | "aircraft positions");
        let to_ais = matches!(lower.as_str(), "ais" | "ship positions");
        let to_aprs = matches!(lower.as_str(), "aprs" | "ham position beacons");
        let to_acars = lower == "acars" || lower == "aircraft datalink" || lower.starts_with("acars ");
        let to_sstv = lower == "sstv" || lower == "slow-scan images" || lower.starts_with("sstv ");
        let to_drone = matches!(lower.as_str(), "drone" | "drones" | "drone scan" | "fpv");
        let to_pager = lower == "pager"
            || lower == "pagers"
            || lower == "pocsag"
            || lower.starts_with("pager ")
            || lower.starts_with("pocsag ");
        let to_ism = lower == "sensors" || lower.starts_with("sensors ");
        if to_adsb {
            self.view = View::Adsb;
        } else if to_ais {
            self.view = View::Marine;
        } else if to_aprs {
            self.view = View::Aprs;
        } else if to_acars {
            self.view = View::Acars;
        } else if to_sstv {
            self.view = View::Sstv;
        } else if to_drone {
            self.view = View::Drone;
        } else if to_pager {
            self.view = View::Pager;
        } else if to_ism {
            self.view = View::Ism;
        } else {
            if self.view == View::Adsb {
                self.view = View::Live;
            }
            if self.view == View::Marine {
                self.view = View::Live;
            }
            if self.view == View::Aprs {
                self.view = View::Live;
            }
            if self.view == View::Acars {
                self.view = View::Live;
            }
            if self.view == View::Sstv {
                self.view = View::Live;
            }
            if self.view == View::Drone {
                self.view = View::Live;
            }
            if self.view == View::Pager {
                self.view = View::Live;
            }
            if self.view == View::Ism {
                self.view = View::Live;
            }
        }
        if !to_adsb {
            self.adsb.clear();
            self.opensky_contacts.clear();
            self.adsb_selected = None;
        }
        if !to_ais {
            self.ais.clear();
            self.ais_selected = None;
        }
        if !to_aprs {
            self.aprs.clear();
            self.aprs_selected = None;
        }
        if !to_pager {
            // Counters belong to a channel the radio has left. The message
            // log is kept on purpose — a page that was received really was
            // received, and throwing the text away on a retune would lose
            // the one thing worth keeping.
            self.pager_lanes.clear();
            self.pager_syncs = 0;
        }
        if !to_drone {
            // The survey's picture belongs to a radio that has moved on.
            self.drone_bands.clear();
            self.drone_sigs.clear();
            self.drone_hop = None;
            self.drone_stare = None;
            self.drone_selected = None;
        }
        self.log_push(format!("▶ TUNE: {text}"));
        self.window_idx = 0;
        self.windows_total = 0;
        self.rds_ps = None;
        self.rds_radiotext = None;
        self.rds_pty = None;
        let _ = self.cmd_tx.send(Cmd::Tune {
            utterance: text.clone(),
            mode: self.selected_mode,
        });
        self.command_input = text;
    }

    /// A band preset button was clicked. Every band already carries its own
    /// correct default mode (Aviation=AM, FM=WFM, everything else=NFM, from
    /// the same table `rules::parse` matches against) — clearing any manual
    /// mode override here is what makes clicking AVIATION actually *set up*
    /// AM instead of silently keeping whatever mode was last forced.
    fn submit_preset(&mut self, key: &str) {
        self.selected_mode = None;
        self.last_band_key = Some(key.to_string());
        // Point the band-wide waterfall at this band's actual range, so its
        // x-axis spans the whole thing rather than one tuner window.
        if let Some((lo, hi)) = Self::band_range(key) {
            self.band_wf.set_band(lo, hi);
        }
        self.submit_command(key);
    }

    /// Frequency range for each band key — the same ranges the preset
    /// buttons advertise.
    fn band_range(key: &str) -> Option<(f64, f64)> {
        Some(match key {
            "aviation" => (118.0, 137.0),
            "marine" => (156.0, 162.025),
            "weather" => (162.400, 162.550),
            "2m" => (144.0, 148.0),
            "70cm" => (420.0, 450.0),
            "frs" => (462.5, 467.75),
            "fm" => (88.0, 108.0),
            "ism" => (433.05, 434.79),
            "railway" => (159.81, 161.565),
            "cb" => (26.965, 27.405),
            "vor" => (108.0, 118.0),
            "satellite" => (136.0, 138.0),
            "police" => (150.0, 174.0),
            "business" => (450.0, 470.0),
            "radiosonde" => (400.0, 406.0),
            "900" => (902.0, 928.0),
            "800" => (851.0, 869.0),
            "adsb" => (1090.0, 1090.0),
            // The whole survey, end to end: the tile marker shows where
            // this reaches, which is the useful thing about it.
            "drone" => (433.05, 1360.0),
            // The Canadian paging plan, from ISED SRSP-504.
            "pager" => (931.0125, 931.9875),
            // The burst survey sits on 433.92 by default; the marker shows
            // where it starts.
            "sensors" => (433.92, 433.92),
            "ais" => (161.975, 162.025),
            "aprs" => (144.39, 144.39),
            "acars" => (131.55, 131.55),
            "sstv" => (14.23, 14.23),
            "80m" => (3.5, 4.0),
            "shortwave" => (5.9, 6.2),
            "40m" => (7.0, 7.3),
            "31m" => (9.4, 9.9),
            "20m" => (14.0, 14.35),
            _ => return None,
        })
    }

    /// A mode button was clicked — re-tunes the current frequency in that
    /// mode. All six modes (NFM/WFM/AM/USB/LSB/CW) run real demod chains.
    fn set_mode(&mut self, mode: Demod, label: &str) {
        self.selected_mode = Some(mode);
        self.log_push(format!("▶ MODE: {label}"));
        let freq_text = format!("{:.4}", self.center_hz / 1e6);
        let _ = self.cmd_tx.send(Cmd::Tune {
            utterance: freq_text,
            mode: Some(mode),
        });
    }

    fn set_gain(&mut self) {
        let g = if self.gain_auto { None } else { Some(self.gain_tenths_db) };
        let _ = self.cmd_tx.send(Cmd::SetGain(g));
    }

    /// Levels the trace/waterfall to whatever's actually on screen right
    /// now — the equivalent of Zeus's "Auto Scale".
    fn auto_scale(&mut self) {
        if self.spectrum_live.is_empty() {
            return;
        }
        let min = self.spectrum_live.iter().cloned().fold(f32::INFINITY, f32::min);
        let max = self.spectrum_live.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
        if min.is_finite() && max.is_finite() && max > min {
            self.floor_db = min - 5.0;
            self.ceil_db = max + 8.0;
        }
    }

    fn save_memory(&mut self) {
        let f = self.center_hz / 1e6;
        self.save_frequency(f, format!("{f:.4}"));
    }

    /// Keep a frequency under a name. Saving the same one twice replaces
    /// it rather than filling the list with duplicates.
    fn save_frequency(&mut self, mhz: f64, label: String) {
        self.memories.retain(|(_, f)| (f - mhz).abs() > 1e-6);
        if self.memories.len() >= 8 {
            self.memories.remove(0);
        }
        self.memories.push((label.clone(), mhz));
        self.log_push(format!("saved {label} at {mhz:.4} MHz"));
        self.save_state();
    }

    /// Write position and saved frequencies to disk. Best-effort: a failure
    /// to write is not worth interrupting anything over.
    fn save_state(&self) {
        if let Some(path) = state_file_path() {
            let _ = std::fs::write(
                &path,
                format_state(self.receiver_lat, self.receiver_lon, &self.memories),
            );
        }
    }

    /// Load position and saved frequencies, if the file is there. Called
    /// once at startup. Anything missing or malformed just keeps its
    /// default, so a first run or a damaged file both start clean.
    fn load_state(&mut self) {
        let path = match state_file_path() {
            Some(p) => p,
            None => return,
        };
        let text = match std::fs::read_to_string(&path) {
            Ok(t) => t,
            Err(_) => return,
        };
        let (lat, lon, mems) = parse_state(&text);
        if let Some(x) = lat {
            self.receiver_lat = x;
        }
        if let Some(x) = lon {
            self.receiver_lon = x;
        }
        if !mems.is_empty() {
            self.memories = mems;
        }
    }

    /// Drive the online aircraft-detail lookup: request details for a newly
    /// selected aircraft, and fold in any reply (decoding the photo to a
    /// texture). Cached per hex so each aircraft is fetched once.
    fn tick_acinfo(&mut self, ctx: &egui::Context) {
        let sel: Option<String> = self
            .adsb_selected
            .as_ref()
            .map(|h| h.to_ascii_lowercase())
            .or_else(|| self.adsb_os_selected.clone());

        if let Some(hex) = sel {
            if !self.ac_cache.contains_key(&hex) {
                if self.ac_lookup.is_none() {
                    self.ac_lookup = Some(acinfo::Lookup::start());
                }
                let idle = self.ac_lookup.as_ref().map(|l| !l.in_flight).unwrap_or(false);
                if idle && self.ac_pending.as_deref() != Some(hex.as_str()) {
                    let callsign = self
                        .adsb
                        .iter()
                        .find(|a| a.hex_id.eq_ignore_ascii_case(&hex))
                        .and_then(|a| a.callsign.clone())
                        .or_else(|| {
                            self.opensky_contacts
                                .iter()
                                .find(|t| t.icao24 == hex)
                                .and_then(|t| t.callsign.clone())
                        });
                    if let Some(l) = self.ac_lookup.as_mut() {
                        if l.request(hex.clone(), callsign) {
                            self.ac_pending = Some(hex);
                        }
                    }
                }
            }
        }

        let reply = self.ac_lookup.as_mut().and_then(|l| l.poll());
        if let Some(reply) = reply {
            match reply {
                acinfo::Reply::Ok(info) => {
                    let hex = info.hex.clone();
                    if let Some(bytes) = &info.photo {
                        if let Ok(img) = image::load_from_memory(bytes) {
                            let rgba = img.to_rgba8();
                            let (w, h) = (rgba.width() as usize, rgba.height() as usize);
                            let ci = egui::ColorImage::from_rgba_unmultiplied([w, h], rgba.as_raw());
                            let tex = ctx.load_texture(
                                format!("acphoto_{hex}"),
                                ci,
                                egui::TextureOptions::LINEAR,
                            );
                            self.ac_textures.insert(hex.clone(), tex);
                        }
                    }
                    self.ac_cache.insert(hex, info);
                }
                acinfo::Reply::Failed(e) => {
                    if let Some(hex) = self.ac_pending.clone() {
                        self.ac_cache.insert(
                            hex.clone(),
                            acinfo::AcInfo {
                                hex,
                                note: e,
                                ..Default::default()
                            },
                        );
                    }
                }
            }
            self.ac_pending = None;
        }
    }

    /// SKIP means "move on" — but when parked on a single frequency there
    /// is nothing to move on *to*, and the button would silently do
    /// nothing. In that state the useful action is to get scanning again.
    fn skip_signal(&mut self) {
        if self.windows_total <= 1 {
            if let Some(key) = self.last_band_key.clone() {
                self.log_push("↻ parked — resuming band sweep".into());
                self.submit_preset(&key);
                return;
            }
        }
        let _ = self.cmd_tx.send(Cmd::SkipSignal);
    }

    fn toggle_auto_scan(&mut self) {
        self.auto_scan = !self.auto_scan;
        let _ = self.cmd_tx.send(Cmd::SetAutoScan(self.auto_scan));
    }

    /// Steps backward through recently found signals — a "previous
    /// station" control, not a reversal of the sweep direction itself
    /// (sweep-core doesn't expose that).
    fn go_back(&mut self) {
        if self.signal_history.len() < 2 {
            return;
        }
        let pos = self
            .history_pos
            .unwrap_or(self.signal_history.len() - 1)
            .saturating_sub(1);
        self.history_pos = Some(pos);
        if let Some(&freq) = self.signal_history.get(pos) {
            let text = format!("{freq:.4}");
            self.submit_command(&text);
        }
    }

    fn try_add_station(&mut self) {
        let name = self.new_station_name.trim().to_string();
        let freq: Option<f64> = self.new_station_freq.trim().parse().ok();
        let lat: Option<f64> = self.new_station_lat.trim().parse().ok();
        let lon: Option<f64> = self.new_station_lon.trim().parse().ok();
        match (freq, lat, lon) {
            (Some(freq_mhz), Some(lat), Some(lon)) if !name.is_empty() => {
                self.log_push(format!("+ site: {name} ({freq_mhz:.4} MHz)"));
                self.stations.push(Station {
                    name,
                    freq_mhz,
                    lat,
                    lon,
                });
                self.new_station_name.clear();
                self.new_station_freq.clear();
                self.new_station_lat.clear();
                self.new_station_lon.clear();
            }
            _ => self.log_push("! site needs a name, MHz, lat, and lon".into()),
        }
    }

    /// A stylized S-meter reading from the SNR we already have. This is NOT
    /// a calibrated dBµV S-meter — the pipeline never touches an absolute
    /// reference level — just a familiar-looking readout so "how strong is
    /// it" has an at-a-glance answer. Every 6 dB of SNR ~ one S-unit, which
    /// is the conventional (if approximate) ham-radio rule of thumb.
    fn s_meter_label(&self) -> String {
        let units = (self.last_snr / 6.0).floor().max(0.0);
        if units <= 9.0 {
            format!("S{}", units as i32)
        } else {
            format!("S9+{:.0}dB", (units - 9.0) * 6.0)
        }
    }

    fn draw_bearing(&self, painter: &egui::Painter, rect: egui::Rect) {
        painter.rect_filled(rect, egui::Rounding::ZERO, theme::surface());
        let center = rect.center();
        let radius = (rect.width().min(rect.height()) / 2.0 - 18.0).max(10.0);

        // Range rings + compass ticks.
        for frac in [0.33, 0.66, 1.0] {
            painter.circle_stroke(
                center,
                radius * frac,
                egui::Stroke::new(1.0_f32, theme::mute()),
            );
        }
        for (deg, label) in [(0.0, "N"), (90.0, "E"), (180.0, "S"), (270.0, "W")] {
            let a = (deg as f32).to_radians();
            let p = center + egui::vec2(a.sin(), -a.cos()) * (radius + 10.0);
            painter.text(
                p,
                egui::Align2::CENTER_CENTER,
                label,
                egui::FontId::monospace(11.0),
                theme::mute(),
            );
        }
        painter.circle_filled(center, 4.0, theme::signal());
        painter.text(
            center + egui::vec2(0.0, 14.0),
            egui::Align2::CENTER_TOP,
            "YOU",
            egui::FontId::monospace(10.0),
            theme::signal(),
        );

        let freq_mhz = self.center_hz / 1e6;
        if stations::is_decommissioned_weather_channel(freq_mhz) {
            painter.text(
                rect.left_top() + egui::vec2(6.0, 6.0),
                egui::Align2::LEFT_TOP,
                "WEATHERADIO CANADA — DECOMMISSIONED MAR 31, 2026",
                egui::FontId::monospace(10.5),
                theme::live(),
            );
        }

        match stations::find_station(&self.stations, freq_mhz, 0.02) {
            Some(st) => {
                let brng = stations::bearing_deg(self.receiver_lat, self.receiver_lon, st.lat, st.lon);
                let dist = stations::distance_km(self.receiver_lat, self.receiver_lon, st.lat, st.lon);
                let max_range = 200.0; // km shown at the outer ring; purely a display scale
                let r = radius * (dist / max_range).clamp(0.04, 1.0) as f32;
                let a = (brng as f32).to_radians();
                let p = center + egui::vec2(a.sin(), -a.cos()) * r;
                painter.line_segment([center, p], egui::Stroke::new(1.2_f32, theme::live()));
                painter.circle_filled(p, 5.0, theme::live());
                painter.text(
                    rect.left_bottom() + egui::vec2(6.0, -6.0),
                    egui::Align2::LEFT_BOTTOM,
                    format!("{} — {:.0}° / {:.0} km", st.name, brng, dist),
                    egui::FontId::monospace(11.0),
                    theme::live(),
                );
            }
            None => {
                painter.text(
                    rect.left_bottom() + egui::vec2(6.0, -6.0),
                    egui::Align2::LEFT_BOTTOM,
                    "no known site for this frequency — add one below",
                    egui::FontId::monospace(10.5),
                    theme::mute(),
                );
            }
        }
        theme::bracket_frame(painter, rect, theme::mute(), 12.0);
    }

    /// The span the *display* currently represents. While sweeping, the
    /// worker retunes constantly and `center_hz` moves many times a
    /// second — so once the pointer is over the display we freeze the span
    /// it was showing when the pointer arrived. Without this, a click maps
    /// against whatever window the sweep happened to jump to between the
    /// press and the release, which lands you on a frequency you never
    /// pointed at (and silently converts a band sweep into parking on one
    /// channel).
    fn current_span_mhz(&self) -> (f64, f64) {
        let half = self.capture_rate() / 2.0 / 1e6;
        let center = self.frozen_center_hz.unwrap_or(self.center_hz);
        (center / 1e6 - half, center / 1e6 + half)
    }

    fn freq_at_x(&self, rect: egui::Rect, x: f32) -> f64 {
        let (low, high) = self.current_span_mhz();
        let t = ((x - rect.left()) / rect.width()).clamp(0.0, 1.0) as f64;
        low + t * (high - low)
    }

    /// Tracks the mouse for the live crosshair on every hover (drawn by
    /// `draw_trace`/`draw_waterfall`), but only actually retunes the
    /// hardware on a plain click or when a drag is released — retuning on
    /// every pixel of a drag was recentering the whole waterfall's
    /// frequency axis underneath the cursor dozens of times a second,
    /// which is what made dragging feel broken rather than smooth.
    /// Two different gestures on the same surface:
    ///
    /// - **Click** — jump to the absolute frequency under the pointer.
    /// - **Drag** — grab the band and slide it, VFO-knob style. This is
    ///   *relative*: horizontal movement shifts frequency continuously and
    ///   can run past the visible span in either direction, rather than
    ///   being limited to what's currently on screen.
    ///
    /// Dragging retunes live (that's the point — you're listening as you
    /// slide), but it accumulates into `drag_freq` rather than re-reading
    /// `center_hz`, which the sweep is busy overwriting many times a
    /// second. Reading that mid-drag is what made the old version fight
    /// the cursor.
    fn handle_tune_interaction(&mut self, resp: &egui::Response, rect: egui::Rect) {
        let pos = resp.hover_pos().or_else(|| resp.interact_pointer_pos());
        if let Some(p) = pos {
            if self.frozen_center_hz.is_none() {
                self.frozen_center_hz = Some(self.center_hz);
            }
            self.cursor_freq = Some(self.freq_at_x(rect, p.x));
        }

        if resp.drag_started() {
            self.drag_freq = Some(self.center_hz / 1e6);
        }

        if resp.dragged() {
            let dx = resp.drag_delta().x;
            if dx != 0.0 {
                // Same scale as the display: one screen-width of drag
                // moves you one full span, so the motion matches what the
                // waterfall shows. Dragging right moves *down* in
                // frequency, like pulling a dial's tape to the right.
                let (low, high) = self.current_span_mhz();
                let mhz_per_px = (high - low) / rect.width() as f64;
                let base = self.drag_freq.unwrap_or(self.center_hz / 1e6);
                let next = (base - dx as f64 * mhz_per_px).clamp(24.0, 1766.0);
                self.drag_freq = Some(next);
                // Retune at most every ~120 ms while dragging: enough to
                // hear the band slide past, without flooding the worker
                // with a retune every frame.
                let now = std::time::Instant::now();
                let due = self
                    .last_drag_tune
                    .map_or(true, |t| now.duration_since(t).as_millis() >= 120);
                if due {
                    self.last_drag_tune = Some(now);
                    let text = format!("{next:.4}");
                    self.submit_command(&text);
                }
            }
        }

        if resp.drag_stopped() {
            if let Some(f) = self.drag_freq.take() {
                let text = format!("{f:.4}");
                self.submit_command(&text);
            }
            self.last_drag_tune = None;
        } else if resp.clicked() {
            if let Some(p) = resp.interact_pointer_pos().or(pos) {
                let freq = self.freq_at_x(rect, p.x);
                let text = format!("{freq:.4}");
                self.submit_command(&text);
            }
        }
    }

    /// Vertical cursor line + frequency label at the mouse position,
    /// shared between the trace and waterfall since they use the same
    /// x-axis mapping — this is what makes the drag position visible
    /// instead of the person flying blind while sliding around.
    /// Analog-style arc S-meter with a swinging needle. S-units are the
    /// ham convention: S1-S9 then "+dB over S9", roughly 6 dB per unit.
    /// Same honest caveat as the text readout — this is derived from SNR,
    /// not an absolute calibrated field-strength measurement.
    /// The channel spacing for wherever we're currently tuned. Stepping by
    /// this (rather than an arbitrary amount) means dragging lands on real
    /// channels — FM on odd tenths, airband on 25 kHz, and so on — instead
    /// of the dead gaps between them.
    fn current_step_mhz(&self) -> f64 {
        let f = self.center_hz / 1e6;
        if (88.0..108.0).contains(&f) {
            0.2
        } else if (118.0..137.0).contains(&f) || (156.0..162.1).contains(&f) {
            0.025
        } else if (26.9..27.5).contains(&f) {
            0.01
        } else {
            0.0125
        }
    }

    /// Steps by whole channels. Dragging right goes up in frequency,
    /// matching how the numbers themselves run.
    fn step_channel(&mut self, steps: i32) {
        if steps == 0 {
            return;
        }
        let step = self.current_step_mhz();
        let f = self.center_hz / 1e6 + steps as f64 * step;
        // FM sits on odd tenths — snap so a step from 98.9 lands on 99.1,
        // never 99.0, which has no station on it.
        let f = if (88.0..108.0).contains(&f) {
            let n = ((f - 87.9) / 0.2).round();
            87.9 + n * 0.2
        } else {
            f
        };
        let f = f.clamp(24.0, 1766.0);
        let text = format!("{f:.4}");
        self.submit_command(&text);
    }

    /// Drag the big frequency readout like a dial. Accumulates pixels so a
    /// slow drag still steps predictably rather than needing a full
    /// channel's worth of movement in a single frame.
    fn handle_freq_drag(&mut self, resp: &egui::Response) {
        if resp.drag_started() {
            self.freq_drag_accum = 0.0;
        }
        if resp.dragged() {
            self.freq_drag_accum += resp.drag_delta().x;
            const PX_PER_CHANNEL: f32 = 24.0;
            let steps = (self.freq_drag_accum / PX_PER_CHANNEL).trunc() as i32;
            if steps != 0 {
                self.freq_drag_accum -= steps as f32 * PX_PER_CHANNEL;
                self.step_channel(steps);
            }
        }
    }

    /// One-click mission tiles. Icon, name, what you'd hear, frequency
    /// range — click and it tunes, sets the right demodulator, and starts
    /// scanning. No typing, no mode selection, no frequency lookup.
    ///
    /// Returns the band key that was clicked, if any.
    /// The SELECT MODE home screen: categorised tiles, one click each.
    ///
    /// Only modes this radio can genuinely do are clickable. A "not built
    /// yet" section lists the decoders that would need real work, marked
    /// as such rather than presented as working buttons.
    ///
    /// Returns the band key that was clicked, if any.
    fn draw_tiles(&mut self, ui: &mut egui::Ui) -> Option<&'static str> {
        use icons::Icon;

        // (icon, label, band key, what you'd actually hear)
        const VOICE: &[(Icon, &'static str, &'static str, &'static str)] = &[
            (Icon::Radio,    "FM RADIO", "fm",       "88–108 MHz"),
            (Icon::Aircraft, "AIRCRAFT", "aviation", "118–137 MHz"),
            (Icon::Anchor,   "MARINE",   "marine",   "156–162 MHz"),
            (Icon::Cloud,    "WEATHER",  "weather",  "162.4–162.55"),
            (Icon::Walkie,   "WALKIE",   "frs",      "462–468 MHz"),
        ];
        const AMATEUR: &[(Icon, &'static str, &'static str, &'static str)] = &[
            (Icon::Antenna, "2M HAM",   "2m",      "144–148 MHz"),
            (Icon::Waves,   "70CM HAM", "70cm",    "420–450 MHz"),
            (Icon::Truck,   "CB RADIO", "cb",      "26.9–27.4 MHz"),
            (Icon::Train,   "RAILWAY",  "railway", "159.8–161.6"),
            (Icon::Key,     "433 MHZ",  "ism",     "433.05-434.79"),
            (Icon::Waves,   "900 MHZ",  "900",     "902-928 MHz"),
        ];
        const HF: &[(Icon, &'static str, &'static str, &'static str)] = &[
            (Icon::Waves,   "SHORTWAVE",  "shortwave", "5.9-6.2 MHz"),
            (Icon::Waves,   "31M SW",     "31m",       "9.4-9.9 MHz"),
            (Icon::Antenna, "80M HAM",    "80m",       "3.5-4.0 MHz"),
            (Icon::Antenna, "40M HAM",    "40m",       "7.0-7.3 MHz"),
            (Icon::Antenna, "20M HAM",    "20m",       "14.0-14.35"),
        ];
        const SERVICES: &[(Icon, &'static str, &'static str, &'static str)] = &[
            (Icon::Scanner,  "PUBLIC SAFETY", "police",   "150-174 MHz"),
            (Icon::Antenna,  "BUSINESS UHF",  "business", "450-470 MHz"),
            (Icon::Aircraft, "VOR NAVAIDS",   "vor",      "108-118 MHz"),
            (Icon::Radio,    "SATELLITE VHF", "satellite","136-138 MHz"),
            (Icon::Cloud,    "RADIOSONDE",    "radiosonde","400-406 MHz"),
            (Icon::Walkie,   "800 TRUNKED",   "800",      "851-869 MHz"),
        ];
        // Decoders — these pull data out of a signal rather than tuning a
        // band, so they get their own row.
        const DECODERS: &[(Icon, &'static str, &'static str, &'static str)] = &[
            (Icon::Aircraft, "AIRCRAFT ADS-B", "adsb", "1090 MHz, on a map"),
            (Icon::Anchor, "VESSELS AIS", "ais", "162 MHz, on a map"),
            (Icon::Antenna, "APRS", "aprs", "144.39 MHz, on a map"),
            (Icon::Aircraft, "ACARS", "acars", "131.55 MHz, messages"),
            (Icon::Star, "SSTV PICTURES", "sstv", "14.23 MHz, images"),
            (Icon::Scanner, "PAGERS", "pager", "931 MHz, messages"),
        ];
        // A survey rather than a decoder: nothing here is demodulated, and
        // the output is the shape of whatever energy is in the band. Its own
        // row because the distinction matters — the decoders above tell you
        // what something said, this one only tells you something is there.
        const SURVEYS: &[(Icon, &'static str, &'static str, &'static str)] = &[
            (Icon::Drone, "DRONE BANDS", "drone", "433 / 915 / 1.2 GHz"),
            (Icon::Key, "ISM SENSORS", "sensors", "433 / 915 bursts"),
        ];
        // Decoders that would each be a real project. Listed so the
        // roadmap is visible, but not dressed up as working buttons.
        const UNBUILT: &[(&str, &str)] = &[("SATELLITE", "pass prediction")];

        let mut clicked: Option<&'static str> = None;

        egui::ScrollArea::vertical().id_source("tiles").show(ui, |ui| {
            ui.add_space(4.0);
            ui.label(
                egui::RichText::new("What do you want to receive?")
                    .size(15.0)
                    .color(theme::text()),
            );

            // One category: a quiet heading, then a wrapped row of tiles.
            let active_key: Option<String> = self.last_band_key.clone();
            // Takes the active key as a parameter rather than capturing
            // `self` — a captured borrow would still be live when
            // `self.presets_open` is written further down.
            // The tile tables are `const`, so their strings really are
            // 'static — saying so lets the clicked key be stored without
            // the borrow checker assuming a shorter closure-body lifetime.
            let section = |ui: &mut egui::Ui,
                           title: &str,
                           items: &[(Icon, &'static str, &'static str, &'static str)],
                           active_key: &Option<String>,
                           clicked: &mut Option<&'static str>| {
                ui.add_space(14.0);
                ui.label(egui::RichText::new(title).font(theme::display(11.0)).color(theme::mute()));
                ui.add_space(6.0);

                let avail = ui.available_width();
                let cols = ((avail / 170.0).floor() as usize).clamp(2, 6);
                let tw = (avail - (cols as f32 - 1.0) * 10.0) / cols as f32;

                for row in items.chunks(cols) {
                    ui.horizontal(|ui| {
                        for (icon, label, key, sub) in row {
                            let active = active_key.as_deref() == Some(*key);
                            let (rect, resp) =
                                ui.allocate_exact_size(egui::vec2(tw, 60.0), egui::Sense::click());
                            let hov = resp.hovered();
                            let p = ui.painter();
                            // No outline on a resting tile. Fifteen outlined
                            // boxes at once is a grid of frames with content
                            // inside it; the fill step alone is enough to say
                            // "this is a target", and the outline then means
                            // something when it appears.
                            p.rect_filled(
                                rect,
                                egui::Rounding::same(4.0),
                                if active {
                                    egui::Color32::from_rgb(52, 42, 20)
                                } else if hov {
                                    egui::Color32::from_rgb(40, 46, 54)
                                } else {
                                    theme::surface()
                                },
                            );
                            if active {
                                p.rect_stroke(
                                    rect,
                                    egui::Rounding::same(4.0),
                                    egui::Stroke::new(1.0_f32, theme::live()),
                                );
                            }
                            let ic = if active {
                                theme::live()
                            } else if hov {
                                theme::text()
                            } else {
                                theme::mute()
                            };
                            let icon_rect = egui::Rect::from_center_size(
                                egui::pos2(rect.left() + 22.0, rect.top() + 21.0),
                                egui::vec2(20.0, 20.0),
                            );
                            icons::draw(p, icon_rect, *icon, ic);
                            p.text(
                                egui::pos2(rect.left() + 40.0, rect.top() + 21.0),
                                egui::Align2::LEFT_CENTER,
                                label,
                                egui::FontId::proportional(12.0),
                                if active { theme::live() } else { theme::text() },
                            );
                            p.text(
                                egui::pos2(rect.left() + 40.0, rect.top() + 37.0),
                                egui::Align2::LEFT_CENTER,
                                sub,
                                egui::FontId::proportional(10.0),
                                theme::mute(),
                            );

                            // Where this band sits in the spectrum.
                            //
                            // Fifteen tiles that differ only in their text is
                            // a menu; the one real attribute every band has,
                            // and differs in, is its place on the dial. A
                            // scale from 100 kHz to 2 GHz — logarithmic,
                            // because the useful bands are not evenly
                            // spread — turns each tile into a position as
                            // well as a name, and the row of them becomes a
                            // picture of the spectrum.
                            // Single-frequency decoders are in the table as
                            // a point; the marker has a minimum width below
                            // and the band waterfall opens them out, so
                            // nothing here needs a special case.
                            let span = Self::band_range(key);
                            if let Some((lo, hi)) = span {
                                let y = rect.bottom() - 10.0;
                                let (x0, x1) = (rect.left() + 12.0, rect.right() - 12.0);
                                let w = x1 - x0;
                                let pos = |f: f64| {
                                    let t = (f.max(0.1).log10() - (-1.0)) / (3.301 - (-1.0));
                                    x0 + w * (t.clamp(0.0, 1.0) as f32)
                                };
                                // No full-width baseline on every tile — just the
                                // position marker. The row of markers still reads
                                // as a spectrum without a line under each name.
                                // A six-pixel floor on the marker. Most of
                                // these bands are a fraction of one percent
                                // of a log scale spanning four decades, and
                                // drawn to true width they come out a single
                                // pixel — an indicator nobody can see is not
                                // an indicator. So width is indicative and
                                // position is exact, which is the right way
                                // round for something whose job is "where".
                                let (a, b) = (pos(lo), pos(hi));
                                p.line_segment(
                                    [egui::pos2(a, y), egui::pos2(a + (b - a).max(6.0), y)],
                                    egui::Stroke::new(
                                        3.0_f32,
                                        if active {
                                            theme::live()
                                        } else {
                                            egui::Color32::from_rgb(96, 108, 122)
                                        },
                                    ),
                                );
                                // The scale's endpoints were labelled on
                                // every tile: twenty-three copies of the
                                // same two strings. The position is read by
                                // comparison with the other tiles, not off
                                // an axis.
                            }
                            if resp.clicked() {
                                *clicked = Some(*key);
                            }
                        }
                    });
                    ui.add_space(8.0);
                }
            };

            // Maps & decoders first: these open a live map or message view,
            // not the spectrum. They used to sit below the listen-only bands,
            // under the fold, which is why every visible tile "just went to
            // spectrum" — the interesting views were off-screen.
            section(ui, "Maps & decoders — opens a live view", DECODERS, &active_key, &mut clicked);
            section(ui, "Surveys — band activity", SURVEYS, &active_key, &mut clicked);
            section(ui, "Voice & broadcast — opens the spectrum", VOICE, &active_key, &mut clicked);
            section(ui, "Amateur and hobby", AMATEUR, &active_key, &mut clicked);
            section(ui, "Services", SERVICES, &active_key, &mut clicked);
            section(ui, "Shortwave and HF", HF, &active_key, &mut clicked);

            // Tools that exist but aren't a band.
            ui.add_space(18.0);
            ui.label(egui::RichText::new("Tools").size(12.0).color(theme::mute()));
            ui.add_space(6.0);
            ui.horizontal_wrapped(|ui| {
                if ui.button("  Things to listen to  ").clicked() {
                    self.presets_open = true;
                }
                if ui.button("  Test tone  ")
                    .on_hover_text("1 kHz straight to the speakers, bypassing the dongle — confirms the audio path works")
                    .clicked()
                {
                    let _ = self.cmd_tx.send(Cmd::TestTone);
                }
                if ui.button("  Settings  ").clicked() {
                    self.settings_open = true;
                }
            });

            // Roadmap, honestly labelled.
            ui.add_space(22.0);
            ui.label(egui::RichText::new("Not built yet").size(12.0).color(theme::mute()));
            ui.add_space(6.0);
            ui.label(
                egui::RichText::new(
                    "These are decoders rather than bands — each needs real DSP work, so \
                     they're listed here rather than shown as buttons that do nothing.",
                )
                .small()
                .color(theme::mute()),
            );
            ui.add_space(6.0);
            ui.horizontal_wrapped(|ui| {
                for (name, what) in UNBUILT {
                    ui.add_enabled(false, egui::Button::new(format!("{name} — {what}")));
                }
            });
            ui.add_space(10.0);
        });

        clicked
    }

    /// The dongle's actual capture rate right now.
    ///
    /// Not a constant any more: ADS-B retunes the hardware to 2 MS/s so
    /// that the bit slicer gets exactly two samples per microsecond. Every
    /// place that turns a spectrum bin into a frequency has to use this
    /// rather than the scanner's own rate, or the ADS-B waterfall is
    /// labelled a fifth wider than it is.
    fn capture_rate(&self) -> f64 {
        if self.view == View::Adsb || self.last_band_key.as_deref() == Some("adsb") {
            sweep_core::adsb::ADSB_RATE as f64
        } else {
            worker::IF_RATE as f64
        }
    }

    /// The demodulation mode in words, for the readout.
    fn mode_label(&self) -> &'static str {
        match self.selected_mode {
            Some(Demod::Am) => "AM",
            Some(Demod::Wfm) => "wide FM",
            Some(Demod::Nfm) => "narrow FM",
            Some(Demod::Usb) => "USB",
            Some(Demod::Lsb) => "LSB",
            Some(Demod::Cw) => "CW",
            None => "auto",
        }
    }

    /// What the receiver is doing, in the words someone would use for it.
    /// Replaces a LISTEN / PARKED / SWEEP status field that needed a legend.
    fn activity_text(&self) -> &'static str {
        if self.signal_active {
            "receiving"
        } else if self.windows_total <= 1 {
            "parked"
        } else {
            "scanning"
        }
    }


    fn draw_crosshair(&self, painter: &egui::Painter, rect: egui::Rect) {
        let Some(freq) = self.cursor_freq else { return };
        let (low, high) = self.current_span_mhz();
        if high <= low {
            return;
        }
        let t = ((freq - low) / (high - low)).clamp(0.0, 1.0) as f32;
        let x = rect.left() + t * rect.width();
        painter.line_segment(
            [egui::pos2(x, rect.top()), egui::pos2(x, rect.bottom())],
            egui::Stroke::new(1.0_f32, theme::live()),
        );
        let id = bands::identify_frequency(freq, &self.stations);
        let label = match id {
            Some(name) => format!("{freq:.4} MHz — {name}"),
            None => format!("{freq:.4} MHz"),
        };
        painter.text(
            egui::pos2(x, rect.top() + 2.0),
            egui::Align2::CENTER_TOP,
            label,
            egui::FontId::monospace(11.0),
            theme::live(),
        );
    }

    fn draw_trace(&self, painter: &egui::Painter, rect: egui::Rect) {
        painter.rect_filled(rect, egui::Rounding::same(8.0), theme::surface());
        // Horizontal dB gridlines, labelled.
        let span = (self.ceil_db - self.floor_db).max(1.0);
        for i in 1..5 {
            let t = i as f32 / 5.0;
            let y = rect.top() + rect.height() * t;
            painter.line_segment(
                [egui::pos2(rect.left(), y), egui::pos2(rect.right(), y)],
                egui::Stroke::new(1.0_f32, theme::grid()),
            );
            let db = self.ceil_db - span * t;
            painter.text(
                egui::pos2(rect.left() + 4.0, y - 1.0),
                egui::Align2::LEFT_BOTTOM,
                format!("{db:.0}"),
                egui::FontId::monospace(9.0),
                theme::mute(),
            );
        }
        // Vertical gridlines give the eye something to measure against.
        for i in 1..8 {
            let x = rect.left() + rect.width() * i as f32 / 8.0;
            painter.line_segment(
                [egui::pos2(x, rect.top()), egui::pos2(x, rect.bottom())],
                egui::Stroke::new(1.0_f32, theme::grid()),
            );
        }
        let n = self.spectrum_live.len().max(1);
        let map_y = |db: f32| {
            let t = ((db - self.floor_db) / span).clamp(0.0, 1.0);
            rect.bottom() - t * rect.height()
        };
        let x_at = |i: usize| rect.left() + rect.width() * i as f32 / n as f32;

        if self.floor_live.len() > 1 {
            let pts: Vec<egui::Pos2> = self
                .floor_live
                .iter()
                .enumerate()
                .map(|(i, &d)| egui::pos2(x_at(i), map_y(d)))
                .collect();
            painter.add(egui::Shape::line(pts, egui::Stroke::new(1.0_f32, theme::line())));
        }
        if self.peak_hold && self.peak_bins.len() > 1 {
            let pts: Vec<egui::Pos2> = self
                .peak_bins
                .iter()
                .enumerate()
                .map(|(i, &d)| egui::pos2(x_at(i), map_y(d)))
                .collect();
            painter.add(egui::Shape::line(
                pts,
                egui::Stroke::new(1.0_f32, theme::live().gamma_multiply(0.7)),
            ));
        }
        // Filled area beneath the trace, as vertical slices whose colour
        // fades with height. This is what makes a spectrum read as a solid
        // shape rather than a thin squiggle.
        if self.spectrum_live.len() > 1 {
            let base = if self.signal_active { theme::live() } else { theme::signal() };
            for (i, &d) in self.spectrum_live.iter().enumerate() {
                let x = x_at(i);
                let y = map_y(d);
                let h = (rect.bottom() - y).max(0.0);
                if h <= 0.5 {
                    continue;
                }
                // Taller peaks get a stronger fill, so activity pops.
                let strength = (h / rect.height()).clamp(0.0, 1.0);
                painter.rect_filled(
                    egui::Rect::from_min_max(
                        egui::pos2(x, y),
                        egui::pos2(x + rect.width() / n as f32 + 0.7, rect.bottom()),
                    ),
                    egui::Rounding::ZERO,
                    base.gamma_multiply(0.10 + strength * 0.30),
                );
            }
            let pts: Vec<egui::Pos2> = self
                .spectrum_live
                .iter()
                .enumerate()
                .map(|(i, &d)| egui::pos2(x_at(i), map_y(d)))
                .collect();
            painter.add(egui::Shape::line(pts, egui::Stroke::new(1.6_f32, base)));
        }
        theme::bracket_frame(painter, rect, theme::line(), 10.0);
        self.draw_crosshair(painter, rect);
    }

    // -- ADS-B ---------------------------------------------------------------

    /// A plane, drawn as a plane — a filled jet silhouette that points down
    /// its reported track, with a soft contact glow underneath.
    ///
    /// The silhouette is assembled from convex pieces — fuselage, each
    /// swept wing, each tailplane half — because egui's tessellator only
    /// fills convex shapes, and a whole aircraft outline is emphatically not
    /// convex. Built this way it fills cleanly and still reads as an
    /// aircraft rather than the three bare strokes it used to be.
    fn draw_plane(
        painter: &egui::Painter,
        p: egui::Pos2,
        heading_deg: Option<f32>,
        size: f32,
        col: egui::Color32,
        weight: f32,
    ) {
        // Contact glow: a soft halo that makes a real decode read as "hot"
        // and lifts it off the map. Kept faint so a crowded sky does not
        // turn into a smear.
        painter.circle_filled(p, size * 1.7, col.gamma_multiply(0.14));
        painter.circle_filled(p, size * 1.05, col.gamma_multiply(0.14));

        // Without a reported track there is no meaningful orientation, so
        // show a filled diamond instead of pointing the nose somewhere
        // invented.
        let h = match heading_deg {
            Some(h) => h.to_radians(),
            None => {
                let s = size * 0.62;
                let pts = vec![
                    egui::pos2(p.x, p.y - s),
                    egui::pos2(p.x + s, p.y),
                    egui::pos2(p.x, p.y + s),
                    egui::pos2(p.x - s, p.y),
                ];
                painter.add(egui::Shape::convex_polygon(
                    pts,
                    col.gamma_multiply(0.85),
                    egui::Stroke::new(weight.max(1.0), col),
                ));
                return;
            }
        };
        let (sn, cs) = (h.sin(), h.cos());
        // Local frame: +y is the nose. Rotating by the track angle means
        // screen-north maps to heading 0, which is what the compass rose
        // around the edge promises.
        let m = |x: f32, y: f32| {
            egui::pos2(p.x + (x * cs + y * sn) * size, p.y - (y * cs - x * sn) * size)
        };
        let edge = egui::Stroke::new((weight * 0.5).max(0.6), col.gamma_multiply(0.5));
        let fill = col;
        let poly = |pts: Vec<egui::Pos2>| {
            painter.add(egui::Shape::convex_polygon(pts, fill, edge));
        };
        // Fuselage: a slim needle from nose to tail.
        poly(vec![
            m(0.0, 1.25),
            m(0.13, 0.15),
            m(0.10, -1.0),
            m(-0.10, -1.0),
            m(-0.13, 0.15),
        ]);
        // Swept wings, one convex triangle each side.
        poly(vec![m(-0.06, 0.28), m(-1.05, -0.34), m(-0.06, -0.12)]);
        poly(vec![m(0.06, 0.28), m(1.05, -0.34), m(0.06, -0.12)]);
        // Tailplane, swept the same way.
        poly(vec![m(-0.05, -0.74), m(-0.44, -1.02), m(-0.05, -0.92)]);
        poly(vec![m(0.05, -0.74), m(0.44, -1.02), m(0.05, -0.92)]);
    }

    /// Fill a closed polygon, however awkward its shape.
    ///
    /// egui can only fill convex shapes reliably, and a lake is not convex
    /// — Georgian Bay alone would tie a fan triangulation in knots. So this
    /// does it the way a rasteriser does: for each horizontal line across
    /// the shape, find where the edges cross it, sort those crossings, and
    /// fill between alternate pairs. That is the even-odd rule, and it is
    /// correct for any outline at all, including ones with holes and
    /// islands.
    ///
    /// Two pixels a scanline rather than one: at map scale the seams are
    /// invisible and it halves the work.
    fn fill_polygon(
        painter: &egui::Painter,
        pts: &[egui::Pos2],
        clip: egui::Rect,
        colour: egui::Color32,
    ) {
        if pts.len() < 3 {
            return;
        }
        let (mut top, mut bot) = (f32::MAX, f32::MIN);
        for p in pts {
            top = top.min(p.y);
            bot = bot.max(p.y);
        }
        top = top.max(clip.top());
        bot = bot.min(clip.bottom());
        if bot <= top {
            return;
        }

        const STEP: f32 = 2.0;
        let mut xs: Vec<f32> = Vec::with_capacity(16);
        let mut y = top;
        while y <= bot {
            xs.clear();
            for i in 0..pts.len() {
                let a = pts[i];
                let b = pts[(i + 1) % pts.len()];
                // A scanline crosses this edge when the endpoints straddle
                // it. The half-open test is what stops a vertex exactly on
                // the line being counted twice.
                if (a.y <= y) != (b.y <= y) {
                    let t = (y - a.y) / (b.y - a.y);
                    xs.push(a.x + t * (b.x - a.x));
                }
            }
            if xs.len() >= 2 {
                xs.sort_by(|p, q| p.partial_cmp(q).unwrap_or(std::cmp::Ordering::Equal));
                for pair in xs.chunks_exact(2) {
                    let x0 = pair[0].max(clip.left());
                    let x1 = pair[1].min(clip.right());
                    if x1 > x0 {
                        painter.rect_filled(
                            egui::Rect::from_min_max(
                                egui::pos2(x0, y),
                                egui::pos2(x1, y + STEP),
                            ),
                            egui::Rounding::ZERO,
                            colour,
                        );
                    }
                }
            }
            y += STEP;
        }
    }

    /// A vessel, drawn as a hull seen from above: pointed at the bow,
    /// square at the stern, so it reads as a boat and never as an aircraft
    /// when both are on the same chart.
    fn draw_ship(
        painter: &egui::Painter,
        p: egui::Pos2,
        course_deg: Option<f32>,
        size: f32,
        col: egui::Color32,
        weight: f32,
    ) {
        let h = course_deg.unwrap_or(0.0).to_radians();
        let (sn, cs) = (h.sin(), h.cos());
        let m = |x: f32, y: f32| {
            egui::pos2(p.x + (x * cs + y * sn) * size, p.y - (y * cs - x * sn) * size)
        };
        let hull = vec![
            m(0.0, 1.3),
            m(0.62, 0.25),
            m(0.62, -1.0),
            m(-0.62, -1.0),
            m(-0.62, 0.25),
        ];
        painter.add(egui::Shape::closed_line(
            hull,
            egui::Stroke::new(weight, col),
        ));
        // Without a course there is no bow to point, so mark it as a hull
        // of unknown heading rather than inventing one.
        if course_deg.is_none() {
            painter.circle_filled(p, size * 0.3, col);
        }
    }

    /// The plan-position display: a north-up map of every aircraft with a
    /// resolved position.
    ///
    /// The projection is azimuthal equidistant about the view centre, so
    /// distance from the receiver's marker is proportional to distance on
    /// the ground and the range rings mean what they say. Coastlines go
    /// through the same projection, which is what lets you read an
    /// aircraft's position off the land underneath it.
    ///
    /// Positions here are self-reported. ADS-B is aircraft saying where
    /// they are; this receiver contributes only whether it heard them.
    fn draw_radar(&mut self, ui: &mut egui::Ui, rect: egui::Rect, resp: &egui::Response) {
        let painter = ui.painter_at(rect);
        let c = rect.center();
        let r = (rect.width().min(rect.height()) / 2.0 - 18.0).max(20.0);
        painter.rect_filled(rect, egui::Rounding::same(6.0), egui::Color32::from_rgb(9, 14, 19));

        let have_pos = self.receiver_lat != 0.0 || self.receiver_lon != 0.0;

        // --- interaction ----------------------------------------------------
        // Scroll to zoom about the pointer, drag to pan. Both adjust the
        // view, never the data.
        if resp.hovered() {
            let scroll = ui.input(|i| i.raw_scroll_delta.y);
            if scroll.abs() > 0.5 {
                let f = (1.0_f32 - scroll * 0.0015).clamp(0.8, 1.25);
                self.adsb_range_km = (self.adsb_range_km * f).clamp(2.0, 800.0);
            }
        }
        if resp.dragged() {
            let d = resp.drag_delta();
            let km_per_px = self.adsb_range_km / r;
            let (vlat, vlon) = self.adsb_view_center.unwrap_or((
                self.receiver_lat,
                self.receiver_lon,
            ));
            let dlat = (d.y * km_per_px) as f64 / 111.32;
            let dlon = -(d.x * km_per_px) as f64
                / (111.32 * vlat.to_radians().cos().abs().max(0.05));
            self.adsb_view_center = Some((
                (vlat + dlat).clamp(-89.0, 89.0),
                vlon + dlon,
            ));
        }
        if resp.double_clicked() {
            self.adsb_view_center = None;
        }

        let (lat0, lon0) = self
            .adsb_view_center
            .unwrap_or((self.receiver_lat, self.receiver_lon));
        let range = self.adsb_range_km as f64;

        // Project a lat/lon to the screen, and say whether it landed inside
        // the plotted disc.
        // The projection still measures distance from the receiver in units
        // of the range ring (magnitude 1.0 == one range), so the rings stay
        // honest. What changed is the clip: instead of discarding everything
        // past the ring, the map now fills the whole panel and the corners
        // simply show further out than the outermost ring. That is what a
        // real radar display does — the circle is the range mark, not the
        // edge of the world.
        let clip = rect.expand(2.0);
        let to_screen = |lat: f64, lon: f64| -> (egui::Pos2, bool) {
            let (x, y) = geomap::project(lat0, lon0, lat, lon, range);
            let p = egui::pos2(c.x + x * r, c.y - y * r);
            (p, clip.contains(p))
        };

        // Clip strokes to the disc by dropping segments that leave it.
        // Cheap, and at these scales indistinguishable from real clipping.
        let draw_line = |pts: &[(f64, f64)], stroke: egui::Stroke| {
            let mut run: Vec<egui::Pos2> = Vec::new();
            for &(la, lo) in pts {
                let (p, inside) = to_screen(la, lo);
                if inside {
                    run.push(p);
                } else if run.len() > 1 {
                    painter.add(egui::Shape::line(std::mem::take(&mut run), stroke));
                } else {
                    run.clear();
                }
            }
            if run.len() > 1 {
                painter.add(egui::Shape::line(run, stroke));
            }
        };

        if have_pos {
            // Land first, as a solid ground tone over the whole plot, then
            // the water cut out of it. That ordering is what turns a
            // wireframe of coastlines into something that reads as a map:
            // the shoreline stops being a line on black and becomes an
            // edge between two surfaces.
            //
            // Natural Earth's coastline file is lines only, with no land
            // polygons in it, so land cannot be filled directly. Filling
            // everything and cutting the lakes back out gives the right
            // answer anywhere the water is lakes — which, for anywhere
            // inland, it is.
            const LAND: egui::Color32 = egui::Color32::from_rgb(22, 26, 17);
            const WATER: egui::Color32 = egui::Color32::from_rgb(11, 24, 38);
            painter.rect_filled(rect, egui::Rounding::same(6.0), LAND);

            if let Some(map) = &self.geomap {
                let mut poly: Vec<egui::Pos2> = Vec::new();
                for l in map.lines.iter().filter(|l| l.closed && l.kind == geomap::Kind::Water)
                {
                    poly.clear();
                    let mut any_near = false;
                    for &(la, lo) in &l.pts {
                        let (p, inside) = to_screen(la, lo);
                        any_near |= inside;
                        poly.push(p);
                    }
                    // A lake whose every vertex is off the plot is either
                    // far away or completely surrounding it; filling the
                    // first wastes time and the second is rare enough to
                    // skip.
                    if any_near {
                        Self::fill_polygon(&painter, &poly, rect, WATER);
                    }
                }
            }

            // Graticule over the surfaces, dim, so it reads as a reference
            // grid rather than part of the geography.
            let (grid, step) = geomap::graticule(lat0, lon0, range);
            let grid_stroke =
                egui::Stroke::new(1.0_f32, egui::Color32::from_rgba_unmultiplied(120, 150, 110, 26));
            for g in &grid {
                draw_line(&g.pts, grid_stroke);
            }

            if let Some(map) = &self.geomap {
                let by_kind = |k: geomap::Kind, stroke: egui::Stroke| {
                    for l in map.lines.iter().filter(|l| l.kind == k) {
                        draw_line(&l.pts, stroke);
                    }
                };
                // Political boundaries are reference, not subject: dashed
                // in feel, dim in fact.
                by_kind(
                    geomap::Kind::Border,
                    egui::Stroke::new(1.0_f32, egui::Color32::from_rgb(78, 80, 54)),
                );
                // The shoreline is the edge between the two surfaces, so it
                // only needs to be a shade brighter than either.
                by_kind(
                    geomap::Kind::Coast,
                    egui::Stroke::new(1.3_f32, egui::Color32::from_rgb(74, 128, 110)),
                );
                by_kind(
                    geomap::Kind::Water,
                    egui::Stroke::new(1.0_f32, egui::Color32::from_rgb(40, 92, 128)),
                );
            }

            // Grid labels along the panel edges — parallels down the left,
            // meridians along the bottom. The loop bounds are sized to the
            // panel's half-extent in kilometres rather than to the range, so
            // the labels reach into the corners that now lie beyond the ring.
            let lblc = egui::Color32::from_rgb(78, 92, 104);
            let font = egui::FontId::monospace(9.0);
            let half_w_km = (rect.width() * 0.5 / r) as f64 * range;
            let half_h_km = (rect.height() * 0.5 / r) as f64 * range;
            let dlat_v = half_h_km / 111.32 * 1.05;
            let dlon_v =
                half_w_km / (111.32 * lat0.to_radians().cos().abs().max(0.05)) * 1.05;
            let mut la = ((lat0 - dlat_v) / step).ceil() * step;
            while la <= lat0 + dlat_v {
                let (p, _) = to_screen(la, lon0);
                if p.y > rect.top() + 6.0 && p.y < rect.bottom() - 6.0 {
                    painter.text(
                        egui::pos2(rect.left() + 4.0, p.y),
                        egui::Align2::LEFT_CENTER,
                        format!("{:.2}{}", la.abs(), if la >= 0.0 { "N" } else { "S" }),
                        font.clone(),
                        lblc,
                    );
                }
                la += step;
            }
            let mut lo = ((lon0 - dlon_v) / step).ceil() * step;
            while lo <= lon0 + dlon_v {
                let (p, _) = to_screen(lat0, lo);
                if p.x > rect.left() + 6.0 && p.x < rect.right() - 6.0 {
                    painter.text(
                        egui::pos2(p.x, rect.bottom() - 4.0),
                        egui::Align2::CENTER_BOTTOM,
                        format!("{:.2}{}", lo.abs(), if lo >= 0.0 { "E" } else { "W" }),
                        font.clone(),
                        lblc,
                    );
                }
                lo += step;
            }
        }

        // --- range rings, centred on the receiver, not the screen ----------
        let (rx, _) = to_screen(self.receiver_lat, self.receiver_lon);
        for k in 1..=4 {
            let rr = r * k as f32 / 4.0;
            painter.circle_stroke(
                rx,
                rr,
                egui::Stroke::new(
                    1.0_f32,
                    if k == 4 {
                        egui::Color32::from_rgb(38, 96, 92)
                    } else {
                        egui::Color32::from_rgb(28, 62, 62)
                    },
                ),
            );
            let km = self.adsb_range_km * k as f32 / 4.0;
            painter.text(
                egui::pos2(rx.x + 3.0, rx.y - rr),
                egui::Align2::LEFT_BOTTOM,
                format!("{km:.0}"),
                egui::FontId::monospace(9.0),
                egui::Color32::from_rgb(52, 96, 96),
            );
        }
        for (deg, name) in [(0.0_f32, "N"), (90.0, "E"), (180.0, "S"), (270.0, "W")] {
            let a = deg.to_radians();
            let (dx, dy) = (a.sin(), -a.cos());
            painter.text(
                egui::pos2(c.x + dx * (r + 9.0), c.y + dy * (r + 9.0)),
                egui::Align2::CENTER_CENTER,
                name,
                egui::FontId::monospace(11.0),
                theme::mute(),
            );
        }
        // The receiver itself.
        painter.circle_filled(rx, 3.5, theme::live());
        painter.circle_stroke(rx, 7.0, egui::Stroke::new(1.0_f32, theme::live()));

        if !have_pos {
            painter.text(
                c + egui::vec2(0.0, 16.0),
                egui::Align2::CENTER_TOP,
                "set your latitude and longitude in Settings\nto plot aircraft here",
                egui::FontId::proportional(12.0),
                theme::live(),
            );
            return;
        }

        // --- sonar sweep ----------------------------------------------------
        // A rotating phosphor arm with a fading wake, plus a ping ring
        // expanding from the receiver. Pure decoration drawn UNDER the
        // aircraft — it never moves a contact or invents one — but it makes
        // the plot read as live radar instead of a static chart.
        if self.adsb_sweep {
            let t = ui.input(|i| i.time);
            ui.ctx().request_repaint(); // keep it turning every frame
            let period = 6.0_f64; // seconds per revolution
            let lead = ((t % period) / period * std::f64::consts::TAU) as f32;
            let reach = r * 1.5; // past the outer ring, into the corners
            let g = theme::signal();
            // Fading wake behind the arm, as a triangle fan from the receiver.
            let mut mesh = egui::Mesh::default();
            let steps = 40usize;
            let wake = 1.2_f32; // radians of trail
            mesh.colored_vertex(rx, egui::Color32::TRANSPARENT);
            for s in 0..=steps {
                let f = s as f32 / steps as f32;
                let a = lead - wake * f;
                let dir = egui::vec2(a.sin(), -a.cos());
                let alpha = ((1.0 - f) * 70.0) as u8;
                mesh.colored_vertex(
                    rx + dir * reach,
                    egui::Color32::from_rgba_unmultiplied(g.r(), g.g(), g.b(), alpha),
                );
                if s > 0 {
                    mesh.add_triangle(0, s as u32, s as u32 + 1);
                }
            }
            painter.add(egui::Shape::mesh(mesh));
            // Bright leading edge.
            let dir = egui::vec2(lead.sin(), -lead.cos());
            painter.line_segment(
                [rx, rx + dir * reach],
                egui::Stroke::new(1.5_f32, g.gamma_multiply(0.9)),
            );
            // Ping ring, expanding and fading on a 2-second cycle.
            let ping = ((t % 2.0) / 2.0) as f32;
            let pa = ((1.0 - ping) * 55.0) as u8;
            painter.circle_stroke(
                rx,
                r * ping,
                egui::Stroke::new(
                    1.2_f32,
                    egui::Color32::from_rgba_unmultiplied(g.r(), g.g(), g.b(), pa),
                ),
            );
        }

        // Everything clickable, gathered as it is drawn so the hit test uses
        // exactly the positions on screen.
        let mut hits: Vec<(egui::Pos2, String)> = Vec::new();

        // --- overlay --------------------------------------------------------
        // Anything we decoded ourselves is left out: a hollow symbol means
        // "up there, and this receiver did not hear it", which is the whole
        // point of the comparison.
        let mine: std::collections::HashSet<String> = self
            .adsb
            .iter()
            .map(|a| a.hex_id.to_ascii_lowercase())
            .collect();
        let mut overlay_drawn = 0usize;
        if self.adsb_overlay {
            let grey = egui::Color32::from_rgb(104, 118, 136);
            for t in &self.opensky_contacts {
                if mine.contains(&t.icao24) {
                    continue;
                }
                let (la, lo) = t.position_now();
                let (p, inside) = to_screen(la, lo);
                if !inside {
                    continue;
                }
                let sel = self.adsb_os_selected.as_deref() == Some(t.icao24.as_str());
                let col = if sel { theme::live() } else { grey };
                // One minute of flight along the reported track, so a moving
                // aircraft shows where it is heading even on the overlay.
                if let (Some(hdg), Some(kt)) = (t.heading_deg, t.speed_kt) {
                    if kt > 1.0 {
                        let lead_km = kt * 1.852 / 60.0;
                        let lr = r * (lead_km / self.adsb_range_km);
                        let h = hdg.to_radians();
                        painter.line_segment(
                            [p, egui::pos2(p.x + h.sin() * lr, p.y - h.cos() * lr)],
                            egui::Stroke::new(1.0_f32, col.gamma_multiply(0.5)),
                        );
                    }
                }
                if sel {
                    painter.circle_stroke(p, 13.0, egui::Stroke::new(1.0_f32, theme::live()));
                }
                Self::draw_plane(&painter, p, t.heading_deg, 5.0, col, if sel { 2.0 } else { 1.0 });
                overlay_drawn += 1;
                hits.push((p, format!("os:{}", t.icao24)));
            }
            // Labelling sixty aircraft at once is unreadable, so the
            // overlay only names itself when the view is sparse enough for
            // the names to land somewhere distinct — callsign and flight
            // level, the two things you read first.
            if overlay_drawn <= 24 {
                for t in &self.opensky_contacts {
                    if mine.contains(&t.icao24) {
                        continue;
                    }
                    let (la, lo) = t.position_now();
                    let (p, inside) = to_screen(la, lo);
                    if !inside {
                        continue;
                    }
                    let sel = self.adsb_os_selected.as_deref() == Some(t.icao24.as_str());
                    let col = if sel { theme::live() } else { grey };
                    let tag = t
                        .callsign
                        .clone()
                        .unwrap_or_else(|| t.icao24.to_ascii_uppercase());
                    let alt = t
                        .alt_ft
                        .map(|f| format!(" FL{:03}", (f as f32 / 100.0).round() as i32))
                        .unwrap_or_default();
                    painter.text(
                        p + egui::vec2(8.0, 7.0),
                        egui::Align2::LEFT_CENTER,
                        format!("{tag}{alt}"),
                        egui::FontId::monospace(9.0),
                        col,
                    );
                }
            }
        }

        // --- our own decodes -------------------------------------------------
        for a in &self.adsb {
            let (lat, lon) = match (a.lat, a.lon) {
                (Some(la), Some(lo)) => (la, lo),
                _ => continue,
            };
            let (p, inside) = to_screen(lat, lon);
            if !inside {
                continue;
            }

            // Contacts fade as they go stale, so a list that has stopped
            // updating looks like one rather than a live picture. Positions
            // are never extrapolated here — unlike the overlay, these are
            // things this radio actually heard, and inventing motion for
            // them would blur that line.
            let fade = (1.0 - a.age_s / 60.0).clamp(0.25, 1.0);
            let sel = self.adsb_selected.as_deref() == Some(a.hex_id.as_str());
            let col = if sel {
                theme::live()
            } else {
                egui::Color32::from_rgba_unmultiplied(
                    theme::signal().r(),
                    theme::signal().g(),
                    theme::signal().b(),
                    (255.0 * fade) as u8,
                )
            };

            // Track vector: one minute of flight at the reported ground
            // speed, so the plot shows where it is going.
            if let (Some(hdg), Some(kt)) = (a.heading_deg, a.speed_kt) {
                let lead_km = kt * 1.852 / 60.0;
                let lr = r * (lead_km / self.adsb_range_km);
                let h = hdg.to_radians();
                painter.line_segment(
                    [p, egui::pos2(p.x + h.sin() * lr, p.y - h.cos() * lr)],
                    egui::Stroke::new(1.0_f32, col.gamma_multiply(0.6)),
                );
            }
            if sel {
                painter.circle_stroke(p, 13.0, egui::Stroke::new(1.0_f32, theme::live()));
            }
            Self::draw_plane(&painter, p, a.heading_deg, 7.0, col, if sel { 2.2 } else { 1.7 });

            let tag = a.callsign.clone().unwrap_or_else(|| a.hex_id.clone());
            let alt = a
                .alt_ft
                .map(|f| format!(" FL{:03}", (f as f32 / 100.0).round() as i32))
                .unwrap_or_default();
            painter.text(
                p + egui::vec2(9.0, -8.0),
                egui::Align2::LEFT_CENTER,
                format!("{tag}{alt}"),
                egui::FontId::monospace(10.0),
                col,
            );
            hits.push((p, a.hex_id.clone()));
        }

        // --- vessels ----------------------------------------------------------
        //
        // Same projection, same rings: a ship 30 km out sits where an
        // aircraft 30 km out would. They never appear together in practice
        // — one dongle, one band — but the chart does not change shape when
        // you switch, which is what makes the two modes feel like one
        // instrument.
        for v in &self.ais {
            let (lat, lon) = match (v.lat, v.lon) {
                (Some(la), Some(lo)) => (la, lo),
                _ => continue,
            };
            let (p, inside) = to_screen(lat, lon);
            if !inside {
                continue;
            }
            let fade = (1.0 - v.age_s / 900.0).clamp(0.3, 1.0);
            let sel = self.ais_selected == Some(v.mmsi);
            let col = if sel {
                theme::live()
            } else {
                egui::Color32::from_rgba_unmultiplied(
                    theme::signal().r(),
                    theme::signal().g(),
                    theme::signal().b(),
                    (255.0 * fade) as u8,
                )
            };
            if let (Some(c), Some(kt)) = (v.cog_deg, v.sog_kt) {
                if kt > 0.3 {
                    // Ten minutes of steaming, because ships are slow and a
                    // one-minute vector would be invisible.
                    let lead_km = kt * 1.852 / 6.0;
                    let lr = r * (lead_km / self.adsb_range_km);
                    let a = c.to_radians();
                    painter.line_segment(
                        [p, egui::pos2(p.x + a.sin() * lr, p.y - a.cos() * lr)],
                        egui::Stroke::new(1.0_f32, col.gamma_multiply(0.6)),
                    );
                }
            }
            if sel {
                painter.circle_stroke(p, 13.0, egui::Stroke::new(1.0_f32, theme::live()));
            }
            Self::draw_ship(&painter, p, v.cog_deg, 6.0, col, if sel { 2.2 } else { 1.6 });
            painter.text(
                p + egui::vec2(9.0, -8.0),
                egui::Align2::LEFT_CENTER,
                v.label.as_str(),
                egui::FontId::monospace(10.0),
                col,
            );
            hits.push((p, format!("mmsi:{}", v.mmsi)));
        }

        // --- amateur stations -------------------------------------------------
        //
        // Mostly fixed or slow, so a square rather than a vehicle symbol —
        // a digipeater on a tower and a car on the highway are the same
        // kind of contact here, and the list says which.
        for st in &self.aprs {
            let (lat, lon) = match (st.lat, st.lon) {
                (Some(la), Some(lo)) => (la, lo),
                _ => continue,
            };
            let (p, inside) = to_screen(lat, lon);
            if !inside {
                continue;
            }
            let fade = (1.0 - st.age_s / 3600.0).clamp(0.3, 1.0);
            let sel = self.aprs_selected.as_deref() == Some(st.call.as_str());
            let col = if sel {
                theme::live()
            } else {
                egui::Color32::from_rgba_unmultiplied(
                    theme::signal().r(),
                    theme::signal().g(),
                    theme::signal().b(),
                    (255.0 * fade) as u8,
                )
            };
            if let (Some(c), Some(kt)) = (st.course_deg, st.speed_kt) {
                if kt > 1.0 {
                    let lead_km = kt * 1.852 / 12.0;
                    let lr = r * (lead_km / self.adsb_range_km);
                    let a = c.to_radians();
                    painter.line_segment(
                        [p, egui::pos2(p.x + a.sin() * lr, p.y - a.cos() * lr)],
                        egui::Stroke::new(1.0_f32, col.gamma_multiply(0.6)),
                    );
                }
            }
            let sq = egui::Rect::from_center_size(p, egui::vec2(8.0, 8.0));
            painter.rect_stroke(
                sq,
                egui::Rounding::ZERO,
                egui::Stroke::new(if sel { 2.0_f32 } else { 1.4_f32 }, col),
            );
            painter.text(
                p + egui::vec2(9.0, -8.0),
                egui::Align2::LEFT_CENTER,
                st.call.as_str(),
                egui::FontId::monospace(10.0),
                col,
            );
            hits.push((p, format!("call:{}", st.call)));
        }

        // --- scale bar --------------------------------------------------------
        {
            // A round number of kilometres that comes out between a fifth
            // and a half of the plot width.
            let target = self.adsb_range_km / 2.0;
            let mag = 10f32.powf(target.log10().floor());
            let bar_km = [1.0, 2.0, 5.0, 10.0]
                .iter()
                .map(|m| m * mag)
                .find(|v| *v >= target * 0.5)
                .unwrap_or(mag);
            let px = r * (bar_km / self.adsb_range_km);
            let y = rect.bottom() - 30.0;
            let x0 = rect.left() + 14.0;
            let st = egui::Stroke::new(1.5_f32, theme::mute());
            painter.line_segment([egui::pos2(x0, y), egui::pos2(x0 + px, y)], st);
            painter.line_segment([egui::pos2(x0, y - 4.0), egui::pos2(x0, y + 4.0)], st);
            painter.line_segment(
                [egui::pos2(x0 + px, y - 4.0), egui::pos2(x0 + px, y + 4.0)],
                st,
            );
            painter.text(
                egui::pos2(x0 + px / 2.0, y - 6.0),
                egui::Align2::CENTER_BOTTOM,
                format!("{bar_km:.0} km"),
                egui::FontId::monospace(9.0),
                theme::mute(),
            );
        }

        // --- selection --------------------------------------------------------
        if resp.clicked() {
            if self.adsb_set_loc {
                // Move the receiver to the clicked point: invert the radar's
                // azimuthal projection to a bearing and distance, then step
                // that far from the view centre.
                if let Some(click) = resp.interact_pointer_pos() {
                    let dx = ((click.x - c.x) / r) as f64;
                    let dy = (-(click.y - c.y) / r) as f64;
                    let dist = (dx * dx + dy * dy).sqrt() * range;
                    let bearing = dx.atan2(dy).to_degrees();
                    let (nlat, nlon) = dest_point(lat0, lon0, bearing, dist);
                    self.receiver_lat = nlat.clamp(-89.9, 89.9);
                    self.receiver_lon = nlon;
                    self.adsb_view_center = None;
                    self.adsb_set_loc = false;
                    self.load_geomap();
                    if self.adsb_overlay {
                        self.tick_opensky(true);
                    }
                    self.save_state();
                }
            } else if let Some(click) = resp.interact_pointer_pos() {
                let mut best: Option<(f32, String)> = None;
                for (p, id) in &hits {
                    let d = p.distance(click);
                    if d <= 14.0 && best.as_ref().map(|(bd, _)| d < *bd).unwrap_or(true) {
                        best = Some((d, id.clone()));
                    }
                }
                match best {
                    Some((_, id)) if id.starts_with("call:") => {
                        let c = id[5..].to_string();
                        self.aprs_selected =
                            if self.aprs_selected.as_deref() == Some(c.as_str()) { None } else { Some(c) };
                        self.adsb_os_selected = None;
                    }
                    Some((_, id)) if id.starts_with("mmsi:") => {
                        let n: u32 = id[5..].parse().unwrap_or(0);
                        self.ais_selected = if self.ais_selected == Some(n) { None } else { Some(n) };
                        self.adsb_os_selected = None;
                    }
                    Some((_, id)) if id.starts_with("os:") => {
                        // An OpenSky contact — open its detail card. Mutually
                        // exclusive with our own selection so the one panel
                        // never has to guess which it is showing.
                        let hex = id[3..].to_string();
                        self.adsb_os_selected =
                            if self.adsb_os_selected.as_deref() == Some(hex.as_str()) {
                                None
                            } else {
                                Some(hex)
                            };
                        self.adsb_selected = None;
                    }
                    Some((_, id)) => {
                        self.adsb_selected = if self.adsb_selected.as_deref() == Some(id.as_str())
                        {
                            None
                        } else {
                            Some(id)
                        };
                        self.adsb_os_selected = None;
                    }
                    None => {
                        self.adsb_selected = None;
                        self.adsb_os_selected = None;
                    }
                }
            }
        }

        // Hover readout, so a blip can be identified without clicking it.
        if let Some(hover) = resp.hover_pos() {
            if let Some((_, id)) = hits
                .iter()
                .map(|(p, id)| (p.distance(hover), id))
                .filter(|(d, _)| *d <= 14.0)
                .min_by(|a, b| a.0.partial_cmp(&b.0).unwrap())
            {
                let text = if let Some(hex) = id.strip_prefix("os:") {
                    let hexu = hex.to_ascii_uppercase();
                    match self.opensky_contacts.iter().find(|t| t.icao24 == hex) {
                        Some(t) => {
                            let cs = t.callsign.clone().unwrap_or_default();
                            let alt = t
                                .alt_ft
                                .map(|f| format!("{f} ft"))
                                .unwrap_or_else(|| "—".into());
                            let spd = t
                                .speed_kt
                                .map(|s| format!("{s:.0} kt"))
                                .unwrap_or_else(|| "—".into());
                            let hdg = t
                                .heading_deg
                                .map(|h| format!("{h:03.0}°"))
                                .unwrap_or_else(|| "—".into());
                            let country = t.origin_country.clone().unwrap_or_default();
                            format!(
                                "{hexu}  {cs}\n{alt}   {spd}   {hdg}\n{country}\nclick for detail — heard elsewhere, not here"
                            )
                        }
                        None => hexu,
                    }
                } else {
                    id.clone()
                };
                let pos = hover + egui::vec2(12.0, 12.0);
                let g = painter.layout_no_wrap(
                    text.clone(),
                    egui::FontId::monospace(10.0),
                    theme::live(),
                );
                painter.rect_filled(
                    egui::Rect::from_min_size(pos, g.size()).expand(3.0),
                    egui::Rounding::same(3.0),
                    egui::Color32::from_rgba_unmultiplied(9, 14, 19, 230),
                );
                painter.galley(pos, g, theme::live());
            }
        }

        // --- legend and hints --------------------------------------------------
        let y = rect.bottom() - 14.0;
        let mut x = rect.left() + 14.0;
        Self::draw_plane(
            &painter,
            egui::pos2(x + 4.0, y),
            Some(0.0),
            5.0,
            theme::signal(),
            1.7,
        );
        painter.text(
            egui::pos2(x + 14.0, y),
            egui::Align2::LEFT_CENTER,
            "decoded here",
            egui::FontId::monospace(9.0),
            theme::mute(),
        );
        x += 105.0;
        if self.adsb_overlay {
            let grey = egui::Color32::from_rgb(104, 118, 136);
            Self::draw_plane(&painter, egui::pos2(x + 4.0, y), Some(0.0), 5.0, grey, 1.0);
            painter.text(
                egui::pos2(x + 14.0, y),
                egui::Align2::LEFT_CENTER,
                "overhead, not heard",
                egui::FontId::monospace(9.0),
                grey,
            );
        }
        painter.text(
            egui::pos2(rect.right() - 12.0, rect.bottom() - 14.0),
            egui::Align2::RIGHT_CENTER,
            if self.adsb_view_center.is_some() {
                "scroll to zoom   drag to pan   double-click to recentre"
            } else {
                "scroll to zoom   drag to pan"
            },
            egui::FontId::monospace(9.0),
            egui::Color32::from_rgb(58, 70, 82),
        );

        theme::bracket_frame(&painter, rect, theme::line(), 10.0);
    }
    /// Everything known about the selected aircraft, and — the part people
    /// always ask about — what is *not* known.
    fn draw_aircraft_detail(&mut self, ui: &mut egui::Ui) {
        // An OpenSky contact takes precedence when one is selected: it is
        // what the user just clicked, and it carries more than our own
        // decode usually does.
        if let Some(hex) = self.adsb_os_selected.clone() {
            match self.opensky_contacts.iter().find(|t| t.icao24 == hex).cloned() {
                Some(t) => {
                    self.draw_os_detail(ui, &t);
                    return;
                }
                None => self.adsb_os_selected = None,
            }
        }
        let sel = match self.adsb_selected.clone() {
            Some(s) => s,
            None => {
                ui.label(
                    egui::RichText::new(
                        "Click an aircraft on the map, or a row in either table below. \
                         Green is a decode from your own antenna; grey is OpenSky reporting \
                         something overhead that this receiver did not hear.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                ui.separator();
                return;
            }
        };
        let a = match self.adsb.iter().find(|a| a.hex_id == sel) {
            Some(a) => a.clone(),
            None => {
                // It aged out while selected.
                self.adsb_selected = None;
                return;
            }
        };

        egui::Frame::none()
            .fill(theme::raised())
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(8.0)
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(
                            a.callsign.clone().unwrap_or_else(|| "(no callsign)".into()),
                        )
                        .size(16.0)
                        .color(theme::live()),
                    );
                    ui.label(
                        egui::RichText::new(format!("ICAO {}", a.hex_id))
                            .monospace()
                            .color(theme::mute()),
                    );
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.small_button("✕").clicked() {
                            self.adsb_selected = None;
                        }
                    });
                });
                ui.separator();

                let row = |ui: &mut egui::Ui, k: &str, v: String| {
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new(k).small().color(theme::mute()));
                        ui.label(egui::RichText::new(v).monospace().color(theme::text()));
                    });
                };
                // Identity straight from the hex and callsign — no database,
                // no network. US tail number, country of registry, operator.
                if let Ok(hx) = u32::from_str_radix(a.hex_id.trim(), 16) {
                    if let Some(reg) = sweep_core::aircraft::icao_to_us_reg(hx) {
                        row(ui, "registration", reg);
                    }
                    if let Some(country) = sweep_core::aircraft::country_from_hex(hx) {
                        row(ui, "registry", country.to_string());
                    }
                }
                if let Some(op) = a
                    .callsign
                    .as_deref()
                    .and_then(sweep_core::aircraft::operator_from_callsign)
                {
                    row(ui, "operator", op.to_string());
                }
                // Online details (type, operator, route, photo), fetched in
                // the background and cached per aircraft.
                let hexl = a.hex_id.to_ascii_lowercase();
                let online = self.ac_cache.get(&hexl).cloned();
                let photo = self.ac_textures.get(&hexl).cloned();
                let pending = self.ac_pending.as_deref() == Some(hexl.as_str());
                draw_online_ac(ui, &row, online.as_ref(), photo.as_ref(), pending);
                if let (Some(la), Some(lo)) = (a.lat, a.lon) {
                    row(ui, "position", format!("{la:.4}, {lo:.4}"));
                    if self.receiver_lat != 0.0 || self.receiver_lon != 0.0 {
                        let d =
                            stations::distance_km(self.receiver_lat, self.receiver_lon, la, lo);
                        let b =
                            stations::bearing_deg(self.receiver_lat, self.receiver_lon, la, lo);
                        row(ui, "from you", format!("{d:.1} km, bearing {b:03.0}°"));
                    }
                } else {
                    row(
                        ui,
                        "position",
                        "not yet — needs a matching even/odd message pair".into(),
                    );
                }
                if let Some(f) = a.alt_ft {
                    row(ui, "altitude", format!("{f} ft"));
                }
                if let Some(s) = a.speed_kt {
                    row(ui, "ground speed", format!("{s:.0} kt"));
                }
                if let Some(h) = a.heading_deg {
                    row(ui, "track", format!("{h:03.0}°"));
                }
                if let Some(v) = a.vert_rate_fpm {
                    row(
                        ui,
                        "vertical",
                        format!(
                            "{v} ft/min {}",
                            if v > 100 {
                                "climbing"
                            } else if v < -100 {
                                "descending"
                            } else {
                                "level"
                            }
                        ),
                    );
                }
                row(ui, "signal", format!("{:.0} dB rel", a.rssi_db));
                row(
                    ui,
                    "messages",
                    format!("{}, last heard {:.0}s ago", a.messages, a.age_s),
                );

                ui.separator();
                // The honest answer to the question everybody asks.
                ui.label(
                    egui::RichText::new("Radio frequency: not transmitted")
                        .small()
                        .strong()
                        .color(theme::live()),
                );
                ui.label(
                    egui::RichText::new(
                        "ADS-B carries position, altitude, speed and identity — there is no \
                         field for which voice channel the crew is tuned to, so no receiver \
                         can report it. What is certain is the band: airliner voice is AM \
                         between 118 and 137 MHz, and the scanner can hunt it.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                ui.horizontal(|ui| {
                    if ui
                        .button("Scan aviation band")
                        .on_hover_text(
                            "Leaves ADS-B and sweeps 118–137 MHz in AM, stopping on whatever \
                             is actually transmitting",
                        )
                        .clicked()
                    {
                        self.submit_preset("aviation");
                        self.view = View::Live;
                    }
                    // Any station the person has entered themselves — the
                    // program ships none, because a tower frequency quoted
                    // from memory is a guess wearing a measurement's
                    // clothes.
                    if let (Some(la), Some(lo)) = (a.lat, a.lon) {
                        let near = self
                            .stations
                            .iter()
                            .filter(|s| (118.0..=137.0).contains(&s.freq_mhz))
                            .map(|s| (stations::distance_km(la, lo, s.lat, s.lon), s.clone()))
                            .min_by(|x, y| x.0.partial_cmp(&y.0).unwrap());
                        if let Some((d, s)) = near {
                            if ui
                                .button(format!("{} {:.3}", s.name, s.freq_mhz))
                                .on_hover_text(format!(
                                    "nearest aviation station you've entered — {d:.0} km from \
                                     this aircraft"
                                ))
                                .clicked()
                            {
                                self.selected_mode = Some(Demod::Am);
                                self.submit_command(&format!("{:.4}", s.freq_mhz));
                                self.view = View::Live;
                            }
                        }
                    }
                });
            });
        ui.add_space(6.0);
    }

    /// Detail for an OpenSky overlay contact — an aircraft a worldwide
    /// network reports overhead that this receiver did not decode itself.
    /// Everything here is self-reported over ADS-B and relayed; the one
    /// thing it is not is a measurement made here, and the card says so.
    fn draw_os_detail(&mut self, ui: &mut egui::Ui, t: &opensky::Contact) {
        let heard_here = self
            .adsb
            .iter()
            .any(|a| a.hex_id.eq_ignore_ascii_case(&t.icao24));
        let have_pos = self.receiver_lat != 0.0 || self.receiver_lon != 0.0;
        egui::Frame::none()
            .fill(theme::raised())
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(8.0)
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(
                            t.callsign.clone().unwrap_or_else(|| "(no callsign)".into()),
                        )
                        .size(16.0)
                        .color(if heard_here { theme::signal() } else { theme::live() }),
                    );
                    ui.label(
                        egui::RichText::new(format!("ICAO {}", t.icao24.to_ascii_uppercase()))
                            .monospace()
                            .color(theme::mute()),
                    );
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.small_button("✕").clicked() {
                            self.adsb_os_selected = None;
                        }
                    });
                });
                ui.label(
                    egui::RichText::new(if heard_here {
                        "via OpenSky — and decoded here too"
                    } else {
                        "via OpenSky — overhead now, not heard by this receiver"
                    })
                    .small()
                    .color(theme::mute()),
                );
                ui.separator();

                let row = |ui: &mut egui::Ui, k: &str, v: String| {
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new(k).small().color(theme::mute()));
                        ui.label(egui::RichText::new(v).monospace().color(theme::text()));
                    });
                };
                if let Some(c) = &t.origin_country {
                    row(ui, "registry", c.clone());
                }
                // Derived identity — US tail number, operator — from the hex
                // and callsign, same as our own decodes.
                if let Ok(hx) = u32::from_str_radix(t.icao24.trim(), 16) {
                    if let Some(reg) = sweep_core::aircraft::icao_to_us_reg(hx) {
                        row(ui, "registration", reg);
                    }
                    if t.origin_country.is_none() {
                        if let Some(country) = sweep_core::aircraft::country_from_hex(hx) {
                            row(ui, "registry", country.to_string());
                        }
                    }
                }
                if let Some(op) = t
                    .callsign
                    .as_deref()
                    .and_then(sweep_core::aircraft::operator_from_callsign)
                {
                    row(ui, "operator", op.to_string());
                }
                let hexl = t.icao24.to_ascii_lowercase();
                let online = self.ac_cache.get(&hexl).cloned();
                let photo = self.ac_textures.get(&hexl).cloned();
                let pending = self.ac_pending.as_deref() == Some(hexl.as_str());
                draw_online_ac(ui, &row, online.as_ref(), photo.as_ref(), pending);
                let (la, lo) = t.position_now();
                row(ui, "position", format!("{la:.4}, {lo:.4}"));
                if have_pos {
                    let d = stations::distance_km(self.receiver_lat, self.receiver_lon, la, lo);
                    let b = stations::bearing_deg(self.receiver_lat, self.receiver_lon, la, lo);
                    row(ui, "from you", format!("{d:.1} km, bearing {b:03.0}°"));
                }
                if let Some(f) = t.alt_ft {
                    row(ui, "altitude", format!("{f} ft  (FL{:03})", (f as f32 / 100.0).round() as i32));
                }
                if let Some(s) = t.speed_kt {
                    row(ui, "ground speed", format!("{s:.0} kt"));
                }
                if let Some(h) = t.heading_deg {
                    row(ui, "track", format!("{h:03.0}°"));
                }
                if let Some(v) = t.vert_rate_fpm {
                    row(
                        ui,
                        "vertical",
                        format!(
                            "{v} ft/min {}",
                            if v > 100 {
                                "climbing"
                            } else if v < -100 {
                                "descending"
                            } else {
                                "level"
                            }
                        ),
                    );
                }
                if let Some(sq) = &t.squawk {
                    // The three codes that mean something specific anywhere
                    // in the world. Everything else is just a discrete code.
                    let meaning = match sq.as_str() {
                        "7500" => "  — hijack",
                        "7600" => "  — radio failure",
                        "7700" => "  — general emergency",
                        _ => "",
                    };
                    row(ui, "squawk", format!("{sq}{meaning}"));
                }
                if t.on_ground {
                    row(ui, "state", "on the ground".into());
                }
                let age = t.fetched.elapsed().as_secs();
                row(
                    ui,
                    "fetched",
                    if age < 90 {
                        format!("{age}s ago")
                    } else {
                        format!("{age}s ago — position carried forward along its track")
                    },
                );

                ui.separator();
                ui.label(
                    egui::RichText::new("Radio frequency: not transmitted")
                        .small()
                        .strong()
                        .color(theme::live()),
                );
                ui.label(
                    egui::RichText::new(
                        "This is the network's picture, not this radio's. If you want to hear \
                         the crew, the band is AM 118–137 MHz — the scanner can hunt it.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                if ui
                    .button("Scan aviation band")
                    .on_hover_text("Sweeps 118–137 MHz in AM, stopping on whatever is transmitting")
                    .clicked()
                {
                    self.submit_preset("aviation");
                    self.view = View::Live;
                }
            });
        ui.add_space(6.0);
    }

    /// Read (or re-read) whatever geography is in `map/`.
    ///
    /// The clip is tied to the current position and range, so changing
    /// either means reloading — cheap enough at these scales, and far
    /// cheaper than keeping a world coastline projected every frame.
    fn load_geomap(&mut self) {
        let dir = geomap::map_dir();
        let (lat, lon) = self
            .adsb_view_center
            .unwrap_or((self.receiver_lat, self.receiver_lon));
        // Deliberately much wider than the current view. Parsing a world
        // coastline takes a noticeable fraction of a second, and doing that
        // on every scroll tick would make zooming unusable — so load once
        // over a window that zooming and panning can move around inside.
        let radius = (self.adsb_range_km as f64 * 4.0).clamp(400.0, 2500.0);
        self.geomap_window = Some((lat, lon, radius));
        let m = geomap::GeoMap::load(&dir, lat, lon, radius);
        self.geomap_note = if !m.note.is_empty() {
            m.note.clone()
        } else if m.loaded_from.is_empty() {
            String::new()
        } else {
            format!("map: {}", m.loaded_from.join(" · "))
        };
        self.geomap = Some(m);
    }

    /// The switch for what sits beside the map.
    fn draw_side_switcher(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            for (p, label, hint) in [
                (SidePane::Signal, "Signal", "spectrum and waterfall — what the radio is receiving"),
                (SidePane::Contacts, "Contacts", "the list, and whatever is selected"),
                (SidePane::Both, "Both", "stacked; wants a wide window"),
            ] {
                if ui
                    .selectable_label(self.side == p, label)
                    .on_hover_text(hint)
                    .clicked()
                {
                    self.side = p;
                }
            }
        });
    }

    /// Spectrum and waterfall, sized to fit beside a map.
    /// Clear the tuning meter's running state — called when retuning to a
    /// new signal so the average, peak, trend and reference all start fresh.
    fn antenna_reset_meter(&mut self) {
        self.antenna_snr_ema = None;
        self.antenna_peak_snr = 0.0;
        self.antenna_snr_hist.clear();
        self.antenna_ref = None;
    }

    /// The antenna-tuning meter. Reads received signal-to-noise off the live
    /// FFT — the one metric a receive-only SDR can honestly report — and
    /// lets you freeze a reference and watch the change as you trim or move
    /// the antenna. No absolute dBm (the dongle isn't calibrated); only the
    /// delta is meaningful, which is all tuning needs.
    fn draw_antenna_view(&mut self, ui: &mut egui::Ui) {
        // --- derive signal, floor, SNR from the live spectrum ---
        let n = self.spectrum_live.len();
        let (sig, floor) = if n == 0 {
            (-120.0_f32, -120.0_f32)
        } else {
            // Signal: the strongest bin in the central 40% of the window,
            // where a station tuned to centre sits.
            let lo = n * 3 / 10;
            let hi = (n * 7 / 10).max(lo + 1).min(n);
            let mut sig = f32::NEG_INFINITY;
            for &v in &self.spectrum_live[lo..hi] {
                if v.is_finite() && v > sig {
                    sig = v;
                }
            }
            if !sig.is_finite() {
                sig = -120.0;
            }
            // Floor: the median of the per-bin noise estimate — robust
            // against the signal itself and the odd spur.
            let mut f: Vec<f32> =
                self.floor_live.iter().copied().filter(|v| v.is_finite()).collect();
            let floor = if f.is_empty() {
                -120.0
            } else {
                f.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
                f[f.len() / 2]
            };
            (sig, floor)
        };
        let snr = (sig - floor).max(0.0);
        // Light smoothing so trimming reads as a steady trend, not jitter.
        let ema = match self.antenna_snr_ema {
            Some(e) => 0.82 * e + 0.18 * snr,
            None => snr,
        };
        self.antenna_snr_ema = Some(ema);
        self.antenna_peak_snr = self.antenna_peak_snr.max(ema);
        self.antenna_snr_hist.push_back(ema);
        while self.antenna_snr_hist.len() > 360 {
            self.antenna_snr_hist.pop_front();
        }
        // Keep the meter live even when nothing else is driving repaints.
        ui.ctx().request_repaint();

        // --- header ---
        ui.label(
            egui::RichText::new("ANTENNA TUNE")
                .font(theme::display(15.0))
                .color(theme::text()),
        );
        ui.label(
            egui::RichText::new(
                "Point the radio at a steady signal, then trim or move the antenna and watch the \
                 number climb. It's received signal-to-noise — the honest proxy for antenna \
                 performance here. It's relative (the dongle isn't calibrated), so only the change \
                 matters.",
            )
            .small()
            .color(theme::mute()),
        );
        ui.add_space(8.0);

        // --- the big meter ---
        egui::Frame::none()
            .fill(theme::surface())
            .stroke(egui::Stroke::new(1.0, theme::line()))
            .rounding(egui::Rounding::same(8.0))
            .inner_margin(16.0)
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(format!("{ema:.1}"))
                            .font(theme::display(46.0))
                            .color(theme::signal()),
                    );
                    ui.add_space(6.0);
                    ui.vertical(|ui| {
                        ui.add_space(10.0);
                        ui.label(
                            egui::RichText::new("dB SNR")
                                .font(theme::display(13.0))
                                .color(theme::mute()),
                        );
                        ui.label(
                            egui::RichText::new(format!("peak {:.1}", self.antenna_peak_snr))
                                .monospace()
                                .small()
                                .color(theme::mute()),
                        );
                    });
                    if let Some(r) = self.antenna_ref {
                        let d = ema - r;
                        let (c, arrow) = if d > 0.3 {
                            (theme::signal(), "▲")
                        } else if d < -0.3 {
                            (theme::alert(), "▼")
                        } else {
                            (theme::mute(), "—")
                        };
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            ui.vertical(|ui| {
                                ui.add_space(6.0);
                                ui.label(
                                    egui::RichText::new(format!("{arrow} {d:+.1} dB"))
                                        .font(theme::display(24.0))
                                        .color(c),
                                );
                                ui.label(
                                    egui::RichText::new(format!("vs reference {r:.1}"))
                                        .small()
                                        .color(theme::mute()),
                                );
                            });
                        });
                    }
                });
                // Bar scaled 0..40 dB, with a tick where the reference sits.
                let w = ui.available_width().min(520.0).max(80.0);
                let (br, _) = ui.allocate_exact_size(egui::vec2(w, 16.0), egui::Sense::hover());
                let p = ui.painter_at(br);
                p.rect_filled(br, egui::Rounding::same(3.0), theme::raised());
                let frac = (ema / 40.0).clamp(0.0, 1.0);
                let fr = egui::Rect::from_min_size(
                    br.min,
                    egui::vec2(br.width() * frac, br.height()),
                );
                p.rect_filled(fr, egui::Rounding::same(3.0), theme::signal());
                if let Some(r) = self.antenna_ref {
                    let x = br.left() + br.width() * (r / 40.0).clamp(0.0, 1.0);
                    p.line_segment(
                        [egui::pos2(x, br.top() - 2.0), egui::pos2(x, br.bottom() + 2.0)],
                        egui::Stroke::new(2.0, theme::live()),
                    );
                }
            });
        ui.add_space(6.0);

        // --- raw readouts ---
        ui.horizontal(|ui| {
            let chip = |ui: &mut egui::Ui, k: &str, v: String| {
                ui.label(egui::RichText::new(k).small().color(theme::mute()));
                ui.label(egui::RichText::new(v).monospace().color(theme::text()));
                ui.add_space(14.0);
            };
            chip(ui, "signal", format!("{sig:.1} dBFS"));
            chip(ui, "noise floor", format!("{floor:.1} dBFS"));
            chip(ui, "tuned", format!("{:.4} MHz", self.center_hz / 1e6));
        });
        ui.add_space(8.0);

        // --- trend strip ---
        let (hr, _) =
            ui.allocate_exact_size(egui::vec2(ui.available_width(), 70.0), egui::Sense::hover());
        {
            let p = ui.painter_at(hr);
            p.rect_filled(hr, egui::Rounding::same(6.0), theme::surface());
            theme::bracket_frame(&p, hr, theme::line(), 8.0);
            if self.antenna_snr_hist.len() > 1 {
                let top = (self.antenna_peak_snr.max(10.0)) * 1.1;
                let last = self.antenna_snr_hist.len() - 1;
                let pts: Vec<egui::Pos2> = self
                    .antenna_snr_hist
                    .iter()
                    .enumerate()
                    .map(|(i, &v)| {
                        let x = hr.left() + hr.width() * (i as f32 / last as f32);
                        let y = hr.bottom() - 4.0 - (hr.height() - 10.0) * (v / top).clamp(0.0, 1.0);
                        egui::pos2(x, y)
                    })
                    .collect();
                p.add(egui::Shape::line(pts, egui::Stroke::new(1.5, theme::signal())));
            }
            p.text(
                hr.left_top() + egui::vec2(6.0, 5.0),
                egui::Align2::LEFT_TOP,
                "SNR — last few seconds",
                egui::FontId::monospace(9.0),
                theme::mute(),
            );
        }
        ui.add_space(8.0);

        // --- controls ---
        ui.horizontal(|ui| {
            if ui
                .button("Set reference")
                .on_hover_text(
                    "Freeze the current SNR as a baseline, then trim the antenna and watch the \
                     ± change. Green is better.",
                )
                .clicked()
            {
                self.antenna_ref = Some(ema);
                self.antenna_peak_snr = ema;
            }
            if ui.button("Clear reference").clicked() {
                self.antenna_ref = None;
            }
            if ui.button("Reset peak").clicked() {
                self.antenna_peak_snr = ema;
            }
        });
        ui.add_space(10.0);

        // --- steady-source presets + free entry ---
        ui.label(
            egui::RichText::new("POINT AT A STEADY SIGNAL")
                .font(theme::display(10.5))
                .color(theme::mute()),
        );
        ui.label(
            egui::RichText::new(
                "A constant transmission gives a stable number to tune against — a NOAA weather \
                 channel (always on), an airport ATIS, or a strong local FM station.",
            )
            .small()
            .color(theme::mute()),
        );
        ui.horizontal(|ui| {
            if ui.button("NOAA Wx 162.550").clicked() {
                self.submit_command("162.550");
                self.view = View::Antenna;
                self.antenna_reset_meter();
            }
            if ui.button("NOAA Wx 162.400").clicked() {
                self.submit_command("162.400");
                self.view = View::Antenna;
                self.antenna_reset_meter();
            }
            ui.add_space(10.0);
            ui.label("MHz");
            ui.add(
                egui::TextEdit::singleline(&mut self.antenna_freq)
                    .desired_width(80.0)
                    .hint_text("118.1"),
            );
            if ui.button("Tune").clicked() && !self.antenna_freq.trim().is_empty() {
                let f = self.antenna_freq.trim().to_string();
                self.submit_command(&f);
                self.view = View::Antenna;
                self.antenna_reset_meter();
            }
        });
        ui.add_space(10.0);

        // --- ADS-B caveat ---
        egui::Frame::none()
            .fill(theme::raised())
            .stroke(egui::Stroke::new(1.0, theme::line()))
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(12.0)
            .show(ui, |ui| {
                ui.label(
                    egui::RichText::new("Tuning for ADS-B (1090 MHz)?")
                        .small()
                        .strong()
                        .color(theme::live()),
                );
                ui.label(
                    egui::RichText::new(
                        "1090 has no steady carrier, so SNR here won't mean much for it. Use the \
                         Aircraft map instead and tune for the highest messages/sec and best \
                         range — those are the real figures of merit for an ADS-B antenna.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                if ui.button("Open Aircraft map").clicked() {
                    if self.last_band_key.as_deref() != Some("adsb") {
                        self.submit_preset("adsb");
                    }
                    self.view = View::Adsb;
                }
            });
    }

    /// The tuning knob — the instrument‑panel centrepiece. Drag it left/right
    /// or scroll over it to step channels, reusing the same channel stepping
    /// as the big readout. The pointer spins with the tuned frequency so it
    /// reads as a real dial, not a decoration.
    fn draw_tuning_knob(&mut self, ui: &mut egui::Ui) {
        let size = 96.0_f32;
        let (rect, resp) = ui.allocate_exact_size(
            egui::vec2(ui.available_width(), size),
            egui::Sense::click_and_drag(),
        );
        let c = rect.center();
        let r = size * 0.40;
        {
            let p = ui.painter_at(rect);
            p.circle_filled(c, r + 4.0, theme::surface());
            p.circle_stroke(c, r + 4.0, egui::Stroke::new(1.0, theme::line()));
            p.circle_filled(c, r, theme::raised());
            p.circle_stroke(c, r, egui::Stroke::new(1.5, theme::line()));
            // Pointer position tracks the fractional part of the tuned MHz, so
            // the dial turns as you tune.
            let frac = (self.center_hz / 1e6).fract() as f32;
            let ang = frac * std::f32::consts::TAU - std::f32::consts::FRAC_PI_2;
            let dir = egui::vec2(ang.cos(), ang.sin());
            p.line_segment(
                [c + dir * (r * 0.35), c + dir * (r - 7.0)],
                egui::Stroke::new(3.0, theme::live()),
            );
            p.circle_filled(c, 4.0, theme::live());
            p.text(
                egui::pos2(c.x, rect.bottom() - 1.0),
                egui::Align2::CENTER_BOTTOM,
                "drag · scroll to tune",
                egui::FontId::monospace(8.5),
                theme::mute(),
            );
        }
        self.handle_freq_drag(&resp);
        if resp.hovered() {
            let sc = ui.input(|i| i.raw_scroll_delta.y);
            if sc > 0.5 {
                self.step_channel(1);
            } else if sc < -0.5 {
                self.step_channel(-1);
            }
        }
    }

    /// The numeric keypad — direct frequency entry plus step up/down, the
    /// last piece of the instrument panel. Shares `command_input` with the
    /// bottom entry box and tunes through the same `submit_command`, so a
    /// frequency typed here or a band name both work.
    fn draw_keypad(&mut self, ui: &mut egui::Ui) {
        // Every width here is a fixed number, never `available_width`: this
        // lives in a resizable side panel, and a child that asks for the
        // available width makes the panel grow to swallow the whole window.
        const BW: f32 = 56.0; // key width
        const BH: f32 = 24.0; // key height
        const GAP: f32 = 4.0;
        ui.horizontal(|ui| {
            if ui.button("◀").on_hover_text("step down one channel").clicked() {
                self.step_channel(-1);
            }
            ui.add(
                egui::TextEdit::singleline(&mut self.command_input)
                    .desired_width(100.0)
                    .hint_text("MHz / band"),
            );
            if ui.button("▶").on_hover_text("step up one channel").clicked() {
                self.step_channel(1);
            }
        });
        let rows = [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"], [".", "0", "⌫"]];
        for row in rows {
            ui.horizontal(|ui| {
                ui.spacing_mut().item_spacing.x = GAP;
                for k in row {
                    if ui.add_sized([BW, BH], egui::Button::new(k)).clicked() {
                        if k == "⌫" {
                            self.command_input.pop();
                        } else {
                            self.command_input.push_str(k);
                        }
                    }
                }
            });
        }
        if ui
            .add_sized(
                [BW * 3.0 + GAP * 2.0, 26.0],
                egui::Button::new(
                    egui::RichText::new("ENTER")
                        .font(theme::display(12.0))
                        .color(theme::signal()),
                ),
            )
            .clicked()
        {
            let t = self.command_input.clone();
            self.submit_command(&t);
        }
    }

    fn draw_signal_pane(&mut self, ui: &mut egui::Ui, h: f32, caption: &str) {
        let w = ui.available_width();
        let (tr, _) = ui.allocate_exact_size(
            egui::vec2(w, (h * 0.34).clamp(48.0, 140.0)),
            egui::Sense::hover(),
        );
        self.draw_trace(ui.painter(), tr);
        ui.add_space(3.0);
        let (wr, _) = ui.allocate_exact_size(
            egui::vec2(w, (h * 0.5).clamp(60.0, 240.0)),
            egui::Sense::hover(),
        );
        let ctx = ui.ctx().clone();
        self.draw_waterfall(&ctx, ui.painter(), wr);
        ui.label(egui::RichText::new(caption).size(10.0).color(theme::mute()));
    }

    /// Pictures: the SSTV workspace.
    ///
    /// The only payload here you look at rather than read, so the picture
    /// gets the room and everything else is a margin around it. It fills in
    /// line by line as it arrives, which is most of the pleasure.
    fn draw_sstv_view(&mut self, ui: &mut egui::Ui) {
        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!("{:.3}", self.center_hz / 1e6))
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(egui::RichText::new("MHz, SSTV").size(10.0).color(theme::mute()));
            });
            ui.add_space(20.0);
            ui.vertical(|ui| {
                let (v, l) = match &self.sstv_image {
                    Some(p) => (
                        format!("{}/{}", p.lines_done, p.height),
                        "lines received",
                    ),
                    None => ("—".to_string(), "nothing yet"),
                };
                ui.label(
                    egui::RichText::new(v)
                        .font(egui::FontId::monospace(15.0))
                        .color(if self.sstv_image.is_some() {
                            theme::live()
                        } else {
                            theme::text()
                        }),
                );
                ui.label(egui::RichText::new(l).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
            if let Some(p) = &self.sstv_image {
                ui.vertical(|ui| {
                    ui.label(
                        egui::RichText::new(p.mode.as_str())
                            .font(egui::FontId::monospace(15.0))
                            .color(theme::text()),
                    );
                    ui.label(egui::RichText::new("mode").size(10.0).color(theme::mute()));
                });
                ui.add_space(14.0);
            }

            if ui
                .add_enabled(self.sstv_image.is_some(), egui::Button::new("Save picture"))
                .on_hover_text("writes a PPM into the recordings folder next to the program")
                .clicked()
            {
                self.save_sstv();
            }
            if ui
                .button(if self.rec_audio_on { "Stop recording" } else { "Record audio" })
                .clicked()
            {
                self.rec_audio_on = !self.rec_audio_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
            }
            if ui.add_enabled(self.sstv_image.is_some(), egui::Button::new("Clear")).clicked() {
                self.sstv_image = None;
            }
        });

        // Where SSTV actually lives. 14.230 is the one everybody uses.
        ui.horizontal_wrapped(|ui| {
            ui.label(egui::RichText::new("try").size(11.0).color(theme::mute()));
            for (hz, note) in sweep_core::sstv::CALLING_FREQUENCIES {
                let on = (self.center_hz - hz).abs() < 2000.0;
                if ui
                    .selectable_label(on, format!("{:.3}", hz / 1e6))
                    .on_hover_text(*note)
                    .clicked()
                {
                    self.submit_command(&format!("sstv {:.3}", hz / 1e6));
                    self.view = View::Sstv;
                }
            }
        });
        if !self.sstv_status.is_empty() {
            ui.label(
                egui::RichText::new(self.sstv_status.as_str())
                    .size(11.0)
                    .color(theme::live()),
            );
        }
        ui.add_space(4.0);

        let avail = ui.available_size();
        let full_h = avail.y.max(260.0);
        ui.horizontal_top(|ui| {
            // The picture, as large as it will go without distorting it.
            let pic_w = (avail.x * 0.55).clamp(260.0, 900.0);
            // Build the image and hand it to the texture before touching
            // anything else on `self`: the same shape the waterfall uses,
            // and it keeps the picture's borrow from overlapping the
            // texture's.
            let dims = self.sstv_image.as_ref().map(|p| (p.width, p.height));
            match dims {
                Some((w, h)) => {
                    let image = egui::ColorImage {
                        size: [w, h],
                        pixels: self
                            .sstv_image
                            .as_ref()
                            .map(|p| {
                                p.rgb
                                    .chunks_exact(3)
                                    .map(|c| egui::Color32::from_rgb(c[0], c[1], c[2]))
                                    .collect::<Vec<_>>()
                            })
                            .unwrap_or_default(),
                    };
                    if let Some(t) = self.sstv_texture.as_mut() {
                        t.set(image, egui::TextureOptions::NEAREST);
                    } else {
                        self.sstv_texture = Some(ui.ctx().load_texture(
                            "sstv",
                            image,
                            egui::TextureOptions::NEAREST,
                        ));
                    }
                    // Whole pixels where possible: an SSTV picture is 320
                    // across and smoothing it just makes it muddy.
                    let scale = (pic_w / w as f32).min(full_h / h as f32);
                    let size = egui::vec2(w as f32 * scale, h as f32 * scale);
                    let (rect, _) = ui.allocate_exact_size(size, egui::Sense::hover());
                    if let Some(t) = self.sstv_texture.as_ref() {
                        ui.painter().image(
                            t.id(),
                            rect,
                            egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)),
                            egui::Color32::WHITE,
                        );
                    }
                }
                None => {
                    ui.allocate_ui(egui::vec2(pic_w, full_h), |ui| {
                        ui.label(
                            egui::RichText::new(
                                "No picture yet.\n\n\
                                 SSTV is people sending photographs over a voice channel, so \
                                 it only appears when somebody is transmitting one. 14.230 MHz \
                                 is where to wait — activity comes in bursts, and a contest \
                                 weekend will have several an hour.\n\n\
                                 A whole picture takes about two minutes to arrive, and this \
                                 one fills in line by line as it does. You will hear it before \
                                 you see it: SSTV has an unmistakable warbling buzz.\n\n\
                                 Martin M1 and M2 and Scottie S1, S2 and DX are decoded. \
                                 Robot, PD and Wraase are recognised and named, but skipped — \
                                 decoding one with the wrong timing would produce a confident, \
                                 wrong picture.",
                            )
                            .color(theme::mute()),
                        );
                    });
                }
            }

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_signal_pane(ui, full_h, "the SSTV channel — a picture is a wide warble");
            });
        });
    }

    /// Write the picture out as a PPM.
    ///
    /// PPM because it is three lines of header and then the bytes: no
    /// encoder, no dependency, and anything that opens images opens it.
    fn save_sstv(&mut self) {
        let Some(p) = &self.sstv_image else { return };
        if std::fs::create_dir_all("recordings").is_err() {
            self.log_push("! could not create the recordings folder".into());
            return;
        }
        let stamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let path = format!("recordings/sstv_{stamp}.ppm");
        let mut out = format!("P6\n{} {}\n255\n", p.width, p.height).into_bytes();
        out.extend_from_slice(&p.rgb);
        match std::fs::write(&path, &out) {
            Ok(()) => self.log_push(format!("picture saved to {path}")),
            Err(e) => self.log_push(format!("! could not save the picture: {e}")),
        }
    }

    /// Aircraft datalink: the ACARS workspace.
    ///
    /// The one workspace with no map. ACARS messages rarely carry a
    /// position — what they carry is text, between an airframe and its
    /// airline — so the message log is the subject and gets the room, with
    /// the spectrum beside it.
    /// The ISM burst survey workspace.
    ///
    /// A log, like pagers and ACARS. The honesty of this screen is the
    /// point: it shows what a transmission's signal proves — its timing
    /// fingerprint, its coding, its raw bits, its repeats, whether a CRC
    /// closes — and it never shows a device name or a sensor value, because
    /// those are not in the bits without a database this does not carry.
    /// The header says so, so nobody reads a hex string as a temperature.
    fn draw_ism_view(&mut self, ui: &mut egui::Ui) {
        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        let mut tune_to: Option<f64> = None;

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!("{:.4}", self.ism_channel_hz / 1e6))
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(egui::RichText::new("MHz, ISM").size(10.0).color(theme::mute()));
            });
            ui.add_space(20.0);
            stat(
                ui,
                format!("{}", self.ism_bursts),
                "bursts",
                self.ism_bursts > 0,
            );
            stat(
                ui,
                format!("{}", self.ism_decoded),
                "with bits",
                self.ism_decoded > 0,
            );
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!("{}", self.ism_with_crc))
                        .font(egui::FontId::monospace(15.0))
                        .color(if self.ism_with_crc > 0 {
                            theme::signal()
                        } else {
                            theme::text()
                        }),
                );
                ui.label(
                    egui::RichText::new("CRC-clean")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "Bursts whose bytes a standard CRC-8 closes over.\n\n\
                 This is strong evidence the bits were recovered correctly and the thing \
                 is a real framed packet — not noise, and not a mis-sliced signal. It is \
                 NOT an identification: it says nothing about what the device is or what \
                 the payload means. Many devices use a plain checksum or no check at all, \
                 so a burst without a CRC match is not necessarily wrong either.",
            );
            ui.add_space(14.0);
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{:.0}/{:.0}",
                        self.ism_mean_dbfs, self.ism_peak_dbfs
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("mean/peak dBFS")
                        .size(10.0)
                        .color(theme::mute()),
                );
            });
            ui.add_space(14.0);

            if ui
                .button(if self.rec_iq_on { "Stop recording" } else { "Record IQ" })
                .on_hover_text(
                    "Writes the raw capture to a .cu8 file. For an unknown device this is \
                     the thing worth keeping — a capture can be studied later or run \
                     through rtl_433's device database, which this survey deliberately \
                     does not try to reproduce.",
                )
                .clicked()
            {
                self.rec_iq_on = !self.rec_iq_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordIq(self.rec_iq_on));
            }
            if ui
                .selectable_label(self.ism_decoded_only, "With bits only")
                .on_hover_text(
                    "Hide bursts that carried energy but no decodable two-level structure \
                     — an FSK device, or OOK this cannot slice. On a busy band those can \
                     be most of what arrives.",
                )
                .clicked()
            {
                self.ism_decoded_only = !self.ism_decoded_only;
            }
            if ui.button("Clear log").clicked() {
                self.ism_msgs.clear();
            }
        });

        // The limitation, on the screen rather than only in a tooltip.
        ui.add_space(2.0);
        ui.label(
            egui::RichText::new(
                "Signal structure, not meaning. This shows timing, coding, raw bits and \
                 repeats — never a device name or a sensor reading, because those are not \
                 in the bits without a device database this does not carry.",
            )
            .size(11.0)
            .color(theme::mute()),
        );
        ui.add_space(4.0);

        // Band picker: the two ISM centres, plus whatever was typed.
        ui.horizontal_wrapped(|ui| {
            ui.label(egui::RichText::new("band").size(11.0).color(theme::mute()));
            for (hz, name) in [
                (sweep_core::ism::ISM_433_HZ, "433.92 MHz"),
                (sweep_core::ism::ISM_915_HZ, "915 MHz"),
            ] {
                let on = (self.ism_channel_hz - hz).abs() < 1.0;
                if ui
                    .selectable_label(on, name)
                    .on_hover_text(if hz < 900e6 {
                        "The busiest ISM band in most places — weather stations, \
                         doorbells, remotes, thermometers."
                    } else {
                        "More telemetry and some FSK devices here. FSK bursts show as \
                         energy with no bits, since this survey slices OOK only."
                    })
                    .clicked()
                {
                    tune_to = Some(hz);
                }
            }
        });
        ui.add_space(4.0);

        let avail = ui.available_size();
        let full_h = avail.y.max(260.0);
        let log_w = (avail.x * 0.62).clamp(300.0, 980.0);
        ui.horizontal_top(|ui| {
            ui.allocate_ui(egui::vec2(log_w, full_h), |ui| {
                let shown = self
                    .ism_msgs
                    .iter()
                    .filter(|m| !(self.ism_decoded_only && m.bits == 0))
                    .count();
                if shown == 0 {
                    ui.label(
                        egui::RichText::new(
                            "Nothing yet.\n\n\
                             433.92 MHz is usually the liveliest — a weather station beacons \
                             every minute or so, a doorbell or key fob the moment it is \
                             pressed. Each device sends its packet several times in a row; \
                             the survey folds those repeats into one entry and counts them.\n\n\
                             A burst with bits and a timing fingerprint is a real framed \
                             transmission. What it means is not something this can tell you — \
                             but the raw hex, the pulse widths and a recorded .cu8 are exactly \
                             what you would feed to a device decoder to find out.",
                        )
                        .color(theme::mute()),
                    );
                    return;
                }
                egui::ScrollArea::vertical()
                    .id_source("ism_log")
                    .stick_to_bottom(true)
                    .show(ui, |ui| {
                        for m in self.ism_msgs.iter() {
                            if self.ism_decoded_only && m.bits == 0 {
                                continue;
                            }
                            egui::Frame::none()
                                .fill(theme::surface())
                                .rounding(egui::Rounding::same(4.0))
                                .inner_margin(8.0)
                                .show(ui, |ui| {
                                    ui.horizontal_wrapped(|ui| {
                                        ui.label(
                                            egui::RichText::new(m.when.as_str())
                                                .monospace()
                                                .size(11.0)
                                                .color(theme::mute()),
                                        );
                                        ui.label(
                                            egui::RichText::new(m.coding)
                                                .size(11.0)
                                                .color(if m.bits > 0 {
                                                    theme::signal()
                                                } else {
                                                    theme::mute()
                                                }),
                                        );
                                        if m.bits > 0 {
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "{} bits",
                                                    m.bits
                                                ))
                                                .size(11.0)
                                                .color(theme::text()),
                                            );
                                            // The timing fingerprint — as
                                            // identifying as anything here.
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "{:.0}/{:.0} µs",
                                                    m.short_us, m.long_us
                                                ))
                                                .monospace()
                                                .size(11.0)
                                                .color(theme::mute()),
                                            )
                                            .on_hover_text(
                                                "The short and long pulse widths that \
                                                 define this device's coding. These are \
                                                 stable for a given model and are the \
                                                 closest thing to a fingerprint the survey \
                                                 produces.",
                                            );
                                        }
                                        if m.repeats > 1 {
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "×{}",
                                                    m.repeats
                                                ))
                                                .size(11.0)
                                                .color(theme::live()),
                                            )
                                            .on_hover_text(
                                                "Sent this many times in a row. Devices \
                                                 repeat a packet for reliability; a high \
                                                 repeat count is a sign of a clean, real \
                                                 transmission.",
                                            );
                                        }
                                        if m.crc_ok {
                                            ui.label(
                                                egui::RichText::new("CRC ✓")
                                                    .size(11.0)
                                                    .color(theme::signal()),
                                            )
                                            .on_hover_text(
                                                "A standard CRC-8 closes over the bytes — \
                                                 the bits are almost certainly right. This \
                                                 does not say what the device is.",
                                            );
                                        }
                                        ui.label(
                                            egui::RichText::new(format!(
                                                "{:.0} dB",
                                                m.snr_db
                                            ))
                                            .size(10.0)
                                            .color(theme::mute()),
                                        );
                                    });
                                    if !m.hex.is_empty() {
                                        ui.label(
                                            egui::RichText::new(&m.hex)
                                                .monospace()
                                                .size(12.0)
                                                .color(theme::text()),
                                        );
                                    } else {
                                        ui.label(
                                            egui::RichText::new(
                                                "energy only — no two-level structure to \
                                                 read (likely FSK)",
                                            )
                                            .size(11.0)
                                            .color(theme::mute()),
                                        );
                                    }
                                });
                            ui.add_space(4.0);
                        }
                    });
            });

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_signal_pane(
                    ui,
                    full_h,
                    "the ISM band — OOK bursts show as short vertical flecks",
                );
            });
        });

        if let Some(hz) = tune_to {
            self.ism_channel_hz = hz;
            let _ = self.cmd_tx.send(Cmd::IsmTune(hz));
        }
    }

    /// The pager workspace.
    ///
    /// A log, like ACARS, because each page is an event rather than a
    /// refresh of a picture. Two things on this screen are not in the other
    /// decoders:
    ///
    /// * **The lane table.** Nothing in a paging transmission announces its
    ///   bit rate, and polarity depends on the receive chain, so six
    ///   decoders run at once and the error-control code picks the winner.
    ///   Showing which lane is seeing sync words turns "nothing decoded"
    ///   into a diagnosis — either nothing is transmitting, or something is
    ///   and the codewords are not surviving the path.
    /// * **Repair counts per page.** The code can correct two bit errors
    ///   per codeword, which is real correction and not a guess, but a page
    ///   assembled from codewords that each needed two bits put back is
    ///   worth reading with suspicion. It is marked rather than hidden.
    fn draw_pager_view(&mut self, ui: &mut egui::Ui) {
        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        let mut tune_to: Option<f64> = None;

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!("{:.4}", self.pager_channel_hz / 1e6))
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("MHz, POCSAG")
                        .size(10.0)
                        .color(theme::mute()),
                );
            });
            ui.add_space(20.0);
            stat(
                ui,
                format!("{}", self.pager_pages),
                "pages",
                self.pager_pages > 0,
            );
            // Sync words are the first thing that works. They arrive long
            // before any page does on a quiet channel, and they are the
            // difference between a dead channel and a live one.
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!("{}", self.pager_syncs))
                        .font(egui::FontId::monospace(15.0))
                        .color(if self.pager_syncs > 0 {
                            theme::signal()
                        } else {
                            theme::text()
                        }),
                );
                ui.label(
                    egui::RichText::new("sync words")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "Frame synchronisation words, the pattern that starts every batch of \
                 codewords.\n\n\
                 These are the first sign of life on a channel and they arrive whether or \
                 not any page is addressed to anyone nearby. Sync words climbing with no \
                 pages means the transmitter is there and the codewords are not surviving \
                 the path — more gain, or a better antenna. No sync words at all means \
                 nothing is transmitting on this channel; try another.",
            );
            ui.add_space(14.0);
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{}/{}/{}",
                        self.pager_cw_ok, self.pager_cw_repaired, self.pager_cw_dropped
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("clean/repaired/lost")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "Codewords that arrived correct, that had one or two bits put back by the \
                 BCH code, and that were beyond repair and dropped.\n\n\
                 Repair is arithmetic, not guesswork — the code's minimum distance is six, \
                 so two errors can be corrected to the only word they could have come \
                 from. Past two, the nearest valid word is no longer necessarily the one \
                 that was sent, so those are dropped rather than reported.",
            );
            ui.add_space(14.0);
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{:.0}/{:.0}",
                        self.pager_mean_dbfs, self.pager_peak_dbfs
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("mean/peak dBFS")
                        .size(10.0)
                        .color(theme::mute()),
                );
            });
            ui.add_space(14.0);

            if ui
                .button(if self.rec_audio_on { "Stop recording" } else { "Record" })
                .clicked()
            {
                self.rec_audio_on = !self.rec_audio_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
            }
            if ui
                .selectable_label(self.pager_text_only, "Text only")
                .on_hover_text(
                    "Hide tone-only pages — an address with no message, which is a real \
                     and very common kind of page. On a busy system they outnumber the \
                     ones with text in them several times over.",
                )
                .clicked()
            {
                self.pager_text_only = !self.pager_text_only;
            }
            if ui.button("Clear log").clicked() {
                self.pager_msgs.clear();
            }
        });

        // Which bit rate and polarity is actually in use, discovered rather
        // than configured.
        if self.pager_lanes.iter().any(|(_, _, n)| *n > 0) {
            ui.horizontal_wrapped(|ui| {
                ui.label(
                    egui::RichText::new("decoding at")
                        .size(11.0)
                        .color(theme::mute()),
                );
                let mut lanes = self.pager_lanes.clone();
                lanes.sort_by(|a, b| b.2.cmp(&a.2));
                for (baud, inverted, n) in lanes.iter().take(3) {
                    if *n == 0 {
                        continue;
                    }
                    ui.label(
                        egui::RichText::new(format!(
                            "{:.0} baud{}  ×{}",
                            baud,
                            if *inverted { ", inverted" } else { "" },
                            n
                        ))
                        .size(11.0)
                        .color(theme::signal()),
                    );
                }
            });
        } else {
            ui.label(
                egui::RichText::new(
                    "No sync words yet. All three bit rates and both polarities are being \
                     tried at once — nothing needs choosing, but nothing is arriving either.",
                )
                .size(11.0)
                .color(theme::mute()),
            );
        }

        // Channel picker. The four nationwide channels first, because they
        // are the likeliest to carry anything anywhere in the country; the
        // rest of the plan is behind a fold.
        ui.horizontal_wrapped(|ui| {
            ui.label(
                egui::RichText::new("nationwide")
                    .size(11.0)
                    .color(theme::mute()),
            );
            for hz in sweep_core::pocsag::NATIONWIDE_HZ.iter() {
                let on = (self.pager_channel_hz - hz).abs() < 1.0;
                if ui
                    .selectable_label(on, format!("{:.4}", hz / 1e6))
                    .on_hover_text("shared Canada-wide and US-wide (ISED SRSP-504)")
                    .clicked()
                {
                    tune_to = Some(*hz);
                }
            }
        });
        egui::CollapsingHeader::new("All 40 Canadian paging channels")
            .id_source("pager_channels")
            .show(ui, |ui| {
                ui.label(
                    egui::RichText::new(
                        "931.0125 to 931.9875 MHz in 25 kHz steps, from ISED SRSP-504. \
                         Toronto, St. Catharines and Niagara are assigned 25 of these; \
                         which ones carry traffic depends on who is licensed near you, so \
                         working through them is the only way to find out.",
                    )
                    .size(11.0)
                    .color(theme::mute()),
                );
                ui.add_space(4.0);
                ui.horizontal_wrapped(|ui| {
                    for hz in sweep_core::pocsag::ca_channels() {
                        let on = (self.pager_channel_hz - hz).abs() < 1.0;
                        if ui
                            .selectable_label(on, format!("{:.4}", hz / 1e6))
                            .clicked()
                        {
                            tune_to = Some(hz);
                        }
                    }
                });
            });
        ui.add_space(4.0);

        let avail = ui.available_size();
        let full_h = avail.y.max(260.0);
        let log_w = (avail.x * 0.62).clamp(300.0, 980.0);
        ui.horizontal_top(|ui| {
            ui.allocate_ui(egui::vec2(log_w, full_h), |ui| {
                let shown = self
                    .pager_msgs
                    .iter()
                    .filter(|m| !(self.pager_text_only && m.tone_only()))
                    .count();
                if shown == 0 {
                    ui.label(
                        egui::RichText::new(
                            "Nothing decoded yet.\n\n\
                             Paging is bursty and local. A channel can sit silent for a \
                             long while and then carry several pages in a few seconds, and \
                             whether any channel here is live at all depends on who holds \
                             a licence near you. Watch the sync word count above: it moves \
                             as soon as a transmitter is in range, long before a page \
                             happens to be readable.\n\n\
                             Everything a page contains is in the clear — there is no \
                             encryption in POCSAG, and hospital and industrial systems \
                             carry real names, addresses and phone numbers.",
                        )
                        .color(theme::mute()),
                    );
                    return;
                }
                egui::ScrollArea::vertical()
                    .id_source("pager_log")
                    .stick_to_bottom(true)
                    .show(ui, |ui| {
                        for m in self.pager_msgs.iter() {
                            if self.pager_text_only && m.tone_only() {
                                continue;
                            }
                            egui::Frame::none()
                                .fill(theme::surface())
                                .rounding(egui::Rounding::same(4.0))
                                .inner_margin(8.0)
                                .show(ui, |ui| {
                                    ui.horizontal_wrapped(|ui| {
                                        ui.label(
                                            egui::RichText::new(m.when.as_str())
                                                .monospace()
                                                .size(11.0)
                                                .color(theme::mute()),
                                        );
                                        // The address is all there is. There
                                        // are no names anywhere in POCSAG.
                                        ui.label(
                                            egui::RichText::new(format!("{}", m.ric))
                                                .monospace()
                                                .color(theme::live()),
                                        )
                                        .on_hover_text(
                                            "The pager's address — its Radio Identity \
                                             Code. The protocol carries no names, so this \
                                             is the only thing that identifies who a page \
                                             was for.",
                                        );
                                        ui.label(
                                            egui::RichText::new(format!(
                                                "fn {}  {:.0} baud{}",
                                                m.func,
                                                m.baud,
                                                if m.inverted { " inv" } else { "" }
                                            ))
                                            .size(10.0)
                                            .color(theme::mute()),
                                        );
                                        if m.tone_only() {
                                            ui.label(
                                                egui::RichText::new("tone only")
                                                    .size(10.0)
                                                    .color(theme::mute()),
                                            )
                                            .on_hover_text(
                                                "An address with no message attached. A \
                                                 real kind of page — the pager beeps and \
                                                 the recipient knows what it means — not a \
                                                 failed decode.",
                                            );
                                        }
                                        if m.repaired_one > 0 && !m.marginal() {
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "{} repaired",
                                                    m.repaired_one
                                                ))
                                                .size(10.0)
                                                .color(theme::mute()),
                                            )
                                            .on_hover_text(
                                                "One bit was wrong in this many codewords \
                                                 and the code put it back. A single-bit \
                                                 repair is exact, not a guess.",
                                            );
                                        }
                                        if m.repaired_two > 0 {
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "{} heavily repaired",
                                                    m.repaired_two
                                                ))
                                                .size(10.0)
                                                .color(theme::alert()),
                                            )
                                            .on_hover_text(
                                                "Two bits were wrong in this many \
                                                 codewords. Still inside what the code can \
                                                 correct, but three errors can \
                                                 occasionally land two bits from a \
                                                 different valid codeword — so read this \
                                                 text with suspicion.",
                                            );
                                        }
                                        if m.dropped > 0 {
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "{} lost",
                                                    m.dropped
                                                ))
                                                .size(10.0)
                                                .color(theme::alert()),
                                            )
                                            .on_hover_text(
                                                "Codewords beyond repair were dropped \
                                                 while this page was being assembled, so \
                                                 part of the message is missing rather \
                                                 than wrong.",
                                            );
                                        }
                                    });
                                    if !m.tone_only() {
                                        ui.label(
                                            egui::RichText::new(m.body())
                                                .monospace()
                                                .size(13.0)
                                                .color(theme::text()),
                                        );
                                        // When both readings are plausible,
                                        // show both rather than picking one
                                        // — the format does not say which is
                                        // right and neither does this.
                                        if m.ambiguous {
                                            ui.label(
                                                egui::RichText::new(format!(
                                                    "or, read as digits: {}",
                                                    m.numeric
                                                ))
                                                .monospace()
                                                .size(11.0)
                                                .color(theme::mute()),
                                            )
                                            .on_hover_text(
                                                "The payload reads sensibly both as text \
                                                 and as digits. The two function bits are \
                                                 supposed to say which, but published \
                                                 mappings contradict each other, so both \
                                                 readings are shown rather than one being \
                                                 chosen for you.",
                                            );
                                        } else if m.reading == "numeric" {
                                            ui.label(
                                                egui::RichText::new(
                                                    "numeric — nibble order is a \
                                                     convention, not verified here",
                                                )
                                                .size(10.0)
                                                .color(theme::mute()),
                                            )
                                            .on_hover_text(
                                                "Numeric pages are 4-bit digits with no \
                                                 checksum of their own, and sources \
                                                 disagree on whether the digit is sent \
                                                 most- or least-significant-bit first. \
                                                 This uses the same order as the text \
                                                 path. Alphanumeric pages have no such \
                                                 doubt.",
                                            );
                                        }
                                    }
                                });
                            ui.add_space(4.0);
                        }
                    });
            });

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_signal_pane(
                    ui,
                    full_h,
                    "the paging channel — bursts are short and hard-edged",
                );
            });
        });

        if let Some(hz) = tune_to {
            self.pager_channel_hz = hz;
            self.submit_command(&format!("pager {:.4}", hz / 1e6));
            self.view = View::Pager;
        }
    }

    /// The drone-band survey workspace.
    ///
    /// The subject here is the band itself, not a map: there are no
    /// positions to plot, because nothing reachable below 1766 MHz carries
    /// one. So the thing on the left is a picture of the spectrum across
    /// each reachable band, and the instrument on the right is either the
    /// live window or the detail of whatever is selected.
    ///
    /// Two things this screen is careful about:
    ///
    /// * "Not measured" is drawn differently from "measured as absent". A
    ///   sweep across 280 MHz revisits a frequency every few seconds, so a
    ///   low hit rate usually says more about the sweep than the signal,
    ///   and presenting that as a duty cycle would be inventing a figure.
    /// * Every verdict is a shape, phrased as "consistent with". The limits
    ///   panel is one click away and says so in full.
    fn draw_drone_view(&mut self, ui: &mut egui::Ui) {
        let staring = self.drone_stare.is_some();
        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        // Actions are collected and applied after the painting, so nothing
        // mutates `self` while a band's profile is still borrowed.
        let mut want_stare: Option<Option<(f64, f64)>> = None;
        let mut want_select: Option<f64> = None;
        let mut want_tune: Option<(f64, String)> = None;
        let mut want_save: Option<(f64, String)> = None;

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(if staring {
                        "MEASURING".to_string()
                    } else {
                        "SWEEPING".to_string()
                    })
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::live()),
                );
                ui.label(
                    egui::RichText::new(if staring {
                        "parked on one range"
                    } else {
                        "stepping the bands"
                    })
                    .size(10.0)
                    .color(theme::mute()),
                );
            });
            ui.add_space(20.0);
            stat(
                ui,
                format!("{:.3}", self.drone_scanning_mhz),
                "MHz, tuner",
                false,
            );
            stat(
                ui,
                format!("{}", self.drone_sigs.len()),
                "signals in band",
                !self.drone_sigs.is_empty(),
            );
            stat(
                ui,
                format!(
                    "{}",
                    self.drone_sigs.iter().filter(|s| s.drone_shaped).count()
                ),
                "drone-shaped",
                self.drone_sigs.iter().any(|s| s.drone_shaped),
            );
            // The single most important number on this screen for reading
            // every other number: how often a given frequency gets looked
            // at. An occupancy figure from a sweep with a six-second pass
            // cannot see a 5 ms packet, and this is what says so.
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(if self.drone_pass_secs > 0.0 {
                        format!("{:.1} s", self.drone_pass_secs)
                    } else {
                        "—".to_string()
                    })
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("per full pass")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "How long the radio takes to get back to any given frequency.\n\n\
                 This is the limit on everything the sweep can say about timing: a \
                 transmission shorter than this, arriving between two visits, is simply \
                 not seen. A 'how often' figure only appears once a frequency has been \
                 visited at least eight times — and to actually time a burst you have to \
                 stop sweeping and measure one, which is what the stare button does.",
            );
            ui.add_space(14.0);

            if ui
                .button(if self.rec_iq_on { "Stop recording" } else { "Record IQ" })
                .on_hover_text(
                    "Writes the raw capture to a .cu8 file, which is the right thing to \
                     record here — a survey has no audio worth keeping, and raw IQ can be \
                     re-analysed afterwards. It fills about 4.8 MB a second.",
                )
                .clicked()
            {
                self.rec_iq_on = !self.rec_iq_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordIq(self.rec_iq_on));
            }
            if ui
                .button("Clear survey")
                .on_hover_text(
                    "Forget everything accumulated so far. One strong transient leaves a \
                     mark that takes a minute or so to fade on its own.",
                )
                .clicked()
            {
                let _ = self.cmd_tx.send(Cmd::DroneClear);
                self.drone_sigs.clear();
                self.drone_selected = None;
            }
            if ui
                .button("What this can't see")
                .on_hover_text("the hardware limits of drone detection on this dongle")
                .clicked()
            {
                self.drone_limits_open = true;
            }
        });

        // The limitation, stated on the screen itself rather than only
        // behind a button. It is the most important fact here and a person
        // who never opens the panel should still not be misled.
        ui.add_space(2.0);
        ui.label(
            egui::RichText::new(
                "Shapes, not identities. Remote ID — the only broadcast carrying a drone's \
                 serial number, operator position and takeoff point — is at 2.4/5.8 GHz, and \
                 this tuner stops at 1766 MHz.",
            )
            .size(11.0)
            .color(theme::mute()),
        );
        ui.add_space(4.0);

        // Which bands to sweep. Every band added lengthens the pass, which
        // is a real cost and the reason this is a choice rather than a
        // fixed list.
        ui.horizontal_wrapped(|ui| {
            ui.label(egui::RichText::new("bands").size(11.0).color(theme::mute()));
            let mut changed = false;
            for b in sweep_core::drone::BANDS {
                let mut on = self.drone_enabled.iter().any(|k| k == b.key);
                let label = format!("{}  {:.0}–{:.0}", b.name, b.f0_mhz, b.f1_mhz);
                if ui
                    .selectable_label(on, label)
                    .on_hover_text(b.what)
                    .clicked()
                {
                    on = !on;
                    if on {
                        self.drone_enabled.push(b.key.to_string());
                    } else {
                        self.drone_enabled.retain(|k| k != b.key);
                    }
                    changed = true;
                }
            }
            if changed {
                if self.drone_enabled.is_empty() {
                    // Refuse here as well as in the worker, so the UI never
                    // shows an empty selection it is about to have rejected.
                    self.drone_enabled.push("ism915".to_string());
                    self.log_push("the survey needs at least one band".into());
                }
                let _ = self
                    .cmd_tx
                    .send(Cmd::DroneBands(self.drone_enabled.clone()));
            }
            ui.separator();
            let before = self.drone_snr;
            ui.add(
                egui::Slider::new(&mut self.drone_snr, 4.0..=40.0)
                    .text("dB over noise")
                    .integer(),
            )
            .on_hover_text(
                "How far above the local noise a bin has to be to count as occupied. \
                 Lower finds weak signals and more noise with them; higher finds only \
                 strong ones. Changing it restarts the survey, because counters built at \
                 two different thresholds do not add up to anything.",
            );
            if (self.drone_snr - before).abs() > 0.4 {
                let _ = self.cmd_tx.send(Cmd::DroneSnr(self.drone_snr));
            }
        });
        ui.add_space(6.0);

        if self.drone_bands.is_empty() && !staring {
            ui.label(
                egui::RichText::new(
                    "Starting the survey…\n\n\
                     The first pass takes a few seconds — longer with the 1.2 GHz band on, \
                     which is 280 MHz wide and needs about 156 tuner windows to cover.",
                )
                .color(theme::mute()),
            );
            return;
        }

        let avail = ui.available_size();
        let full_h = avail.y.max(280.0);
        let left_w = match self.side {
            SidePane::Signal | SidePane::Contacts => (avail.x * 0.62).clamp(320.0, 1000.0),
            SidePane::Both => (avail.x * 0.54).clamp(300.0, 900.0),
        };

        ui.horizontal_top(|ui| {
            ui.allocate_ui(egui::vec2(left_w, full_h), |ui| {
                egui::ScrollArea::vertical()
                    .id_source("drone_left")
                    .show(ui, |ui| {
                        // --- one scope per band -------------------------
                        //
                        // x is frequency across the whole band, which means
                        // the 1.2 GHz strip covers 280 MHz in a few hundred
                        // pixels. Each pixel column is a max-hold of the
                        // bins behind it, so a narrow carrier survives the
                        // reduction instead of being averaged into the
                        // noise.
                        for bi in 0..self.drone_bands.len() {
                            let (name, f0, f1, passes, n) = {
                                let b = &self.drone_bands[bi];
                                (b.name, b.f0_mhz, b.f1_mhz, b.passes, b.peak.len())
                            };
                            ui.horizontal(|ui| {
                                ui.label(
                                    egui::RichText::new(name)
                                        .size(11.0)
                                        .color(theme::text()),
                                );
                                ui.label(
                                    egui::RichText::new(format!(
                                        "{:.2}–{:.2} MHz · {} pass{}",
                                        f0,
                                        f1,
                                        passes,
                                        if passes == 1 { "" } else { "es" }
                                    ))
                                    .size(10.0)
                                    .color(theme::mute()),
                                );
                            });
                            let w = ui.available_width();
                            let (rect, resp) = ui.allocate_exact_size(
                                egui::vec2(w, 74.0),
                                egui::Sense::click(),
                            );
                            {
                                let p = ui.painter();
                                p.rect_filled(rect, egui::Rounding::same(3.0), theme::surface());
                                let b = &self.drone_bands[bi];
                                // 40 dB of range above each group's own
                                // noise estimate. Absolute dBFS would make
                                // every band look different because the
                                // noise floor is not the same at 433 MHz
                                // and 1.3 GHz.
                                const RANGE_DB: f32 = 40.0;
                                for g in 0..n {
                                    let peak = b.peak[g];
                                    let floor = b.floor[g];
                                    if !peak.is_finite() || !floor.is_finite() {
                                        continue;
                                    }
                                    let over = (peak - floor).max(0.0);
                                    if over < 1.0 {
                                        continue;
                                    }
                                    let h = (over / RANGE_DB).clamp(0.0, 1.0) * rect.height();
                                    let x0 = rect.left() + rect.width() * g as f32 / n as f32;
                                    let x1 = rect.left()
                                        + rect.width() * (g + 1) as f32 / n as f32;
                                    let occ = b.occupancy.get(g).copied().unwrap_or(-1.0);
                                    // Never measured often enough is a
                                    // third colour, not a shade of the
                                    // other two: "we don't know" and "it is
                                    // rarely on" are different answers and
                                    // must not look alike.
                                    let col = if occ < 0.0 {
                                        egui::Color32::from_rgb(96, 108, 122)
                                    } else {
                                        let t = occ.clamp(0.0, 1.0);
                                        egui::Color32::from_rgb(
                                            (86.0 + (255.0 - 86.0) * t) as u8,
                                            (211.0 + (178.0 - 211.0) * t) as u8,
                                            (200.0 + (36.0 - 200.0) * t) as u8,
                                        )
                                    };
                                    p.rect_filled(
                                        egui::Rect::from_min_max(
                                            egui::pos2(x0, rect.bottom() - h),
                                            egui::pos2(x1.max(x0 + 1.0), rect.bottom()),
                                        ),
                                        egui::Rounding::ZERO,
                                        col,
                                    );
                                }
                                let to_x = |mhz: f64| {
                                    let t = ((mhz - f0) / (f1 - f0)).clamp(0.0, 1.0) as f32;
                                    rect.left() + rect.width() * t
                                };
                                // Where the tuner is, so the sweep is
                                // visibly walking rather than a still
                                // picture that may or may not be live.
                                if !staring
                                    && self.drone_scanning_mhz >= f0
                                    && self.drone_scanning_mhz <= f1
                                {
                                    let x = to_x(self.drone_scanning_mhz);
                                    p.line_segment(
                                        [
                                            egui::pos2(x, rect.top()),
                                            egui::pos2(x, rect.bottom()),
                                        ],
                                        egui::Stroke::new(1.0_f32, theme::live()),
                                    );
                                }
                                // The selected signature, marked in its band.
                                if let Some(sel) = self.drone_selected {
                                    if sel >= f0 && sel <= f1 {
                                        let x = to_x(sel);
                                        p.line_segment(
                                            [
                                                egui::pos2(x, rect.top()),
                                                egui::pos2(x, rect.bottom()),
                                            ],
                                            egui::Stroke::new(1.0_f32, theme::text()),
                                        );
                                    }
                                }
                                p.text(
                                    egui::pos2(rect.left() + 3.0, rect.bottom() - 2.0),
                                    egui::Align2::LEFT_BOTTOM,
                                    format!("{f0:.0}"),
                                    egui::FontId::monospace(9.0),
                                    theme::mute(),
                                );
                                p.text(
                                    egui::pos2(rect.right() - 3.0, rect.bottom() - 2.0),
                                    egui::Align2::RIGHT_BOTTOM,
                                    format!("{f1:.0}"),
                                    egui::FontId::monospace(9.0),
                                    theme::mute(),
                                );
                            }
                            // Clicking the band picks the nearest signature
                            // in it, which is what you want: the scope says
                            // where to look and the detail pane says what.
                            if resp.clicked() {
                                if let Some(pos) = resp.interact_pointer_pos() {
                                    let t = ((pos.x - rect.left()) / rect.width())
                                        .clamp(0.0, 1.0) as f64;
                                    let at = f0 + (f1 - f0) * t;
                                    let nearest = self
                                        .drone_sigs
                                        .iter()
                                        .filter(|s| {
                                            s.center_mhz >= f0 && s.center_mhz <= f1
                                        })
                                        .min_by(|a, b| {
                                            (a.center_mhz - at)
                                                .abs()
                                                .partial_cmp(&(b.center_mhz - at).abs())
                                                .unwrap_or(std::cmp::Ordering::Equal)
                                        })
                                        .map(|s| s.center_mhz);
                                    if let Some(f) = nearest {
                                        want_select = Some(f);
                                    }
                                }
                            }
                            ui.add_space(8.0);
                        }

                        if let Some(h) = self.drone_hop.clone() {
                            egui::Frame::none()
                                .fill(theme::surface())
                                .rounding(egui::Rounding::same(4.0))
                                .inner_margin(8.0)
                                .show(ui, |ui| {
                                    ui.label(
                                        egui::RichText::new("PATTERN")
                                            .size(10.0)
                                            .color(theme::live()),
                                    );
                                    ui.label(
                                        egui::RichText::new(h).size(11.0).color(theme::text()),
                                    );
                                });
                            ui.add_space(8.0);
                        }

                        // --- the list -----------------------------------
                        ui.label(
                            egui::RichText::new("SIGNALS").size(10.0).color(theme::mute()),
                        );
                        if self.drone_sigs.is_empty() {
                            ui.label(
                                egui::RichText::new(
                                    "Nothing above the threshold yet. Lower it, or give the \
                                     survey a pass or two — the first pass only establishes \
                                     where the noise sits.",
                                )
                                .size(11.0)
                                .color(theme::mute()),
                            );
                            return;
                        }
                        ui.add_space(2.0);
                        for si in 0..self.drone_sigs.len() {
                            let s = &self.drone_sigs[si];
                            let selected =
                                self.drone_selected.map_or(false, |f| {
                                    (f - s.center_mhz).abs() < 1e-6
                                });
                            let row = egui::Frame::none()
                                .fill(if selected {
                                    theme::raised()
                                } else {
                                    theme::surface()
                                })
                                .rounding(egui::Rounding::same(3.0))
                                .inner_margin(egui::Margin::symmetric(8.0, 5.0))
                                .show(ui, |ui| {
                                    ui.horizontal(|ui| {
                                        ui.label(
                                            egui::RichText::new(format!(
                                                "{:>9.3}",
                                                s.center_mhz
                                            ))
                                            .font(egui::FontId::monospace(13.0))
                                            .color(if s.drone_shaped {
                                                theme::live()
                                            } else {
                                                theme::text()
                                            }),
                                        );
                                        ui.label(
                                            egui::RichText::new(if s.bw_khz >= 1000.0 {
                                                format!("{:.2} MHz", s.bw_khz / 1000.0)
                                            } else {
                                                format!("{:.0} kHz", s.bw_khz)
                                            })
                                            .font(egui::FontId::monospace(11.0))
                                            .color(theme::text()),
                                        );
                                        ui.label(
                                            egui::RichText::new(format!("{:.0} dB", s.snr_db))
                                                .font(egui::FontId::monospace(11.0))
                                                .color(theme::mute()),
                                        );
                                        // Unknown is printed as unknown.
                                        ui.label(
                                            egui::RichText::new(match s.occupancy {
                                                Some(o) => format!("{:.0}% on", o * 100.0),
                                                None => "how often: not yet".to_string(),
                                            })
                                            .size(10.0)
                                            .color(if s.occupancy.is_some() {
                                                theme::text()
                                            } else {
                                                theme::mute()
                                            }),
                                        );
                                        ui.label(
                                            egui::RichText::new(s.kind)
                                                .size(10.0)
                                                .color(if s.drone_shaped {
                                                    theme::signal()
                                                } else {
                                                    theme::mute()
                                                }),
                                        );
                                    });
                                });
                            let resp = row.response.interact(egui::Sense::click());
                            if resp.on_hover_text(s.verdict).clicked() {
                                want_select = Some(s.center_mhz);
                            }
                            ui.add_space(2.0);
                        }
                    });
            });

            ui.add_space(8.0);
            ui.vertical(|ui| {
                // Same instrument switch as the map workspaces: the subject
                // is on the left, and what you want beside it depends on
                // what you are doing.
                ui.horizontal(|ui| {
                    if ui
                        .selectable_label(self.side == SidePane::Signal, "Live window")
                        .clicked()
                    {
                        self.side = SidePane::Signal;
                    }
                    if ui
                        .selectable_label(self.side == SidePane::Contacts, "Detail")
                        .clicked()
                    {
                        self.side = SidePane::Contacts;
                    }
                    if ui
                        .selectable_label(self.side == SidePane::Both, "Both")
                        .clicked()
                    {
                        self.side = SidePane::Both;
                    }
                });
                ui.add_space(4.0);

                let pane_h = match self.side {
                    SidePane::Both => full_h * 0.46,
                    _ => full_h - 40.0,
                };

                if matches!(self.side, SidePane::Signal | SidePane::Both) {
                    self.draw_signal_pane(
                        ui,
                        pane_h,
                        if staring {
                            "the window being measured"
                        } else {
                            "the window the sweep is in right now"
                        },
                    );
                    ui.add_space(6.0);
                }

                if matches!(self.side, SidePane::Contacts | SidePane::Both) {
                    let sel = self.drone_selected.and_then(|f| {
                        self.drone_sigs
                            .iter()
                            .find(|s| (s.center_mhz - f).abs() < 1e-6)
                            .cloned()
                    });
                    egui::ScrollArea::vertical()
                        .id_source("drone_detail")
                        .max_height(pane_h)
                        .show(ui, |ui| {
                            // The measurement, when one is running, comes
                            // first: its numbers are real and the sweep's
                            // are provisional.
                            if let Some(st) = self.drone_stare.clone() {
                                ui.label(
                                    egui::RichText::new("MEASURED")
                                        .size(10.0)
                                        .color(theme::live()),
                                );
                                ui.label(
                                    egui::RichText::new(format!(
                                        "{:.3}–{:.3} MHz",
                                        st.target_lo_mhz, st.target_hi_mhz
                                    ))
                                    .font(egui::FontId::monospace(13.0))
                                    .color(theme::text()),
                                );
                                let line = |ui: &mut egui::Ui, k: &str, v: String| {
                                    ui.horizontal(|ui| {
                                        ui.label(
                                            egui::RichText::new(k)
                                                .size(10.0)
                                                .color(theme::mute()),
                                        );
                                        ui.label(
                                            egui::RichText::new(v)
                                                .font(egui::FontId::monospace(11.0))
                                                .color(theme::text()),
                                        );
                                    });
                                };
                                line(ui, "on", format!("{:.1}%", st.duty * 100.0));
                                line(
                                    ui,
                                    "burst",
                                    match st.burst_ms {
                                        Some(b) => format!("{b:.1} ms"),
                                        // A carrier that never stops has no
                                        // burst length. Saying so is the
                                        // measurement, not a missing value.
                                        None if st.duty > 0.99 => {
                                            "never stops".to_string()
                                        }
                                        None => "not seen yet".to_string(),
                                    },
                                );
                                line(
                                    ui,
                                    "gap",
                                    match st.gap_ms {
                                        Some(g) => format!("{g:.1} ms"),
                                        None => "—".to_string(),
                                    },
                                );
                                line(
                                    ui,
                                    "rate",
                                    match st.rate_hz {
                                        Some(r) => format!("{r:.1} /s"),
                                        None => "—".to_string(),
                                    },
                                );
                                // A signal wider than the 1.8 MHz window
                                // runs off both edges, and then this is a
                                // floor, not a figure. Saying so is the
                                // difference between a measurement and a
                                // claim.
                                line(
                                    ui,
                                    "width",
                                    if st.bw_is_lower_bound {
                                        format!(
                                            "at least {:.2} MHz — wider than the window",
                                            st.bw_khz / 1000.0
                                        )
                                    } else if st.bw_khz >= 1000.0 {
                                        format!("{:.2} MHz", st.bw_khz / 1000.0)
                                    } else {
                                        format!("{:.1} kHz", st.bw_khz)
                                    },
                                );
                                line(
                                    ui,
                                    "peak",
                                    format!("{:.0} dBFS over {:.0}", st.peak_db, st.floor_db),
                                );
                                line(
                                    ui,
                                    "measured for",
                                    format!("{:.0} s, {} frames", st.seconds, st.frames),
                                );
                                ui.add_space(4.0);
                                ui.label(
                                    egui::RichText::new(st.kind)
                                        .size(11.0)
                                        .color(theme::signal()),
                                );
                                ui.label(
                                    egui::RichText::new(st.verdict)
                                        .size(11.0)
                                        .color(theme::text()),
                                );
                                ui.add_space(6.0);
                                ui.horizontal_wrapped(|ui| {
                                    if ui.button("Back to sweeping").clicked() {
                                        want_stare = Some(None);
                                    }
                                    // Not `center_mhz`: the tuner is
                                    // deliberately offset from the target so
                                    // the DC spur misses it, so the tuner
                                    // centre is the one frequency here that
                                    // is certainly wrong.
                                    let at = st.peak_mhz.unwrap_or(
                                        (st.target_lo_mhz + st.target_hi_mhz) / 2.0,
                                    );
                                    if ui
                                        .button("Tune the radio here")
                                        .on_hover_text(
                                            "Leaves the survey and parks on this \
                                             frequency so you can listen to it. There is \
                                             one dongle, so the band stops being watched.",
                                        )
                                        .clicked()
                                    {
                                        want_tune =
                                            Some((at, format!("{at:.4} MHz")));
                                    }
                                    if ui.button("Save it").clicked() {
                                        want_save = Some((
                                            at,
                                            format!("{} {:.3}", st.kind, at),
                                        ));
                                    }
                                });
                                ui.separator();
                            }

                            match sel {
                                None => {
                                    ui.label(
                                        egui::RichText::new(
                                            "Pick a signal from the list, or click a band \
                                             above, to see what its shape is consistent \
                                             with and to measure it properly.",
                                        )
                                        .size(11.0)
                                        .color(theme::mute()),
                                    );
                                }
                                Some(s) => {
                                    ui.label(
                                        egui::RichText::new("SELECTED")
                                            .size(10.0)
                                            .color(theme::mute()),
                                    );
                                    ui.label(
                                        egui::RichText::new(format!("{:.4} MHz", s.center_mhz))
                                            .font(egui::FontId::monospace(16.0))
                                            .color(theme::live()),
                                    );
                                    ui.label(
                                        egui::RichText::new(format!(
                                            "{} · {}",
                                            s.band_name, s.kind
                                        ))
                                        .size(11.0)
                                        .color(theme::signal()),
                                    );
                                    ui.add_space(4.0);
                                    ui.label(
                                        egui::RichText::new(s.verdict)
                                            .size(11.0)
                                            .color(theme::text()),
                                    );
                                    ui.add_space(6.0);
                                    let line = |ui: &mut egui::Ui, k: &str, v: String| {
                                        ui.horizontal(|ui| {
                                            ui.label(
                                                egui::RichText::new(k)
                                                    .size(10.0)
                                                    .color(theme::mute()),
                                            );
                                            ui.label(
                                                egui::RichText::new(v)
                                                    .font(egui::FontId::monospace(11.0))
                                                    .color(theme::text()),
                                            );
                                        });
                                    };
                                    line(
                                        ui,
                                        "width",
                                        if s.bw_khz >= 1000.0 {
                                            format!("{:.2} MHz", s.bw_khz / 1000.0)
                                        } else {
                                            format!("{:.0} kHz", s.bw_khz)
                                        },
                                    );
                                    line(ui, "above noise", format!("{:.0} dB", s.snr_db));
                                    line(ui, "peak", format!("{:.0} dBFS", s.peak_db));
                                    line(
                                        ui,
                                        "how often",
                                        match s.occupancy {
                                            Some(o) => format!(
                                                "{:.0}% of {} looks",
                                                o * 100.0,
                                                s.looks
                                            ),
                                            None => format!(
                                                "unknown — only {} look{} so far",
                                                s.looks,
                                                if s.looks == 1 { "" } else { "s" }
                                            ),
                                        },
                                    );
                                    ui.add_space(8.0);
                                    ui.horizontal_wrapped(|ui| {
                                        if ui
                                            .button("Measure this properly")
                                            .on_hover_text(
                                                "Stops sweeping and parks on this signal, \
                                                 which is the only way to get a real duty \
                                                 cycle and burst timing out of it. While \
                                                 this runs the rest of the bands are not \
                                                 being watched — one dongle, one \
                                                 frequency.",
                                            )
                                            .clicked()
                                        {
                                            // At least 50 kHz of target, so
                                            // a narrow carrier that drifts a
                                            // little is still inside it.
                                            let half =
                                                (s.bw_khz / 2.0).max(25.0) / 1000.0;
                                            want_stare = Some(Some((
                                                s.center_mhz - half,
                                                s.center_mhz + half,
                                            )));
                                        }
                                        if ui
                                            .button("Tune the radio here")
                                            .on_hover_text(
                                                "Leaves the survey and parks on this \
                                                 frequency in NFM so you can hear it. A \
                                                 data link sounds like a buzz and a wide \
                                                 video carrier sounds like nothing useful \
                                                 — the shape above is the information, not \
                                                 the audio.",
                                            )
                                            .clicked()
                                        {
                                            want_tune = Some((
                                                s.center_mhz,
                                                format!("{:.4} MHz", s.center_mhz),
                                            ));
                                        }
                                        if ui
                                            .button("Save it")
                                            .on_hover_text("keeps this frequency in the memories")
                                            .clicked()
                                        {
                                            want_save = Some((
                                                s.center_mhz,
                                                format!("{} {:.3}", s.kind, s.center_mhz),
                                            ));
                                        }
                                    });
                                }
                            }
                        });
                }
            });
        });

        if let Some(f) = want_select {
            self.drone_selected = Some(f);
            if self.side == SidePane::Signal {
                // Picking something and seeing nothing about it is the
                // worse failure, so a selection opens the pane that
                // describes it.
                self.side = SidePane::Both;
            }
        }
        if let Some(t) = want_stare {
            let _ = self.cmd_tx.send(Cmd::DroneStare(t));
            if t.is_none() {
                self.drone_stare = None;
            }
        }
        if let Some((mhz, label)) = want_save {
            self.save_frequency(mhz, label);
        }
        if let Some((mhz, _)) = want_tune {
            // Leaving the survey stops it, so say so and put the radio
            // where it was asked to go.
            let _ = self.cmd_tx.send(Cmd::DroneStare(None));
            self.submit_command(&format!("{mhz:.4}"));
            self.view = View::Live;
        }

        if self.drone_limits_open {
            let mut open = true;
            egui::Window::new("What this cannot see")
                .open(&mut open)
                .resizable(true)
                .default_width(560.0)
                .show(ui.ctx(), |ui| {
                    ui.label(
                        egui::RichText::new(format!(
                            "The R828D tuner in an RTL-SDR Blog V4 covers 24 MHz to {:.0} MHz. \
                             Everything below is above that ceiling. This is the hardware, \
                             not the software — no setting, antenna or amplifier changes it.",
                            sweep_core::drone::TUNER_CEILING_MHZ
                        ))
                        .color(theme::text()),
                    );
                    ui.add_space(8.0);
                    for (name, range, why) in sweep_core::drone::UNREACHABLE {
                        egui::Frame::none()
                            .fill(theme::surface())
                            .rounding(egui::Rounding::same(4.0))
                            .inner_margin(8.0)
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        egui::RichText::new(*name)
                                            .strong()
                                            .color(theme::alert()),
                                    );
                                    ui.label(
                                        egui::RichText::new(*range)
                                            .font(egui::FontId::monospace(11.0))
                                            .color(theme::mute()),
                                    );
                                });
                                ui.label(
                                    egui::RichText::new(*why).size(11.0).color(theme::text()),
                                );
                            });
                        ui.add_space(6.0);
                    }
                    ui.separator();
                    ui.label(
                        egui::RichText::new("What is reachable, and what lives there")
                            .strong()
                            .color(theme::live()),
                    );
                    ui.add_space(4.0);
                    for b in sweep_core::drone::BANDS {
                        ui.label(
                            egui::RichText::new(format!(
                                "{} — {:.2} to {:.2} MHz",
                                b.name, b.f0_mhz, b.f1_mhz
                            ))
                            .font(egui::FontId::monospace(11.0))
                            .color(theme::text()),
                        );
                        ui.label(egui::RichText::new(b.what).size(11.0).color(theme::mute()));
                        ui.add_space(6.0);
                    }
                    ui.separator();
                    ui.label(
                        egui::RichText::new(
                            "Even in the bands it can reach, this does not decode anything. \
                             ExpressLRS, Crossfire and the rest are proprietary \
                             frequency-hopping schemes whose hop sequence comes from a \
                             binding phrase, so there is no payload to read and no model or \
                             operator to name. What you get is where the energy is, how wide \
                             it is, and how often it is there — which is real information, \
                             and is not an identification.\n\n\
                             If identifying a drone is the actual goal, a phone app that \
                             reads Remote ID over Bluetooth and Wi-Fi will do it, and this \
                             radio will not.",
                        )
                        .size(11.0)
                        .color(theme::text()),
                    );
                });
            self.drone_limits_open = open;
        }
    }

    fn draw_acars_view(&mut self, ui: &mut egui::Ui) {
        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!("{:.3}", self.acars_channel_hz / 1e6))
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(egui::RichText::new("MHz, ACARS").size(10.0).color(theme::mute()));
            });
            ui.add_space(20.0);
            stat(ui, format!("{}", self.acars_msgs.len()), "messages", !self.acars_msgs.is_empty());
            stat(ui, format!("{}", self.acars_aircraft), "airframes", self.acars_aircraft > 0);
            stat(
                ui,
                format!("{}", self.acars_bad_parity),
                "parity failures",
                false,
            );
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{:.0}/{:.0}",
                        self.acars_mean_dbfs, self.acars_peak_dbfs
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("mean/peak dBFS")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "ACARS is AM in the aviation band, so the audio is the raw envelope — bursts \
                 sound like a short buzz. Traffic is heaviest near an airport and can be \
                 sparse otherwise.",
            );
            ui.add_space(14.0);

            if ui
                .button(if self.rec_audio_on { "Stop recording" } else { "Record" })
                .clicked()
            {
                self.rec_audio_on = !self.rec_audio_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
            }
            if ui
                .button("Listen to aircraft voice")
                .on_hover_text("leaves ACARS and scans 118–137 MHz in AM")
                .clicked()
            {
                self.submit_preset("aviation");
                self.view = View::Live;
            }
            if ui.button("Clear log").clicked() {
                self.acars_msgs.clear();
            }
        });

        // Channel picker: five published North American channels, one
        // radio. Which one is busy depends entirely on where you are.
        ui.horizontal_wrapped(|ui| {
            ui.label(egui::RichText::new("channel").size(11.0).color(theme::mute()));
            for (hz, note) in sweep_core::acars::CHANNELS {
                let on = (self.acars_channel_hz - hz).abs() < 1.0;
                if ui
                    .selectable_label(on, format!("{:.3}", hz / 1e6))
                    .on_hover_text(*note)
                    .clicked()
                {
                    self.acars_channel_hz = *hz;
                    self.submit_command(&format!("acars {:.3}", hz / 1e6));
                    self.view = View::Acars;
                }
            }
        });
        ui.add_space(4.0);

        let avail = ui.available_size();
        let full_h = avail.y.max(260.0);
        let log_w = (avail.x * 0.62).clamp(300.0, 980.0);
        ui.horizontal_top(|ui| {
            ui.allocate_ui(egui::vec2(log_w, full_h), |ui| {
                if self.acars_msgs.is_empty() {
                    ui.label(
                        egui::RichText::new(
                            "Nothing decoded yet.\n\n\
                             ACARS is bursty — an airframe sends a few messages per flight, \
                             not continuously — so near a quiet airport an hour can pass with \
                             nothing. Near a busy one you will see several a minute.\n\n\
                             131.550 is the primary channel in North America and the right \
                             place to start. If it stays silent, the others above are worth \
                             trying.",
                        )
                        .color(theme::mute()),
                    );
                    return;
                }
                egui::ScrollArea::vertical()
                    .id_source("acars_log")
                    .stick_to_bottom(true)
                    .show(ui, |ui| {
                        for m in self.acars_msgs.iter() {
                            egui::Frame::none()
                                .fill(theme::surface())
                                .rounding(egui::Rounding::same(4.0))
                                .inner_margin(8.0)
                                .show(ui, |ui| {
                                    ui.horizontal_wrapped(|ui| {
                                        ui.label(
                                            egui::RichText::new(m.when.as_str())
                                                .monospace()
                                                .size(11.0)
                                                .color(theme::mute()),
                                        );
                                        ui.label(
                                            egui::RichText::new(m.registration.as_str())
                                                .monospace()
                                                .color(theme::live()),
                                        );
                                        if let Some(f) = &m.flight {
                                            ui.label(
                                                egui::RichText::new(f.as_str())
                                                    .monospace()
                                                    .color(theme::text()),
                                            );
                                        }
                                        ui.label(
                                            egui::RichText::new(format!(
                                                "{}  {}",
                                                m.label, m.label_text
                                            ))
                                            .size(11.0)
                                            .color(theme::mute()),
                                        );
                                        if m.more {
                                            ui.label(
                                                egui::RichText::new("continues")
                                                    .size(10.0)
                                                    .color(theme::mute()),
                                            );
                                        }
                                        // The checksum span could not be
                                        // confirmed without a real capture,
                                        // so a block is shown either way and
                                        // marked for what it is.
                                        if !m.crc_ok {
                                            ui.label(
                                                egui::RichText::new("checksum did not match")
                                                    .size(10.0)
                                                    .color(theme::alert()),
                                            )
                                            .on_hover_text(
                                                "The structure and every character's parity \
                                                 were correct, so this is a real message, but \
                                                 the checksum disagreed. Treat the text as \
                                                 possibly corrupt.",
                                            );
                                        }
                                    });
                                    if !m.text.is_empty() {
                                        ui.label(
                                            egui::RichText::new(m.text.as_str())
                                                .monospace()
                                                .size(12.0)
                                                .color(theme::text()),
                                        );
                                    }
                                });
                            ui.add_space(4.0);
                        }
                    });
            });

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_signal_pane(
                    ui,
                    full_h,
                    "the ACARS channel — bursts are short and wide",
                );
            });
        });
    }

    /// Amateur stations: the APRS workspace.
    ///
    /// Same chart again. What differs is the traffic: APRS carries text as
    /// well as position — a comment, a destination, a weather report — so
    /// the list shows what each station actually said rather than only
    /// where it is.
    fn draw_aprs_view(&mut self, ui: &mut egui::Ui) {
        if self.geomap.is_none() {
            self.load_geomap();
        }
        let heard = self.aprs.len();
        let plotted = self.aprs.iter().filter(|s| s.lat.is_some()).count();

        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new("144.390")
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(egui::RichText::new("MHz, APRS").size(10.0).color(theme::mute()));
            });
            ui.add_space(20.0);
            stat(ui, format!("{heard}"), "stations", heard > 0);
            stat(ui, format!("{plotted}"), "with a position", false);
            stat(ui, format!("{}", self.aprs_packets), "packets", self.aprs_packets > 0);
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{:.0}/{:.0}",
                        self.aprs_mean_dbfs, self.aprs_peak_dbfs
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("mean/peak dBFS")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "APRS is 2 m FM and the easiest of these to receive — a whip indoors often \
                 works. Packets are short bursts every few minutes, so patience matters more \
                 than antenna here.",
            );
            ui.add_space(14.0);

            ui.label(
                egui::RichText::new("audio is live — packets chirp")
                    .size(11.0)
                    .color(theme::mute()),
            );
            if ui
                .button(if self.rec_audio_on { "Stop recording" } else { "Record" })
                .clicked()
            {
                self.rec_audio_on = !self.rec_audio_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
            }
            if ui
                .button("Listen to 2 m voice")
                .on_hover_text("leaves APRS and scans 144–148 MHz")
                .clicked()
            {
                self.submit_preset("2m");
                self.view = View::Live;
            }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                ui.add(
                    egui::Slider::new(&mut self.adsb_range_km, 10.0..=500.0)
                        .text("km")
                        .logarithmic(true),
                );
            });
        });
        ui.add_space(4.0);

        let avail = ui.available_size();
        let map_w = (avail.x * 0.52).clamp(240.0, 760.0);
        let full_h = avail.y.max(260.0);
        ui.horizontal_top(|ui| {
            let (rect, resp) = ui.allocate_exact_size(
                egui::vec2(map_w, full_h),
                egui::Sense::click_and_drag(),
            );
            self.draw_radar(ui, rect, &resp);

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_side_switcher(ui);
                if self.side != SidePane::Contacts {
                    let h = if self.side == SidePane::Both { full_h * 0.5 } else { full_h };
                    self.draw_signal_pane(
                        ui,
                        h,
                        "144.390 MHz — packets are brief vertical bursts",
                    );
                    ui.add_space(6.0);
                }
                if self.side == SidePane::Signal {
                    return;
                }
                egui::ScrollArea::vertical()
                    .id_source("aprs_table")
                    .show(ui, |ui| {
                        if self.aprs.is_empty() {
                            ui.label(
                                egui::RichText::new(
                                    "Nothing decoded yet.\n\n\
                                     APRS stations beacon every few minutes, and a fixed \
                                     station may be slower still, so this is the one decoder \
                                     where several minutes of silence means nothing is wrong.\n\n\
                                     Of everything here this is the easiest to receive — 2 m \
                                     FM, and a whip indoors often picks up a digipeater.",
                                )
                                .color(theme::mute()),
                            );
                            return;
                        }
                        let rows: Vec<(String, String, String, String, String, f32, bool)> = self
                            .aprs
                            .iter()
                            .map(|s| {
                                let dist = match (s.lat, s.lon) {
                                    (Some(la), Some(lo))
                                        if self.receiver_lat != 0.0 || self.receiver_lon != 0.0 =>
                                    {
                                        format!(
                                            "{:.0} km",
                                            stations::distance_km(
                                                self.receiver_lat,
                                                self.receiver_lon,
                                                la,
                                                lo
                                            )
                                        )
                                    }
                                    _ => String::new(),
                                };
                                (
                                    s.call.clone(),
                                    s.kind.to_string(),
                                    s.comment.chars().take(40).collect::<String>(),
                                    s.via.clone(),
                                    dist,
                                    s.age_s,
                                    self.aprs_selected.as_deref() == Some(s.call.as_str()),
                                )
                            })
                            .collect();

                        egui::Grid::new("aprs_rows")
                            .num_columns(5)
                            .striped(true)
                            .spacing([10.0, 3.0])
                            .show(ui, |ui| {
                                for h in ["STATION", "TYPE", "SAID", "VIA", "AGE"] {
                                    ui.label(
                                        egui::RichText::new(h).size(10.0).color(theme::mute()),
                                    );
                                }
                                ui.end_row();
                                let mut pick: Option<String> = None;
                                for (call, kind, said, via, _dist, age, sel) in &rows {
                                    let c = if *sel { theme::live() } else { theme::text() };
                                    if ui
                                        .add(
                                            egui::Label::new(
                                                egui::RichText::new(call.as_str())
                                                    .monospace()
                                                    .color(c),
                                            )
                                            .sense(egui::Sense::click()),
                                        )
                                        .clicked()
                                    {
                                        pick = Some(call.clone());
                                    }
                                    ui.label(
                                        egui::RichText::new(kind.as_str()).size(11.0).color(c),
                                    );
                                    ui.label(
                                        egui::RichText::new(said.as_str()).size(11.0).color(c),
                                    );
                                    ui.label(
                                        egui::RichText::new(via.as_str())
                                            .size(10.0)
                                            .color(theme::mute()),
                                    );
                                    ui.label(
                                        egui::RichText::new(format!("{age:.0}s"))
                                            .monospace()
                                            .color(theme::mute()),
                                    );
                                    ui.end_row();
                                }
                                if let Some(p) = pick {
                                    self.aprs_selected =
                                        if self.aprs_selected.as_deref() == Some(p.as_str()) {
                                            None
                                        } else {
                                            Some(p)
                                        };
                                }
                            });
                    });
            });
        });
    }

    /// Ships: the marine workspace.
    ///
    /// Deliberately the same chart as the aircraft map — same projection,
    /// same rings, same pan and zoom — because it is the same question
    /// asked of a different band, and a second map that behaved differently
    /// would be a second thing to learn.
    fn draw_marine_view(&mut self, ui: &mut egui::Ui) {
        if self.geomap.is_none() {
            self.load_geomap();
        }
        let heard = self.ais.len();
        let plotted = self.ais.iter().filter(|v| v.lat.is_some()).count();
        let named = self.ais.iter().filter(|v| v.name.is_some()).count();

        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new("161.975 + 162.025")
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("MHz, AIS — both channels")
                        .size(10.0)
                        .color(theme::mute()),
                );
            });
            ui.add_space(20.0);
            stat(ui, format!("{heard}"), "vessels", heard > 0);
            stat(ui, format!("{plotted}"), "with a position", false);
            stat(ui, format!("{named}"), "named", false);
            stat(ui, format!("{}", self.ais_frames), "messages", self.ais_frames > 0);
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{:.0}/{:.0}",
                        self.ais_mean_dbfs, self.ais_peak_dbfs
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("mean/peak dBFS")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "Signal level on the marine data channels. AIS is VHF and far more forgiving \
                 than ADS-B — a plain whip or a marine antenna does well, and range over water \
                 is routinely 40 km or more.",
            );
            ui.add_space(14.0);

            if ui
                .button("Listen to marine voice")
                .on_hover_text(
                    "Leaves AIS and scans 156–162 MHz. Channel 16 is the calling and distress \
                     channel; working traffic moves off it.",
                )
                .clicked()
            {
                self.submit_preset("marine");
                self.view = View::Live;
            }
            if ui
                .button(if self.rec_audio_on { "Stop recording" } else { "Record" })
                .clicked()
            {
                self.rec_audio_on = !self.rec_audio_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
            }
            ui.label(
                egui::RichText::new("parked on the data channels — not scanning")
                    .size(11.0)
                    .color(theme::mute()),
            );
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                ui.add(
                    egui::Slider::new(&mut self.adsb_range_km, 10.0..=200.0)
                        .text("km")
                        .logarithmic(true),
                );
            });
        });
        ui.add_space(4.0);

        let avail = ui.available_size();
        let map_w = (avail.x * 0.52).clamp(240.0, 760.0);
        let full_h = avail.y.max(260.0);
        ui.horizontal_top(|ui| {
            let (rect, resp) = ui.allocate_exact_size(
                egui::vec2(map_w, full_h),
                egui::Sense::click_and_drag(),
            );
            self.draw_radar(ui, rect, &resp);

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_side_switcher(ui);
                if self.side != SidePane::Contacts {
                    let h = if self.side == SidePane::Both { full_h * 0.5 } else { full_h };
                    self.draw_signal_pane(
                        ui,
                        h,
                        "162.000 MHz ± 1.2 — the two AIS channels sit either side of centre",
                    );
                    ui.add_space(6.0);
                }
                if self.side == SidePane::Signal {
                    return;
                }
                egui::ScrollArea::vertical()
                    .id_source("ais_table")
                    .show(ui, |ui| {
                        if self.ais.is_empty() {
                            ui.label(
                                egui::RichText::new(
                                    "Nothing decoded yet.\n\n\
                                     AIS is VHF line-of-sight, so this depends on open water \
                                     or a clear path toward it. On Lake Ontario a shore \
                                     position with a plain whip typically reaches well past \
                                     the horizon; inland and surrounded by buildings it may \
                                     reach nothing at all.\n\n\
                                     Ships at anchor can go minutes between messages, so give \
                                     it longer than you would give aircraft.",
                                )
                                .color(theme::mute()),
                            );
                            return;
                        }
                        // Selected vessel first, in full.
                        if let Some(sel) = self.ais_selected {
                            if let Some(v) = self.ais.iter().find(|v| v.mmsi == sel).cloned() {
                                egui::Frame::none()
                                    .fill(theme::raised())
                                    .rounding(egui::Rounding::same(4.0))
                                    .inner_margin(8.0)
                                    .show(ui, |ui| {
                                        ui.label(
                                            egui::RichText::new(v.label.as_str())
                                                .size(16.0)
                                                .color(theme::live()),
                                        );
                                        let row = |ui: &mut egui::Ui, k: &str, val: String| {
                                            if val.is_empty() {
                                                return;
                                            }
                                            ui.horizontal(|ui| {
                                                ui.label(
                                                    egui::RichText::new(k)
                                                        .size(10.0)
                                                        .color(theme::mute()),
                                                );
                                                ui.label(
                                                    egui::RichText::new(val)
                                                        .monospace()
                                                        .color(theme::text()),
                                                );
                                            });
                                        };
                                        row(ui, "MMSI", format!("{}", v.mmsi));
                                        row(ui, "flag", v.flag.to_string());
                                        row(ui, "type", v.kind.to_string());
                                        row(
                                            ui,
                                            "callsign",
                                            v.callsign.clone().unwrap_or_default(),
                                        );
                                        row(ui, "status", v.status.to_string());
                                        row(
                                            ui,
                                            "bound for",
                                            v.destination.clone().unwrap_or_default(),
                                        );
                                        if let (Some(la), Some(lo)) = (v.lat, v.lon) {
                                            row(ui, "position", format!("{la:.4}, {lo:.4}"));
                                            if self.receiver_lat != 0.0 || self.receiver_lon != 0.0
                                            {
                                                row(
                                                    ui,
                                                    "from you",
                                                    format!(
                                                        "{:.1} km, bearing {:03.0}°",
                                                        stations::distance_km(
                                                            self.receiver_lat,
                                                            self.receiver_lon,
                                                            la,
                                                            lo
                                                        ),
                                                        stations::bearing_deg(
                                                            self.receiver_lat,
                                                            self.receiver_lon,
                                                            la,
                                                            lo
                                                        )
                                                    ),
                                                );
                                            }
                                        }
                                        if let Some(k) = v.sog_kt {
                                            row(ui, "speed", format!("{k:.1} kt"));
                                        }
                                        if let Some(c) = v.cog_deg {
                                            row(ui, "course", format!("{c:03.0}°"));
                                        }
                                        row(
                                            ui,
                                            "heard",
                                            format!(
                                                "{} messages, last {:.0}s ago",
                                                v.messages, v.age_s
                                            ),
                                        );
                                        row(
                                            ui,
                                            "class",
                                            if v.class_b { "B".into() } else { "A".into() },
                                        );
                                    });
                                ui.add_space(6.0);
                            }
                        }

                        let rows: Vec<(u32, String, String, String, String, f32, bool)> = self
                            .ais
                            .iter()
                            .map(|v| {
                                let dist = match (v.lat, v.lon) {
                                    (Some(la), Some(lo))
                                        if self.receiver_lat != 0.0 || self.receiver_lon != 0.0 =>
                                    {
                                        format!(
                                            "{:.0} km",
                                            stations::distance_km(
                                                self.receiver_lat,
                                                self.receiver_lon,
                                                la,
                                                lo
                                            )
                                        )
                                    }
                                    _ => String::new(),
                                };
                                (
                                    v.mmsi,
                                    v.label.clone(),
                                    v.kind.to_string(),
                                    v.sog_kt
                                        .map(|k| format!("{k:.1} kt"))
                                        .unwrap_or_default(),
                                    dist,
                                    v.age_s,
                                    self.ais_selected == Some(v.mmsi),
                                )
                            })
                            .collect();

                        egui::Grid::new("ais_rows")
                            .num_columns(5)
                            .striped(true)
                            .spacing([10.0, 3.0])
                            .show(ui, |ui| {
                                for h in ["VESSEL", "TYPE", "SPEED", "RANGE", "AGE"] {
                                    ui.label(
                                        egui::RichText::new(h).size(10.0).color(theme::mute()),
                                    );
                                }
                                ui.end_row();
                                let mut pick: Option<u32> = None;
                                for (mmsi, label, kind, spd, dist, age, sel) in &rows {
                                    let c = if *sel { theme::live() } else { theme::text() };
                                    if ui
                                        .add(
                                            egui::Label::new(
                                                egui::RichText::new(label.as_str())
                                                    .monospace()
                                                    .color(c),
                                            )
                                            .sense(egui::Sense::click()),
                                        )
                                        .clicked()
                                    {
                                        pick = Some(*mmsi);
                                    }
                                    ui.label(
                                        egui::RichText::new(kind.as_str()).size(11.0).color(c),
                                    );
                                    ui.label(
                                        egui::RichText::new(spd.as_str()).monospace().color(c),
                                    );
                                    ui.label(
                                        egui::RichText::new(dist.as_str()).monospace().color(c),
                                    );
                                    ui.label(
                                        egui::RichText::new(format!("{age:.0}s"))
                                            .monospace()
                                            .color(theme::mute()),
                                    );
                                    ui.end_row();
                                }
                                if let Some(p) = pick {
                                    self.ais_selected =
                                        if self.ais_selected == Some(p) { None } else { Some(p) };
                                }
                            });
                    });
            });
        });
    }

    /// Pump the OpenSky client: collect any reply, and ask for a refresh if
    /// the overlay is on and the cooldown has expired.
    fn tick_opensky(&mut self, force: bool) {
        if !self.adsb_overlay && !force {
            self.opensky_contacts.clear();
            return;
        }
        if self.opensky.is_none() {
            self.opensky = Some(opensky::OpenSky::start());
        }
        let (lat, lon) = (self.receiver_lat, self.receiver_lon);
        // Ask for a little more than the display shows, so aircraft drifting
        // in from outside the ring are already there when they arrive.
        let radius = (self.adsb_range_km as f64 * 1.2).clamp(25.0, 600.0);
        let mut log: Option<String> = None;
        if let Some(os) = self.opensky.as_mut() {
            match os.poll() {
                Some(opensky::Reply::Ok(v)) => {
                    self.opensky_status =
                        format!("OpenSky sees {} aircraft, in {} queries", v.len(), os.queries);
                    self.opensky_contacts = v;
                }
                Some(opensky::Reply::Failed(e)) => {
                    self.opensky_status = format!("OpenSky unavailable — {e}");
                    log = Some(format!("! {e}"));
                }
                None => {}
            }
            let interval = std::time::Duration::from_secs_f32(self.opensky_interval_s.max(1.0));
            if os.request(lat, lon, radius, interval, force) {
                self.opensky_status = "OpenSky: fetching…".into();
            }
        }
        if let Some(l) = log {
            self.log_push(l);
        }
    }

    fn draw_adsb_view(&mut self, ui: &mut egui::Ui) {
        self.tick_opensky(false);
        // Reload only when the view has wandered near the edge of what was
        // clipped, or zoomed out past it.
        let (vlat, vlon) = self
            .adsb_view_center
            .unwrap_or((self.receiver_lat, self.receiver_lon));
        let stale = match self.geomap_window {
            None => true,
            Some((clat, clon, crad)) => {
                stations::distance_km(clat, clon, vlat, vlon) > crad * 0.4
                    || (self.adsb_range_km as f64) > crad * 0.5
            }
        };
        if self.geomap.is_none() || stale {
            self.load_geomap();
        }
        let heard = self.adsb.len();
        let plotted = self.adsb.iter().filter(|a| a.lat.is_some()).count();
        let named = self.adsb.iter().filter(|a| a.callsign.is_some()).count();

        // Each figure with its own word under it, rather than three
        // dot-joined strings. The numbers are what gets read; the labels are
        // there the first time and ignorable afterwards.
        let stat = |ui: &mut egui::Ui, value: String, label: &'static str, hot: bool| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(value)
                        .font(egui::FontId::monospace(15.0))
                        .color(if hot { theme::live() } else { theme::text() }),
                );
                ui.label(egui::RichText::new(label).size(10.0).color(theme::mute()));
            });
            ui.add_space(14.0);
        };

        ui.horizontal_wrapped(|ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new("1090.000")
                        .font(egui::FontId::monospace(15.0))
                        .color(theme::text()),
                );
                ui.label(egui::RichText::new("MHz, ADS-B").size(10.0).color(theme::mute()));
            });
            ui.add_space(20.0);

            stat(ui, format!("{heard}"), "aircraft", heard > 0);
            stat(ui, format!("{plotted}"), "with a position", false);
            stat(ui, format!("{named}"), "named", false);
            stat(
                ui,
                format!("{}", self.adsb_frames_ok),
                "frames decoded",
                self.adsb_frames_ok > 0,
            );
            stat(
                ui,
                format!("{:.0}", self.adsb_per_min),
                "per minute",
                false,
            );
            // Front-end health, and the pair of numbers that says whether a
            // quiet map is the antenna or the sky.
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "{:.0}/{:.0}",
                        self.adsb_mean_dbfs, self.adsb_peak_dbfs
                    ))
                    .font(egui::FontId::monospace(15.0))
                    .color(theme::text()),
                );
                ui.label(
                    egui::RichText::new("mean/peak dBFS")
                        .size(10.0)
                        .color(theme::mute()),
                );
            })
            .response
            .on_hover_text(
                "Mean and peak sample level at 1090 MHz.\n\n\
                 Peak within a few dB of mean, and no frames: nothing is reaching the dongle \
                 — an antenna or feedline problem.\n\
                 Peak well above mean, still no frames: signals are arriving but too weak or \
                 distorted to survive the parity check. More gain, or a better antenna.\n\n\
                 A few hundred preambles a second with zero frames is what pure noise looks \
                 like. That is the floor, not a fault.",
            );
            ui.add_space(14.0);
            stat(
                ui,
                format!("{:.0}", self.adsb_preambles_per_s),
                "bursts/sec",
                false,
            );

            if self.adsb_best_km > 0.0 {
                ui.separator();
                ui.label(
                    egui::RichText::new(format!("best range {:.0} km", self.adsb_best_km))
                        .small()
                        .color(theme::live()),
                );
            }
            ui.add(
                egui::Slider::new(&mut self.adsb_range_km, 25.0..=500.0)
                    .text("km")
                    .logarithmic(true),
            );
            // Both, by taking turns. The honest framing matters here: this
            // is not simultaneous and cannot be, but positions stay valid
            // for the few seconds the radio is away, so in practice the map
            // stays current while you listen.
            let was = self.track_and_listen;
            ui.checkbox(&mut self.track_and_listen, "Also scan aviation voice")
                .on_hover_text(
                    "Takes turns: about twelve seconds tracking aircraft on 1090 MHz, then \
                     up to twenty-five scanning 118–137 MHz for tower, ground and approach. \
                     A transmission already in progress is never cut off part way.\n\n\
                     One dongle can only be on one frequency, so this is the closest thing \
                     to doing both that the hardware allows.",
                );
            if self.track_and_listen != was {
                let _ = self
                    .cmd_tx
                    .send(Cmd::SetTrackAndListen(self.track_and_listen));
            }
            if ui
                .button("Voice only")
                .on_hover_text(
                    "Leaves the map entirely and scans 118–137 MHz in AM. ADS-B tells you \
                     where an aircraft is; this is the crew talking.",
                )
                .clicked()
            {
                self.track_and_listen = false;
                let _ = self.cmd_tx.send(Cmd::SetTrackAndListen(false));
                self.submit_preset("aviation");
                self.view = View::Live;
            }
            // Whatever was last heard, with a way to keep it. By the time
            // you have decided a frequency was worth saving the scanner has
            // moved on, so saving "the current frequency" is the wrong
            // thing to offer.
            if let Some((mhz, label)) = self.last_heard.clone() {
                ui.separator();
                ui.vertical(|ui| {
                    ui.label(
                        egui::RichText::new(format!("{mhz:.4} MHz"))
                            .font(egui::FontId::monospace(13.0))
                            .color(theme::live()),
                    );
                    ui.label(
                        egui::RichText::new(format!("last heard — {label}"))
                            .size(10.0)
                            .color(theme::mute()),
                    );
                });
                if ui
                    .button("Save it")
                    .on_hover_text("keeps this frequency in the saved list on the left")
                    .clicked()
                {
                    self.save_frequency(mhz, format!("{mhz:.3}"));
                }
                if ui.button("Go back to it").clicked() {
                    self.track_and_listen = false;
                    let _ = self.cmd_tx.send(Cmd::SetTrackAndListen(false));
                    self.selected_mode = Some(Demod::Am);
                    self.submit_command(&format!("{mhz:.4}"));
                    self.view = View::Live;
                }
            }
            if ui
                .button(if self.rec_audio_on { "Stop recording" } else { "Record" })
                .on_hover_text("writes a WAV into the recordings folder next to the program")
                .clicked()
            {
                self.rec_audio_on = !self.rec_audio_on;
                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
            }
            if ui
                .button("Back to scanning")
                .on_hover_text(
                    "ADS-B holds the radio on 1090 MHz. One dongle can only be on one \
                     frequency, so nothing is being scanned or heard while this is open.",
                )
                .clicked()
            {
                self.submit_preset("fm");
                self.view = View::Home;
            }
            // Say which half of the turn the radio is actually in, rather
            // than a fixed line that is wrong half the time.
            let on_1090 = self.plan_name.starts_with("ADS-B");
            ui.label(
                egui::RichText::new(if !self.track_and_listen {
                    "parked on 1090 MHz — not scanning".to_string()
                } else if on_1090 {
                    "tracking on 1090 MHz".to_string()
                } else {
                    format!("listening on {:.4} MHz", self.center_hz / 1e6)
                })
                .size(11.0)
                .color(if self.track_and_listen && !on_1090 {
                    theme::live()
                } else {
                    theme::mute()
                }),
            );
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button("Leave ADS-B").clicked() {
                    if let Some(k) = self.last_band_key.clone() {
                        if k != "adsb" {
                            self.submit_preset(&k);
                        } else {
                            self.submit_preset("fm");
                        }
                    } else {
                        self.submit_preset("fm");
                    }
                    self.view = View::Home;
                }
            });
        });

        // --- the cross-check row ------------------------------------------
        ui.horizontal(|ui| {
            let was = self.adsb_overlay;
            ui.checkbox(&mut self.adsb_overlay, "Compare with OpenSky")
                .on_hover_text(
                    "Fetches what a worldwide network of receivers says is overhead right now, \
                     and draws anything you did NOT decode as a hollow ring. This is the only \
                     part of Sweep that touches the internet.",
                );
            if self.adsb_overlay && !was {
                self.tick_opensky(true);
            }
            if !self.adsb_overlay {
                ui.label(
                    egui::RichText::new(
                        "— off. Turn on to find out whether an empty map means empty skies \
                         or a bad antenna.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                return;
            }

            let busy = self.opensky.as_ref().map(|o| o.in_flight).unwrap_or(false);
            let cooldown = self
                .opensky
                .as_ref()
                .map(|o| o.cooldown())
                .unwrap_or_default();
            if ui
                .add_enabled(!busy && cooldown.is_zero(), egui::Button::new("Refresh"))
                .on_disabled_hover_text(if busy {
                    "fetching".to_string()
                } else {
                    format!("{}s until the next allowed query", cooldown.as_secs())
                })
                .clicked()
            {
                self.tick_opensky(true);
            }
            // The cost of a faster refresh, stated where the choice is made
            // rather than buried somewhere it will not be read.
            let per_day = opensky::queries_per_day(self.opensky_interval_s);
            ui.add(
                egui::Slider::new(&mut self.opensky_interval_s, 15.0..=300.0)
                    .text("s")
                    .logarithmic(true),
            )
            .on_hover_text(format!(
                "Seconds between automatic refreshes.\n\n\
                 At this rate that is about {per_day:.0} queries a day. Anonymous OpenSky \
                 access allows 400 a day per IP address, so anything under ~3.5 minutes \
                 will run out if you leave it on — fine for an afternoon, not for a week.\n\n\
                 Aircraft keep moving between refreshes either way: the overlay carries them \
                 forward along their reported track, and stops doing so after four minutes."
            ));
            if per_day > 400.0 {
                ui.label(
                    egui::RichText::new(format!("≈{per_day:.0}/day — over the 400 free limit"))
                        .small()
                        .color(theme::live()),
                );
            }

            // The number the whole feature exists to produce.
            if !self.opensky_contacts.is_empty() || !self.opensky_status.is_empty() {
                let in_range = self
                    .opensky_contacts
                    .iter()
                    .filter(|t| {
                        let (la, lo) = t.position_now();
                        stations::distance_km(self.receiver_lat, self.receiver_lon, la, lo)
                            <= self.adsb_range_km as f64
                    })
                    .count();
                let mine: std::collections::HashSet<String> =
                    self.adsb.iter().map(|a| a.hex_id.to_ascii_lowercase()).collect();
                let matched = self
                    .opensky_contacts
                    .iter()
                    .filter(|t| mine.contains(&t.icao24))
                    .count();
                ui.separator();
                if in_range > 0 {
                    let pct = 100.0 * matched as f32 / in_range as f32;
                    ui.label(
                        egui::RichText::new(format!(
                            "you heard {matched} of {in_range} within {:.0} km  ({pct:.0}%)",
                            self.adsb_range_km
                        ))
                        .color(if pct >= 50.0 {
                            theme::signal()
                        } else if pct > 0.0 {
                            theme::live()
                        } else {
                            theme::alert()
                        }),
                    );
                } else {
                    ui.label(
                        egui::RichText::new(
                            "no aircraft overhead right now — a blank map is the correct answer",
                        )
                        .color(theme::text()),
                    );
                }
            }
            ui.separator();
            ui.label(
                egui::RichText::new(self.opensky_status.as_str())
                    .small()
                    .color(theme::mute()),
            );
        });

        // --- map files -----------------------------------------------------
        ui.horizontal(|ui| {
            if ui.button("Reload map").clicked() {
                self.load_geomap();
            }
            if ui.button("Where to get maps…").clicked() {
                self.geomap_help_open = true;
            }
            let n = self.geomap.as_ref().map(|m| m.lines.len()).unwrap_or(0);
            let txt = if n > 0 {
                self.geomap_note.clone()
            } else if self.geomap_note.is_empty() {
                "no coastline loaded — grid only".to_string()
            } else {
                self.geomap_note.clone()
            };
            ui.label(
                egui::RichText::new(txt)
                    .small()
                    .color(if n > 0 { theme::mute() } else { theme::live() }),
            );
        });

        // --- your location -------------------------------------------------
        // Editable here, not just in Settings, because it is the one number
        // this whole display depends on and you often only notice it is
        // wrong once aircraft are plotting in the wrong place.
        ui.horizontal(|ui| {
            ui.label(
                egui::RichText::new("Your location")
                    .small()
                    .color(theme::mute()),
            );
            let (la0, lo0) = (self.receiver_lat, self.receiver_lon);
            ui.label("Lat");
            ui.add(
                egui::DragValue::new(&mut self.receiver_lat)
                    .speed(0.0005)
                    .range(-90.0..=90.0)
                    .max_decimals(5),
            );
            ui.label("Lon");
            ui.add(
                egui::DragValue::new(&mut self.receiver_lon)
                    .speed(0.0005)
                    .range(-180.0..=180.0)
                    .max_decimals(5),
            );
            if ui
                .small_button("Recentre")
                .on_hover_text("Drop any panning and put your marker back at the centre")
                .clicked()
            {
                self.adsb_view_center = None;
            }
            if ui
                .selectable_label(self.adsb_set_loc, "⌖ Set on map")
                .on_hover_text("Then click anywhere on the radar to move your location there")
                .clicked()
            {
                self.adsb_set_loc = !self.adsb_set_loc;
            }
            ui.checkbox(&mut self.adsb_sweep, "Sonar sweep");
            // The rings and aircraft follow the numbers live. The coastline
            // is clipped to a window on disk, so it is reloaded only once a
            // move leaves that window — reading it every drag-step would
            // stutter for no visible gain.
            let moved = (self.receiver_lat - la0).abs() > 1e-9
                || (self.receiver_lon - lo0).abs() > 1e-9;
            if moved {
                self.adsb_view_center = None;
                let need_reload = match self.geomap_window {
                    Some((wlat, wlon, wrad)) => {
                        stations::distance_km(wlat, wlon, self.receiver_lat, self.receiver_lon)
                            > wrad * 0.2
                    }
                    None => true,
                };
                if need_reload {
                    self.load_geomap();
                    if self.adsb_overlay {
                        self.tick_opensky(true);
                    }
                }
                self.save_state();
            }
            ui.label(
                egui::RichText::new("drag the numbers — the map follows")
                    .small()
                    .color(theme::mute()),
            );
        });
        ui.add_space(4.0);

        let avail = ui.available_size();
        let radar_w = (avail.x * 0.52).clamp(240.0, 760.0);
        let full_h = avail.y.max(260.0);
        ui.horizontal_top(|ui| {
            let (rect, resp) = ui.allocate_exact_size(
                egui::vec2(radar_w, full_h),
                egui::Sense::click_and_drag(),
            );
            self.draw_radar(ui, rect, &resp);

            ui.add_space(8.0);
            ui.vertical(|ui| {
                self.draw_side_switcher(ui);
                // The spectrum answers "is anything arriving?" without
                // waiting for a frame to pass parity: ADS-B bursts appear as
                // short vertical flecks on the centre line. A flat trace
                // means the band is empty as far as this radio is concerned,
                // which on the wrong antenna is the whole story.
                if self.side != SidePane::Contacts {
                    let h = if self.side == SidePane::Both { full_h * 0.5 } else { full_h };
                    self.draw_signal_pane(
                        ui,
                        h,
                        "1090 MHz — bursts show as flecks on the centre line",
                    );
                    ui.add_space(6.0);
                }
                if self.side == SidePane::Signal {
                    return;
                }

            egui::ScrollArea::vertical()
                .id_source("adsb_table")
                .show(ui, |ui| {
                    self.draw_aircraft_detail(ui);
                    let have_pos = self.receiver_lat != 0.0 || self.receiver_lon != 0.0;
                    if self.adsb.is_empty() {
                        ui.label(
                            egui::RichText::new(
                                "Nothing decoded here yet.\n\n\
                                 ADS-B is line-of-sight at 1090 MHz, so an aircraft has to be \
                                 above your horizon. Ten minutes of waiting is normal near a \
                                 flight path, and longer if you aren't.\n\n\
                                 A quarter-wave whip cut to 69 mm, up high with a clear view, \
                                 does far better here than a TV antenna — at 1090 MHz a yagi \
                                 built for 470–700 MHz is well off resonance, and long coax \
                                 costs several more dB.",
                            )
                            .color(theme::mute()),
                        );
                        // Even with nothing of our own, the overlay list is
                        // the answer to "what is up there?" — so it shows
                        // here rather than behind an empty table.
                        self.draw_opensky_list(ui);
                        return;
                    }
                    // Snapshot the rows first: the click handler writes
                    // `self.adsb_selected`, which cannot happen while the
                    // list it came from is still borrowed.
                    let rows: Vec<(String, String, String, String, String, String, f32, bool)> =
                        self.adsb
                            .iter()
                            .map(|a| {
                                let dist = match (a.lat, a.lon, have_pos) {
                                    (Some(la), Some(lo), true) => format!(
                                        "{:.0} km",
                                        stations::distance_km(
                                            self.receiver_lat,
                                            self.receiver_lon,
                                            la,
                                            lo
                                        )
                                    ),
                                    (Some(_), Some(_), false) => "—".into(),
                                    _ => "".into(),
                                };
                                (
                                    a.hex_id.clone(),
                                    a.callsign.clone().unwrap_or_else(|| "·".into()),
                                    a.alt_ft
                                        .map(|f| format!("{f} ft"))
                                        .unwrap_or_else(|| "".into()),
                                    a.speed_kt
                                        .map(|s| format!("{s:.0} kt"))
                                        .unwrap_or_else(|| "".into()),
                                    a.heading_deg
                                        .map(|h| format!("{h:03.0}°"))
                                        .unwrap_or_else(|| "".into()),
                                    dist,
                                    a.age_s,
                                    self.adsb_selected.as_deref() == Some(a.hex_id.as_str()),
                                )
                            })
                            .collect();

                    egui::Grid::new("adsb_rows")
                        .num_columns(7)
                        .striped(true)
                        .spacing([10.0, 3.0])
                        .show(ui, |ui| {
                            for h in ["ICAO", "FLIGHT", "ALT", "SPD", "HDG", "RANGE", "AGE"] {
                                ui.label(
                                    egui::RichText::new(h).small().color(theme::mute()),
                                );
                            }
                            ui.end_row();
                            let mut pick: Option<String> = None;
                            for (hex, cs, alt, spd, hdg, dist, age, sel) in &rows {
                                let c = if *sel { theme::live() } else { theme::text() };
                                if ui
                                    .add(
                                        egui::Label::new(
                                            egui::RichText::new(hex.as_str()).monospace().color(c),
                                        )
                                        .sense(egui::Sense::click()),
                                    )
                                    .clicked()
                                {
                                    pick = Some(hex.clone());
                                }
                                ui.label(egui::RichText::new(cs.as_str()).monospace().color(c));
                                ui.label(egui::RichText::new(alt.as_str()).monospace().color(c));
                                ui.label(egui::RichText::new(spd.as_str()).monospace().color(c));
                                ui.label(egui::RichText::new(hdg.as_str()).monospace().color(c));
                                ui.label(egui::RichText::new(dist.as_str()).monospace().color(c));
                                ui.label(
                                    egui::RichText::new(format!("{age:.0}s"))
                                        .monospace()
                                        .color(theme::mute()),
                                );
                                ui.end_row();
                            }
                            if let Some(p) = pick {
                                self.adsb_selected =
                                    if self.adsb_selected.as_deref() == Some(p.as_str()) {
                                        None
                                    } else {
                                        Some(p)
                                    };
                                self.adsb_os_selected = None;
                            }
                        });
                    self.draw_opensky_list(ui);
                });
            });
        });
    }

    /// The "overhead now" table: every OpenSky contact within range, sorted
    /// nearest-first, each a row you can click to open its detail. This is
    /// the list that answers "what is up there?" when your own antenna has
    /// heard nothing — which, on a bad antenna, is most of the time.
    fn draw_opensky_list(&mut self, ui: &mut egui::Ui) {
        if !self.adsb_overlay || self.opensky_contacts.is_empty() {
            return;
        }
        let (lat0, lon0) = (self.receiver_lat, self.receiver_lon);
        let mine: std::collections::HashSet<String> =
            self.adsb.iter().map(|a| a.hex_id.to_ascii_lowercase()).collect();
        // Snapshot the rows before drawing, so the click handler is free to
        // write `self.adsb_os_selected` without the contact list borrowed.
        let mut rows: Vec<(String, String, String, String, String, f64, bool, bool)> = self
            .opensky_contacts
            .iter()
            .filter_map(|t| {
                let (la, lo) = t.position_now();
                let d = stations::distance_km(lat0, lon0, la, lo);
                if d > self.adsb_range_km as f64 {
                    return None;
                }
                Some((
                    t.icao24.clone(),
                    t.callsign.clone().unwrap_or_else(|| "·".into()),
                    t.alt_ft.map(|f| format!("{f} ft")).unwrap_or_default(),
                    t.speed_kt.map(|s| format!("{s:.0} kt")).unwrap_or_default(),
                    t.heading_deg.map(|h| format!("{h:03.0}°")).unwrap_or_default(),
                    d,
                    mine.contains(&t.icao24),
                    self.adsb_os_selected.as_deref() == Some(t.icao24.as_str()),
                ))
            })
            .collect();
        rows.sort_by(|a, b| a.5.partial_cmp(&b.5).unwrap_or(std::cmp::Ordering::Equal));

        ui.add_space(8.0);
        ui.horizontal(|ui| {
            ui.label(
                egui::RichText::new("OVERHEAD NOW")
                    .font(theme::display(10.5))
                    .color(theme::mute()),
            );
            ui.label(
                egui::RichText::new(format!("{} within {:.0} km · via OpenSky", rows.len(), self.adsb_range_km))
                    .small()
                    .color(theme::mute()),
            );
        });
        if rows.is_empty() {
            ui.label(
                egui::RichText::new("nothing within range right now")
                    .small()
                    .color(theme::mute()),
            );
            return;
        }

        let mut pick: Option<String> = None;
        egui::Grid::new("os_rows")
            .num_columns(6)
            .striped(true)
            .spacing([10.0, 3.0])
            .show(ui, |ui| {
                for h in ["FLIGHT", "ALT", "SPD", "HDG", "RANGE", ""] {
                    ui.label(egui::RichText::new(h).small().color(theme::mute()));
                }
                ui.end_row();
                for (hex, cs, alt, spd, hdg, d, heard, sel) in &rows {
                    let c = if *sel {
                        theme::live()
                    } else if *heard {
                        theme::signal()
                    } else {
                        theme::text()
                    };
                    if ui
                        .add(
                            egui::Label::new(
                                egui::RichText::new(cs.as_str()).monospace().color(c),
                            )
                            .sense(egui::Sense::click()),
                        )
                        .on_hover_text(format!("ICAO {}", hex.to_ascii_uppercase()))
                        .clicked()
                    {
                        pick = Some(hex.clone());
                    }
                    ui.label(egui::RichText::new(alt.as_str()).monospace().color(c));
                    ui.label(egui::RichText::new(spd.as_str()).monospace().color(c));
                    ui.label(egui::RichText::new(hdg.as_str()).monospace().color(c));
                    ui.label(egui::RichText::new(format!("{d:.0} km")).monospace().color(c));
                    ui.label(
                        egui::RichText::new(if *heard { "heard" } else { "" })
                            .small()
                            .color(theme::signal()),
                    );
                    ui.end_row();
                }
            });
        if let Some(p) = pick {
            self.adsb_os_selected = if self.adsb_os_selected.as_deref() == Some(p.as_str()) {
                None
            } else {
                Some(p)
            };
            self.adsb_selected = None;
        }
    }

    /// The band-wide waterfall: one image covering the entire band rather
    /// than the 2.4 MHz the tuner sees at once.
    fn draw_band_waterfall(
        &mut self,
        ctx: &egui::Context,
        painter: &egui::Painter,
        rect: egui::Rect,
    ) {
        self.band_wf
            .resize(1024, rect.height().round().max(60.0) as usize);
        let image = self.band_wf.image();
        if let Some(t) = self.band_wf_texture.as_mut() {
            t.set(image, egui::TextureOptions::NEAREST);
        } else {
            self.band_wf_texture =
                Some(ctx.load_texture("band_waterfall", image, egui::TextureOptions::NEAREST));
        }
        let tex = self.band_wf_texture.as_ref().unwrap();
        painter.image(
            tex.id(),
            rect,
            egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)),
            egui::Color32::WHITE,
        );

        let (lo, hi) = (self.band_wf.lo_mhz, self.band_wf.hi_mhz);
        if hi > lo {
            // Frequency ticks along the bottom.
            for i in 0..=8 {
                let t = i as f32 / 8.0;
                let f = lo + (hi - lo) * t as f64;
                let x = rect.left() + rect.width() * t;
                painter.line_segment(
                    [
                        egui::pos2(x, rect.bottom() - 5.0),
                        egui::pos2(x, rect.bottom()),
                    ],
                    egui::Stroke::new(1.0_f32, theme::mute()),
                );
                painter.text(
                    egui::pos2(x, rect.bottom() - 6.0),
                    egui::Align2::CENTER_BOTTOM,
                    format!("{f:.1}"),
                    egui::FontId::monospace(9.0),
                    theme::mute(),
                );
            }
            // Where the tuner is pointed right now.
            let cur = self.center_hz / 1e6;
            if cur >= lo && cur <= hi {
                let x = rect.left() + rect.width() * ((cur - lo) / (hi - lo)) as f32;
                painter.line_segment(
                    [egui::pos2(x, rect.top()), egui::pos2(x, rect.bottom())],
                    egui::Stroke::new(1.0_f32, theme::live()),
                );
            }
        }
        theme::bracket_frame(painter, rect, theme::mute(), 12.0);
    }

    fn draw_waterfall(&mut self, ctx: &egui::Context, painter: &egui::Painter, rect: egui::Rect) {
        self.waterfall
            .resize(waterfall::WF_WIDTH, rect.height().round().max(60.0) as usize);
        self.waterfall.floor_db = self.floor_db;
        self.waterfall.ceil_db = self.ceil_db;

        let image = self.waterfall.image();
        if let Some(t) = self.wf_texture.as_mut() {
            t.set(image, egui::TextureOptions::NEAREST);
        } else {
            self.wf_texture =
                Some(ctx.load_texture("waterfall", image, egui::TextureOptions::NEAREST));
        }
        let tex = self.wf_texture.as_ref().unwrap();
        painter.image(
            tex.id(),
            rect,
            egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)),
            egui::Color32::WHITE,
        );
        theme::scanlines(painter, rect);
        theme::bracket_frame(painter, rect, theme::mute(), 14.0);

        let half_span_mhz = self.capture_rate() / 2.0 / 1e6;
        let low_mhz = self.center_hz / 1e6 - half_span_mhz;
        let high_mhz = self.center_hz / 1e6 + half_span_mhz;
        painter.text(
            egui::pos2(rect.left() + 6.0, rect.bottom() - 6.0),
            egui::Align2::LEFT_BOTTOM,
            format!("{low_mhz:.3} MHz"),
            egui::FontId::monospace(11.0),
            theme::signal(),
        );
        painter.text(
            egui::pos2(rect.right() - 6.0, rect.bottom() - 6.0),
            egui::Align2::RIGHT_BOTTOM,
            format!("{high_mhz:.3} MHz"),
            egui::FontId::monospace(11.0),
            theme::signal(),
        );
        self.draw_crosshair(painter, rect);
    }
}

impl eframe::App for SweepApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.drain_messages();
        self.tick_acinfo(ctx);
        if !ctx.wants_keyboard_input() {
            ctx.input(|i| {
                if i.key_pressed(egui::Key::ArrowLeft) { self.step_channel(-1); }
                if i.key_pressed(egui::Key::ArrowRight) { self.step_channel(1); }
                if i.key_pressed(egui::Key::Space) || i.key_pressed(egui::Key::N) { self.skip_signal(); }
                if i.key_pressed(egui::Key::B) { self.go_back(); }
                if i.key_pressed(egui::Key::P) { self.peak_hold = !self.peak_hold; if !self.peak_hold { self.peak_bins.clear(); } }
                if i.key_pressed(egui::Key::A) { self.toggle_auto_scan(); }
            });
        }

        // ---- menu bar -----------------------------------------------------
        egui::TopBottomPanel::top("menubar")
            .frame(egui::Frame::none().fill(theme::surface()).inner_margin(egui::Margin::symmetric(10.0, 6.0)))
            .show(ctx, |ui| {
            ui.horizontal(|ui| {
                // Wordmark in the display face, with the signature amber
                // mid-letters. A nested zero-gap row so the letters read as
                // one word rather than three spaced labels.
                ui.horizontal(|ui| {
                    ui.spacing_mut().item_spacing.x = 0.0;
                    ui.label(egui::RichText::new("SW").font(theme::display(18.0)).color(theme::text()));
                    ui.label(egui::RichText::new("EE").font(theme::display(18.0)).color(theme::live()));
                    ui.label(egui::RichText::new("P").font(theme::display(18.0)).color(theme::text()));
                });
                ui.add_space(6.0);
                ui.menu_button("File", |ui| {
                    if ui.button("Open recordings folder…").clicked() {
                        self.log_push("recordings/ sits next to the executable".into());
                        ui.close_menu();
                    }
                });
                // Every screen reachable from here as well as from the
                // tab row, so no view can ever become a dead end.
                ui.menu_button("View", |ui| {
                    if ui.button("Home screen").clicked() { self.view = View::Home; ui.close_menu(); }
                    if ui.button("Antenna tune").clicked() { self.view = View::Antenna; ui.close_menu(); }
                    if ui.button("Spectrum and waterfall").clicked() { self.view = View::Live; ui.close_menu(); }
                    if ui.button("Whole band").clicked() { self.view = View::Band; ui.close_menu(); }
                    if ui.button("Aircraft map").clicked() { self.view = View::Adsb; ui.close_menu(); }
                    if ui.button("Ships").clicked() { self.view = View::Marine; ui.close_menu(); }
                    if ui.button("APRS").clicked() { self.view = View::Aprs; ui.close_menu(); }
                    if ui.button("ACARS").clicked() { self.view = View::Acars; ui.close_menu(); }
                    if ui.button("Pictures (SSTV)").clicked() { self.view = View::Sstv; ui.close_menu(); }
                    if ui.button("Drone bands").clicked() { self.view = View::Drone; ui.close_menu(); }
                    if ui.button("Pagers").clicked() { self.view = View::Pager; ui.close_menu(); }
                    if ui.button("ISM sensors").clicked() { self.view = View::Ism; ui.close_menu(); }
                    ui.separator();
                    if ui.button(if self.wf3d_on {"3D waterfall: on"} else {"3D waterfall: off"}).clicked() {
                        self.wf3d_on = !self.wf3d_on;
                        if self.view != View::Live { self.view = View::Live; }
                        ui.close_menu();
                    }
                    if ui.button(if self.peak_hold {"Peak hold: on"} else {"Peak hold: off"}).clicked() {
                        self.peak_hold = !self.peak_hold;
                        if !self.peak_hold { self.peak_bins.clear(); }
                        ui.close_menu();
                    }
                });
                ui.menu_button("Receiver", |ui| {
                    if ui.button("Resume band sweep").clicked() {
                        if let Some(k) = self.last_band_key.clone() { self.submit_preset(&k); }
                        ui.close_menu();
                    }
                    if ui.button("Skip current signal").clicked() { self.skip_signal(); ui.close_menu(); }
                });
                ui.menu_button("Tools", |ui| {
                    if ui.button("Things to listen to…").clicked() { self.presets_open = true; ui.close_menu(); }
                    if ui.button("Test tone").clicked() { let _ = self.cmd_tx.send(Cmd::TestTone); ui.close_menu(); }
                    if ui.button("Settings…").clicked() { self.settings_open = true; ui.close_menu(); }
                });
                ui.menu_button("Help", |ui| {
                    ui.label("←/→ step channel");
                    ui.label("Space skip · B previous");
                    ui.label("P peak hold · A auto scan");
                });

                // Day / night, right out in the open on the menu bar rather
                // than buried in settings — the whole reason to reach for it
                // is that the screen is hard to see, so it has to be easy to
                // find. The label says what you'll switch TO.
                if ui
                    .button(if theme::is_day() { "☾ Night" } else { "☀ Day" })
                    .on_hover_text(
                        "Day mode: black on a pale panel, for reading the screen outdoors \
                         in sunlight. Night mode: the dark instrument look, for indoors \
                         and after dark.",
                    )
                    .clicked()
                {
                    theme::set_day(!theme::is_day());
                    theme::apply(ctx);
                }

                ui.separator();
                ui.label(egui::RichText::new("Record").size(11.0).color(theme::mute()));
                if ui.selectable_label(self.rec_iq_on, "raw IQ").on_hover_text("write the undemodulated samples to disk — about 4.8 MB every second").clicked() {
                    self.rec_iq_on = !self.rec_iq_on;
                    let _ = self.cmd_tx.send(Cmd::SetRecordIq(self.rec_iq_on));
                }

                // Device status used to be repeated here. It now lives in
                // the readout strip immediately below, where the rest of
                // "what is happening right now" already is.
            });
        });

        // ---- the readout: what you are hearing, right now ------------------
        //
        // This line replaces a 300px right-hand rail that held a needle
        // gauge, a table of constants and a status block. Everything on it
        // was read at a glance or not at all, which is what a strip is for;
        // the rail was spending a fifth of the window on it.
        egui::TopBottomPanel::top("readout")
            .frame(
                egui::Frame::none()
                    .fill(theme::ink())
                    .inner_margin(egui::Margin::symmetric(14.0, 10.0)),
            )
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    // The one large thing on screen. Monospace so the digits
                    // hold still as it retunes, and the whole readout is the
                    // drag target for stepping channels.
                    let fr = ui
                        .add(
                            egui::Label::new(
                                egui::RichText::new(format!("{:.4}", self.center_hz / 1e6))
                                    .font(theme::display(42.0))
                                    .color(theme::live()),
                            )
                            .sense(egui::Sense::click_and_drag()),
                        )
                        .on_hover_text("drag left or right to step channels");
                    self.handle_freq_drag(&fr);
                    ui.add_space(2.0);
                    ui.vertical(|ui| {
                        ui.add_space(6.0);
                        ui.label(egui::RichText::new("MHz").size(11.0).color(theme::mute()));
                        ui.label(
                            egui::RichText::new(format!(
                                "{:.1} kHz step",
                                self.current_step_mhz() * 1000.0
                            ))
                            .size(11.0)
                            .color(theme::mute()),
                        );
                    });

                    ui.add_space(18.0);
                    ui.vertical(|ui| {
                        ui.add_space(3.0);
                        // What this frequency is, when anything knows. The
                        // name of a station is more use than its number, and
                        // it is the thing a person actually wants confirmed.
                        let id = bands::identify_frequency(self.center_hz / 1e6, &self.stations);
                        match (&self.rds_ps, id) {
                            (Some(ps), _) => ui.label(
                                egui::RichText::new(ps.as_str()).size(15.0).color(theme::live()),
                            ),
                            (None, Some(name)) => {
                                ui.label(egui::RichText::new(name).size(15.0).color(theme::text()))
                            }
                            (None, None) => ui.label(
                                egui::RichText::new("unidentified")
                                    .size(15.0)
                                    .color(theme::mute()),
                            ),
                        };
                        ui.horizontal(|ui| {
                            ui.label(
                                egui::RichText::new(self.mode_label())
                                    .size(11.0)
                                    .color(theme::mute()),
                            );
                            if let Some(bw) = self.bw_override_khz {
                                ui.label(
                                    egui::RichText::new(format!("{bw:.0} kHz"))
                                        .size(11.0)
                                        .color(theme::mute()),
                                );
                            }
                            ui.label(
                                egui::RichText::new(self.activity_text())
                                    .size(11.0)
                                    .color(if self.signal_active {
                                        theme::live()
                                    } else {
                                        theme::mute()
                                    }),
                            );
                        });
                    });

                    ui.add_space(18.0);
                    ui.vertical(|ui| {
                        ui.add_space(5.0);
                        let (br, _) = ui.allocate_exact_size(
                            egui::vec2(140.0, 8.0),
                            egui::Sense::hover(),
                        );
                        theme::level_bar(ui.painter(), br, self.last_snr, self.signal_active);
                        ui.horizontal(|ui| {
                            // The S-unit reading hams would quote, and the
                            // raw figure it comes from. Neither is calibrated
                            // against an absolute reference — the dongle has
                            // none — so both are relative to the noise floor
                            // and the label says so.
                            ui.label(
                                egui::RichText::new(self.s_meter_label())
                                    .font(egui::FontId::monospace(13.0))
                                    .color(if self.signal_active {
                                        theme::live()
                                    } else {
                                        theme::mute()
                                    }),
                            );
                            ui.label(
                                egui::RichText::new(format!("{:.0} dB over noise", self.last_snr))
                                    .size(11.0)
                                    .color(theme::mute()),
                            );
                        });
                    });

                    // Right-aligned: the things you glance at rather than read.
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let c = if self.device_ok { theme::text() } else { theme::alert() };
                        ui.label(
                            egui::RichText::new(if self.device_ok {
                                "RTL-SDR connected"
                            } else {
                                "no device"
                            })
                            .size(11.0)
                            .color(c),
                        );
                        if self.windows_total <= 1 && self.last_band_key.is_some() {
                            if ui
                                .button("Resume sweep")
                                .on_hover_text("parked on one frequency — go back to scanning the band")
                                .clicked()
                            {
                                if let Some(k) = self.last_band_key.clone() {
                                    self.submit_preset(&k);
                                }
                            }
                        }
                        if let Some(ms) = self.last_pass_ms {
                            if ms > 0 && self.plan_channels > 0 {
                                ui.label(
                                    egui::RichText::new(format!(
                                        "{:.0} channels/sec",
                                        self.plan_channels as f64 / (ms as f64 / 1000.0)
                                    ))
                                    .size(11.0)
                                    .color(theme::mute()),
                                );
                            }
                        }
                        if self.windows_total > 1 {
                            ui.label(
                                egui::RichText::new(format!(
                                    "window {} of {}",
                                    self.window_idx + 1,
                                    self.windows_total
                                ))
                                .size(11.0)
                                .color(theme::mute()),
                            );
                        }
                        ui.label(
                            egui::RichText::new(self.plan_name.as_str())
                                .size(11.0)
                                .color(theme::mute()),
                        );
                    });
                });
                // Radiotext gets its own line only when there is one; it is
                // a scrolling message and does not fit beside anything.
                if let Some(rt) = self.rds_radiotext.clone() {
                    if !rt.trim().is_empty() {
                        ui.label(egui::RichText::new(rt).size(11.0).color(theme::mute()));
                    }
                }
            });

        // ---- right: the controls -------------------------------------------
        //
        // One job: everything you set. Readings live in the strip above,
        // navigation in the bar below. On the right, instrument-panel style —
        // mode, tuning knob, squelch, gain, memories — so the eye runs
        // scope-in-the-middle, controls-down-the-side like a real rig.
        egui::SidePanel::right("rx_control")
            .resizable(true)
            .default_width(212.0)
            .frame(egui::Frame::none().fill(theme::ink()).inner_margin(12.0))
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .id_source("rx_scroll")
                    .show(ui, |ui| {
                        egui::Grid::new("modegrid")
                            .num_columns(3)
                            .spacing([4.0, 4.0])
                            .show(ui, |ui| {
                                for (i, (m, l)) in [
                                    (Demod::Am, "AM"),
                                    (Demod::Nfm, "NFM"),
                                    (Demod::Wfm, "WFM"),
                                    (Demod::Usb, "USB"),
                                    (Demod::Lsb, "LSB"),
                                    (Demod::Cw, "CW"),
                                ]
                                .into_iter()
                                .enumerate()
                                {
                                    if ui
                                        .selectable_label(self.selected_mode == Some(m), l)
                                        .clicked()
                                    {
                                        self.set_mode(m, l);
                                    }
                                    if i % 3 == 2 {
                                        ui.end_row();
                                    }
                                }
                            });

                        ui.add_space(10.0);
                        self.draw_tuning_knob(ui);
                        ui.add_space(8.0);
                        theme::section(ui, "Direct entry");
                        self.draw_keypad(ui);

                        ui.add_space(12.0);
                        let sq = ui.add(
                            egui::Slider::new(&mut self.squelch_db, 3.0..=30.0).text("squelch"),
                        );
                        if sq.drag_stopped() || (sq.changed() && !sq.dragged()) {
                            let _ = self.cmd_tx.send(Cmd::SetSquelch(self.squelch_db));
                        }
                        let v = ui.add(egui::Slider::new(&mut self.volume, 0.0..=3.0).text("volume"));
                        if v.changed() {
                            let _ = self.cmd_tx.send(Cmd::SetVolume(self.volume));
                        }
                        // Output level, directly under the control that sets
                        // it, so a silent station and a muted radio are
                        // distinguishable without hunting.
                        let (ar, _) = ui
                            .allocate_exact_size(egui::vec2(ui.available_width(), 5.0), egui::Sense::hover());
                        theme::level_bar(
                            ui.painter(),
                            ar,
                            self.audio_peak.clamp(0.0, 1.0) * 40.0,
                            self.audio_peak > 0.01,
                        );

                        ui.add_space(12.0);
                        theme::section(ui, "Bandwidth");
                        let mut auto_bw = self.bw_override_khz.is_none();
                        if ui.checkbox(&mut auto_bw, "follow the mode").changed() {
                            self.bw_override_khz =
                                if auto_bw { None } else { Some(self.bw_slider_khz) };
                            let _ = self.cmd_tx.send(Cmd::SetBandwidthKhz(self.bw_override_khz));
                        }
                        if !auto_bw {
                            let r = ui.add(
                                egui::Slider::new(&mut self.bw_slider_khz, 2.0..=250.0)
                                    .logarithmic(true)
                                    .suffix(" kHz"),
                            );
                            if r.drag_stopped() || (r.changed() && !r.dragged()) {
                                self.bw_override_khz = Some(self.bw_slider_khz);
                                let _ =
                                    self.cmd_tx.send(Cmd::SetBandwidthKhz(self.bw_override_khz));
                            }
                        }

                        ui.add_space(12.0);
                        theme::section(ui, "RF gain");
                        ui.horizontal(|ui| {
                            if ui.selectable_label(self.gain_auto, "auto").clicked() {
                                self.gain_auto = true;
                                self.set_gain();
                            }
                            if ui.selectable_label(!self.gain_auto, "manual").clicked() {
                                self.gain_auto = false;
                                self.set_gain();
                            }
                        });
                        if !self.gain_auto {
                            let mut db = self.gain_tenths_db as f32 / 10.0;
                            let r = ui.add(
                                egui::Slider::new(&mut db, 0.0..=49.6).suffix(" dB"),
                            );
                            if r.changed() {
                                self.gain_tenths_db = (db * 10.0).round() as i32;
                                self.set_gain();
                            }
                        }

                        ui.add_space(12.0);
                        let mut bias = self.bias_tee_on;
                        if ui
                            .checkbox(&mut bias, "Power an antenna preamp")
                            .on_hover_text(
                                "Sends 4.5 V up the coax to power an inline LNA or a mast-mounted \
                                 preamp that takes bias power. Leave it OFF for a plain antenna, \
                                 or for a rooftop/TV preamp that already has its own power inserter \
                                 — double-powering or a shorted feedline trips the dongle's \
                                 protection.",
                            )
                            .changed()
                        {
                            self.bias_tee_on = bias;
                            let _ = self.cmd_tx.send(Cmd::SetBiasTee(bias));
                        }
                        if self.bias_tee_on {
                            ui.label(
                                egui::RichText::new(
                                    "⚠ preamp powered — if strong signals distort or the noise \
                                     floor jumps, lower RF gain or switch this off",
                                )
                                .small()
                                .color(theme::live()),
                            );
                        }

                        ui.add_space(12.0);
                        ui.horizontal_wrapped(|ui| {
                            let rec = if self.rec_audio_on { "Stop recording" } else { "Record" };
                            if ui
                                .button(egui::RichText::new(rec).color(if self.rec_audio_on {
                                    theme::alert()
                                } else {
                                    theme::text()
                                }))
                                .clicked()
                            {
                                self.rec_audio_on = !self.rec_audio_on;
                                let _ = self.cmd_tx.send(Cmd::SetRecordAudio(self.rec_audio_on));
                            }
                            if ui.button("Save").on_hover_text("bookmark this frequency").clicked() {
                                self.save_memory();
                            }
                            if ui.button("Settings").clicked() {
                                self.settings_open = true;
                            }
                        });

                        if !self.memories.is_empty() {
                            ui.add_space(12.0);
                            theme::section(ui, "Saved");
                            let mems: Vec<(String, f64)> = self.memories.clone();
                            let mut recall = None;
                            ui.horizontal_wrapped(|ui| {
                                for (label, f) in &mems {
                                    if ui.small_button(label.as_str()).clicked() {
                                        recall = Some(*f);
                                    }
                                }
                            });
                            if let Some(f) = recall {
                                self.submit_command(&format!("{f:.4}"));
                            }
                        }

                        ui.add_space(14.0);
                        theme::section(ui, "Log");
                        egui::ScrollArea::vertical()
                            .id_source("logscroll")
                            .max_height(190.0)
                            .stick_to_bottom(true)
                            .show(ui, |ui| {
                                for line in &self.log {
                                    let c = if line.starts_with('!') {
                                        theme::alert()
                                    } else if line.starts_with(">>") || line.starts_with("<<") {
                                        theme::live()
                                    } else {
                                        theme::mute()
                                    };
                                    ui.label(egui::RichText::new(line).size(11.0).color(c));
                                }
                            });
                    });
            });

        // ---- bottom: where to go next ---------------------------------------
        //
        // Was four labelled groups behind separators. The labels said
        // "TUNING", "BAND", "DIRECT ENTRY", "SCAN" above controls that are
        // arrows, band names, a text field with a hint, and buttons that
        // name their own action — four headings explaining nothing. One row
        // now, grouped by spacing.
        egui::TopBottomPanel::bottom("tuning")
            .resizable(false)
            .frame(
                egui::Frame::none()
                    .fill(theme::surface())
                    .inner_margin(egui::Margin::symmetric(12.0, 8.0)),
            )
            .show(ctx, |ui| {
                ui.horizontal_wrapped(|ui| {
                    if ui.button("◀◀").on_hover_text("back ten channels").clicked() {
                        self.step_channel(-10);
                    }
                    if ui.button("◀").clicked() {
                        self.step_channel(-1);
                    }
                    if ui.button("▶").clicked() {
                        self.step_channel(1);
                    }
                    if ui.button("▶▶").on_hover_text("forward ten channels").clicked() {
                        self.step_channel(10);
                    }

                    ui.add_space(16.0);
                    // Band abbreviations stay in caps: that is their name,
                    // not a styling choice.
                    for (k, l) in [
                        ("fm", "FM"),
                        ("aviation", "AIR"),
                        ("marine", "MARINE"),
                        ("weather", "WX"),
                        ("2m", "2M"),
                        ("70cm", "70CM"),
                        ("frs", "FRS"),
                        ("cb", "CB"),
                        ("railway", "RAIL"),
                        ("ism", "ISM"),
                    ] {
                        if ui
                            .selectable_label(self.last_band_key.as_deref() == Some(k), l)
                            .clicked()
                        {
                            self.submit_preset(k);
                        }
                    }

                    ui.add_space(16.0);
                    let r = ui.add(
                        egui::TextEdit::singleline(&mut self.command_input)
                            .desired_width(170.0)
                            .hint_text("146.520, or a band name"),
                    );
                    if (r.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)))
                        || ui.button("Tune").clicked()
                    {
                        let t = self.command_input.clone();
                        self.submit_command(&t);
                    }

                    ui.add_space(16.0);
                    if ui
                        .button("Skip")
                        .on_hover_text("leave this signal and carry on scanning")
                        .clicked()
                    {
                        self.skip_signal();
                    }
                    if ui
                        .selectable_label(self.auto_scan, "Keep moving")
                        .on_hover_text(
                            "Move on after a short listen instead of staying put. Without this \
                             a station that never stops transmitting holds the scanner forever.",
                        )
                        .clicked()
                    {
                        self.toggle_auto_scan();
                    }
                    if ui
                        .selectable_label(self.voice_only, "Voices only")
                        .on_hover_text("walk past carriers and data bursts, stop on speech")
                        .clicked()
                    {
                        self.voice_only = !self.voice_only;
                        let _ = self.cmd_tx.send(Cmd::SetVoiceOnly(self.voice_only));
                    }
                    if ui
                        .add_enabled(self.signal_history.len() >= 2, egui::Button::new("Back"))
                        .on_hover_text("return to the previous signal")
                        .clicked()
                    {
                        self.go_back();
                    }
                });
            });

        // ---- centre: spectrum + waterfall ----------------------------------
        egui::CentralPanel::default()
            .frame(egui::Frame::none().fill(theme::ink()).inner_margin(10.0))
            .show(ctx, |ui| {
            ui.horizontal(|ui| {
                if ui.selectable_label(self.view == View::Home, "Home").clicked() { self.view = View::Home; }
                if ui.selectable_label(self.view == View::Live, "Spectrum").clicked() { self.view = View::Live; }
                if ui.selectable_label(self.view == View::Band, "Whole band").clicked() { self.view = View::Band; }
                if ui.selectable_label(self.view == View::Antenna, "Antenna tune").clicked() { self.view = View::Antenna; }
                if ui.selectable_label(self.view == View::Sstv, "Pictures").clicked() {
                    if self.last_band_key.as_deref() != Some("sstv") {
                        self.submit_preset("sstv");
                    }
                    self.view = View::Sstv;
                }
                if ui.selectable_label(self.view == View::Acars, "ACARS").clicked() {
                    if self.last_band_key.as_deref() != Some("acars") {
                        self.submit_preset("acars");
                    }
                    self.view = View::Acars;
                }
                if ui.selectable_label(self.view == View::Aprs, "APRS").clicked() {
                    if self.last_band_key.as_deref() != Some("aprs") {
                        self.submit_preset("aprs");
                    }
                    self.view = View::Aprs;
                }
                if ui.selectable_label(self.view == View::Marine, "Ships").clicked() {
                    if self.last_band_key.as_deref() != Some("ais") {
                        self.submit_preset("ais");
                    }
                    self.view = View::Marine;
                }
                if ui.selectable_label(self.view == View::Pager, "Pagers").clicked() {
                    if self.last_band_key.as_deref() != Some("pager") {
                        self.submit_preset("pager");
                    }
                    self.view = View::Pager;
                }
                if ui.selectable_label(self.view == View::Ism, "ISM sensors").clicked() {
                    if self.last_band_key.as_deref() != Some("sensors") {
                        self.submit_preset("sensors");
                    }
                    self.view = View::Ism;
                }
                if ui.selectable_label(self.view == View::Drone, "Drone bands").clicked() {
                    // Same rule as the aircraft map: opening the survey
                    // retunes to it, because a band picture fed by a radio
                    // pointed somewhere else is a lie with axes on it.
                    if self.last_band_key.as_deref() != Some("drone") {
                        self.submit_preset("drone");
                    }
                    self.view = View::Drone;
                }
                if ui.selectable_label(self.view == View::Adsb, "Aircraft map").clicked() {
                    // Opening the map retunes to 1090 MHz, because an
                    // aircraft map fed by a radio pointed somewhere else is
                    // the bug that shipped in v65.
                    if self.last_band_key.as_deref() != Some("adsb") {
                        self.submit_preset("adsb");
                    }
                    self.view = View::Adsb;
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(egui::RichText::new(format!("Span {:.3} MHz", self.capture_rate()/1e6)).small().color(theme::mute()));
                    ui.label(egui::RichText::new(format!("FFT {}", worker::FFT_N)).small().color(theme::mute()));
                });
            });
            ui.add_space(4.0);

            if self.view == View::Home {
                // Clicking a tile tunes that band and drops straight into
                // the live view — one press, from nothing to listening.
                if let Some(key) = self.draw_tiles(ui) {
                    // submit_command picks the view: ADS-B goes to the
                    // aircraft map, everything else to the spectrum.
                    self.submit_preset(key);
                    if self.view == View::Home {
                        self.view = View::Live;
                    }
                }
            } else if self.view == View::Adsb {
                self.draw_adsb_view(ui);
            } else if self.view == View::Marine {
                self.draw_marine_view(ui);
            } else if self.view == View::Aprs {
                self.draw_aprs_view(ui);
            } else if self.view == View::Acars {
                self.draw_acars_view(ui);
            } else if self.view == View::Sstv {
                self.draw_sstv_view(ui);
            } else if self.view == View::Drone {
                self.draw_drone_view(ui);
            } else if self.view == View::Pager {
                self.draw_pager_view(ui);
            } else if self.view == View::Ism {
                self.draw_ism_view(ui);
            } else if self.view == View::Antenna {
                self.draw_antenna_view(ui);
            } else if self.view == View::Band {
                self.band_view = true;
                let (r, _) = ui.allocate_exact_size(ui.available_size(), egui::Sense::hover());
                self.draw_band_waterfall(ctx, ui.painter(), r);
            } else {
                self.band_view = false;
                let (tr, tresp) = ui.allocate_exact_size(
                    egui::vec2(ui.available_width(), (ui.available_height()*0.38).max(90.0)),
                    egui::Sense::click_and_drag());
                self.cursor_freq = None;
                self.handle_tune_interaction(&tresp, tr);
                self.draw_trace(ui.painter(), tr);
                ui.add_space(4.0);
                // Leave room below the waterfall for the controls row
                // (peak hold, 3D, floor/ceiling). Without this the waterfall
                // takes the entire remaining height and that row is pushed
                // off the bottom of the panel — which is why the 3D toggle
                // was invisible and "not working".
                let wf_h = (ui.available_height() - 36.0).max(90.0);
                let (wr, wresp) = ui.allocate_exact_size(
                    egui::vec2(ui.available_width(), wf_h),
                    egui::Sense::click_and_drag(),
                );
                if self.wf3d_on {
                    // The surface has no frequency axis to click, so it does
                    // not take the tune interaction — the spectrum trace
                    // above still does.
                    wf3d::draw(ui.painter(), wr, &self.wf_hist, self.floor_db, self.ceil_db);
                    theme::bracket_frame(ui.painter(), wr, theme::mute(), 14.0);
                } else {
                    self.handle_tune_interaction(&wresp, wr);
                    self.draw_waterfall(ctx, ui.painter(), wr);
                }
                if self.cursor_freq.is_none() { self.frozen_center_hz = None; }
            }

            if self.view != View::Home {
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                if ui.selectable_label(self.peak_hold, "Peak hold").clicked() {
                    self.peak_hold = !self.peak_hold;
                    if !self.peak_hold { self.peak_bins.clear(); }
                }
                if ui.selectable_label(self.wf3d_on, "3D")
                    .on_hover_text(
                        "Tip the waterfall into perspective: the newest sweep across the \
                         front, older sweeps receding, signal strength raised into ridges. \
                         Same data as the flat view — the flat one is easier to read an \
                         exact frequency off, so this is for watching the band move.",
                    )
                    .clicked()
                {
                    self.wf3d_on = !self.wf3d_on;
                }
                if ui.button("Clear peak").clicked() { self.peak_bins = self.spectrum_live.clone(); }
                if ui.button("Auto scale").clicked() { self.auto_scale(); }
                if ui.button("Recentre").on_hover_text("re-centre on the current frequency").clicked() {
                    let f = self.center_hz / 1e6; self.submit_command(&format!("{f:.4}"));
                }
                ui.separator();
                ui.add(egui::Slider::new(&mut self.floor_db, -140.0..=-20.0).text("floor"));
                ui.add(egui::Slider::new(&mut self.ceil_db, -80.0..=0.0).text("ceiling"));
            });
            }
        });

        // ---- windows -------------------------------------------------------
        if self.presets_open {
            let mut open = true;
            let mut tune: Option<(f64, &'static str)> = None;
            egui::Window::new("Things to listen to").open(&mut open).resizable(true).default_width(520.0).show(ctx, |ui| {
                ui.label(egui::RichText::new("Everything here is reachable on this dongle. Notes say what you'd actually hear — and where something no longer transmits, it says so.").small().color(theme::mute()));
                ui.separator();
                egui::ScrollArea::vertical().show(ui, |ui| {
                    for g in presets::GROUPS {
                        ui.add_space(6.0);
                        ui.label(egui::RichText::new(g.title).strong().color(theme::live()));
                        for p in g.presets {
                            ui.horizontal(|ui| {
                                if ui.button(format!("{:.4}", p.freq_mhz)).clicked() { tune = Some((p.freq_mhz, p.mode)); }
                                ui.label(egui::RichText::new(p.name).strong());
                                ui.label(egui::RichText::new(p.mode).small().color(theme::mute()));
                            });
                            ui.label(egui::RichText::new(p.note).small().color(theme::mute()));
                        }
                    }
                });
            });
            self.presets_open = open;
            if let Some((f, m)) = tune {
                self.selected_mode = Some(match m {
                    "AM" => Demod::Am, "WFM" => Demod::Wfm, "USB" => Demod::Usb,
                    "LSB" => Demod::Lsb, "CW" => Demod::Cw, _ => Demod::Nfm });
                self.submit_command(&format!("{f:.4}"));
            }
        }

        if self.geomap_help_open {
            let mut open = true;
            egui::Window::new("Map data")
                .open(&mut open)
                .resizable(true)
                .default_width(520.0)
                .show(ctx, |ui| {
                    ui.label(
                        egui::RichText::new(geomap::MAP_HELP)
                            .color(theme::text()),
                    );
                    ui.separator();
                    ui.label(
                        egui::RichText::new(format!(
                            "Sweep is looking in: {}",
                            geomap::map_dir().display()
                        ))
                        .monospace()
                        .small()
                        .color(theme::mute()),
                    );
                });
            self.geomap_help_open = open;
        }

        if self.settings_open {
            let mut open = true;
            egui::Window::new("Settings").open(&mut open).resizable(true).default_width(430.0).show(ctx, |ui| {
                ui.label(egui::RichText::new("Keyboard").strong());
                ui.label("←/→ step channel · Space skip · B previous · P peak hold · A auto scan");
                ui.separator();
                ui.label(egui::RichText::new("Receiver").strong());
                ui.horizontal(|ui| {
                    ui.label("PPM");
                    if ui.add(egui::DragValue::new(&mut self.ppm).speed(1).range(-200..=200)).changed() {
                        let _ = self.cmd_tx.send(Cmd::SetPpm(self.ppm));
                    }
                });
                ui.separator();
                ui.label(egui::RichText::new("Your position").strong());
                ui.label(
                    egui::RichText::new(
                        "Used for range and bearing only — to place aircraft on the ADS-B map \
                         and to point at stations you've entered yourself. Nothing is sent \
                         anywhere. Defaults to downtown Toronto, which will put every aircraft \
                         in slightly the wrong place until you change it.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                ui.horizontal(|ui| {
                    ui.label("Lat");
                    let c1 = ui.add(egui::DragValue::new(&mut self.receiver_lat).speed(0.001).range(-90.0..=90.0).max_decimals(5)).changed();
                    ui.label("Lon");
                    let c2 = ui.add(egui::DragValue::new(&mut self.receiver_lon).speed(0.001).range(-180.0..=180.0).max_decimals(5)).changed();
                    if c1 || c2 {
                        self.save_state();
                    }
                });

                ui.separator();
                ui.label(egui::RichText::new("Devices").strong());
                ui.label(
                    egui::RichText::new(
                        "Offline file bridges — nothing streams live. Plug the Garmin in as a \
                         USB drive, or move the exported files across by hand.",
                    )
                    .small()
                    .color(theme::mute()),
                );
                // Garmin → receiver position.
                if ui
                    .button("Set location from Garmin")
                    .on_hover_text(
                        "Scans for a connected Garmin (a drive with a \\Garmin\\GPX folder), \
                         and also a gps\\ folder next to the executable. Reads the waypoints \
                         so you can pick one as your position.",
                    )
                    .clicked()
                {
                    let mut wps = Vec::new();
                    for f in gps::find_garmin_waypoints() {
                        if let Ok(t) = std::fs::read_to_string(&f) {
                            wps.extend(gps::parse_waypoints(&t));
                        }
                    }
                    self.gps_status = if wps.is_empty() {
                        "No Garmin waypoints found. Plug the GPS in (it mounts as a drive), \
                         or drop a .gpx into a gps\\ folder next to the program."
                            .into()
                    } else {
                        format!("Found {} waypoint(s) — pick one below.", wps.len())
                    };
                    self.gps_waypoints = wps;
                }
                // The waypoints, each a button that sets the position.
                for w in self.gps_waypoints.clone() {
                    if ui
                        .button(format!("  {}   {:.4}, {:.4}", w.name, w.lat, w.lon))
                        .clicked()
                    {
                        self.receiver_lat = w.lat;
                        self.receiver_lon = w.lon;
                        self.gps_status =
                            format!("Position set to {} ({:.4}, {:.4}).", w.name, w.lat, w.lon);
                        self.save_state();
                    }
                }
                // Sweep → Baofeng (CHIRP CSV from saved channels).
                if ui
                    .button("Export channels for CHIRP (Baofeng)")
                    .on_hover_text(
                        "Writes your saved frequencies as a CHIRP CSV in exports\\. Open it in \
                         CHIRP, plug in the UV-5RH, and write the channels to it. (The Baofeng \
                         is FM-only, so AM airband frequencies are written as FM.)",
                    )
                    .clicked()
                {
                    let chans: Vec<gps::Channel> = self
                        .memories
                        .iter()
                        .map(|(n, f)| gps::Channel {
                            name: n.clone(),
                            freq_mhz: *f,
                        })
                        .collect();
                    self.gps_status = if chans.is_empty() {
                        "No saved channels yet — use Save on a frequency first.".into()
                    } else {
                        let csv = gps::write_chirp_csv(&chans);
                        match write_export_file("sweep_channels.csv", &csv) {
                            Some(p) => format!("Wrote {} channel(s) → {}", chans.len(), p.display()),
                            None => "Couldn't write the CSV (check folder permissions).".into(),
                        }
                    };
                }
                // Sweep → Garmin (GPX of decoded positions).
                if ui
                    .button("Export contacts to GPX (Garmin)")
                    .on_hover_text(
                        "Writes the aircraft, ships and APRS stations currently decoded as GPX \
                         waypoints in exports\\. Copy it into the Garmin's \\Garmin\\GPX folder \
                         to see them on the handheld.",
                    )
                    .clicked()
                {
                    let mut cs: Vec<gps::Contact> = Vec::new();
                    for a in &self.adsb {
                        if let (Some(la), Some(lo)) = (a.lat, a.lon) {
                            cs.push(gps::Contact {
                                name: a.callsign.clone().unwrap_or_else(|| a.hex_id.clone()),
                                lat: la,
                                lon: lo,
                                desc: a.alt_ft.map(|ft| format!("{ft} ft")).unwrap_or_default(),
                                sym: "Airport",
                            });
                        }
                    }
                    for v in &self.ais {
                        if let (Some(la), Some(lo)) = (v.lat, v.lon) {
                            cs.push(gps::Contact {
                                name: v.name.clone().unwrap_or_else(|| format!("MMSI {}", v.mmsi)),
                                lat: la,
                                lon: lo,
                                desc: v.destination.clone().unwrap_or_default(),
                                sym: "Boat",
                            });
                        }
                    }
                    for s in &self.aprs {
                        if let (Some(la), Some(lo)) = (s.lat, s.lon) {
                            cs.push(gps::Contact {
                                name: s.call.clone(),
                                lat: la,
                                lon: lo,
                                desc: s.comment.clone(),
                                sym: "Flag, Blue",
                            });
                        }
                    }
                    self.gps_status = match gps::write_gpx(&cs) {
                        None => "Nothing with a position to export yet — open the aircraft, ship \
                                 or APRS view and let some contacts come in first."
                            .into(),
                        Some(gpx) => match write_export_file("sweep_contacts.gpx", &gpx) {
                            Some(p) => format!("Wrote {} contact(s) → {}", cs.len(), p.display()),
                            None => "Couldn't write the GPX (check folder permissions).".into(),
                        },
                    };
                }
                if !self.gps_status.is_empty() {
                    ui.label(
                        egui::RichText::new(&self.gps_status)
                            .small()
                            .color(theme::signal()),
                    );
                }

                ui.separator();
                if ui.button("Test tone").on_hover_text("1 kHz straight to the speakers, bypassing the dongle and demodulator").clicked() {
                    let _ = self.cmd_tx.send(Cmd::TestTone);
                }
                ui.separator();
                ui.label(egui::RichText::new("Recordings are written to the recordings/ folder next to the executable.").small().color(theme::mute()));
            });
            self.settings_open = open;
        }

        ctx.request_repaint_after(std::time::Duration::from_millis(33));
    }
}
