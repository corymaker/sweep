//! A scrolling waterfall kept as a plain pixel buffer and blitted to a GPU
//! texture each frame. New rows enter at the top; everything else shifts
//! down. `FFT_N` is 1024 and `Spectrum::usable()` drops the outer eighth on
//! each side, so incoming rows are always 768 bins wide — but `push_row`
//! resamples defensively in case that ever changes upstream.

use eframe::egui;

pub const WF_WIDTH: usize = 768;

pub struct Waterfall {
    width: usize,
    height: usize,
    pixels: Vec<egui::Color32>,
    pub floor_db: f32,
    pub ceil_db: f32,
}

impl Waterfall {
    pub fn new(width: usize, height: usize) -> Self {
        Waterfall {
            width,
            height,
            pixels: vec![bg_color(); width * height],
            floor_db: -100.0,
            ceil_db: -20.0,
        }
    }

    /// Re-sizes the backing buffer, clearing it. Cheap no-op if unchanged.
    pub fn resize(&mut self, width: usize, height: usize) {
        let height = height.max(2);
        if width == self.width && height == self.height {
            return;
        }
        self.width = width;
        self.height = height;
        self.pixels = vec![bg_color(); width * height];
    }

    pub fn push_row(&mut self, row_db: &[f32]) {
        let w = self.width;
        if row_db.is_empty() || w == 0 {
            return;
        }
        if self.height > 1 {
            self.pixels.copy_within(0..w * (self.height - 1), w);
        }
        for x in 0..w {
            let src = if row_db.len() == w {
                row_db[x]
            } else {
                let idx = x * row_db.len() / w;
                row_db[idx.min(row_db.len() - 1)]
            };
            self.pixels[x] = colormap(src, self.floor_db, self.ceil_db);
        }
    }

    pub fn image(&self) -> egui::ColorImage {
        egui::ColorImage {
            size: [self.width, self.height],
            pixels: self.pixels.clone(),
        }
    }
}

/// A waterfall spanning an entire *band*, not just the 2.4 MHz the tuner
/// can see at once.
///
/// The dongle only ever sees one window at a time, so a band view has to be
/// assembled: each incoming spectrum is painted into the horizontal slice
/// of the image that its frequencies actually occupy, and the picture fills
/// in as the sweep walks across. Rows scroll on a timer rather than per
/// update, so one full pass of the band lands on roughly one row and the
/// vertical axis stays meaningful as time.
pub struct BandWaterfall {
    width: usize,
    height: usize,
    pixels: Vec<egui::Color32>,
    /// Accumulator for the row currently being built, in dB.
    row: Vec<f32>,
    row_seen: Vec<bool>,
    pub lo_mhz: f64,
    pub hi_mhz: f64,
    pub floor_db: f32,
    pub ceil_db: f32,
}

impl BandWaterfall {
    pub fn new(width: usize, height: usize) -> Self {
        BandWaterfall {
            width,
            height,
            pixels: vec![bg_color(); width * height],
            row: vec![-140.0; width],
            row_seen: vec![false; width],
            lo_mhz: 88.0,
            hi_mhz: 108.0,
            floor_db: -100.0,
            ceil_db: -20.0,
        }
    }

    /// Changing the band clears everything — the x-axis now means
    /// different frequencies, so old pixels would be actively misleading.
    pub fn set_band(&mut self, lo_mhz: f64, hi_mhz: f64) {
        // A single-frequency "band" — APRS, ADS-B — would otherwise give
        // this a zero width to divide by. Open it out to the tuner's own
        // window, which is what you can actually see from there anyway.
        let (lo_mhz, hi_mhz) = if (hi_mhz - lo_mhz).abs() < 1e-6 {
            (lo_mhz - 1.2, hi_mhz + 1.2)
        } else {
            (lo_mhz, hi_mhz)
        };
        if (self.lo_mhz - lo_mhz).abs() < 1e-9 && (self.hi_mhz - hi_mhz).abs() < 1e-9 {
            return;
        }
        self.lo_mhz = lo_mhz;
        self.hi_mhz = hi_mhz;
        self.pixels.iter_mut().for_each(|p| *p = bg_color());
        self.row.iter_mut().for_each(|v| *v = -140.0);
        self.row_seen.iter_mut().for_each(|v| *v = false);
    }

    pub fn resize(&mut self, width: usize, height: usize) {
        let height = height.max(2);
        if width == self.width && height == self.height {
            return;
        }
        self.width = width;
        self.height = height;
        self.pixels = vec![bg_color(); width * height];
        self.row = vec![-140.0; width];
        self.row_seen = vec![false; width];
    }

    /// Paint one tuner window's spectrum into its slice of the band.
    /// `bins` spans `center_mhz ± span_mhz/2`.
    pub fn add_window(&mut self, bins: &[f32], center_mhz: f64, span_mhz: f64) {
        if bins.is_empty() || self.hi_mhz <= self.lo_mhz {
            return;
        }
        let band_span = self.hi_mhz - self.lo_mhz;
        let w_lo = center_mhz - span_mhz / 2.0;
        for (i, &db) in bins.iter().enumerate() {
            let f = w_lo + span_mhz * (i as f64 + 0.5) / bins.len() as f64;
            if f < self.lo_mhz || f > self.hi_mhz {
                continue;
            }
            let x = (((f - self.lo_mhz) / band_span) * self.width as f64) as usize;
            if x >= self.width {
                continue;
            }
            // Keep the strongest value seen for this pixel this pass —
            // several FFT bins can land on one screen column.
            if !self.row_seen[x] || db > self.row[x] {
                self.row[x] = db;
                self.row_seen[x] = true;
            }
        }
    }

    /// Commit the accumulated row and start a new one.
    pub fn commit_row(&mut self) {
        let w = self.width;
        if self.height > 1 {
            self.pixels.copy_within(0..w * (self.height - 1), w);
        }
        for x in 0..w {
            self.pixels[x] = if self.row_seen[x] {
                colormap(self.row[x], self.floor_db, self.ceil_db)
            } else {
                bg_color()
            };
        }
        self.row.iter_mut().for_each(|v| *v = -140.0);
        self.row_seen.iter_mut().for_each(|v| *v = false);
    }

    pub fn image(&self) -> egui::ColorImage {
        egui::ColorImage {
            size: [self.width, self.height],
            pixels: self.pixels.clone(),
        }
    }
}

fn bg_color() -> egui::Color32 {
    egui::Color32::from_rgb(6, 8, 16)
}

/// Classic SDR ramp: near-black → deep blue → cyan → green → yellow → red
/// → white. Perceptually this spreads far more distinguishable colour
/// across the mid-range where real signals sit than a single-hue phosphor
/// ramp does, so weak carriers stand out from the noise floor instead of
/// blending into it.
pub fn colormap(db: f32, floor: f32, ceil: f32) -> egui::Color32 {
    let t = if ceil > floor {
        ((db - floor) / (ceil - floor)).clamp(0.0, 1.0)
    } else {
        0.0
    };
    // A thermal/IR ramp: black → deep blue → indigo → magenta → ember →
    // amber → white. Deliberately with no green anywhere on it, so the
    // phosphor-green interface colour can never be mistaken for signal
    // strength. It also reads harder and hotter than the old blue-green-red
    // scale, which is the register this whole instrument is in now.
    const STOPS: [(f32, u8, u8, u8); 7] = [
        (0.00, 6, 8, 16),
        (0.18, 24, 26, 84),
        (0.38, 78, 28, 132),
        (0.55, 158, 36, 120),
        (0.72, 226, 74, 54),
        (0.88, 255, 168, 40),
        (1.00, 255, 246, 222),
    ];
    for i in 0..STOPS.len() - 1 {
        let (t0, r0, g0, b0) = STOPS[i];
        let (t1, r1, g1, b1) = STOPS[i + 1];
        if t >= t0 && t <= t1 {
            let l = if t1 > t0 { (t - t0) / (t1 - t0) } else { 0.0 };
            return egui::Color32::from_rgb(lerp(r0, r1, l), lerp(g0, g1, l), lerp(b0, b1, l));
        }
    }
    let (_, r, g, b) = STOPS[STOPS.len() - 1];
    egui::Color32::from_rgb(r, g, b)
}

fn lerp(a: u8, b: u8, t: f32) -> u8 {
    (a as f32 + (b as f32 - a as f32) * t).round().clamp(0.0, 255.0) as u8
}
