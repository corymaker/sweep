//! Runs the whole core end to end on synthetic IQ. No dongle required.
//!
//!     cargo run --example pipeline -- "listen to air traffic"

use rustfft::num_complex::Complex32;
use std::f32::consts::TAU;
use sweep_core::*;

const FFT: usize = 1024;
const SR: u32 = 2_400_000;

/// A capture centred at `center_hz` containing a few carriers, plus noise.
fn fake_capture(center_hz: f64, carriers: &[(f64, f32)], frame: u64) -> Vec<Complex32> {
    let mut out = vec![Complex32::new(0.0, 0.0); FFT];
    let mut s = frame.wrapping_mul(6364136223846793005).wrapping_add(1);
    let mut noise = || {
        s = s.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        ((s >> 33) as f32 / (1u64 << 31) as f32 - 0.5) * 0.004
    };
    for (freq_hz, amp) in carriers {
        let off = (freq_hz - center_hz) / SR as f64;
        if off.abs() > 0.4 {
            continue;
        }
        for (i, o) in out.iter_mut().enumerate() {
            let ph = TAU * (off as f32) * i as f32;
            *o += Complex32::new(amp * ph.cos(), amp * ph.sin());
        }
    }
    for o in out.iter_mut() {
        *o += Complex32::new(noise(), noise());
    }
    out
}

fn main() {
    let utterance = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "listen to air traffic".to_string());

    println!("utterance   {utterance:?}");

    let plan = match rules::parse(&utterance) {
        Some(p) => {
            println!("parsed by   rule table (no model)");
            p
        }
        None => {
            println!("parsed by   nothing — this is where the model would be called");
            return;
        }
    };

    println!("plan        {}  [{}]", plan.name, plan.source);
    println!("demod       {:?} @ {} kHz steps", plan.demod, plan.step_khz);

    let run = match resolve(&plan, false) {
        Ok(r) => r,
        Err(e) => {
            println!("REJECTED    {e}");
            return;
        }
    };

    println!("windows     {}", run.windows.len());
    if run.is_single_window() {
        println!("blind time  none — single window, nothing is ever missed");
    } else {
        println!(
            "blind time  {:.0}% of the time per window, {} ms revisit",
            run.blind_fraction() * 100.0,
            run.revisit_ms()
        );
    }

    // Plant three carriers inside the first window so there is something to find.
    let w = &run.windows[0];
    let c = w.center_mhz * 1e6;
    let carriers = [
        (c - 400_000.0, 0.05f32),
        (c + 120_000.0, 0.012),
        (c + 610_000.0, 0.030),
    ];
    println!(
        "\nwindow 1    centre {:.4} MHz, covering {:.3}-{:.3} MHz",
        w.center_mhz,
        w.low_mhz(),
        w.high_mhz()
    );

    let mut spec = Spectrum::new(FFT);
    let mut frame_db = vec![0.0f32; FFT];
    let mut power = vec![0.0f32; FFT];
    let mut integ = Integrator::new(FFT, 16);
    println!(
        "integration {} frames, noise sigma ~{:.1} dB",
        integ.frames(),
        integ.noise_sigma_db()
    );
    let mut floor = NoiseFloor::new(FFT);
    let det = Detector::default();
    let mut tracker = Tracker::new(12_500.0, 200);
    let mut squelch = Squelch::new(plan.squelch_db as f32, plan.hang_ms);

    let bin_hz = SR as f64 / FFT as f64;
    let f0 = c - SR as f64 / 2.0;

    for frame in 0..120u64 {
        // The middle carrier keys up for a while, then unkeys. Watch squelch.
        let live: Vec<(f64, f32)> = carriers
            .iter()
            .enumerate()
            .filter(|(i, _)| *i != 1 || (30..70).contains(&frame))
            .map(|(_, c)| *c)
            .collect();
        // Integrate 16 FFTs per dwell before anything downstream sees it.
        let mut ready = false;
        for sub in 0..16u64 {
            let iq = fake_capture(c, &live, frame * 16 + sub);
            spec.process(&iq, &mut frame_db);
            ready = integ.push_db(&frame_db);
        }
        if !ready {
            continue;
        }
        integ.take(&mut power);
        spec.blank_dc(&mut power, SR, 30_000.0, -140.0);
        floor.update(&power);
        if frame < 8 {
            continue; // let the floor settle
        }
        let dets = det.scan(&power, floor.get(), f0, bin_hz);
        tracker.ingest(&dets, frame);

        // Squelch follows the middle carrier as if it were the parked channel.
        let bin = ((carriers[1].0 - f0) / bin_hz).round() as usize;
        let snr = power[bin] - floor.get()[bin];
        let before = squelch.state();
        let after = squelch.update(snr, 20);
        if before != after {
            println!(
                "  frame {frame:>3}  squelch {before:?} -> {after:?}   ({snr:.0} dB over floor)"
            );
        }
    }

    println!("\nnoise floor {:.1} dBFS median", floor.median());
    println!("\ndetections");
    println!("  {:>12}   {:>8}   {:>7}   {:>5}", "MHz", "BW kHz", "SNR dB", "duty");
    for t in tracker.confirmed(5) {
        println!(
            "  {:>12.4}   {:>8.1}   {:>7.1}   {:>4.0}%",
            t.center_hz / 1e6,
            t.bw_hz / 1e3,
            t.peak_db - floor.median(),
            t.duty() * 100.0
        );
    }
}
