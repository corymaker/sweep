//! POCSAG paging — CCIR Recommendation 584.
//!
//! Pagers are the easiest genuinely useful thing an RTL-SDR can decode, and
//! the reason is the error-control code. Every 32-bit codeword carries a
//! BCH(31,21) check and an overall even parity bit, so a decode either
//! passes arithmetic or it does not. There is no judgement call about
//! whether a message is real, which means this decoder could be written and
//! proved correct without a single off-air capture — the tests below encode
//! valid batches, modulate them, slice them back and compare.
//!
//! The chain:
//!
//! ```text
//!   NFM discriminator ──► Nrz (DC block, timing recovery) ──► bits
//!                                                              │
//!                                     PocsagDemod (sync hunt, batch, BCH)
//!                                                              │
//!                                                          Message
//! ```
//!
//! # What is certain and what is not
//!
//! Certain, because it is specified and self-checking: the framing, the BCH
//! code, the parity, the address/frame arithmetic, and alphanumeric text.
//! An alphanumeric message that comes out of here passed its checks.
//!
//! Not certain: the **numeric** rendering. Numeric messages are 4-bit BCD
//! with no checksum of their own beyond the codeword's, and sources
//! disagree on whether the nibble is transmitted most- or least-
//! significant-bit first. [`Message::numeric`] uses the same LSB-first
//! convention as the text path and is marked unverified rather than
//! presented as fact. The same goes for the two function bits: published
//! mappings of function to message type contradict each other, so this
//! decoder does not use them to decide how to read a payload. It renders
//! the payload both ways and reports the function bits raw.

/// Frame synchronisation codeword. Begins every batch.
pub const SYNC: u32 = 0x7CD2_15D8;
/// Fills unused codeword slots. Not a real address.
pub const IDLE: u32 = 0x7A89_C197;

/// BCH(31,21) generator: x^10 + x^9 + x^8 + x^6 + x^5 + x^3 + 1.
const GEN: u32 = 0x769;

/// How many bit errors the sync hunt tolerates in the 32-bit sync word.
///
/// The code's minimum distance is 6, so two errors is what a codeword can
/// actually be corrected through; allowing the same slack on sync keeps a
/// noisy first batch from being thrown away. Allowing much more than this
/// starts finding "sync" in noise.
pub const SYNC_SLACK: u32 = 2;

/// Standard POCSAG bit rates.
pub const BAUDS: [f32; 3] = [512.0, 1200.0, 2400.0];

/// Largest possible pager address. A RIC is 21 bits: eighteen transmitted
/// in the address codeword and three implied by the frame it arrived in.
/// Anything above this is not a POCSAG address.
pub const MAX_RIC: u32 = 0x1F_FFFF;

/// The Canadian paging channel plan, from ISED SRSP-504: 931.0125 to
/// 931.9875 MHz in 25 kHz steps, forty channels.
pub const CA_PAGING_LO_HZ: f64 = 931_012_500.0;
pub const CA_PAGING_HI_HZ: f64 = 931_987_500.0;
pub const CA_PAGING_STEP_HZ: f64 = 25_000.0;

/// The four channels shared Canada-wide and US-wide, which makes them the
/// sensible place to start looking. Also from SRSP-504.
pub const NATIONWIDE_HZ: [f64; 4] = [
    931_437_500.0,
    931_887_500.0,
    931_912_500.0,
    931_937_500.0,
];

/// Every channel in the Canadian plan, low to high.
pub fn ca_channels() -> Vec<f64> {
    let n = ((CA_PAGING_HI_HZ - CA_PAGING_LO_HZ) / CA_PAGING_STEP_HZ).round() as usize + 1;
    (0..n)
        .map(|i| CA_PAGING_LO_HZ + i as f64 * CA_PAGING_STEP_HZ)
        .collect()
}

/// Remainder of a 31-bit codeword body modulo the generator.
///
/// Zero for a valid codeword. Operates on bits 31..1 of `cw` — bit 0 is the
/// overall parity bit and is not part of the BCH code.
pub fn syndrome(cw: u32) -> u32 {
    let mut r = cw >> 1; // 31 bits: 21 information + 10 check
    for i in (10..31).rev() {
        if r & (1 << i) != 0 {
            r ^= GEN << (i - 10);
        }
    }
    r & 0x3FF
}

/// Even parity over bits 31..1, which is what bit 0 must equal.
pub fn parity_bit(cw: u32) -> u32 {
    ((cw >> 1).count_ones() & 1) as u32
}

pub fn parity_ok(cw: u32) -> bool {
    (cw & 1) == parity_bit(cw)
}

/// A codeword passes if both its BCH syndrome and its parity are clean.
pub fn codeword_ok(cw: u32) -> bool {
    syndrome(cw) == 0 && parity_ok(cw)
}

/// Build a valid codeword from 21 information bits (the flag bit and the 20
/// data bits), filling in the BCH check bits and the parity bit.
///
/// Used by the tests to generate real batches, and by nothing else — but it
/// belongs next to [`syndrome`] so the two cannot drift apart.
pub fn encode(info21: u32) -> u32 {
    let info = info21 & 0x1F_FFFF;
    let mut r = info << 10;
    for i in (10..31).rev() {
        if r & (1 << i) != 0 {
            r ^= GEN << (i - 10);
        }
    }
    let cw = (info << 11) | ((r & 0x3FF) << 1);
    cw | parity_bit(cw)
}

/// How much repair a codeword needed.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Repair {
    /// Arrived correct.
    Clean,
    /// One bit was wrong and was put back.
    OneBit,
    /// Two bits were wrong. Inside what the code can correct, but a message
    /// built from codewords like this is worth flagging rather than
    /// presenting as clean text.
    TwoBits,
}

/// Correct up to two bit errors, or give up.
///
/// The code has a minimum distance of 6, so two errors is genuinely
/// correctable and not a guess. Beyond that the nearest valid codeword is
/// no longer necessarily the one that was sent, and returning it would be
/// inventing a message — so this returns `None` and the caller drops the
/// codeword.
///
/// Done by search rather than by syndrome table: 31 single flips and 465
/// pairs is a few thousand operations, against 75 codewords a second at the
/// fastest bit rate. The table would be faster and is not needed.
pub fn repair(cw: u32) -> Option<(u32, Repair)> {
    if codeword_ok(cw) {
        return Some((cw, Repair::Clean));
    }
    for i in 0..32 {
        let t = cw ^ (1 << i);
        if codeword_ok(t) {
            return Some((t, Repair::OneBit));
        }
    }
    for i in 0..32 {
        for j in (i + 1)..32 {
            let t = cw ^ (1 << i) ^ (1 << j);
            if codeword_ok(t) {
                return Some((t, Repair::TwoBits));
            }
        }
    }
    None
}

/// Hamming distance between a word and the sync pattern.
pub fn sync_distance(cw: u32) -> u32 {
    (cw ^ SYNC).count_ones()
}

/// One decoded page.
#[derive(Clone, Debug, PartialEq)]
pub struct Message {
    /// Radio Identity Code: the full 21-bit pager address. The low three
    /// bits are not transmitted — they are which frame of the batch the
    /// address appeared in.
    pub ric: u32,
    /// The two function bits, as received. Deliberately not interpreted:
    /// published mappings from function to message type disagree with each
    /// other, so this decoder reports the bits and lets the content decide.
    pub func: u8,
    /// Which rendering of the payload to believe. See [`Reading`].
    pub reading: Reading,
    /// 7-bit ASCII reading of the payload, when the result looks like text.
    pub text: Option<String>,
    /// 4-bit BCD reading of the same payload. Always produced; the nibble
    /// bit order is a convention this decoder cannot verify without an
    /// off-air capture, so treat it as a reading rather than a fact.
    pub numeric: String,
    /// Payload codewords that went into this message. Zero means a
    /// tone-only page: an address with no data, which is a real and common
    /// kind of page, not a failed decode.
    pub codewords: u32,
    /// Codewords that needed one bit repaired.
    pub repaired_one: u32,
    /// Codewords that needed two bits repaired. Any of these and the text
    /// should be read with suspicion.
    pub repaired_two: u32,
    /// Codewords dropped as beyond repair while this message was being
    /// assembled, so a hole in the text is visible rather than silent.
    pub dropped: u32,
}

impl Message {
    /// Whether this is an address with no payload.
    pub fn tone_only(&self) -> bool {
        self.codewords == 0
    }

    /// Whether anything needed repairing or was lost.
    pub fn marginal(&self) -> bool {
        self.repaired_two > 0 || self.dropped > 0
    }

    /// The reading to show: text when it looks like text, digits otherwise.
    /// When [`Message::reading`] is `Ambiguous` this picks the text, and the
    /// UI is expected to offer the other one as well rather than hiding it.
    pub fn best(&self) -> &str {
        match self.text.as_deref() {
            Some(t) => t,
            None => self.numeric.as_str(),
        }
    }
}

/// Fraction of characters that must be letters, digits or spaces before a
/// payload is called text.
///
/// "Printable" is not enough, and finding that out cost a test: a twelve-
/// digit numeric page read as 7-bit ASCII came back as `,W*\n"&f` — 87%
/// printable, and complete nonsense. Random 7-bit values land in the
/// printable range often enough that printability says almost nothing. What
/// separates real text from a misread is that real text is mostly letters,
/// digits and spaces, while a misread is a scatter of punctuation.
///
/// Set low enough for a punctuation-heavy page ("CALL DR. SMITH EXT. 4412 —
/// URGENT" is 88%) and well above what a random payload reaches.
const TEXTLIKE_RATIO: f32 = 0.65;

/// How many odd characters a text reading may contain, as one in N.
///
/// Not zero: a triple bit error can mis-correct to a valid codeword and
/// corrupt one character, and throwing away an otherwise perfect page for
/// that would be worse than showing it with a mark where the damage is. But
/// a numeric payload misread as ASCII is around a quarter control
/// characters, so anything above a few percent is a misread.
const ODD_CHAR_LIMIT: usize = 16;

/// Which reading of a payload to believe.
///
/// The format does not settle this. There are two function bits that are
/// supposed to select the message type, but published mappings of function
/// value to type contradict each other, so this decoder does not rely on
/// them — it reads the payload both ways and judges by content. When both
/// readings are plausible it says so rather than picking one, and the UI
/// shows both.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Reading {
    /// The ASCII reading looks like language; the numeric one does not.
    Text,
    /// The ASCII reading does not survive its checks.
    Numeric,
    /// Both are plausible. Rare, and short payloads are where it happens.
    Ambiguous,
}

/// Decode packed 7-bit characters, or decline.
///
/// Bits arrive most-significant-first out of each codeword's 20-bit field
/// and run continuously across codeword boundaries, but each character's
/// own bits are sent least-significant-first — so the first bit of a group
/// of seven is that character's bit 0.
///
/// Returns `None` when the result does not look like text. That judgement
/// is the whole job: every payload can be *read* as ASCII, and a numeric
/// page read that way produces something printable and meaningless. See
/// [`TEXTLIKE_RATIO`].
pub fn decode_text(bits: &[u8]) -> Option<String> {
    if bits.len() < 7 {
        return None;
    }
    let mut out = String::new();
    let mut textlike = 0usize;
    let mut odd = 0usize;
    let mut breaks = 0usize;
    let mut total = 0usize;
    for g in bits.chunks_exact(7) {
        let mut c = 0u8;
        for (i, &b) in g.iter().enumerate() {
            if b != 0 {
                c |= 1 << i;
            }
        }
        // NUL and EOT both end a message; everything after is padding.
        if c == 0x00 || c == 0x04 {
            break;
        }
        total += 1;
        match c {
            b'\r' | b'\n' => {
                breaks += 1;
                out.push('\n');
            }
            0x20..=0x7E => {
                if c.is_ascii_alphanumeric() || c == b' ' {
                    textlike += 1;
                }
                out.push(c as char);
            }
            _ => {
                // A control character or DEL. Kept visible rather than
                // dropped, so a message with a hole in it looks like one.
                odd += 1;
                out.push('·');
            }
        }
    }
    if total == 0 {
        return None;
    }
    if odd * ODD_CHAR_LIMIT > total {
        return None;
    }
    // A page that is mostly line breaks is a misread, not a page.
    if breaks * 10 > total {
        return None;
    }
    if (textlike as f32 / total as f32) < TEXTLIKE_RATIO {
        return None;
    }
    Some(out.trim_end().to_string())
}

/// Whether a numeric reading looks like something somebody sent.
///
/// A numeric page is digits, and usually a phone number, an extension or a
/// job number. The tell for a *misread* is the special characters: `[`, `]`
/// and `*` are rare in real numeric pages and common in random nibbles.
fn numeric_plausible(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }
    let odd = s
        .chars()
        .filter(|c| matches!(c, '[' | ']' | '*' | 'U'))
        .count();
    odd * 8 <= s.len()
}

/// Decode packed 4-bit BCD digits.
///
/// Same LSB-first convention as the text path. The special values are from
/// CCIR 584: 0xB is an urgency marker, 0xC a space, 0xD a hyphen, and 0xE
/// and 0xF the two brackets. Trailing spaces are padding.
pub fn decode_numeric(bits: &[u8]) -> String {
    let mut out = String::new();
    for g in bits.chunks_exact(4) {
        let mut v = 0u8;
        for (i, &b) in g.iter().enumerate() {
            if b != 0 {
                v |= 1 << i;
            }
        }
        out.push(match v {
            0..=9 => (b'0' + v) as char,
            0xA => '*',
            0xB => 'U',
            0xC => ' ',
            0xD => '-',
            0xE => ']',
            0xF => '[',
            _ => unreachable!(),
        });
    }
    out.trim_end().to_string()
}

/// Message under construction, between an address codeword and whatever
/// ends it.
struct Pending {
    ric: u32,
    func: u8,
    bits: Vec<u8>,
    codewords: u32,
    repaired_one: u32,
    repaired_two: u32,
    dropped: u32,
}

impl Pending {
    fn finish(self) -> Message {
        let text = decode_text(&self.bits);
        let numeric = decode_numeric(&self.bits);
        let reading = match (&text, numeric_plausible(&numeric)) {
            (Some(_), true) => Reading::Ambiguous,
            (Some(_), false) => Reading::Text,
            (None, _) => Reading::Numeric,
        };
        Message {
            ric: self.ric,
            func: self.func,
            reading,
            text,
            numeric,
            codewords: self.codewords,
            repaired_one: self.repaired_one,
            repaired_two: self.repaired_two,
            dropped: self.dropped,
        }
    }
}

/// Where the bit-level decoder is.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum State {
    /// Shifting bits looking for the sync pattern.
    Hunting,
    /// Inside a batch, collecting the sixteen payload codewords.
    Batch,
    /// Batch finished; the next 32 bits should be another sync word.
    ExpectSync,
}

/// Bit-level POCSAG decoder. Feed it bits, get messages.
pub struct PocsagDemod {
    window: u32,
    bits_in: u32,
    state: State,
    /// Which of the sixteen codeword slots in this batch is next.
    slot: usize,
    pending: Option<Pending>,
    /// Counters, for telling "nothing is transmitting" from "something is
    /// transmitting and this decoder cannot read it".
    pub syncs: u64,
    pub codewords_ok: u64,
    pub codewords_repaired: u64,
    pub codewords_dropped: u64,
    pub addresses: u64,
}

impl Default for PocsagDemod {
    fn default() -> Self {
        Self::new()
    }
}

impl PocsagDemod {
    pub fn new() -> Self {
        PocsagDemod {
            window: 0,
            bits_in: 0,
            state: State::Hunting,
            slot: 0,
            pending: None,
            syncs: 0,
            codewords_ok: 0,
            codewords_repaired: 0,
            codewords_dropped: 0,
            addresses: 0,
        }
    }

    /// Feed one bit. Completed messages go to `sink`.
    pub fn bit(&mut self, b: u8, sink: &mut impl FnMut(Message)) {
        self.window = (self.window << 1) | (b as u32 & 1);
        self.bits_in += 1;
        match self.state {
            State::Hunting => {
                if self.bits_in >= 32 && sync_distance(self.window) <= SYNC_SLACK {
                    self.syncs += 1;
                    self.state = State::Batch;
                    self.slot = 0;
                    self.bits_in = 0;
                }
            }
            State::Batch | State::ExpectSync => {
                if self.bits_in < 32 {
                    return;
                }
                self.bits_in = 0;
                let word = self.window;
                if self.state == State::ExpectSync {
                    if sync_distance(word) <= SYNC_SLACK {
                        // The next batch of the same transmission. A
                        // message can legitimately run across the boundary,
                        // so `pending` is deliberately left alone.
                        self.syncs += 1;
                        self.state = State::Batch;
                        self.slot = 0;
                    } else {
                        // Transmission over, or lost. Flush and hunt again.
                        self.flush(sink);
                        self.state = State::Hunting;
                    }
                    return;
                }
                self.consume(word, sink);
                self.slot += 1;
                if self.slot >= 16 {
                    self.state = State::ExpectSync;
                }
            }
        }
    }

    /// Feed a slice of bits.
    pub fn bits(&mut self, bits: &[u8], sink: &mut impl FnMut(Message)) {
        for &b in bits {
            self.bit(b, sink);
        }
    }

    fn consume(&mut self, word: u32, sink: &mut impl FnMut(Message)) {
        // An idle codeword ends whatever message was in progress and
        // carries nothing itself. It is checked before repair because it is
        // a known-good word and repairing it would be wasted work.
        if sync_distance(word ^ (IDLE ^ SYNC)) == 0 || word == IDLE {
            self.flush(sink);
            return;
        }
        let (cw, rep) = match repair(word) {
            Some(v) => v,
            None => {
                self.codewords_dropped += 1;
                if let Some(p) = self.pending.as_mut() {
                    p.dropped += 1;
                }
                return;
            }
        };
        if cw == IDLE {
            self.flush(sink);
            return;
        }
        match rep {
            Repair::Clean => self.codewords_ok += 1,
            _ => self.codewords_repaired += 1,
        }
        if cw >> 31 == 0 {
            // Address codeword. Ends any previous message and starts one.
            self.flush(sink);
            let addr18 = (cw >> 13) & 0x3_FFFF;
            let func = ((cw >> 11) & 0x3) as u8;
            // The three low bits of the address are not sent: they are the
            // frame this codeword arrived in, which is the slot index
            // halved since a frame is two codewords.
            let frame = (self.slot / 2) as u32 & 0x7;
            self.addresses += 1;
            let mut p = Pending {
                ric: (addr18 << 3) | frame,
                func,
                bits: Vec::new(),
                codewords: 0,
                repaired_one: 0,
                repaired_two: 0,
                dropped: 0,
            };
            match rep {
                Repair::OneBit => p.repaired_one += 1,
                Repair::TwoBits => p.repaired_two += 1,
                Repair::Clean => {}
            }
            self.pending = Some(p);
            return;
        }
        // Message codeword: twenty payload bits, most significant first.
        if let Some(p) = self.pending.as_mut() {
            for i in (11..31).rev() {
                p.bits.push(((cw >> i) & 1) as u8);
            }
            p.codewords += 1;
            match rep {
                Repair::OneBit => p.repaired_one += 1,
                Repair::TwoBits => p.repaired_two += 1,
                Repair::Clean => {}
            }
        }
        // A message codeword with no address before it is a fragment of
        // somebody else's page that started before we synchronised. There
        // is no address to attribute it to, so it is dropped rather than
        // reported against a guess.
    }

    fn flush(&mut self, sink: &mut impl FnMut(Message)) {
        if let Some(p) = self.pending.take() {
            sink(p.finish());
        }
    }

    /// End of transmission: emit anything still being assembled.
    pub fn finish(&mut self, sink: &mut impl FnMut(Message)) {
        self.flush(sink);
        self.state = State::Hunting;
        self.bits_in = 0;
    }
}

/// Direct-FSK bit recovery from a discriminator output.
///
/// POCSAG is not audio-frequency keying — there are no mark and space tones
/// to correlate against, as there are in APRS and ACARS. The two RF
/// frequencies come out of an FM discriminator as a bipolar baseband
/// signal, so the data is the *sign* of the demodulated output and all this
/// has to do is find the bit boundaries.
///
/// Three things it does have to get right:
///
/// * **DC.** The discriminator output is offset by however far the tuner is
///   from the transmitter, and that offset is routinely larger than the
///   ±4.5 kHz deviation being measured. A long-running mean is subtracted,
///   so the slicing threshold follows the carrier instead of sitting at
///   zero and reading every bit as the same symbol.
/// * **Timing.** A phase accumulator at the nominal bit rate, nudged toward
///   each observed zero crossing. Without it a 0.1% clock error walks a
///   whole bit out of place in a thousand bits, which is well inside one
///   batch.
/// * **Integration.** Each bit is the mean of its whole span rather than
///   one sample at the centre, which is a matched filter for a rectangular
///   symbol and the cheapest real noise rejection available.
pub struct Nrz {
    samples_per_bit: f32,
    phase: f32,
    dc: f32,
    dc_alpha: f32,
    prev: f32,
    acc: f32,
    acc_n: u32,
    primed: bool,
}

/// How hard a zero crossing pulls the bit clock. Small: the nominal rate is
/// known exactly and only the phase is in doubt, so this has to track drift
/// without being dragged around by noise.
const TIMING_GAIN: f32 = 0.08;

impl Nrz {
    pub fn new(sample_rate: f32, baud: f32) -> Self {
        let spb = (sample_rate / baud).max(2.0);
        Nrz {
            samples_per_bit: spb,
            phase: 0.0,
            dc: 0.0,
            // Averaged over roughly thirty bits: long enough not to follow
            // the data, short enough to track a drifting tuner.
            dc_alpha: 1.0 / (spb * 30.0),
            prev: 0.0,
            acc: 0.0,
            acc_n: 0,
            primed: false,
        }
    }

    /// Feed demodulated audio. Recovered bits go to `sink`.
    pub fn process(&mut self, audio: &[f32], sink: &mut impl FnMut(u8)) {
        for &x in audio {
            if !self.primed {
                self.dc = x;
                self.primed = true;
            }
            self.dc += (x - self.dc) * self.dc_alpha;
            let v = x - self.dc;

            // Pull the bit clock toward the crossing. The ideal crossing
            // sits on a bit boundary, which is phase 0 — so a crossing
            // early in a bit means the clock is late and vice versa.
            if (v < 0.0) != (self.prev < 0.0) {
                let err = if self.phase < 0.5 {
                    self.phase
                } else {
                    self.phase - 1.0
                };
                self.phase -= err * TIMING_GAIN;
            }
            self.prev = v;

            self.acc += v;
            self.acc_n += 1;
            self.phase += 1.0 / self.samples_per_bit;
            if self.phase >= 1.0 {
                self.phase -= 1.0;
                if self.acc_n > 0 {
                    // POCSAG sends the *higher* frequency for a binary 0,
                    // and a discriminator turns higher frequency into a
                    // more positive output — so a positive mean is a zero.
                    // The worker runs a second decoder on the inverse
                    // anyway, because any stage of the chain can flip this
                    // and the BCH check is what decides which one is right.
                    sink(if self.acc >= 0.0 { 0 } else { 1 });
                }
                self.acc = 0.0;
                self.acc_n = 0;
            }
        }
    }
}

/// One channel's worth of decoding: every bit rate and both polarities at
/// once.
///
/// There is no way to know a transmission's bit rate before decoding it,
/// and polarity depends on the whole receive chain rather than on the
/// standard. Both are cheap to brute-force — six bit-slicers over the same
/// audio is a rounding error next to the FFT — and the BCH check means a
/// wrong combination produces nothing rather than producing rubbish. So
/// rather than make the person pick, run them all and report whichever one
/// yields valid codewords.
pub struct PagerChannel {
    lanes: Vec<Lane>,
}

struct Lane {
    baud: f32,
    inverted: bool,
    nrz: Nrz,
    demod: PocsagDemod,
}

/// A decoded page, with the settings that read it.
#[derive(Clone, Debug)]
pub struct Page {
    pub message: Message,
    pub baud: f32,
    pub inverted: bool,
}

impl PagerChannel {
    pub fn new(sample_rate: f32) -> Self {
        let mut lanes = Vec::new();
        for &baud in BAUDS.iter() {
            for &inverted in [false, true].iter() {
                lanes.push(Lane {
                    baud,
                    inverted,
                    nrz: Nrz::new(sample_rate, baud),
                    demod: PocsagDemod::new(),
                });
            }
        }
        PagerChannel { lanes }
    }

    /// Feed demodulated audio; completed pages go to `sink`.
    pub fn process(&mut self, audio: &[f32], sink: &mut impl FnMut(Page)) {
        for lane in self.lanes.iter_mut() {
            let baud = lane.baud;
            let inverted = lane.inverted;
            let demod = &mut lane.demod;
            lane.nrz.process(audio, &mut |b| {
                let b = if inverted { b ^ 1 } else { b };
                demod.bit(b, &mut |message| {
                    sink(Page {
                        message,
                        baud,
                        inverted,
                    })
                });
            });
        }
    }

    /// Valid sync words seen on each lane. The lane with a nonzero count is
    /// the bit rate and polarity actually in use, which is worth showing:
    /// it turns "nothing decoded" into either "nothing is transmitting" or
    /// "something is, at this rate, and the codewords are not surviving".
    pub fn lane_syncs(&self) -> Vec<(f32, bool, u64)> {
        self.lanes
            .iter()
            .map(|l| (l.baud, l.inverted, l.demod.syncs))
            .collect()
    }

    pub fn totals(&self) -> (u64, u64, u64, u64) {
        let mut syncs = 0;
        let mut ok = 0;
        let mut repaired = 0;
        let mut dropped = 0;
        for l in self.lanes.iter() {
            syncs += l.demod.syncs;
            ok += l.demod.codewords_ok;
            repaired += l.demod.codewords_repaired;
            dropped += l.demod.codewords_dropped;
        }
        (syncs, ok, repaired, dropped)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // ---- an encoder, so the tests can make real batches ----------------
    //
    // Written here rather than in the library because nothing in the
    // program transmits. It exists to prove the decoder against data built
    // from the specification rather than from the decoder's own
    // assumptions.

    fn address_word(ric: u32, func: u8) -> u32 {
        let addr18 = (ric >> 3) & 0x3_FFFF;
        encode((addr18 << 2) | (func as u32 & 0x3))
    }

    /// Pack a string into 7-bit characters, LSB of each character first.
    fn text_bits(s: &str) -> Vec<u8> {
        let mut bits = Vec::new();
        for c in s.bytes() {
            for i in 0..7 {
                bits.push((c >> i) & 1);
            }
        }
        bits
    }

    /// Pack BCD digits, then pad to a whole codeword with 0xC as the
    /// standard requires.
    ///
    /// The padding matters, and not only for the test: a numeric message
    /// carries no length, so the decoder cannot tell a padding digit from a
    /// real one. CCIR 584 resolves that by padding with 0xC, which renders
    /// as a space and is trimmed. A transmitter that pads with zeros
    /// instead produces trailing zeros that are indistinguishable from
    /// data, and no decoder can do better than show them.
    fn numeric_bits(digits: &str) -> Vec<u8> {
        let mut bits = Vec::new();
        let mut padded = digits.to_string();
        while padded.len() % 5 != 0 {
            padded.push(' '); // 0xC
        }
        let digits = padded.as_str();
        for c in digits.bytes() {
            let v: u8 = match c {
                b'0'..=b'9' => c - b'0',
                b'*' => 0xA,
                b'U' => 0xB,
                b' ' => 0xC,
                b'-' => 0xD,
                b']' => 0xE,
                b'[' => 0xF,
                _ => 0xC,
            };
            for i in 0..4 {
                bits.push((v >> i) & 1);
            }
        }
        bits
    }

    /// Message codewords carrying `bits`, 20 bits each, MSB first.
    fn message_words(bits: &[u8]) -> Vec<u32> {
        let mut out = Vec::new();
        for chunk in bits.chunks(20) {
            let mut payload = 0u32;
            for i in 0..20 {
                let b = chunk.get(i).copied().unwrap_or(0);
                payload = (payload << 1) | b as u32;
            }
            // Flag bit 1 marks a message codeword; it is the top bit of the
            // 21 information bits.
            out.push(encode((1 << 20) | payload));
        }
        out
    }

    /// A transmission: preamble, then batches, with `ric`'s address placed
    /// in the frame its low three bits demand.
    fn transmission(pages: &[(u32, u8, Vec<u8>)]) -> Vec<u8> {
        let mut bits = Vec::new();
        // Preamble: 576 bits of alternating 1 and 0.
        for i in 0..576 {
            bits.push((i % 2) as u8);
        }
        // Lay every page into slots, honouring each address's frame.
        let mut slots: Vec<Option<u32>> = Vec::new();
        for (ric, func, payload) in pages {
            let frame = (ric & 0x7) as usize;
            let want = frame * 2;
            // Grow to the start of a batch that has room at `want`.
            while slots.len() % 16 != 0 || slots.len() < want + 1 {
                slots.push(None);
                if slots.len() % 16 == 0 && slots.len() >= want + 1 {
                    break;
                }
            }
            let base = (slots.len() / 16) * 16;
            while slots.len() < base + want {
                slots.push(None);
            }
            slots.push(Some(address_word(*ric, *func)));
            for w in message_words(payload) {
                slots.push(Some(w));
            }
        }
        while slots.len() % 16 != 0 {
            slots.push(None);
        }
        for batch in slots.chunks(16) {
            push_word(&mut bits, SYNC);
            for slot in batch {
                push_word(&mut bits, slot.unwrap_or(IDLE));
            }
        }
        // One more sync-less batch boundary so the decoder knows the
        // transmission ended and flushes.
        push_word(&mut bits, 0);
        bits
    }

    fn push_word(bits: &mut Vec<u8>, w: u32) {
        for i in (0..32).rev() {
            bits.push(((w >> i) & 1) as u8);
        }
    }

    fn decode_all(bits: &[u8]) -> Vec<Message> {
        let mut d = PocsagDemod::new();
        let mut out = Vec::new();
        d.bits(bits, &mut |m| out.push(m));
        d.finish(&mut |m| out.push(m));
        out
    }

    // ---- the code itself ----------------------------------------------

    /// The two reserved codewords must themselves be valid under the code.
    /// If they are not, the generator polynomial is wrong, and every other
    /// test in this file would be checking the decoder against a matching
    /// mistake in the encoder.
    #[test]
    fn the_reserved_codewords_pass_their_own_checks() {
        assert_eq!(syndrome(SYNC), 0, "sync word fails BCH — wrong generator");
        assert!(parity_ok(SYNC), "sync word fails parity");
        assert_eq!(syndrome(IDLE), 0, "idle word fails BCH");
        assert!(parity_ok(IDLE), "idle word fails parity");
    }

    #[test]
    fn encode_round_trips_through_the_checks() {
        for info in [0u32, 1, 0x1F_FFFF, 0x12345, 0xABCDE, 0x155555] {
            let cw = encode(info);
            assert!(codeword_ok(cw), "info {info:#x} -> {cw:#010x} failed");
            assert_eq!(cw >> 11, info & 0x1F_FFFF, "information bits moved");
        }
    }

    /// The whole value of this decoder rests on the code catching errors,
    /// so check that it does — at every single-bit position.
    #[test]
    fn every_single_bit_error_is_detected() {
        let cw = encode(0x12345);
        for i in 0..32 {
            let bad = cw ^ (1 << i);
            assert!(!codeword_ok(bad), "bit {i} flipped and still passed");
        }
    }

    #[test]
    fn every_double_bit_error_is_detected() {
        let cw = encode(0x0ABCD);
        for i in 0..32 {
            for j in (i + 1)..32 {
                let bad = cw ^ (1 << i) ^ (1 << j);
                assert!(!codeword_ok(bad), "bits {i},{j} flipped and still passed");
            }
        }
    }

    #[test]
    fn single_and_double_errors_are_repaired_to_the_original() {
        let cw = encode(0x1BEEF);
        for i in 0..32 {
            let (fixed, rep) = repair(cw ^ (1 << i)).expect("one bit should repair");
            assert_eq!(fixed, cw, "bit {i} repaired to the wrong word");
            assert_eq!(rep, Repair::OneBit);
        }
        let mut two = 0;
        for i in 0..32 {
            for j in (i + 1)..32 {
                let (fixed, rep) = repair(cw ^ (1 << i) ^ (1 << j))
                    .unwrap_or_else(|| panic!("bits {i},{j} should repair"));
                assert_eq!(fixed, cw, "bits {i},{j} repaired to the wrong word");
                assert_eq!(rep, Repair::TwoBits);
                two += 1;
            }
        }
        assert_eq!(two, 496);
    }

    /// Three errors is beyond what the code can correct, so the decoder
    /// must refuse rather than hand back the nearest word — which would be
    /// a message nobody sent.
    #[test]
    fn three_bit_errors_are_refused_or_never_wrong() {
        let cw = encode(0x15AA5);
        let mut refused = 0;
        let mut wrong = 0;
        for i in 0..30 {
            for j in (i + 1)..31 {
                for k in (j + 1)..32 {
                    let bad = cw ^ (1 << i) ^ (1 << j) ^ (1 << k);
                    match repair(bad) {
                        None => refused += 1,
                        // A triple error can land exactly two bits from a
                        // *different* valid codeword, and the code cannot
                        // tell. What must never happen is silently
                        // reporting it as clean.
                        Some((fixed, rep)) => {
                            assert_ne!(rep, Repair::Clean, "a 3-bit error passed as clean");
                            if fixed != cw {
                                wrong += 1;
                            }
                        }
                    }
                }
            }
        }
        assert!(refused > 0, "nothing was refused — correction is too eager");
        // Stated rather than asserted away: this is the residual risk of
        // two-bit correction, and the Message carries repaired_two so the
        // UI can show it.
        assert!(
            wrong < 4500,
            "{wrong} of 4495 triple errors mis-corrected — unexpectedly high"
        );
    }

    // ---- framing -------------------------------------------------------

    #[test]
    fn a_text_page_round_trips() {
        let ric = 1_234_568; // low 3 bits = 0
        let bits = transmission(&[(ric, 3, text_bits("ENGINE 4 RESPOND STATION 12"))]);
        let msgs = decode_all(&bits);
        assert_eq!(msgs.len(), 1, "{msgs:?}");
        let m = &msgs[0];
        assert_eq!(m.ric, ric);
        assert_eq!(m.func, 3);
        assert_eq!(m.text.as_deref(), Some("ENGINE 4 RESPOND STATION 12"));
        assert!(!m.marginal());
        assert_eq!(m.dropped, 0);
    }

    /// The three low bits of the address are never transmitted — they are
    /// which frame the address landed in. Get this wrong and every RIC is
    /// off by up to seven, which is the difference between one pager and
    /// another.
    #[test]
    fn the_frame_supplies_the_low_three_address_bits() {
        for low in 0..8u32 {
            let ric = (1_400_000 & !0x7) | low;
            assert!(ric <= MAX_RIC);
            let bits = transmission(&[(ric, 0, text_bits("TEST"))]);
            let msgs = decode_all(&bits);
            assert_eq!(msgs.len(), 1, "low bits {low}: {msgs:?}");
            assert_eq!(
                msgs[0].ric, ric,
                "low bits {low}: frame index not folded into the address"
            );
        }
    }

    /// Text runs continuously across the 20-bit codeword boundary, so a
    /// character is routinely split between two codewords. A decoder that
    /// restarts character packing at each codeword produces plausible
    /// garbage, which is the worst failure mode available.
    #[test]
    fn text_spanning_codeword_boundaries_is_reassembled() {
        // 20 bits is not a whole number of 7-bit characters, so any message
        // longer than two characters crosses a boundary.
        for len in [3usize, 6, 20, 41, 100] {
            let want: String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "
                .chars()
                .cycle()
                .take(len)
                .collect();
            let bits = transmission(&[(800_000, 3, text_bits(&want))]);
            let msgs = decode_all(&bits);
            assert_eq!(msgs.len(), 1, "len {len}: {msgs:?}");
            assert_eq!(
                msgs[0].text.as_deref().map(str::trim_end),
                Some(want.trim_end()),
                "len {len}"
            );
        }
    }

    /// A message long enough to need more codewords than one batch holds
    /// must survive the sync word in the middle of it.
    #[test]
    fn a_message_survives_a_batch_boundary() {
        let want: String = "LONG MESSAGE ".chars().cycle().take(300).collect();
        let bits = transmission(&[(800_000, 3, text_bits(&want))]);
        let msgs = decode_all(&bits);
        assert_eq!(msgs.len(), 1, "{:?}", msgs.len());
        assert_eq!(
            msgs[0].text.as_deref().map(str::trim_end),
            Some(want.trim_end())
        );
        // More than 16 codewords, so it really did cross a batch.
        assert!(msgs[0].codewords > 16, "only {} codewords", msgs[0].codewords);
    }

    #[test]
    fn an_address_with_no_payload_is_a_tone_only_page() {
        let bits = transmission(&[(555_552, 1, Vec::new())]);
        let msgs = decode_all(&bits);
        assert_eq!(msgs.len(), 1, "{msgs:?}");
        assert!(msgs[0].tone_only());
        assert_eq!(msgs[0].text, None);
        assert_eq!(msgs[0].numeric, "");
        assert_eq!(msgs[0].ric, 555_552);
    }

    #[test]
    fn several_pages_in_one_transmission_all_come_out() {
        let pages = vec![
            (1_000_000 & !0x7, 3, text_bits("FIRST")),
            ((1_000_008 & !0x7) | 2, 3, text_bits("SECOND")),
            ((1_000_016 & !0x7) | 5, 3, text_bits("THIRD")),
        ];
        let bits = transmission(&pages);
        let msgs = decode_all(&bits);
        assert_eq!(msgs.len(), 3, "{msgs:?}");
        let texts: Vec<&str> = msgs.iter().map(|m| m.best()).collect();
        assert!(texts.contains(&"FIRST"), "{texts:?}");
        assert!(texts.contains(&"SECOND"), "{texts:?}");
        assert!(texts.contains(&"THIRD"), "{texts:?}");
    }

    #[test]
    fn a_numeric_page_reads_as_digits_not_as_text() {
        let bits = transmission(&[(600_000, 0, numeric_bits("416-555-0199"))]);
        let msgs = decode_all(&bits);
        assert_eq!(msgs.len(), 1, "{msgs:?}");
        let m = &msgs[0];
        assert_eq!(m.numeric, "416-555-0199");
        // Read as 7-bit text the same bits are a scatter of punctuation, so
        // the text path must decline rather than offering mojibake.
        assert_eq!(m.text, None, "numeric payload was passed off as text: {:?}", m.text);
        assert_eq!(m.reading, Reading::Numeric);
        assert_eq!(m.best(), "416-555-0199");
    }

    /// Noise must not produce messages. This is the single most important
    /// property: a pager screen that invents pages is worse than a blank
    /// one.
    #[test]
    fn pseudorandom_noise_produces_nothing() {
        let mut state = 0x1234_5678u32;
        let mut bits = Vec::with_capacity(400_000);
        for _ in 0..400_000 {
            // xorshift32
            state ^= state << 13;
            state ^= state >> 17;
            state ^= state << 5;
            bits.push((state & 1) as u8);
        }
        let msgs = decode_all(&bits);
        let real: Vec<&Message> = msgs
            .iter()
            .filter(|m| m.text.is_some() && m.text.as_deref().map_or(0, |t| t.len()) >= 4)
            .collect();
        assert!(
            real.is_empty(),
            "{} text pages fabricated from noise: {:?}",
            real.len(),
            real.iter().map(|m| m.best()).collect::<Vec<_>>()
        );
    }

    /// Bit errors sprinkled through a real transmission must either be
    /// repaired or reported, never silently turned into different text.
    #[test]
    fn a_damaged_transmission_is_flagged_not_falsified() {
        let want = "PLANT 3 ALARM HIGH LEVEL TANK 7";
        let clean = transmission(&[(900_000, 3, text_bits(want))]);
        // One bit error per codeword, which the code can always repair.
        let mut damaged = clean.clone();
        let start = 576; // past the preamble
        let mut i = start + 32 + 5; // inside the first payload codeword
        while i < damaged.len() {
            damaged[i] ^= 1;
            i += 32;
        }
        let msgs = decode_all(&damaged);
        assert_eq!(msgs.len(), 1, "{msgs:?}");
        let m = &msgs[0];
        assert_eq!(m.text.as_deref(), Some(want), "repair changed the text");
        assert!(m.repaired_one > 0, "repairs happened but were not counted");
        assert_eq!(m.repaired_two, 0);
    }

    #[test]
    fn sync_is_found_through_two_bit_errors() {
        let want = "SLACK TEST";
        let mut bits = transmission(&[(700_000, 3, text_bits(want))]);
        // Corrupt two bits of the first sync word.
        bits[576 + 3] ^= 1;
        bits[576 + 17] ^= 1;
        let msgs = decode_all(&bits);
        assert_eq!(msgs.len(), 1, "{msgs:?}");
        assert_eq!(msgs[0].text.as_deref(), Some(want));
        assert_eq!(sync_distance(SYNC ^ 0b101), 2);
        assert!(sync_distance(!SYNC) > SYNC_SLACK);
    }

    // ---- bit recovery --------------------------------------------------

    /// Modulate bits as a bipolar NRZ waveform, with a DC offset and a
    /// clock error, and check they come back. The DC offset is the
    /// realistic part: a tuner a few kHz off frequency produces one larger
    /// than the deviation being measured.
    fn modulate(bits: &[u8], rate: f32, baud: f32, dc: f32, clock_err: f32, amp: f32) -> Vec<f32> {
        let spb = rate / (baud * (1.0 + clock_err));
        let n = (bits.len() as f32 * spb).ceil() as usize;
        let mut out = Vec::with_capacity(n);
        for i in 0..n {
            let b = bits[((i as f32 / spb) as usize).min(bits.len() - 1)];
            // Binary 1 is the lower frequency, so a negative excursion.
            let v = if b == 0 { amp } else { -amp };
            out.push(v + dc);
        }
        out
    }

    #[test]
    fn the_slicer_recovers_bits_at_every_standard_rate() {
        let pattern: Vec<u8> = (0..2000).map(|i| ((i * 7 + i / 3) % 2) as u8).collect();
        for &baud in BAUDS.iter() {
            let rate = 22_050.0;
            let audio = modulate(&pattern, rate, baud, 0.0, 0.0, 0.5);
            let mut nrz = Nrz::new(rate, baud);
            let mut got = Vec::new();
            nrz.process(&audio, &mut |b| got.push(b));
            // Allow for the first bit or two while the DC estimate settles.
            let skip = 4;
            assert!(
                got.len() + 8 >= pattern.len(),
                "baud {baud}: got {} bits for {}",
                got.len(),
                pattern.len()
            );
            let n = got.len().min(pattern.len()) - skip;
            let errs = (skip..n).filter(|&i| got[i] != pattern[i]).count();
            assert!(
                errs * 1000 < n,
                "baud {baud}: {errs} bit errors in {n} — slicer is not locking"
            );
        }
    }

    /// The DC block is what makes this work on a real receiver, so test it
    /// with an offset bigger than the signal.
    #[test]
    fn the_slicer_survives_a_dc_offset_larger_than_the_signal() {
        let pattern: Vec<u8> = (0..3000).map(|i| ((i / 5 + i * 3) % 2) as u8).collect();
        let rate = 22_050.0;
        let baud = 1200.0;
        for &dc in [-2.0f32, -0.4, 0.4, 2.0].iter() {
            let audio = modulate(&pattern, rate, baud, dc, 0.0, 0.3);
            let mut nrz = Nrz::new(rate, baud);
            let mut got = Vec::new();
            nrz.process(&audio, &mut |b| got.push(b));
            let n = got.len().min(pattern.len());
            let errs = (200..n).filter(|&i| got[i] != pattern[i]).count();
            assert!(
                errs * 200 < n,
                "dc {dc}: {errs} errors in {n} bits — DC block is not working"
            );
        }
    }

    /// A clock half a percent off is ordinary, and without timing recovery
    /// it walks a whole bit out of position inside two hundred bits.
    #[test]
    fn the_slicer_tracks_a_clock_error() {
        let pattern: Vec<u8> = (0..4000).map(|i| ((i * 11 + i / 7) % 2) as u8).collect();
        let rate = 22_050.0;
        let baud = 1200.0;
        for &err in [-0.005f32, -0.002, 0.002, 0.005].iter() {
            let audio = modulate(&pattern, rate, baud, 0.1, err, 0.4);
            let mut nrz = Nrz::new(rate, baud);
            let mut got = Vec::new();
            nrz.process(&audio, &mut |b| got.push(b));
            let n = got.len().min(pattern.len());
            assert!(n > 3000, "clock {err}: only {n} bits recovered");
            let errs = (200..n).filter(|&i| got[i] != pattern[i]).count();
            assert!(
                errs * 100 < n,
                "clock {err}: {errs} errors in {n} bits — timing is not tracking"
            );
        }
    }

    /// The end-to-end test: a real transmission, modulated as audio, read
    /// back through the slicer and the decoder, with the bit rate and
    /// polarity unknown to the receiver.
    #[test]
    fn a_page_survives_the_whole_chain_at_an_unknown_rate_and_polarity() {
        let want = "UNIT 7 PROCEED TO 400 UNIVERSITY AVE";
        let bits = transmission(&[(1_500_000 & !0x7, 3, text_bits(want))]);
        let rate = 22_050.0;
        for &baud in BAUDS.iter() {
            for &flip in [false, true].iter() {
                let tx: Vec<u8> = if flip {
                    bits.iter().map(|b| b ^ 1).collect()
                } else {
                    bits.clone()
                };
                let audio = modulate(&tx, rate, baud, 0.25, 0.001, 0.4);
                let mut ch = PagerChannel::new(rate);
                let mut got: Vec<Page> = Vec::new();
                ch.process(&audio, &mut |p| got.push(p));
                let hit = got.iter().find(|p| p.message.text.as_deref() == Some(want));
                let hit = hit.unwrap_or_else(|| {
                    panic!(
                        "baud {baud} flip {flip}: not decoded. got {:?}",
                        got.iter().map(|p| (p.baud, p.inverted, p.message.best()))
                            .collect::<Vec<_>>()
                    )
                });
                assert_eq!(hit.baud, baud, "reported the wrong bit rate");
                assert_eq!(hit.inverted, flip, "reported the wrong polarity");
            }
        }
    }

    /// Silence must not produce pages, and must not report a lane as
    /// synchronised either.
    #[test]
    fn silence_produces_nothing() {
        let rate = 22_050.0;
        let audio = vec![0.0f32; 22_050 * 2];
        let mut ch = PagerChannel::new(rate);
        let mut got = 0;
        ch.process(&audio, &mut |_| got += 1);
        assert_eq!(got, 0);
        let (syncs, ok, _, _) = ch.totals();
        assert_eq!(syncs, 0);
        assert_eq!(ok, 0);
    }

    // ---- the channel plan ----------------------------------------------

    /// The property that actually matters about the text/numeric decision:
    /// how often a numeric page gets passed off as text.
    ///
    /// Every payload can be read as ASCII, so this is a judgement and it
    /// will never be perfect. What it must be is rarely wrong — a pager log
    /// full of punctuation soup presented as messages is worse than one
    /// that shows the digits.
    #[test]
    fn numeric_pages_are_seldom_mistaken_for_text() {
        let mut state = 0x9E37_79B9u32;
        let mut next = move || {
            state ^= state << 13;
            state ^= state >> 17;
            state ^= state << 5;
            state
        };
        let mut as_text = 0;
        let trials = 300;
        for _ in 0..trials {
            // Phone-number-shaped payloads, which is most of what numeric
            // paging actually carries.
            let digits: String = (0..10)
                .map(|_| char::from(b'0' + (next() % 10) as u8))
                .collect();
            let bits = transmission(&[(1_000_000, 0, numeric_bits(&digits))]);
            let msgs = decode_all(&bits);
            assert_eq!(msgs.len(), 1);
            let m = &msgs[0];
            assert_eq!(m.numeric, digits, "numeric reading is wrong, never mind text");
            if m.reading == Reading::Text {
                as_text += 1;
            }
        }
        assert_eq!(
            as_text, 0,
            "{as_text} of {trials} numeric pages were presented as text"
        );
    }

    /// And the converse: real text must not be downgraded to digits.
    #[test]
    fn real_text_pages_are_recognised_as_text() {
        let pages = [
            "ENGINE 4 RESPOND STATION 12",
            "CALL DR. SMITH EXT. 4412 - URGENT",
            "PLANT 3 ALARM: HIGH LEVEL TANK 7",
            "MEDICAL 221 QUEEN ST W APT 4B",
            "SYSTEM TEST - NO ACTION REQUIRED",
            "OK",
            "ALARM",
            "LIFT 2 STUCK FLOOR 14 2 PERSONS INSIDE",
        ];
        for want in pages {
            let bits = transmission(&[(1_000_000, 3, text_bits(want))]);
            let msgs = decode_all(&bits);
            assert_eq!(msgs.len(), 1, "{want:?}");
            let m = &msgs[0];
            assert_eq!(m.text.as_deref(), Some(want), "text did not round-trip");
            assert_ne!(
                m.reading,
                Reading::Numeric,
                "{want:?} was downgraded to digits"
            );
            assert_eq!(m.best(), want);
        }
    }

    /// A decoded address can never be outside the 21 bits the format has,
    /// whatever arrives. The 18-bit field plus a 3-bit frame index is
    /// exactly 21, so this is arithmetic rather than a check — but it is
    /// the arithmetic that a shift in the wrong place would break, and a
    /// RIC with a stray high bit would send someone looking for a pager
    /// that cannot exist.
    #[test]
    fn a_decoded_address_is_always_inside_21_bits() {
        for ric in [0u32, 7, 8, 1_000_000, MAX_RIC - 7, MAX_RIC] {
            let bits = transmission(&[(ric, 0, text_bits("X"))]);
            let msgs = decode_all(&bits);
            assert_eq!(msgs.len(), 1, "ric {ric}: {msgs:?}");
            assert_eq!(msgs[0].ric, ric, "ric {ric} did not round-trip");
            assert!(msgs[0].ric <= MAX_RIC);
        }
    }

    /// These are regulatory figures from ISED SRSP-504, not guesses, and
    /// the arithmetic that expands them has to land on the published
    /// endpoints exactly.
    #[test]
    fn the_canadian_channel_plan_is_forty_channels() {
        let ch = ca_channels();
        assert_eq!(ch.len(), 40, "SRSP-504 gives forty 25 kHz channels");
        assert!((ch[0] - 931_012_500.0).abs() < 1.0);
        assert!((ch[39] - 931_987_500.0).abs() < 1.0);
        for w in ch.windows(2) {
            assert!((w[1] - w[0] - 25_000.0).abs() < 1.0);
        }
        // The nationwide channels must actually be in the plan.
        for n in NATIONWIDE_HZ.iter() {
            assert!(
                ch.iter().any(|c| (c - n).abs() < 1.0),
                "{n} is not on the 25 kHz grid"
            );
        }
    }
}
