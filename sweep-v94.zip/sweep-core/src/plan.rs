//! Scan plans: what the natural-language layer emits, and what the engine
//! refuses to run.
//!
//! The rule that matters is [`ScanPlan::validate`] check 6: every frequency
//! must be traceable to a database record or to the user typing it. A model
//! that produced a frequency from memory does not get to drive the tuner.

use serde::{Deserialize, Serialize};

/// Tuner limits for an R820T2-based dongle.
pub const TUNER_MIN_MHZ: f64 = 24.0;
pub const TUNER_MAX_MHZ: f64 = 1766.0;
/// Reachable only with the direct-sampling mod (RTL-SDR Blog v3/v4 Q branch).
pub const HF_MIN_MHZ: f64 = 0.5;
pub const HF_MAX_MHZ: f64 = 24.0;

pub const SAMPLE_RATE: u32 = 2_400_000;
/// Fraction of each capture that survives filter rolloff at the band edges.
pub const USABLE_FRACTION: f64 = 0.75;
/// Usable width of a single tuner window, in MHz. 1.8 at 2.4 MS/s.
pub const WINDOW_MHZ: f64 = SAMPLE_RATE as f64 * USABLE_FRACTION / 1e6;
/// Keep channels this far from the DC spike at the centre of each capture.
pub const DC_GUARD_MHZ: f64 = 0.030;

pub const STEPS_KHZ: [f64; 6] = [5.0, 6.25, 12.5, 25.0, 100.0, 200.0];

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Demod {
    #[serde(rename = "NFM")]
    Nfm,
    #[serde(rename = "WFM")]
    Wfm,
    #[serde(rename = "AM")]
    Am,
    #[serde(rename = "USB")]
    Usb,
    #[serde(rename = "LSB")]
    Lsb,
    #[serde(rename = "CW")]
    Cw,
}

impl Demod {
    /// Default channel bandwidth in kHz for this mode.
    pub fn default_bw_khz(self) -> f64 {
        match self {
            Demod::Nfm => 12.5,
            Demod::Wfm => 200.0,
            Demod::Am => 8.33,
            Demod::Usb | Demod::Lsb => 2.8,
            Demod::Cw => 0.5,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Window {
    pub f0: f64,
    pub f1: f64,
}

impl Window {
    pub fn width(&self) -> f64 {
        self.f1 - self.f0
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Channel {
    pub freq_mhz: f64,
    pub label: String,
    #[serde(default)]
    pub demod: Option<Demod>,
    #[serde(default)]
    pub ctcss_hz: Option<f32>,
    #[serde(default)]
    pub priority: bool,
}

impl Channel {
    pub fn new(freq_mhz: f64, label: &str) -> Self {
        Channel {
            freq_mhz,
            label: label.to_string(),
            demod: None,
            ctcss_hz: None,
            priority: false,
        }
    }
}

/// Where the frequencies in a plan came from. Anything else is rejected.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Provenance {
    /// One or more database record ids.
    Database,
    /// The user typed a frequency.
    User,
    /// The built-in rule parser, which only emits band-plan constants.
    Rules,
    /// Unattributed — the model made it up. Never runnable.
    Unverified,
}

impl Provenance {
    pub fn parse(source: &str) -> Provenance {
        if source.starts_with("db:") {
            Provenance::Database
        } else if source == "user" {
            Provenance::User
        } else if source == "rules" {
            Provenance::Rules
        } else {
            Provenance::Unverified
        }
    }
    pub fn is_trusted(&self) -> bool {
        !matches!(self, Provenance::Unverified)
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScanPlan {
    pub name: String,
    #[serde(default)]
    pub windows: Vec<Window>,
    #[serde(default)]
    pub channels: Vec<Channel>,
    pub demod: Demod,
    pub step_khz: f64,
    pub squelch_db: f64,
    pub hang_ms: u32,
    #[serde(default = "default_dwell")]
    pub dwell_ms: u32,
    #[serde(default)]
    pub priority: Vec<f64>,
    #[serde(default)]
    pub lockout: Vec<f64>,
    #[serde(default)]
    pub ctcss_hz: Option<f32>,
    /// `db:<ids>`, `user`, or `rules`. Anything else fails validation.
    pub source: String,
}

fn default_dwell() -> u32 {
    40
}

#[derive(Debug, Clone, PartialEq)]
pub enum PlanError {
    Empty,
    OutOfRange { freq_mhz: f64 },
    BadWindow { f0: f64, f1: f64 },
    BadStep(f64),
    BadSquelch(f64),
    BadHang(u32),
    Unverified { source: String },
}

impl std::fmt::Display for PlanError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PlanError::Empty => write!(f, "plan has no windows and no channels"),
            PlanError::OutOfRange { freq_mhz } => write!(
                f,
                "{freq_mhz} MHz is outside {TUNER_MIN_MHZ}-{TUNER_MAX_MHZ} MHz \
                 (and outside {HF_MIN_MHZ}-{HF_MAX_MHZ} MHz direct sampling)"
            ),
            PlanError::BadWindow { f0, f1 } => write!(f, "window {f0}-{f1} MHz is not ascending"),
            PlanError::BadStep(s) => write!(f, "{s} kHz is not a supported channel step"),
            PlanError::BadSquelch(s) => write!(f, "squelch {s} dB outside 3-30 dB"),
            PlanError::BadHang(h) => write!(f, "hang {h} ms outside 0-10000 ms"),
            PlanError::Unverified { source } => write!(
                f,
                "source {source:?} is not a database record, \"user\", or \"rules\" — \
                 refusing to tune to frequencies of unknown origin"
            ),
        }
    }
}

impl std::error::Error for PlanError {}

/// True if the frequency is reachable, given whether direct sampling is on.
pub fn in_range(freq_mhz: f64, direct_sampling: bool) -> bool {
    (freq_mhz >= TUNER_MIN_MHZ && freq_mhz <= TUNER_MAX_MHZ)
        || (direct_sampling && freq_mhz >= HF_MIN_MHZ && freq_mhz < HF_MAX_MHZ)
}

impl ScanPlan {
    pub fn validate(&self, direct_sampling: bool) -> Result<(), PlanError> {
        // 6. Provenance first — a plan of unknown origin is not worth checking.
        let prov = Provenance::parse(&self.source);
        if !prov.is_trusted() {
            return Err(PlanError::Unverified {
                source: self.source.clone(),
            });
        }
        // 2. Something to scan.
        if self.windows.is_empty() && self.channels.is_empty() {
            return Err(PlanError::Empty);
        }
        // 3. Ascending windows, 1. in range.
        for w in &self.windows {
            if w.f1 <= w.f0 {
                return Err(PlanError::BadWindow { f0: w.f0, f1: w.f1 });
            }
            for f in [w.f0, w.f1] {
                if !in_range(f, direct_sampling) {
                    return Err(PlanError::OutOfRange { freq_mhz: f });
                }
            }
        }
        for c in &self.channels {
            if !in_range(c.freq_mhz, direct_sampling) {
                return Err(PlanError::OutOfRange {
                    freq_mhz: c.freq_mhz,
                });
            }
        }
        for f in self.priority.iter().chain(self.lockout.iter()) {
            if !in_range(*f, direct_sampling) {
                return Err(PlanError::OutOfRange { freq_mhz: *f });
            }
        }
        // 4, 5.
        if !STEPS_KHZ.iter().any(|s| (s - self.step_khz).abs() < 1e-9) {
            return Err(PlanError::BadStep(self.step_khz));
        }
        if !(3.0..=30.0).contains(&self.squelch_db) {
            return Err(PlanError::BadSquelch(self.squelch_db));
        }
        if self.hang_ms > 10_000 {
            return Err(PlanError::BadHang(self.hang_ms));
        }
        Ok(())
    }

    /// Total frequency extent the plan touches, in MHz.
    pub fn extent(&self) -> Option<(f64, f64)> {
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for w in &self.windows {
            lo = lo.min(w.f0);
            hi = hi.max(w.f1);
        }
        for c in &self.channels {
            lo = lo.min(c.freq_mhz);
            hi = hi.max(c.freq_mhz);
        }
        if lo.is_finite() {
            Some((lo, hi))
        } else {
            None
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn base() -> ScanPlan {
        ScanPlan {
            name: "test".into(),
            windows: vec![],
            channels: vec![Channel::new(146.94, "VE3TWR")],
            demod: Demod::Nfm,
            step_khz: 12.5,
            squelch_db: 8.0,
            hang_ms: 2000,
            dwell_ms: 40,
            priority: vec![],
            lockout: vec![],
            ctcss_hz: None,
            source: "user".into(),
        }
    }

    #[test]
    fn window_width_is_1_8_mhz() {
        assert!((WINDOW_MHZ - 1.8).abs() < 1e-9);
    }

    #[test]
    fn accepts_a_typed_frequency() {
        assert!(base().validate(false).is_ok());
    }

    #[test]
    fn rejects_unattributed_source() {
        let mut p = base();
        p.source = "i think it is around here".into();
        assert_eq!(
            p.validate(false),
            Err(PlanError::Unverified {
                source: "i think it is around here".into()
            })
        );
    }

    #[test]
    fn rejects_hallucinated_out_of_range_frequency() {
        let mut p = base();
        p.channels = vec![Channel::new(2400.0, "wifi?")];
        assert_eq!(
            p.validate(false),
            Err(PlanError::OutOfRange { freq_mhz: 2400.0 })
        );
    }

    #[test]
    fn hf_needs_direct_sampling() {
        let mut p = base();
        p.channels = vec![Channel::new(14.074, "FT8 20m")];
        assert!(p.validate(false).is_err());
        assert!(p.validate(true).is_ok());
    }

    #[test]
    fn rejects_empty_plan() {
        let mut p = base();
        p.channels.clear();
        assert_eq!(p.validate(false), Err(PlanError::Empty));
    }

    #[test]
    fn rejects_odd_step() {
        let mut p = base();
        p.step_khz = 17.0;
        assert_eq!(p.validate(false), Err(PlanError::BadStep(17.0)));
    }

    #[test]
    fn round_trips_through_json() {
        let p = base();
        let s = serde_json::to_string(&p).unwrap();
        let back: ScanPlan = serde_json::from_str(&s).unwrap();
        assert_eq!(p, back);
    }

    #[test]
    fn parses_a_plan_the_model_would_emit() {
        let raw = r#"{
            "name": "Ottawa airband",
            "windows": [],
            "channels": [
                {"freq_mhz": 118.8, "label": "CYOW Tower"},
                {"freq_mhz": 121.9, "label": "CYOW Ground"}
            ],
            "demod": "AM",
            "step_khz": 25,
            "squelch_db": 8,
            "hang_ms": 1500,
            "priority": [121.5],
            "source": "db:ised#4471192,4471193"
        }"#;
        let p: ScanPlan = serde_json::from_str(raw).unwrap();
        assert!(p.validate(false).is_ok());
        assert_eq!(p.dwell_ms, 40, "dwell should fall back to its default");
        assert_eq!(Provenance::parse(&p.source), Provenance::Database);
    }
}
