//! The seam between the core and the radio.
//!
//! Everything above this trait is testable without a dongle. `sweep-rtl`
//! implements it over librtlsdr on Windows and Linux; Android implements it
//! over a wrapped USB file descriptor. Neither one is allowed to leak upward.

use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TunerGain {
    /// Let the tuner AGC decide. Convenient, and wrong for survey work: the
    /// gain moves under you and levels stop being comparable between sweeps.
    Auto,
    /// Tenths of a dB, as librtlsdr expects.
    Manual(i32),
}

#[derive(Debug)]
pub enum SourceError {
    NotFound,
    Busy,
    Io(String),
    Unsupported(String),
}

impl fmt::Display for SourceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SourceError::NotFound => write!(f, "no device found"),
            SourceError::Busy => write!(f, "device is already in use"),
            SourceError::Io(s) => write!(f, "io error: {s}"),
            SourceError::Unsupported(s) => write!(f, "unsupported: {s}"),
        }
    }
}

impl std::error::Error for SourceError {}

/// A tunable source of interleaved unsigned-8 IQ.
pub trait IqSource {
    fn set_center_hz(&mut self, hz: f64) -> Result<(), SourceError>;
    fn set_sample_rate(&mut self, hz: u32) -> Result<(), SourceError>;
    fn set_gain(&mut self, gain: TunerGain) -> Result<(), SourceError>;

    /// Discard whatever is in flight. Must be called after retuning, or the
    /// first buffer you read still contains samples from the old frequency
    /// and you get a ghost signal at the wrong place in the waterfall.
    fn reset_buffer(&mut self) -> Result<(), SourceError>;

    /// Fill `buf` with interleaved u8 IQ. Returns bytes written.
    fn read(&mut self, buf: &mut [u8]) -> Result<usize, SourceError>;

    fn center_hz(&self) -> f64;
    fn sample_rate(&self) -> u32;
}

/// A synthetic source with planted carriers. Deterministic, so tests of
/// anything above this line cannot flake.
pub struct FakeSource {
    center_hz: f64,
    sample_rate: u32,
    /// (absolute frequency in Hz, amplitude 0..1)
    pub carriers: Vec<(f64, f32)>,
    pub noise: f32,
    seed: u64,
    /// Set true to simulate a dongle that was retuned but not flushed.
    pub stale_after_tune: bool,
    stale: bool,
    prev_center_hz: f64,
}

impl FakeSource {
    pub fn new(sample_rate: u32) -> Self {
        FakeSource {
            center_hz: 100e6,
            sample_rate,
            carriers: Vec::new(),
            noise: 0.004,
            seed: 0x5EED,
            stale_after_tune: false,
            stale: false,
            prev_center_hz: 100e6,
        }
    }

    pub fn with_carrier(mut self, hz: f64, amp: f32) -> Self {
        self.carriers.push((hz, amp));
        self
    }

    fn next_noise(&mut self) -> f32 {
        self.seed = self
            .seed
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        ((self.seed >> 33) as f32 / (1u64 << 31) as f32 - 0.5) * self.noise
    }
}

impl IqSource for FakeSource {
    fn set_center_hz(&mut self, hz: f64) -> Result<(), SourceError> {
        self.prev_center_hz = self.center_hz;
        self.center_hz = hz;
        if self.stale_after_tune {
            self.stale = true;
        }
        Ok(())
    }
    fn set_sample_rate(&mut self, hz: u32) -> Result<(), SourceError> {
        self.sample_rate = hz;
        Ok(())
    }
    fn set_gain(&mut self, _g: TunerGain) -> Result<(), SourceError> {
        Ok(())
    }
    fn reset_buffer(&mut self) -> Result<(), SourceError> {
        self.stale = false;
        Ok(())
    }
    fn read(&mut self, buf: &mut [u8]) -> Result<usize, SourceError> {
        let n = buf.len() / 2;
        // A stale buffer still holds the previous frequency's samples.
        // A buffer that was in flight when we retuned still holds samples
        // captured at the *previous* centre frequency.
        let effective_center = if self.stale {
            self.prev_center_hz
        } else {
            self.center_hz
        };
        let carriers = self.carriers.clone();
        for i in 0..n {
            let mut re = self.next_noise();
            let mut im = self.next_noise();
            for (hz, amp) in &carriers {
                let off = (hz - effective_center) / self.sample_rate as f64;
                if off.abs() > 0.45 {
                    continue;
                }
                let ph = std::f64::consts::TAU * off * i as f64;
                re += amp * ph.cos() as f32;
                im += amp * ph.sin() as f32;
            }
            buf[i * 2] = ((re * 127.5 + 127.4).clamp(0.0, 255.0)) as u8;
            buf[i * 2 + 1] = ((im * 127.5 + 127.4).clamp(0.0, 255.0)) as u8;
        }
        Ok(n * 2)
    }
    fn center_hz(&self) -> f64 {
        self.center_hz
    }
    fn sample_rate(&self) -> u32 {
        self.sample_rate
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::spectrum::Spectrum;

    #[test]
    fn fake_source_puts_a_carrier_where_it_says() {
        let n = 1024;
        let mut src = FakeSource::new(2_400_000).with_carrier(100_300_000.0, 0.4);
        src.set_center_hz(100e6).unwrap();
        let mut buf = vec![0u8; n * 2];
        src.read(&mut buf).unwrap();

        let mut spec = Spectrum::new(n);
        let mut out = vec![0.0; n];
        spec.process_u8(&buf, &mut out);
        let peak = out
            .iter()
            .enumerate()
            .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
            .unwrap()
            .0;
        let f = spec.bin_hz(peak, 100e6, 2_400_000);
        assert!(
            (f - 100_300_000.0).abs() < 5_000.0,
            "carrier landed at {f} Hz"
        );
    }

    #[test]
    fn an_unflushed_buffer_shows_the_old_frequency() {
        // This is the bug reset_buffer exists to prevent. Worth pinning so
        // nobody "optimises" the flush away later.
        // Start at 100 MHz, then retune to a carrier 1.5 MHz away — far
        // enough that the stale buffer cannot contain it at all.
        let mut src = FakeSource::new(2_400_000).with_carrier(101_500_000.0, 0.4);
        src.set_center_hz(100e6).unwrap();
        src.stale_after_tune = true;
        src.set_center_hz(101_500_000.0).unwrap();

        let n = 1024;
        let mut buf = vec![0u8; n * 2];
        let mut spec = Spectrum::new(n);
        let mut out = vec![0.0; n];

        src.read(&mut buf).unwrap();
        spec.process_u8(&buf, &mut out);
        let stale_peak = out.iter().cloned().fold(f32::MIN, f32::max);

        src.reset_buffer().unwrap();
        src.read(&mut buf).unwrap();
        spec.process_u8(&buf, &mut out);
        let clean_peak = out.iter().cloned().fold(f32::MIN, f32::max);

        assert!(
            clean_peak > stale_peak + 10.0,
            "flushing should reveal the real carrier: {stale_peak} -> {clean_peak}"
        );
    }
}
