//! Aircraft identity derived from what ADS-B already gives us — the 24-bit
//! ICAO address and the callsign — with no database and no network.
//!
//! Three things fall out for free:
//!
//! - [`icao_to_us_reg`] — the US tail number (N-number) is a pure function of
//!   the ICAO hex for the whole American block. The FAA assigns them by a
//!   fixed formula, so no lookup table is needed; this is that formula.
//! - [`country_from_hex`] — ICAO allocates the address space to countries in
//!   blocks (Annex 10), so the hex alone says where a tail is registered.
//! - [`operator_from_callsign`] — an airliner's callsign starts with its
//!   three-letter ICAO airline code (ACA = Air Canada), so the operator is
//!   the first token, looked up in a small built-in table.
//!
//! Everything richer than this — the aircraft *type*, a photo, the route —
//! needs an external database or API and belongs in the online-lookup path,
//! not here.

/// N-number charset: A–Z without I or O (they look like 1 and 0).
const CHARSET: &[u8; 24] = b"ABCDEFGHJKLMNPQRSTUVWXYZ";

fn suffix(rem: u32) -> String {
    // rem in 0..=600 → "", one letter, or two letters.
    if rem == 0 {
        return String::new();
    }
    let r = rem - 1;
    if r < 24 {
        return (CHARSET[r as usize] as char).to_string();
    }
    let r = r - 24; // 0..575 → two letters
    format!(
        "{}{}",
        CHARSET[(r / 24) as usize] as char,
        CHARSET[(r % 24) as usize] as char
    )
}

/// The US registration (N-number) for an ICAO address, or `None` if the
/// address is outside the American block (0xA00001–0xADF7C7).
///
/// The FAA packs N1 … N99999 (with up to two trailing letters) into the
/// block by a fixed base-mixed scheme; the bucket sizes below are that
/// scheme. Verified against the documented anchor 0xA00001 = N1 and by the
/// ordering of the first entries.
pub fn icao_to_us_reg(icao: u32) -> Option<String> {
    if !(0xA0_0001..=0xAD_F7C7).contains(&icao) {
        return None;
    }
    let mut v = icao - 0xA0_0001;
    let mut n = String::from("N");
    // digit 1 (1–9)
    n.push_str(&(v / 101_711 + 1).to_string());
    v %= 101_711;
    if v < 601 {
        n.push_str(&suffix(v));
        return Some(n);
    }
    v -= 601;
    // digit 2 (0–9)
    n.push_str(&(v / 10_111).to_string());
    v %= 10_111;
    if v < 601 {
        n.push_str(&suffix(v));
        return Some(n);
    }
    v -= 601;
    // digit 3
    n.push_str(&(v / 951).to_string());
    v %= 951;
    if v < 601 {
        n.push_str(&suffix(v));
        return Some(n);
    }
    v -= 601;
    // digit 4
    n.push_str(&(v / 35).to_string());
    v %= 35;
    // tail: 0 bare, 1..=24 a letter, 25..=34 a fifth digit
    if v == 0 {
        return Some(n);
    }
    let r = v - 1;
    if r < 24 {
        n.push(CHARSET[r as usize] as char);
    } else {
        n.push_str(&(r - 24).to_string());
    }
    Some(n)
}

/// Country of registration from the ICAO address block. Covers the blocks
/// that actually show up over North America plus the major world carriers;
/// an unlisted block returns `None` rather than a guess.
pub fn country_from_hex(icao: u32) -> Option<&'static str> {
    // (start, end_inclusive, country), ICAO Annex 10 allocations.
    const BLOCKS: &[(u32, u32, &str)] = &[
        (0xA0_0000, 0xAF_FFFF, "United States"),
        (0xC0_0000, 0xC3_FFFF, "Canada"),
        (0xC8_0000, 0xC8_7FFF, "New Zealand"),
        (0x7C_0000, 0x7F_FFFF, "Australia"),
        (0x40_0000, 0x43_FFFF, "United Kingdom"),
        (0x3C_0000, 0x3F_FFFF, "Germany"),
        (0x38_0000, 0x3B_FFFF, "France"),
        (0x30_0000, 0x33_FFFF, "Italy"),
        (0x34_0000, 0x37_FFFF, "Spain"),
        (0x44_0000, 0x44_7FFF, "Austria"),
        (0x48_0000, 0x48_7FFF, "Netherlands"),
        (0x4A_0000, 0x4A_7FFF, "Sweden"),
        (0x46_0000, 0x46_7FFF, "Finland"),
        (0x45_0000, 0x45_7FFF, "Denmark"),
        (0x47_0000, 0x47_7FFF, "Norway"),
        (0x4B_0000, 0x4B_FFFF, "Switzerland"),
        (0x50_0000, 0x50_7FFF, "Belgium"),
        (0x49_0000, 0x49_7FFF, "Portugal"),
        (0x4C_0000, 0x4C_7FFF, "Portugal"),
        (0x51_0000, 0x51_7FFF, "Bulgaria"),
        (0x0A_0000, 0x0A_7FFF, "South Africa"),
        (0x78_0000, 0x7B_FFFF, "China"),
        (0x84_0000, 0x87_FFFF, "Japan"),
        (0x71_8000, 0x71_FFFF, "South Korea"),
        (0x76_0000, 0x76_7FFF, "Singapore"),
        (0x88_0000, 0x88_7FFF, "Thailand"),
        (0x75_0000, 0x75_7FFF, "India"),
        (0x89_6000, 0x89_6FFF, "United Arab Emirates"),
        (0xE0_0000, 0xE3_FFFF, "Argentina"),
        (0xE4_0000, 0xE7_FFFF, "Brazil"),
        (0x0D_0000, 0x0D_7FFF, "Mexico"),
        (0x0B_0000, 0x0B_FFFF, "Mexico"),
    ];
    for &(lo, hi, name) in BLOCKS {
        if (lo..=hi).contains(&icao) {
            return Some(name);
        }
    }
    None
}

/// The airline from a callsign, when it is an airliner callsign — a
/// three-letter ICAO airline code followed by a flight number (ACA123).
/// A tail-number callsign (N…, C-F…) or an unknown code returns `None`.
pub fn operator_from_callsign(callsign: &str) -> Option<&'static str> {
    let cs = callsign.trim();
    if cs.len() < 4 {
        return None;
    }
    let code: String = cs.chars().take(3).collect();
    if !code.chars().all(|c| c.is_ascii_alphabetic()) {
        return None; // not an AAA### airline callsign
    }
    // The fourth character of an airline callsign is a digit.
    if !cs.chars().nth(3).map(|c| c.is_ascii_digit()).unwrap_or(false) {
        return None;
    }
    let code = code.to_ascii_uppercase();
    const OPS: &[(&str, &str)] = &[
        // Canadian
        ("ACA", "Air Canada"),
        ("ROU", "Air Canada Rouge"),
        ("JZA", "Jazz Aviation"),
        ("WJA", "WestJet"),
        ("WEN", "WestJet Encore"),
        ("POE", "Porter Airlines"),
        ("TSC", "Air Transat"),
        ("SWG", "Sunwing"),
        ("FLE", "Flair Airlines"),
        ("CJT", "Cargojet"),
        // US passenger
        ("AAL", "American Airlines"),
        ("UAL", "United Airlines"),
        ("DAL", "Delta Air Lines"),
        ("SWA", "Southwest"),
        ("JBU", "JetBlue"),
        ("ASA", "Alaska Airlines"),
        ("FFT", "Frontier"),
        ("NKS", "Spirit"),
        ("SKW", "SkyWest"),
        ("ENY", "Envoy Air"),
        ("RPA", "Republic Airways"),
        ("EDV", "Endeavor Air"),
        ("JIA", "PSA Airlines"),
        ("AAY", "Allegiant"),
        ("HAL", "Hawaiian"),
        // Cargo
        ("FDX", "FedEx"),
        ("UPS", "UPS Airlines"),
        ("GTI", "Atlas Air"),
        ("ABX", "ABX Air"),
        ("CKS", "Kalitta Air"),
        // Major international
        ("BAW", "British Airways"),
        ("DLH", "Lufthansa"),
        ("AFR", "Air France"),
        ("KLM", "KLM"),
        ("UAE", "Emirates"),
        ("QTR", "Qatar Airways"),
        ("ETD", "Etihad"),
        ("ACA2", "Air Canada"),
        ("IBE", "Iberia"),
        ("VIR", "Virgin Atlantic"),
        ("AMX", "Aeroméxico"),
        ("CPA", "Cathay Pacific"),
        ("ANA", "All Nippon"),
        ("JAL", "Japan Airlines"),
        ("KAL", "Korean Air"),
        ("SIA", "Singapore Airlines"),
        ("UAL2", "United Airlines"),
    ];
    OPS.iter()
        .find(|(c, _)| *c == code)
        .map(|(_, name)| *name)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nnumber_anchors() {
        // Documented base of the US block, then the next entries by the
        // scheme: N1, N1A, N1B … N1Z, N1AA, then N10.
        assert_eq!(icao_to_us_reg(0xA0_0001).as_deref(), Some("N1"));
        assert_eq!(icao_to_us_reg(0xA0_0002).as_deref(), Some("N1A"));
        assert_eq!(icao_to_us_reg(0xA0_0003).as_deref(), Some("N1B"));
        assert_eq!(icao_to_us_reg(0xA0_0001 + 24).as_deref(), Some("N1Z"));
        assert_eq!(icao_to_us_reg(0xA0_0001 + 25).as_deref(), Some("N1AA"));
        assert_eq!(icao_to_us_reg(0xA0_0001 + 601).as_deref(), Some("N10"));
    }

    #[test]
    fn nnumber_well_formed_across_block() {
        // Every address in the block must produce a syntactically valid
        // N-number: 'N', then 1–5 trailing chars, letters only from the
        // no-I/no-O set, at most two of them and only at the end.
        let mut last: Option<String> = None;
        for icao in (0xA0_0001..=0xAD_F7C7).step_by(4999) {
            let n = icao_to_us_reg(icao).expect("in-block address has a reg");
            assert!(n.starts_with('N'));
            let body = &n[1..];
            assert!((1..=5).contains(&body.len()), "{n} wrong length");
            let letters: String = body.chars().filter(|c| c.is_ascii_alphabetic()).collect();
            assert!(letters.len() <= 2, "{n} too many letters");
            assert!(!letters.contains('I') && !letters.contains('O'), "{n} bad letter");
            // letters only ever trail digits
            assert!(body.ends_with(&letters[..]) || letters.is_empty(), "{n} letters not trailing");
            // strictly increasing addresses give distinct regs
            if let Some(p) = &last {
                assert_ne!(p, &n, "duplicate reg {n}");
            }
            last = Some(n);
        }
    }

    #[test]
    fn out_of_block_is_none() {
        assert_eq!(icao_to_us_reg(0xC0_1234), None); // Canadian block
        assert_eq!(icao_to_us_reg(0x3C_1234), None); // Germany
    }

    #[test]
    fn country_blocks() {
        assert_eq!(country_from_hex(0xA1_B2C3), Some("United States"));
        assert_eq!(country_from_hex(0xC0_1234), Some("Canada"));
        assert_eq!(country_from_hex(0x3C_6789), Some("Germany"));
        assert_eq!(country_from_hex(0x00_0001), None);
    }

    #[test]
    fn operators() {
        assert_eq!(operator_from_callsign("ACA123"), Some("Air Canada"));
        assert_eq!(operator_from_callsign("WJA456"), Some("WestJet"));
        assert_eq!(operator_from_callsign("DAL89"), Some("Delta Air Lines"));
        assert_eq!(operator_from_callsign("N612AB"), None); // tail number
        assert_eq!(operator_from_callsign("ZZZ999"), None); // unknown code
        assert_eq!(operator_from_callsign("AC"), None); // too short
    }
}
