//! Audio-frequency-shift demodulation, shared by APRS and ACARS.
//!
//! Both send data as two audio tones through an ordinary analogue radio —
//! APRS at 1200 baud through an FM receiver, ACARS at 2400 baud through an
//! AM one. Only the numbers differ, so the receiver is written once:
//!
//! - A pair of correlators one bit long. The window is compared against
//!   each tone and whichever matches better wins. This is a matched filter
//!   and it is the right tool: it uses the whole symbol rather than
//!   guessing from zero crossings, which is what lets it work at the signal
//!   levels these protocols actually arrive at.
//! - A digital phase-locked loop for bit timing, nudged by every transition
//!   in that decision. The nudge is what carries it through a long run of
//!   identical bits, where there are no transitions to synchronise on and a
//!   free-running clock would drift off the symbol.
//!
//! What it does *not* do is interpret the bits. Differential coding and
//! framing belong to the protocol above, and the two protocols disagree
//! about both.

use std::f32::consts::TAU;

pub struct ToneDemod {
    /// One bit period of audio, as a ring buffer.
    win: Vec<f32>,
    pos: usize,
    filled: usize,
    /// Pre-computed tone references, so correlating is a dot product rather
    /// than two trigonometric calls per sample.
    mark: Vec<(f32, f32)>,
    space: Vec<(f32, f32)>,
    /// Running DC estimate, removed before correlating. An FM
    /// discriminator turns any tuning error into an offset, and an AM
    /// envelope detector has a large one by construction.
    dc: f32,
    phase: u32,
    inc: u32,
    last_level: bool,
    /// Strength of the winning tone over the losing one on the last symbol,
    /// as a ratio. A reader can use it to tell a decoded burst from a
    /// coin-toss on noise.
    pub confidence: f32,
}

impl ToneDemod {
    pub fn new(rate: f32, mark_hz: f32, space_hz: f32, baud: f32) -> Self {
        let n = (rate / baud).round().max(4.0) as usize;
        let reference = |f: f32| -> Vec<(f32, f32)> {
            (0..n)
                .map(|i| {
                    let a = TAU * f * i as f32 / rate;
                    (a.cos(), a.sin())
                })
                .collect()
        };
        ToneDemod {
            win: vec![0.0; n],
            pos: 0,
            filled: 0,
            mark: reference(mark_hz),
            space: reference(space_hz),
            dc: 0.0,
            phase: 0,
            // A full turn of the accumulator is one bit period.
            inc: ((baud / rate) * 4_294_967_296.0) as u32,
            last_level: false,
            confidence: 0.0,
        }
    }

    /// Feed audio; `sink` is called once per recovered bit with the raw
    /// tone decision — 1 for mark, 0 for space.
    pub fn process(&mut self, audio: &[f32], sink: &mut impl FnMut(u8)) {
        let n = self.win.len();
        for &s in audio {
            self.dc += (s - self.dc) * 0.0005;
            self.win[self.pos] = s - self.dc;
            self.pos = (self.pos + 1) % n;
            if self.filled < n {
                self.filled += 1;
                continue;
            }

            // The window is a ring buffer, so the reference index has to
            // follow the write head — otherwise the phase reference rotates
            // with the buffer and the correlation washes out.
            let (mut mi, mut mq, mut si, mut sq) = (0.0f32, 0.0f32, 0.0f32, 0.0f32);
            for k in 0..n {
                let v = self.win[(self.pos + k) % n];
                mi += v * self.mark[k].0;
                mq += v * self.mark[k].1;
                si += v * self.space[k].0;
                sq += v * self.space[k].1;
            }
            let m = mi * mi + mq * mq;
            let sp = si * si + sq * sq;
            let level = m > sp;

            // Pull the accumulator a third of the way toward the centre on
            // every transition: enough to track drift, not so much that a
            // single noisy decision drags the clock off.
            if level != self.last_level {
                let centre = 0x8000_0000u32;
                let err = self.phase.wrapping_sub(centre) as i32;
                self.phase = self.phase.wrapping_sub((err / 3) as u32);
            }
            self.last_level = level;

            let before = self.phase;
            self.phase = self.phase.wrapping_add(self.inc);
            if self.phase < before {
                let (hi, lo) = if m > sp { (m, sp) } else { (sp, m) };
                self.confidence = hi / lo.max(1e-9);
                sink(level as u8);
            }
        }
    }
}
