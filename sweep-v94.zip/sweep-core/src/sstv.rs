//! SSTV — slow-scan television: pictures sent as sound.
//!
//! The oldest idea here and the only one whose payload you look at rather
//! than read. An operator sends a photograph over a voice channel, one line
//! at a time, by sweeping an audio tone: 1500 Hz is black, 2300 Hz is
//! white, and everything between is a shade. 1200 Hz is not a colour at
//! all — it is the sync pulse that says a new line starts here.
//!
//! ```text
//!   audio ──► instantaneous frequency ──► VIS header ──► mode
//!                       │                                  │
//!                       └──────► line sync ──► pixels ──► picture
//! ```
//!
//! Everything downstream of the frequency track is timing. A mode is a
//! table of durations — how long the sync pulse lasts, how long each colour
//! sweep takes — and decoding is sampling that track at the right moments.
//! Which is why the VIS header matters so much: get the mode wrong and the
//! picture still arrives, sheared and in the wrong colours.
//!
//! Supported: Martin M1 and M2, Scottie S1, S2 and DX. These are the common
//! HF modes and they share a shape — a sync pulse and three colour sweeps
//! per line. Robot, PD and Wraase are recognised from their VIS codes and
//! reported by name rather than decoded, because a mode decoded with the
//! wrong timing produces a confident, wrong picture.

use std::f32::consts::TAU;

/// Black.
pub const FREQ_BLACK: f32 = 1500.0;
/// White.
pub const FREQ_WHITE: f32 = 2300.0;
/// Sync. Below the picture's range on purpose, so a sync pulse can never be
/// mistaken for a dark pixel.
pub const FREQ_SYNC: f32 = 1200.0;
/// The centre the demodulator mixes to.
const CENTRE: f32 = 1900.0;

/// Where SSTV is usually found. 14.230 MHz is the busiest by a wide margin.
pub const CALLING_FREQUENCIES: &[(f64, &str)] = &[
    (14_230_000.0, "20 m, the main SSTV calling frequency"),
    (14_233_000.0, "20 m, secondary"),
    (7_171_000.0, "40 m"),
    (21_340_000.0, "15 m"),
    (28_680_000.0, "10 m"),
    (144_500_000.0, "2 m FM, North America"),
];

// ---------------------------------------------------------------------------
// Modes
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Mode {
    MartinM1,
    MartinM2,
    ScottieS1,
    ScottieS2,
    ScottieDx,
}

/// One mode's timing, in seconds. Everything the decoder needs to turn a
/// frequency track into a picture.
#[derive(Clone, Copy)]
pub struct Timing {
    pub mode: Mode,
    pub name: &'static str,
    pub width: usize,
    pub height: usize,
    /// Duration of the 1200 Hz line-sync pulse.
    pub sync: f32,
    /// The 1500 Hz gap between sync and the first colour, and between
    /// colours.
    pub porch: f32,
    /// How long one colour sweep takes.
    pub scan: f32,
    /// The order the three colour sweeps arrive in.
    pub order: [usize; 3],
    /// Scottie puts its sync in the middle of the line rather than at the
    /// start, which changes where a line begins relative to the pulse.
    pub sync_after_two: bool,
}

/// One line, cut into its parts: how long each lasts and which colour
/// sweep it is, if any.
///
/// This is the single source of truth for the line's shape. Martin leads
/// with the sync pulse and closes with a fourth separator; Scottie puts the
/// pulse between the second and third sweeps and has three. Writing the
/// length as a formula was how the Martin line came out one separator short
/// — 445.874 ms against a published 446.446.
pub fn line_plan(t: &Timing) -> Vec<(f32, Option<usize>)> {
    if t.sync_after_two {
        vec![
            (t.porch, None),
            (t.scan, Some(0)),
            (t.porch, None),
            (t.scan, Some(1)),
            (t.sync, None),
            (t.porch, None),
            (t.scan, Some(2)),
        ]
    } else {
        vec![
            (t.sync, None),
            (t.porch, None),
            (t.scan, Some(0)),
            (t.porch, None),
            (t.scan, Some(1)),
            (t.porch, None),
            (t.scan, Some(2)),
            (t.porch, None),
        ]
    }
}

impl Timing {
    /// Total length of one line.
    pub fn line_seconds(&self) -> f32 {
        line_plan(self).iter().map(|(d, _)| *d).sum()
    }

    pub fn image_seconds(&self) -> f32 {
        self.line_seconds() * self.height as f32
    }
}

/// Indices into an RGB pixel, for the `order` field.
const R: usize = 0;
const G: usize = 1;
const B: usize = 2;

pub fn timing(mode: Mode) -> Timing {
    match mode {
        // Martin: sync, then green, blue, red, each with a separator.
        Mode::MartinM1 => Timing {
            mode,
            name: "Martin M1",
            width: 320,
            height: 256,
            sync: 0.004862,
            porch: 0.000572,
            scan: 0.146432,
            order: [G, B, R],
            sync_after_two: false,
        },
        Mode::MartinM2 => Timing {
            mode,
            name: "Martin M2",
            width: 320,
            height: 256,
            sync: 0.004862,
            porch: 0.000572,
            scan: 0.073216,
            order: [G, B, R],
            sync_after_two: false,
        },
        // Scottie: green and blue come first, then the sync pulse, then
        // red. The pulse is genuinely mid-line.
        Mode::ScottieS1 => Timing {
            mode,
            name: "Scottie S1",
            width: 320,
            height: 256,
            sync: 0.009,
            porch: 0.0015,
            scan: 0.138240,
            order: [G, B, R],
            sync_after_two: true,
        },
        Mode::ScottieS2 => Timing {
            mode,
            name: "Scottie S2",
            width: 320,
            height: 256,
            sync: 0.009,
            porch: 0.0015,
            scan: 0.088064,
            order: [G, B, R],
            sync_after_two: true,
        },
        Mode::ScottieDx => Timing {
            mode,
            name: "Scottie DX",
            width: 320,
            height: 256,
            sync: 0.009,
            porch: 0.0015,
            scan: 0.345600,
            order: [G, B, R],
            sync_after_two: true,
        },
    }
}

/// What a VIS code means. The supported ones come back as a mode; the rest
/// are named so the UI can say which mode was heard and skipped, rather
/// than showing nothing or guessing.
pub fn mode_from_vis(vis: u8) -> Result<Mode, &'static str> {
    match vis {
        44 => Ok(Mode::MartinM1),
        40 => Ok(Mode::MartinM2),
        60 => Ok(Mode::ScottieS1),
        56 => Ok(Mode::ScottieS2),
        76 => Ok(Mode::ScottieDx),
        8 => Err("Robot 36"),
        12 => Err("Robot 72"),
        93 => Err("PD50"),
        99 => Err("PD90"),
        95 => Err("PD120"),
        98 => Err("PD160"),
        96 => Err("PD180"),
        97 => Err("PD240"),
        94 => Err("PD290"),
        55 => Err("Wraase SC2-180"),
        _ => Err("an unknown mode"),
    }
}

// ---------------------------------------------------------------------------
// The picture
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct Picture {
    pub width: usize,
    pub height: usize,
    /// Row-major RGB, three bytes per pixel.
    pub rgb: Vec<u8>,
    /// How many lines have arrived. A picture is useful well before it is
    /// finished — this is what lets the display fill in as it receives.
    pub lines_done: usize,
    pub mode: &'static str,
}

impl Picture {
    fn new(t: &Timing) -> Self {
        Picture {
            width: t.width,
            height: t.height,
            rgb: vec![0u8; t.width * t.height * 3],
            lines_done: 0,
            mode: t.name,
        }
    }

    fn put(&mut self, x: usize, y: usize, c: usize, v: u8) {
        if x < self.width && y < self.height {
            self.rgb[(y * self.width + x) * 3 + c] = v;
        }
    }

    pub fn complete(&self) -> bool {
        self.lines_done >= self.height
    }
}

// ---------------------------------------------------------------------------
// Decoder
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Debug)]
enum State {
    /// Waiting for a leader tone and the start bit after it.
    Listening,
    /// Reading the eight VIS bits.
    ReadingVis,
    /// Receiving a picture.
    Receiving,
}

/// What the decoder wants the caller to know about, as it happens.
#[derive(Clone, Debug)]
pub enum Event {
    /// A header arrived and named a mode this decoder can receive.
    Started(&'static str),
    /// A header arrived for a mode that is recognised but not decoded.
    Unsupported(&'static str),
    /// A picture finished.
    Finished,
}

pub struct SstvDecoder {
    rate: f32,
    /// Quadrature mixer to bring the audio band down around zero.
    phasor: (f32, f32),
    step: (f32, f32),
    /// Lowpass on the complex baseband, so only the tone survives.
    taps: Vec<f32>,
    hist: Vec<(f32, f32)>,
    hp: usize,
    prev: (f32, f32),

    /// Instantaneous frequency, smoothed a little.
    freq: f32,
    /// Samples since the decoder started, used as a clock.
    clock: u64,

    state: State,
    /// How long the tone has been near 1900 Hz, for finding the leader.
    leader: u32,
    /// How long it has been away from 1900 Hz. A tone does not jump: it
    /// glides, passing through frequencies that are neither the leader nor
    /// the start bit. Zeroing the leader the instant it leaves 1900 throws
    /// the count away during that glide, and the header is never seen.
    away: u32,
    /// Where the current run of 1200 Hz began, and how long it has lasted.
    ///
    /// Length matters: the header contains a 10 ms break at 1200 Hz
    /// *between* its two leader tones, and the start bit proper is 30 ms.
    /// Accept the first 1200 Hz you see and that break is read as the start
    /// bit, putting every VIS bit a third of a second early — which decodes
    /// to a mode nobody sent.
    sync_began: u64,
    sync_run: u32,
    /// Sample index where the VIS start bit ended.
    vis_start: u64,
    vis_bits: Vec<u8>,

    timing: Option<Timing>,
    /// The line, cut into segments: where each one starts and ends in
    /// samples, and which colour sweep it is (none for sync and porches).
    /// Built once when the mode is known, because working it out per
    /// sample is the same arithmetic forty-eight thousand times a second.
    segments: Vec<(u64, u64, Option<usize>)>,
    /// Sample index where the current line's first colour sweep begins.
    line_start: u64,
    line: usize,

    pub picture: Option<Picture>,
    pub headers_seen: u64,
}

impl SstvDecoder {
    pub fn new(rate: f32) -> Self {
        // A 900 Hz lowpass keeps the whole 1100–2300 Hz range once it is
        // mixed down, and rejects everything else on the channel.
        let n = 63usize;
        let fc = 900.0 / rate;
        let mut taps = vec![0.0f32; n];
        let mid = (n - 1) as f32 / 2.0;
        let mut sum = 0.0;
        for (i, t) in taps.iter_mut().enumerate() {
            let x = i as f32 - mid;
            let sinc = if x == 0.0 {
                2.0 * fc
            } else {
                (TAU * fc * x).sin() / (std::f32::consts::PI * x)
            };
            // Hamming window.
            let w = 0.54 - 0.46 * (TAU * i as f32 / (n - 1) as f32).cos();
            *t = sinc * w;
            sum += *t;
        }
        for t in taps.iter_mut() {
            *t /= sum;
        }
        let w = -TAU * CENTRE / rate;
        SstvDecoder {
            rate,
            phasor: (1.0, 0.0),
            step: (w.cos(), w.sin()),
            taps,
            hist: vec![(0.0, 0.0); n],
            hp: 0,
            prev: (1.0, 0.0),
            freq: CENTRE,
            clock: 0,
            state: State::Listening,
            leader: 0,
            away: 0,
            sync_began: 0,
            sync_run: 0,
            vis_start: 0,
            vis_bits: Vec::with_capacity(8),
            timing: None,
            segments: Vec::new(),
            line_start: 0,
            line: 0,
            picture: None,
            headers_seen: 0,
        }
    }

    /// Feed demodulated audio. Events are appended as they occur; the
    /// picture is readable at any time through [`Self::picture`].
    pub fn process(&mut self, audio: &[f32], events: &mut Vec<Event>) {
        for &s in audio {
            // --- instantaneous frequency ---------------------------------
            let (pr, pi) = self.phasor;
            let x = (s * pr, s * pi);
            self.phasor = (pr * self.step.0 - pi * self.step.1, pr * self.step.1 + pi * self.step.0);
            // Rounding walks the phasor off the unit circle; pull it back
            // occasionally rather than every sample.
            if self.clock % 8192 == 0 {
                let m = (self.phasor.0 * self.phasor.0 + self.phasor.1 * self.phasor.1).sqrt();
                if m > 0.0 {
                    self.phasor = (self.phasor.0 / m, self.phasor.1 / m);
                }
            }

            self.hist[self.hp] = x;
            self.hp = (self.hp + 1) % self.taps.len();
            let n = self.taps.len();
            let (mut yr, mut yi) = (0.0f32, 0.0f32);
            for k in 0..n {
                let (hr, hi) = self.hist[(self.hp + k) % n];
                yr += hr * self.taps[k];
                yi += hi * self.taps[k];
            }

            // Phase difference between consecutive samples is frequency.
            let (ar, ai) = (self.prev.0, -self.prev.1);
            let d = (yr * ar - yi * ai, yr * ai + yi * ar);
            self.prev = (yr, yi);
            let dphi = d.1.atan2(d.0);
            let f = CENTRE + dphi * self.rate / TAU;
            // Light smoothing: enough to steady the slicing decisions,
            // little enough that a sync pulse edge stays sharp.
            self.freq += (f - self.freq) * 0.35;

            self.clock += 1;
            self.step_state(events);
        }
    }

    fn samples(&self, seconds: f32) -> u64 {
        (seconds * self.rate) as u64
    }

    fn step_state(&mut self, events: &mut Vec<Event>) {
        match self.state {
            State::Listening => {
                // The header is a long 1900 Hz leader, then a 1200 Hz start
                // bit. Requiring the leader before accepting a start bit is
                // what keeps ordinary speech from looking like a header.
                if (self.freq - CENTRE).abs() < 70.0 {
                    self.leader = self.leader.saturating_add(1);
                    self.away = 0;
                    self.sync_run = 0;
                    return;
                }
                self.away = self.away.saturating_add(1);

                if (self.freq - FREQ_SYNC).abs() < 70.0 {
                    if self.sync_run == 0 {
                        self.sync_began = self.clock;
                    }
                    self.sync_run = self.sync_run.saturating_add(1);
                    // Two thirds of a start bit is enough to tell it from
                    // the 10 ms break, and short enough to leave time to
                    // line the VIS bits up afterwards.
                    if self.sync_run == self.samples(0.020) as u32
                        && self.leader > self.samples(0.1) as u32
                    {
                        // The bits begin one whole start bit after this run
                        // started, not after it was recognised.
                        self.vis_start = self.sync_began + self.samples(0.030);
                        self.vis_bits.clear();
                        self.state = State::ReadingVis;
                        self.leader = 0;
                        self.away = 0;
                        self.sync_run = 0;
                    }
                    return;
                }
                self.sync_run = 0;
                // Only give up on the leader once the tone has been
                // somewhere else long enough that it is not a glide.
                if self.away > self.samples(0.006) as u32 {
                    self.leader = 0;
                }
            }
            State::ReadingVis => {
                // Eight bits, 30 ms each, sampled at the centre of each
                // slot. 1100 Hz is a one, 1300 Hz a zero.
                let slot = self.vis_bits.len() as u64;
                let at = self.vis_start + self.samples(0.030) * slot + self.samples(0.015);
                if self.clock < at {
                    return;
                }
                let bit = if self.freq < 1200.0 { 1u8 } else { 0u8 };
                self.vis_bits.push(bit);
                if self.vis_bits.len() < 8 {
                    return;
                }

                // Bits arrive least significant first; the eighth is even
                // parity over the other seven.
                let mut vis = 0u8;
                for (i, b) in self.vis_bits.iter().take(7).enumerate() {
                    vis |= b << i;
                }
                let parity = self.vis_bits[7];
                self.state = State::Listening;
                self.leader = 0;
                self.away = 0;
                if (vis.count_ones() as u8 % 2) != parity {
                    // A header whose parity fails is not a header.
                    return;
                }
                self.headers_seen += 1;

                match mode_from_vis(vis) {
                    Ok(m) => {
                        let t = timing(m);
                        self.segments = Self::segments_of(&t, self.rate);
                        self.picture = Some(Picture::new(&t));
                        self.timing = Some(t);
                        self.line = 0;
                        // The picture starts one stop bit after the VIS.
                        self.line_start =
                            self.vis_start + self.samples(0.030) * 8 + self.samples(0.030);
                        self.state = State::Receiving;
                        events.push(Event::Started(t.name));
                    }
                    Err(name) => events.push(Event::Unsupported(name)),
                }
            }
            State::Receiving => {
                let Some(t) = self.timing else {
                    self.state = State::Listening;
                    return;
                };
                let line_len = self.samples(t.line_seconds());
                let into = self.clock.saturating_sub(self.line_start);

                if into < line_len {
                    // Write the pixel this instant belongs to. Doing it as
                    // the clock passes rather than buffering a line means
                    // the picture fills in live, which is most of the
                    // pleasure of watching SSTV arrive.
                    for &(a, b, sweep) in &self.segments {
                        if into >= a && into < b {
                            if let Some(sw) = sweep {
                                let span = (b - a).max(1);
                                let x = ((into - a) as f32 / span as f32
                                    * t.width as f32) as usize;
                                let v = freq_to_level(self.freq);
                                let ch = t.order[sw];
                                let line = self.line;
                                if let Some(p) = &mut self.picture {
                                    p.put(x, line, ch, v);
                                }
                            }
                            break;
                        }
                    }
                    return;
                }

                self.line += 1;
                self.line_start += line_len;
                if let Some(p) = &mut self.picture {
                    p.lines_done = self.line.min(p.height);
                }
                if self.line >= t.height {
                    self.state = State::Listening;
                    self.leader = 0;
                    self.away = 0;
                    events.push(Event::Finished);
                }
            }
        }
    }

    /// Cut one line into its segments.
    ///
    /// Martin leads with the sync pulse; Scottie puts it between the second
    /// and third colour sweeps, which is the whole reason this is a table
    /// rather than a formula.
    fn segments_of(t: &Timing, rate: f32) -> Vec<(u64, u64, Option<usize>)> {
        let s = |sec: f32| (sec * rate) as u64;
        let (sync, porch, scan) = (s(t.sync), s(t.porch), s(t.scan));
        let plan: Vec<(u64, Option<usize>)> = if t.sync_after_two {
            vec![
                (porch, None),
                (scan, Some(0)),
                (porch, None),
                (scan, Some(1)),
                (sync, None),
                (porch, None),
                (scan, Some(2)),
            ]
        } else {
            vec![
                (sync, None),
                (porch, None),
                (scan, Some(0)),
                (porch, None),
                (scan, Some(1)),
                (porch, None),
                (scan, Some(2)),
            ]
        };

        let mut out = Vec::with_capacity(plan.len());
        let mut at = 0u64;
        for (len, sweep) in plan {
            out.push((at, at + len, sweep));
            at += len;
        }
        out
    }
}

/// Turn a tone into a shade. Anything at or below black is black, anything
/// at or above white is white, and a sync pulse clamps to black rather than
/// wrapping round to bright.
pub fn freq_to_level(f: f32) -> u8 {
    let v = (f - FREQ_BLACK) / (FREQ_WHITE - FREQ_BLACK);
    (v.clamp(0.0, 1.0) * 255.0).round() as u8
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vis_codes_map_to_the_right_modes() {
        assert_eq!(mode_from_vis(44), Ok(Mode::MartinM1));
        assert_eq!(mode_from_vis(40), Ok(Mode::MartinM2));
        assert_eq!(mode_from_vis(60), Ok(Mode::ScottieS1));
        assert_eq!(mode_from_vis(56), Ok(Mode::ScottieS2));
        assert_eq!(mode_from_vis(76), Ok(Mode::ScottieDx));
    }

    #[test]
    fn modes_that_are_not_decoded_are_named_not_guessed() {
        assert_eq!(mode_from_vis(8), Err("Robot 36"));
        assert_eq!(mode_from_vis(95), Err("PD120"));
        assert_eq!(mode_from_vis(200), Err("an unknown mode"));
    }

    #[test]
    fn line_timing_matches_the_published_figures() {
        // Martin M1 is 446.446 ms a line; the whole 256-line picture takes
        // close to 114 seconds, which is the number everyone quotes.
        let t = timing(Mode::MartinM1);
        assert!((t.line_seconds() - 0.446446).abs() < 1e-5, "{}", t.line_seconds());
        assert!((t.image_seconds() - 114.3).abs() < 0.2, "{}", t.image_seconds());

        // Scottie S1 is 428.22 ms.
        let s = timing(Mode::ScottieS1);
        assert!((s.line_seconds() - 0.42822).abs() < 1e-4, "{}", s.line_seconds());
    }

    #[test]
    fn tones_map_to_shades_and_sync_cannot_look_bright() {
        assert_eq!(freq_to_level(FREQ_BLACK), 0);
        assert_eq!(freq_to_level(FREQ_WHITE), 255);
        assert_eq!(freq_to_level(1900.0), 128);
        // A sync pulse is below black. It must clamp, not wrap.
        assert_eq!(freq_to_level(FREQ_SYNC), 0);
        assert_eq!(freq_to_level(3000.0), 255);
    }

    /// Generate the audio for a VIS header.
    fn vis_audio(vis: u8, rate: f32) -> Vec<f32> {
        let mut out = Vec::new();
        let mut phase = 0.0f32;
        let mut tone = |f: f32, secs: f32, out: &mut Vec<f32>| {
            let n = (secs * rate) as usize;
            for _ in 0..n {
                out.push(phase.sin());
                phase += TAU * f / rate;
                if phase > TAU {
                    phase -= TAU;
                }
            }
        };
        tone(1900.0, 0.3, &mut out);
        tone(1200.0, 0.01, &mut out);
        tone(1900.0, 0.3, &mut out);
        tone(1200.0, 0.03, &mut out); // start bit
        let mut ones = 0;
        for i in 0..7 {
            let b = (vis >> i) & 1;
            if b == 1 {
                ones += 1;
            }
            tone(if b == 1 { 1100.0 } else { 1300.0 }, 0.03, &mut out);
        }
        // Even parity.
        tone(if ones % 2 == 1 { 1100.0 } else { 1300.0 }, 0.03, &mut out);
        tone(1200.0, 0.03, &mut out); // stop bit
        out
    }

    #[test]
    fn a_synthesised_header_identifies_the_mode() {
        let audio = vis_audio(44, 12_000.0);
        let mut d = SstvDecoder::new(12_000.0);
        let mut ev = Vec::new();
        d.process(&vec![0.0f32; 2000], &mut ev);
        d.process(&audio, &mut ev);
        assert!(
            ev.iter().any(|e| matches!(e, Event::Started("Martin M1"))),
            "expected a Martin M1 start, got {ev:?}"
        );
        assert!(d.picture.is_some());
        let p = d.picture.as_ref().unwrap();
        assert_eq!((p.width, p.height), (320, 256));
    }

    #[test]
    fn a_header_for_an_unsupported_mode_says_so_and_decodes_nothing() {
        let audio = vis_audio(8, 12_000.0); // Robot 36
        let mut d = SstvDecoder::new(12_000.0);
        let mut ev = Vec::new();
        d.process(&audio, &mut ev);
        assert!(
            ev.iter().any(|e| matches!(e, Event::Unsupported("Robot 36"))),
            "got {ev:?}"
        );
        assert!(d.picture.is_none(), "must not start a picture it cannot fill");
    }

    #[test]
    fn speech_shaped_noise_is_not_mistaken_for_a_header() {
        // A header needs a long steady leader before its start bit. Noise
        // has no such thing, which is the point of requiring it.
        let rate = 12_000.0f32;
        let mut rng: u32 = 4242;
        let mut phase = 0.0f32;
        let mut audio = Vec::new();
        for i in 0..rate as usize * 6 {
            rng = rng.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
            // A tone wandering all over the voice band.
            let f = 700.0 + 1600.0 * ((i as f32 / 900.0).sin() * 0.5 + 0.5);
            phase += TAU * f / rate;
            let n = (rng >> 8) as f32 / 8_388_608.0 - 1.0;
            audio.push(phase.sin() * 0.8 + n * 0.2);
        }
        let mut d = SstvDecoder::new(rate);
        let mut ev = Vec::new();
        d.process(&audio, &mut ev);
        assert!(
            !ev.iter().any(|e| matches!(e, Event::Started(_))),
            "noise started a picture: {ev:?}"
        );
    }

    /// A full Martin M1 transmission of a few lines, each a flat colour,
    /// pushed through and checked pixel by pixel. This is the only test
    /// that exercises the frequency track, the VIS header, the line
    /// segmentation and the colour order together.
    #[test]
    fn a_synthesised_picture_comes_back_in_the_right_colours() {
        let rate = 12_000.0f32;
        let t = timing(Mode::MartinM1);
        let mut out = vis_audio(44, rate);
        let mut phase = 0.0f32;
        let mut tone = |f: f32, secs: f32, out: &mut Vec<f32>| {
            for _ in 0..(secs * rate) as usize {
                out.push(phase.sin());
                phase += TAU * f / rate;
                if phase > TAU {
                    phase -= TAU;
                }
            }
        };
        let level_to_freq =
            |v: u8| FREQ_BLACK + (v as f32 / 255.0) * (FREQ_WHITE - FREQ_BLACK);

        // Three lines: pure green, pure blue, mid grey.
        let lines: [[u8; 3]; 3] = [[0, 255, 0], [0, 0, 255], [128, 128, 128]];
        for rgb in lines.iter() {
            tone(FREQ_SYNC, t.sync, &mut out);
            // Martin sends green, blue, red, each after a separator.
            for ch in t.order.iter() {
                tone(FREQ_BLACK, t.porch, &mut out);
                tone(level_to_freq(rgb[*ch]), t.scan, &mut out);
            }
        }

        let mut d = SstvDecoder::new(rate);
        let mut ev = Vec::new();
        d.process(&vec![0.0f32; 1000], &mut ev);
        d.process(&out, &mut ev);

        let p = d.picture.as_ref().expect("a picture should have started");
        assert!(p.lines_done >= 2, "only {} lines done", p.lines_done);

        // Sample the middle of each line, away from the segment edges where
        // the filter is still settling.
        let at = |p: &Picture, x: usize, y: usize| -> [u8; 3] {
            let i = (y * p.width + x) * 3;
            [p.rgb[i], p.rgb[i + 1], p.rgb[i + 2]]
        };
        for (y, want) in lines.iter().enumerate().take(2) {
            let got = at(p, 160, y);
            for c in 0..3 {
                let diff = (got[c] as i32 - want[c] as i32).abs();
                assert!(
                    diff < 40,
                    "line {y} channel {c}: got {} wanted {} (whole pixel {got:?})",
                    got[c],
                    want[c]
                );
            }
        }
    }

    #[test]
    fn a_bad_parity_header_is_rejected() {
        let rate = 12_000.0f32;
        let mut out = Vec::new();
        let mut phase = 0.0f32;
        let mut tone = |f: f32, secs: f32, out: &mut Vec<f32>| {
            for _ in 0..(secs * rate) as usize {
                out.push(phase.sin());
                phase += TAU * f / rate;
                if phase > TAU {
                    phase -= TAU;
                }
            }
        };
        tone(1900.0, 0.3, &mut out);
        tone(1200.0, 0.03, &mut out);
        for i in 0..7 {
            let b = (44u8 >> i) & 1;
            tone(if b == 1 { 1100.0 } else { 1300.0 }, 0.03, &mut out);
        }
        // 44 has three ones, so even parity is a one. Send a zero.
        tone(1300.0, 0.03, &mut out);
        let mut d = SstvDecoder::new(rate);
        let mut ev = Vec::new();
        d.process(&out, &mut ev);
        assert!(ev.is_empty(), "a broken header produced {ev:?}");
    }
}
