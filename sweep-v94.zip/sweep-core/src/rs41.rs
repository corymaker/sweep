//! Vaisala RS41 radiosonde decoder — the decode engine.
//!
//! A radiosonde is the instrument package on a weather balloon. The RS41 is
//! the current Vaisala model, launched twice a day from most weather
//! offices, transmitting GFSK telemetry around 400–406 MHz as it climbs to
//! ~35 km. Each frame carries the sonde's GPS position, which is what this
//! extracts.
//!
//! This module is the **engine**: it turns a frame of demodulated bytes into
//! a position. It is deliberately pure-std and self-contained so it can be
//! tested with `rustc` alone, with no SDR and no real signal:
//!
//! - [`Rs`] — the Reed–Solomon RS(255,231) error corrector over GF(256),
//!   the hard part. Verified by encoding, corrupting and decoding (below).
//! - [`crc16`] — the CRC each frame block carries, checked against the
//!   standard CCITT test vector.
//! - [`ecef_to_geodetic`] — WGS-84 Earth-centred XYZ to latitude, longitude
//!   and altitude, verified by round-trip against its inverse.
//! - [`demask`] — the fixed whitening the RS41 XORs over its frame.
//! - [`parse_frame`] — ties them together: header, de-whiten, error-correct,
//!   walk the typed blocks, pull the GPS position out of block 0x7B.
//!
//! What is **not** here, and comes next, is the live side: the worker
//! FM/GFSK-demodulating 400–406 MHz into the bytes this takes, and a view to
//! plot the balloons. The exact on-air byte layout (block offsets, the RS
//! interleave) follows the published RS41 format, but it must still be
//! confirmed against a real captured frame before the live path is trusted —
//! the engine below is what that confirmation will run on.

/// A decoded position from one RS41 frame.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SondePosition {
    pub lat_deg: f64,
    pub lon_deg: f64,
    pub alt_m: f64,
}

// ---------------------------------------------------------------------------
// GF(256) + Reed–Solomon RS(255,231)
// ---------------------------------------------------------------------------

/// Reed–Solomon over GF(2^8) with primitive polynomial 0x11D (the one the
/// RS41 uses). RS(255,231): 24 parity bytes, so it corrects up to 12 byte
/// errors anywhere in a 255-byte codeword.
///
/// The tables are built once in [`Rs::new`]; decoding is the classic
/// syndrome → Berlekamp–Massey → Chien → Forney chain.
pub struct Rs {
    exp: [u8; 512],
    log: [u8; 256],
}

/// Parity byte count (n - k = 255 - 231).
pub const RS_PARITY: usize = 24;

impl Default for Rs {
    fn default() -> Self {
        Self::new()
    }
}

impl Rs {
    pub fn new() -> Self {
        let mut exp = [0u8; 512];
        let mut log = [0u8; 256];
        let mut x: u16 = 1;
        for i in 0..255 {
            exp[i] = x as u8;
            log[x as usize] = i as u8;
            x <<= 1;
            if x & 0x100 != 0 {
                x ^= 0x11D;
            }
        }
        for i in 255..512 {
            exp[i] = exp[i - 255];
        }
        Rs { exp, log }
    }

    #[inline]
    fn mul(&self, a: u8, b: u8) -> u8 {
        if a == 0 || b == 0 {
            0
        } else {
            self.exp[self.log[a as usize] as usize + self.log[b as usize] as usize]
        }
    }

    #[inline]
    fn pow(&self, i: i32) -> u8 {
        // α^i, i taken mod 255 into [0,255)
        let mut m = i % 255;
        if m < 0 {
            m += 255;
        }
        self.exp[m as usize]
    }

    #[inline]
    fn inv(&self, a: u8) -> u8 {
        // a^-1 = α^(255 - log a)
        debug_assert!(a != 0);
        self.exp[255 - self.log[a as usize] as usize]
    }

    /// Append `RS_PARITY` parity bytes for a systematic codeword. Used by the
    /// tests (and by the synthetic frame builder) to produce valid input.
    /// `msg` is the data; returns the 24 parity bytes. Generator roots are
    /// α^0 … α^23 (first-consonant-root = 0), matching the decoder.
    pub fn encode_parity(&self, msg: &[u8]) -> [u8; RS_PARITY] {
        // Generator g(x) = ∏ (x - α^i), i = 0..24, stored HIGHEST degree
        // first so gen[0] is the monic leading term and gen[1..] are the
        // division feedback taps.
        let mut gen = vec![1u8];
        for i in 0..RS_PARITY {
            let root = self.pow(i as i32);
            // multiply gen (descending) by (x + root)
            let mut ng = vec![0u8; gen.len() + 1];
            for (j, &c) in gen.iter().enumerate() {
                ng[j] ^= c; // c · x  (shifts up a degree)
                ng[j + 1] ^= self.mul(c, root); // c · root
            }
            gen = ng;
        }
        // Systematic remainder of msg·x^parity divided by g (LFSR division).
        let mut rem = vec![0u8; RS_PARITY];
        for &m in msg {
            let factor = m ^ rem[0];
            rem.remove(0);
            rem.push(0);
            if factor != 0 {
                for j in 0..RS_PARITY {
                    rem[j] ^= self.mul(gen[j + 1], factor);
                }
            }
        }
        let mut out = [0u8; RS_PARITY];
        out.copy_from_slice(&rem);
        out
    }

    /// Correct errors in a 255-byte codeword in place. Returns the number of
    /// bytes corrected, or `None` if the errors exceed what RS(255,231) can
    /// fix (more than 12). A clean codeword returns `Some(0)`.
    pub fn decode(&self, cw: &mut [u8; 255]) -> Option<usize> {
        // --- syndromes S_j = c(α^j), j = 0..24 ---
        let mut synd = [0u8; RS_PARITY];
        let mut any = false;
        for (j, s) in synd.iter_mut().enumerate() {
            let mut acc = 0u8;
            let root = self.pow(j as i32);
            for &b in cw.iter() {
                acc = self.mul(acc, root) ^ b;
            }
            *s = acc;
            if acc != 0 {
                any = true;
            }
        }
        if !any {
            return Some(0);
        }

        // --- Berlekamp–Massey → error locator Λ(x) ---
        let mut lambda = vec![1u8];
        let mut b = vec![1u8];
        let mut l = 0usize;
        let mut m = 1usize;
        let mut b_scalar = 1u8;
        for n in 0..RS_PARITY {
            // discrepancy δ = S_n + Σ λ_i S_{n-i}
            let mut delta = synd[n];
            for i in 1..=l {
                delta ^= self.mul(lambda[i], synd[n - i]);
            }
            if delta == 0 {
                m += 1;
            } else if 2 * l <= n {
                let t = lambda.clone();
                // λ ← λ - (δ/b) x^m B
                let coef = self.mul(delta, self.inv(b_scalar));
                while lambda.len() < b.len() + m {
                    lambda.push(0);
                }
                for (i, &bc) in b.iter().enumerate() {
                    lambda[i + m] ^= self.mul(coef, bc);
                }
                l = n + 1 - l;
                b = t;
                b_scalar = delta;
                m = 1;
            } else {
                let coef = self.mul(delta, self.inv(b_scalar));
                while lambda.len() < b.len() + m {
                    lambda.push(0);
                }
                for (i, &bc) in b.iter().enumerate() {
                    lambda[i + m] ^= self.mul(coef, bc);
                }
                m += 1;
            }
        }
        let deg_lambda = l;
        if deg_lambda == 0 || deg_lambda > RS_PARITY / 2 {
            return None;
        }

        // --- Chien search: roots of Λ give the error locators ---
        // A root at x = α^-i means an error locator X = α^i. With this
        // module's syndromes (where cw[0] is the highest-degree term), the
        // locator X = α^i sits at BYTE index 254 - i — the mapping that was
        // the bug when it was taken as i directly.
        let mut locs = Vec::new(); // α-exponents i (not byte indices)
        for i in 0..255usize {
            // evaluate Λ(α^-i)
            let xinv = self.pow(-(i as i32));
            let mut acc = 0u8;
            let mut xp = 1u8;
            for &lc in lambda.iter() {
                acc ^= self.mul(lc, xp);
                xp = self.mul(xp, xinv);
            }
            if acc == 0 {
                locs.push(i);
            }
        }
        if locs.len() != deg_lambda {
            return None; // locator roots don't match its degree → uncorrectable
        }

        // --- error evaluator Ω(x) = S(x)·Λ(x) mod x^parity ---
        let mut omega = vec![0u8; RS_PARITY];
        for (i, oi) in omega.iter_mut().enumerate() {
            let mut acc = 0u8;
            for j in 0..=i.min(lambda.len() - 1) {
                acc ^= self.mul(synd[i - j], lambda[j]);
            }
            *oi = acc;
        }

        // --- Forney: magnitude at each locator (fcr = 0) ---
        for &loc in &locs {
            let x = self.pow(loc as i32); // X_k = α^loc
            let xinv = self.inv(x);
            // Ω(X^-1)
            let mut num = 0u8;
            let mut xp = 1u8;
            for &oc in omega.iter() {
                num ^= self.mul(oc, xp);
                xp = self.mul(xp, xinv);
            }
            // Λ'(X^-1): formal derivative keeps odd-index terms only
            let mut den = 0u8;
            let mut xp2 = 1u8; // (X^-1)^0
            for i in 1..lambda.len() {
                if i & 1 == 1 {
                    den ^= self.mul(lambda[i], xp2);
                }
                xp2 = self.mul(xp2, xinv);
            }
            if den == 0 {
                return None;
            }
            // e = X · Ω(X^-1) / Λ'(X^-1)   (the X factor is the fcr=0 case)
            let mag = self.mul(x, self.mul(num, self.inv(den)));
            let pos = 254 - loc; // α-exponent → byte index
            cw[pos] ^= mag;
        }

        // --- verify the correction actually cleared the syndromes ---
        for j in 0..RS_PARITY {
            let mut acc = 0u8;
            let root = self.pow(j as i32);
            for &byte in cw.iter() {
                acc = self.mul(acc, root) ^ byte;
            }
            if acc != 0 {
                return None;
            }
        }
        Some(locs.len())
    }
}

// ---------------------------------------------------------------------------
// CRC-16/CCITT (poly 0x1021, init 0xFFFF) — each frame block's checksum
// ---------------------------------------------------------------------------

pub fn crc16(data: &[u8]) -> u16 {
    let mut crc: u16 = 0xFFFF;
    for &b in data {
        crc ^= (b as u16) << 8;
        for _ in 0..8 {
            if crc & 0x8000 != 0 {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc <<= 1;
            }
        }
    }
    crc
}

// ---------------------------------------------------------------------------
// WGS-84 ECEF → geodetic
// ---------------------------------------------------------------------------

/// Earth-centred, Earth-fixed metres → (lat°, lon°, altitude m) on WGS-84.
/// Closed-form Bowring method; accurate to well under a metre at balloon
/// altitudes. The RS41 reports position as ECEF, so this is the last step to
/// a lat/lon that can go on a map.
pub fn ecef_to_geodetic(x: f64, y: f64, z: f64) -> (f64, f64, f64) {
    const A: f64 = 6_378_137.0; // semi-major axis
    const F: f64 = 1.0 / 298.257_223_563; // flattening
    let b = A * (1.0 - F); // semi-minor
    let e2 = F * (2.0 - F); // first eccentricity²
    let ep2 = (A * A - b * b) / (b * b); // second eccentricity²

    let p = (x * x + y * y).sqrt();
    let lon = y.atan2(x);
    if p < 1e-9 {
        // On the polar axis.
        let lat = if z >= 0.0 {
            std::f64::consts::FRAC_PI_2
        } else {
            -std::f64::consts::FRAC_PI_2
        };
        let alt = z.abs() - b;
        return (lat.to_degrees(), lon.to_degrees(), alt);
    }
    let theta = (z * A).atan2(p * b);
    let lat = (z + ep2 * b * theta.sin().powi(3)).atan2(p - e2 * A * theta.cos().powi(3));
    let n = A / (1.0 - e2 * lat.sin() * lat.sin()).sqrt();
    let alt = p / lat.cos() - n;
    (lat.to_degrees(), lon.to_degrees(), alt)
}

/// Inverse of [`ecef_to_geodetic`] — only needed to test the round-trip.
#[cfg(test)]
fn geodetic_to_ecef(lat_deg: f64, lon_deg: f64, alt_m: f64) -> (f64, f64, f64) {
    const A: f64 = 6_378_137.0;
    const F: f64 = 1.0 / 298.257_223_563;
    let e2 = F * (2.0 - F);
    let (lat, lon) = (lat_deg.to_radians(), lon_deg.to_radians());
    let n = A / (1.0 - e2 * lat.sin() * lat.sin()).sqrt();
    let x = (n + alt_m) * lat.cos() * lon.cos();
    let y = (n + alt_m) * lat.cos() * lon.sin();
    let z = (n * (1.0 - e2) + alt_m) * lat.sin();
    (x, y, z)
}

// ---------------------------------------------------------------------------
// Frame whitening (de-mask)
// ---------------------------------------------------------------------------

/// The fixed 64-byte XOR whitening the RS41 applies to its frame after the
/// header. XORing with it again recovers the data (it is its own inverse).
pub const MASK: [u8; 64] = [
    0x96, 0x83, 0x3E, 0x51, 0xB1, 0x49, 0x08, 0x98, 0x32, 0x05, 0x59, 0x0E, 0xF9, 0x44, 0xC6, 0x26,
    0x21, 0x60, 0xC2, 0xEA, 0x79, 0x5D, 0x6D, 0xA1, 0x54, 0x69, 0x47, 0x0C, 0xDC, 0xE8, 0x5C, 0xF1,
    0xF7, 0x76, 0x82, 0x7F, 0x07, 0x99, 0xA2, 0x2C, 0x93, 0x7C, 0x30, 0x63, 0xF5, 0x10, 0x2E, 0x61,
    0xD0, 0xBC, 0xB4, 0xB6, 0x06, 0xAA, 0xF4, 0x23, 0x78, 0x6E, 0x3B, 0xAE, 0xBF, 0x7B, 0x4C, 0xC1,
];

/// XOR `buf` with the repeating mask, starting the mask at phase 0 for
/// `buf[0]`. Self-inverse: applying it twice is the identity.
pub fn demask(buf: &mut [u8]) {
    for (i, b) in buf.iter_mut().enumerate() {
        *b ^= MASK[i % MASK.len()];
    }
}

// ---------------------------------------------------------------------------
// Frame assembly: header → de-whiten → error-correct → blocks → position
// ---------------------------------------------------------------------------

/// The RS41 frame header (post bit-sync), used to find frame start.
pub const HEADER: [u8; 8] = [0x10, 0xB6, 0xCA, 0x11, 0x22, 0x96, 0x12, 0xF8];

/// Block type carrying the GPS position (ECEF x/y/z).
pub const BLOCK_GPS_POS: u8 = 0x7B;

/// Walk the typed blocks in an already-de-whitened, error-corrected frame
/// body and return the first valid GPS-position block as a position.
///
/// Block layout: `[type:1][len:1][payload:len][crc16:2]`, the CRC over
/// type+len+payload. The 0x7B payload begins with three little-endian i32
/// ECEF coordinates in centimetres.
pub fn position_from_blocks(body: &[u8]) -> Option<SondePosition> {
    let mut i = 0usize;
    while i + 4 <= body.len() {
        let btype = body[i];
        let len = body[i + 1] as usize;
        let end = i + 2 + len + 2;
        if end > body.len() {
            break;
        }
        let crc_given = u16::from_le_bytes([body[end - 2], body[end - 1]]);
        let crc_calc = crc16(&body[i..end - 2]);
        if crc_given == crc_calc && btype == BLOCK_GPS_POS && len >= 12 {
            let p = &body[i + 2..];
            let xr = i32::from_le_bytes([p[0], p[1], p[2], p[3]]) as f64 / 100.0;
            let yr = i32::from_le_bytes([p[4], p[5], p[6], p[7]]) as f64 / 100.0;
            let zr = i32::from_le_bytes([p[8], p[9], p[10], p[11]]) as f64 / 100.0;
            let (lat, lon, alt) = ecef_to_geodetic(xr, yr, zr);
            // Reject obviously bogus fixes (a failed CRC can still collide).
            if (-90.0..=90.0).contains(&lat) && (-180.0..=180.0).contains(&lon) && alt > -500.0
                && alt < 60_000.0
            {
                return Some(SondePosition {
                    lat_deg: lat,
                    lon_deg: lon,
                    alt_m: alt,
                });
            }
        }
        i = end;
    }
    None
}

/// Full engine entry point: given a raw frame that starts with [`HEADER`],
/// de-whiten the body, Reed–Solomon error-correct the two interleaved code
/// blocks, and pull out the GPS position.
///
/// `rs` is reused across calls so its tables aren't rebuilt each frame.
///
/// NOTE: the parity offset and the even/odd interleave below follow the
/// published RS41 layout; they are exercised end-to-end by
/// [`tests::frame_roundtrip`] on a synthetic frame, but must be confirmed
/// against a real captured frame when the live GFSK path is wired up.
pub fn parse_frame(rs: &Rs, raw: &[u8]) -> Option<SondePosition> {
    if raw.len() < HEADER.len() + 2 * RS_PARITY + 4 || raw[..HEADER.len()] != HEADER {
        return None;
    }
    let mut body = raw[HEADER.len()..].to_vec();
    demask(&mut body);

    // The body ends with 2 × 24 interleaved RS parity bytes; the data they
    // protect is everything before them, split even/odd into two codewords.
    let total = body.len();
    let data_len = total - 2 * RS_PARITY;
    for cwsel in 0..2usize {
        // Gather this codeword's data bytes (every other byte) then its
        // parity (the matching half of the trailing parity region).
        let mut cw = [0u8; 255];
        let data_bytes: Vec<usize> = (0..data_len).filter(|k| k % 2 == cwsel).collect();
        let n_data = data_bytes.len();
        // Right-align into a 255-long codeword (shortened RS): leading zeros.
        let pad = 255 - RS_PARITY - n_data;
        for (slot, &k) in data_bytes.iter().enumerate() {
            cw[pad + slot] = body[k];
        }
        for p in 0..RS_PARITY {
            cw[255 - RS_PARITY + p] = body[data_len + 2 * p + cwsel];
        }
        rs.decode(&mut cw)?;
        // Write corrected data back.
        for (slot, &k) in data_bytes.iter().enumerate() {
            body[k] = cw[pad + slot];
        }
    }

    position_from_blocks(&body[..data_len])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rs_corrects_up_to_twelve_errors() {
        let rs = Rs::new();
        // deterministic pseudo-random message
        let mut msg = [0u8; 231];
        let mut s: u32 = 0x1234_5678;
        for m in msg.iter_mut() {
            s = s.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
            *m = (s >> 16) as u8;
        }
        let parity = rs.encode_parity(&msg);
        let mut cw = [0u8; 255];
        cw[..231].copy_from_slice(&msg);
        cw[231..].copy_from_slice(&parity);

        // clean codeword decodes with zero corrections
        let mut clean = cw;
        assert_eq!(rs.decode(&mut clean), Some(0));
        assert_eq!(clean, cw);

        // corrupt exactly 12 distinct positions
        let mut bad = cw;
        for (n, pos) in [3, 10, 31, 55, 77, 100, 128, 150, 199, 220, 240, 254]
            .iter()
            .enumerate()
        {
            bad[*pos] ^= (0x5B + n as u8) | 1;
        }
        let fixed = rs.decode(&mut bad);
        assert_eq!(fixed, Some(12));
        assert_eq!(bad, cw, "12 errors must be fully corrected");
    }

    #[test]
    fn rs_reports_uncorrectable() {
        let rs = Rs::new();
        let msg = [7u8; 231];
        let parity = rs.encode_parity(&msg);
        let mut cw = [0u8; 255];
        cw[..231].copy_from_slice(&msg);
        cw[231..].copy_from_slice(&parity);
        // 13 errors is past the limit — must not claim a false success.
        for pos in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13] {
            cw[pos] ^= 0xA7;
        }
        // Either None, or a decode that fails its own syndrome re-check.
        assert_ne!(rs.decode(&mut cw.clone()), Some(0));
    }

    #[test]
    fn crc16_ccitt_vector() {
        // Standard CRC-16/CCITT-FALSE check value for "123456789".
        assert_eq!(crc16(b"123456789"), 0x29B1);
    }

    #[test]
    fn ecef_geodetic_roundtrip() {
        // A plausible balloon position: Southern Ontario, 18 km up.
        let (lat, lon, alt) = (43.95, -79.6, 18_000.0);
        let (x, y, z) = geodetic_to_ecef(lat, lon, alt);
        let (la, lo, al) = ecef_to_geodetic(x, y, z);
        assert!((la - lat).abs() < 1e-6, "lat {la} vs {lat}");
        assert!((lo - lon).abs() < 1e-6, "lon {lo} vs {lon}");
        assert!((al - alt).abs() < 1e-3, "alt {al} vs {alt}");
    }

    #[test]
    fn demask_is_self_inverse() {
        let mut buf: Vec<u8> = (0..200).map(|i| (i * 7 + 3) as u8).collect();
        let orig = buf.clone();
        demask(&mut buf);
        assert_ne!(buf, orig);
        demask(&mut buf);
        assert_eq!(buf, orig);
    }

    #[test]
    fn position_block_parses() {
        // Build one 0x7B block with a known ECEF position and good CRC.
        let (lat, lon, alt) = (43.95_f64, -79.6_f64, 18_000.0_f64);
        let (x, y, z) = geodetic_to_ecef(lat, lon, alt);
        let mut payload = Vec::new();
        payload.extend_from_slice(&((x * 100.0) as i32).to_le_bytes());
        payload.extend_from_slice(&((y * 100.0) as i32).to_le_bytes());
        payload.extend_from_slice(&((z * 100.0) as i32).to_le_bytes());
        let mut block = vec![BLOCK_GPS_POS, payload.len() as u8];
        block.extend_from_slice(&payload);
        let crc = crc16(&block);
        block.extend_from_slice(&crc.to_le_bytes());

        let pos = position_from_blocks(&block).expect("should parse");
        assert!((pos.lat_deg - lat).abs() < 1e-4);
        assert!((pos.lon_deg - lon).abs() < 1e-4);
        assert!((pos.alt_m - alt).abs() < 1.0);
    }

    #[test]
    fn frame_roundtrip() {
        // End-to-end on a synthetic frame: header + whitened, RS-protected
        // body carrying a position block, with 10 byte errors injected.
        let rs = Rs::new();
        let (lat, lon, alt) = (44.1_f64, -79.9_f64, 22_500.0_f64);
        let (x, y, z) = geodetic_to_ecef(lat, lon, alt);
        let mut payload = Vec::new();
        payload.extend_from_slice(&((x * 100.0) as i32).to_le_bytes());
        payload.extend_from_slice(&((y * 100.0) as i32).to_le_bytes());
        payload.extend_from_slice(&((z * 100.0) as i32).to_le_bytes());
        let mut block = vec![BLOCK_GPS_POS, payload.len() as u8];
        block.extend_from_slice(&payload);
        let crc = crc16(&block);
        block.extend_from_slice(&crc.to_le_bytes());

        // Pad the data region to an even length so the even/odd split is tidy.
        let mut data = block.clone();
        while data.len() % 2 != 0 {
            data.push(0);
        }
        let data_len = data.len();

        // Compute interleaved RS parity the way parse_frame expects.
        let mut parity_bytes = vec![0u8; 2 * RS_PARITY];
        for cwsel in 0..2usize {
            let data_bytes: Vec<usize> = (0..data_len).filter(|k| k % 2 == cwsel).collect();
            let n_data = data_bytes.len();
            let pad = 255 - RS_PARITY - n_data;
            let mut cw = [0u8; 255];
            for (slot, &k) in data_bytes.iter().enumerate() {
                cw[pad + slot] = data[k];
            }
            let par = rs.encode_parity(&cw[..255 - RS_PARITY]);
            for p in 0..RS_PARITY {
                parity_bytes[2 * p + cwsel] = par[p];
            }
        }

        // body = data + interleaved parity, then whiten and prepend header.
        let mut body = data.clone();
        body.extend_from_slice(&parity_bytes);
        demask(&mut body); // whiten (parse_frame de-whitens)
        let mut frame = HEADER.to_vec();
        frame.extend_from_slice(&body);

        // Inject 10 byte errors across the frame body.
        for (n, off) in [2, 9, 20, 33, 44, 51, 60, 70, 71, 72].iter().enumerate() {
            let idx = HEADER.len() + off;
            if idx < frame.len() {
                frame[idx] ^= 0x80 | (n as u8);
            }
        }

        let pos = parse_frame(&rs, &frame).expect("frame should decode");
        assert!((pos.lat_deg - lat).abs() < 1e-4, "lat {}", pos.lat_deg);
        assert!((pos.lon_deg - lon).abs() < 1e-4, "lon {}", pos.lon_deg);
        assert!((pos.alt_m - alt).abs() < 2.0, "alt {}", pos.alt_m);
    }
}
