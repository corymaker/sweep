//! # sweep-core
//!
//! Hardware-independent core of the Sweep scanner. No USB, no libusb, no
//! platform code — desktop and Android link this same crate and supply their
//! own capture layer.
//!
//! The pipeline, in order:
//!
//! ```text
//!   utterance ──► rules::parse ──► ScanPlan ──► plan::validate ──► resolve::resolve
//!                                                                        │
//!                                                                   RunPlan
//!                                                                        │
//!   IQ ──► Spectrum ──► Integrator ──► NoiseFloor ──► Detector ──► Tracker ──► UI
//!                                     │
//!                                  Squelch ──► audio
//! ```

pub mod adsb;
pub mod ais;
pub mod acars;
pub mod aircraft;
pub mod aprs;
pub mod sstv;
pub mod tone;
pub mod hdlc;
pub mod demod;
pub mod detect;
pub mod drone;
pub mod ism;
pub mod plan;
pub mod pocsag;
pub mod rds;
pub mod resolve;
pub mod rs41;
pub mod scheduler;
pub mod source;
pub mod rules;
pub mod spectrum;
pub mod voice;

pub use adsb::{Aircraft, AircraftTable, AdsbDemod, Frame as AdsbFrame};
pub use ais::{AisDemod, Vessel, VesselTable};
pub use acars::{AcarsDemod, AcarsLog, Block as AcarsBlock};
pub use aprs::{Afsk1200, Station, StationTable};
pub use sstv::{Picture, SstvDecoder};
pub use demod::{
    AmChannel, ComplexBandpassDecimator, CwChannel, Deemphasis, Discriminator, EnvelopeDetector,
    LowpassDecimator, NfmChannel, SsbChannel,
};
pub use detect::{Detection, Detector, NoiseFloor, Squelch, SquelchState, Track, Tracker};
pub use drone::{BandMap, Signature as DroneSignature, Stare};
pub use ism::{analyse as ism_analyse, Analysis as IsmAnalysis, Burst as IsmBurst, BurstDetector};
pub use plan::{Channel, Demod, PlanError, Provenance, ScanPlan, Window};
pub use pocsag::{Message as Page, PagerChannel, PocsagDemod};
pub use resolve::{resolve, RunPlan, TunerWindow};
pub use scheduler::{Mode, Scheduler, Task};
pub use source::{FakeSource, IqSource, SourceError, TunerGain};
pub use spectrum::{Integrator, Spectrum};
