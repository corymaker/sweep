//! The rule parser: turns most of what you would actually say into a plan
//! without a model anywhere in the loop.
//!
//! This is the front door. The language model is the fallback for what falls
//! through here, not the other way round.

use crate::plan::*;

struct BandRule {
    keys: &'static [&'static str],
    name: &'static str,
    f0: f64,
    f1: f64,
    demod: Demod,
    step_khz: f64,
    priority: &'static [f64],
}

const BANDS: &[BandRule] = &[
    BandRule {
        keys: &["aviation", "air traffic", "airband", "air band", "aircraft", "atc", "planes"],
        name: "Airband",
        f0: 118.0,
        f1: 137.0,
        demod: Demod::Am,
        step_khz: 25.0,
        priority: &[121.5],
    },
    BandRule {
        keys: &["marine", "boats", "coast guard", "vhf marine", "ships"],
        name: "Marine VHF",
        f0: 156.0,
        f1: 162.025,
        demod: Demod::Nfm,
        step_khz: 25.0,
        priority: &[156.8],
    },
    BandRule {
        keys: &["weather", "wx", "environment canada", "noaa"],
        name: "Weather radio",
        f0: 162.400,
        f1: 162.550,
        demod: Demod::Nfm,
        step_khz: 25.0,
        priority: &[],
    },
    BandRule {
        keys: &["2 m", "2m", "two meter", "two metre", "144"],
        name: "2 m amateur",
        f0: 144.0,
        f1: 148.0,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        keys: &["70 cm", "70cm", "seventy cm", "440", "repeaters"],
        name: "70 cm amateur",
        f0: 420.0,
        f1: 450.0,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        keys: &["frs", "gmrs", "walkie", "walkies", "handhelds"],
        name: "FRS / GMRS",
        f0: 462.5,
        f1: 467.75,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        keys: &["fm", "radio stations", "broadcast", "music"],
        name: "FM broadcast",
        f0: 88.0,
        f1: 108.0,
        demod: Demod::Wfm,
        step_khz: 200.0,
        priority: &[],
    },
    BandRule {
        keys: &["ism", "433", "sensors", "remotes"],
        name: "ISM 433",
        f0: 433.05,
        f1: 434.79,
        demod: Demod::Nfm,
        step_khz: 25.0,
        priority: &[],
    },
    BandRule {
        keys: &["railway", "rail", "trains"],
        name: "Railway VHF",
        f0: 159.81,
        f1: 161.565,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        keys: &["cb", "citizens band", "cb radio"],
        name: "CB Radio",
        f0: 26.965,
        f1: 27.405,
        demod: Demod::Am,
        step_khz: 10.0,
        priority: &[],
    },
    BandRule {
        keys: &["vor", "navigation", "navaid", "nav"],
        name: "VOR / navaids",
        f0: 108.0,
        f1: 118.0,
        demod: Demod::Am,
        step_khz: 50.0,
        priority: &[],
    },
    BandRule {
        // Weather-satellite APT is gone, but this slice still carries
        // amateur and cubesat downlinks worth watching during a pass.
        keys: &["satellite", "satellites", "sat", "space"],
        name: "Satellite VHF",
        f0: 136.0,
        f1: 138.0,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        // Much North American public safety has moved to encrypted
        // digital; whatever analog remains lives here.
        keys: &["police", "fire", "ems", "emergency", "public safety"],
        name: "Public safety VHF",
        f0: 150.0,
        f1: 174.0,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        keys: &["business", "industrial", "uhf business", "public safety uhf"],
        name: "Business / public safety UHF",
        f0: 450.0,
        f1: 470.0,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    BandRule {
        keys: &["radiosonde", "sonde", "weather balloon", "balloon"],
        name: "Radiosondes",
        f0: 400.0,
        f1: 406.0,
        demod: Demod::Nfm,
        step_khz: 25.0,
        priority: &[],
    },
    BandRule {
        keys: &["900", "33cm", "900 mhz", "ism 900"],
        name: "33cm / 900 MHz ISM",
        f0: 902.0,
        f1: 928.0,
        demod: Demod::Nfm,
        step_khz: 25.0,
        priority: &[],
    },
    BandRule {
        // Trunked control channels are visible here even though following
        // the voice traffic would need a trunk-tracking decoder.
        keys: &["800", "trunked", "800 mhz"],
        name: "800 MHz trunked",
        f0: 851.0,
        f1: 869.0,
        demod: Demod::Nfm,
        step_khz: 12.5,
        priority: &[],
    },
    // --- HF, reachable only via direct sampling -------------------------
    // These sit below the R828D's ~24 MHz tuning floor, so they need the
    // direct-sampling path (the worker switches it on automatically).
    // Expect noticeably lower sensitivity than the tuner gives on VHF, and
    // a long wire rather than a whip.
    BandRule {
        keys: &["80m", "80 meter", "80 meters"],
        name: "80m amateur",
        f0: 3.5,
        f1: 4.0,
        demod: Demod::Lsb,
        step_khz: 1.0,
        priority: &[],
    },
    BandRule {
        keys: &["shortwave", "world band", "international"],
        name: "Shortwave 49m",
        f0: 5.9,
        f1: 6.2,
        demod: Demod::Am,
        step_khz: 5.0,
        priority: &[],
    },
    BandRule {
        keys: &["40m", "40 meter", "40 meters"],
        name: "40m amateur",
        f0: 7.0,
        f1: 7.3,
        demod: Demod::Lsb,
        step_khz: 1.0,
        priority: &[],
    },
    BandRule {
        keys: &["31m", "shortwave 31"],
        name: "Shortwave 31m",
        f0: 9.4,
        f1: 9.9,
        demod: Demod::Am,
        step_khz: 5.0,
        priority: &[],
    },
    BandRule {
        keys: &["20m", "20 meter", "20 meters"],
        name: "20m amateur",
        f0: 14.0,
        f1: 14.35,
        demod: Demod::Usb,
        step_khz: 1.0,
        priority: &[],
    },
];

/// Which of the built-in bands (if any) a frequency falls in. Reuses the
/// same table `parse` matches keywords against, so this can never drift out
/// of sync with what the scanner actually knows how to tune.
pub fn identify(freq_mhz: f64) -> Option<&'static str> {
    BANDS
        .iter()
        .find(|b| freq_mhz >= b.f0 && freq_mhz <= b.f1)
        .map(|b| b.name)
}

/// Pull a bare frequency out of free text. Accepts "146.94", "146.94 MHz",
/// "146940 kHz". Returns MHz.
fn find_frequency(s: &str) -> Option<f64> {
    let lower = s.to_ascii_lowercase();
    let bytes = lower.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if !bytes[i].is_ascii_digit() {
            i += 1;
            continue;
        }
        let start = i;
        while i < bytes.len() && (bytes[i].is_ascii_digit() || bytes[i] == b'.') {
            i += 1;
        }
        let tok = &lower[start..i];
        // A number with no decimal point and few digits is more likely a band
        // nickname ("2 m", "440") than a tuned frequency; let BANDS win those.
        let has_dot = tok.contains('.');
        let val: f64 = match tok.parse() {
            Ok(v) => v,
            Err(_) => continue,
        };
        let rest = lower[i..].trim_start();
        let khz = rest.starts_with("khz") || rest.starts_with("k hz");
        let mhz = rest.starts_with("mhz") || rest.starts_with("m hz") || rest.starts_with("meg");
        let v = if khz { val / 1000.0 } else { val };
        if !has_dot && !khz && !mhz {
            continue;
        }
        if in_range(v, true) {
            return Some(v);
        }
    }
    None
}

/// Try to build a plan without a model. Returns `None` when nothing matched,
/// which is the signal to fall through to the language layer.
pub fn parse(utterance: &str) -> Option<ScanPlan> {
    let u = utterance.to_ascii_lowercase();

    // An explicit frequency always wins: the user typed a number, they mean it.
    if let Some(f) = find_frequency(&u) {
        let demod = if (88.0..108.0).contains(&f) {
            Demod::Wfm
        } else if (118.0..137.0).contains(&f) {
            Demod::Am
        } else {
            Demod::Nfm
        };
        return Some(ScanPlan {
            name: format!("{f:.4} MHz").replace(".0000", ""),
            windows: vec![],
            channels: vec![Channel::new(f, "Tuned")],
            demod,
            step_khz: if demod == Demod::Wfm { 200.0 } else { 12.5 },
            squelch_db: 8.0,
            hang_ms: 2000,
            dwell_ms: 40,
            priority: vec![],
            lockout: vec![],
            ctcss_hz: None,
            source: "user".into(),
        });
    }

    // Longest keyword first, so "vhf marine" beats "marine" and "2 m" does not
    // shadow a longer phrase containing it.
    let mut best: Option<(&BandRule, usize)> = None;
    for b in BANDS {
        for k in b.keys {
            if u.contains(k) {
                let better = best.map_or(true, |(_, len)| k.len() > len);
                if better {
                    best = Some((b, k.len()));
                }
            }
        }
    }
    let (b, _) = best?;
    // Densely-occupied bands defeat blind peak detection: the noise-floor
    // estimator's median lands on signal rather than noise when most of a
    // window is occupied, so every station's SNR reads low and nothing
    // clears squelch. Bands with a known channel raster get an explicit
    // list instead, which is what a real scanner checks.
    //
    // The channel count barely affects speed: one 2.4 MHz tuner window
    // already contains ~96 channels at 25 kHz spacing, and the FFT sees
    // all of them at once. Covering airband's 760 channels takes 8
    // retunes, not 760 — so the cap here only exists to bound memory on
    // something absurd, not to keep scanning fast.
    let channels = if b.step_khz > 0.0 {
        let span_khz = (b.f1 - b.f0) * 1000.0;
        let count = (span_khz / b.step_khz).floor() as usize;
        if count > 0 && count <= 4096 {
            // North American FM lives on odd tenths (87.9, 88.1, ...), so
            // start from the first raster point at or above f0 rather than
            // from f0 itself.
            let step_mhz = b.step_khz / 1000.0;
            let first = if b.demod == Demod::Wfm {
                let mut f = 87.9;
                while f < b.f0 - 1e-9 {
                    f += step_mhz;
                }
                f
            } else {
                b.f0
            };
            let mut v = Vec::new();
            let mut f = first;
            while f <= b.f1 + 1e-9 && v.len() <= 4096 {
                v.push(Channel::new(f, b.name));
                f += step_mhz;
            }
            v
        } else {
            vec![]
        }
    } else {
        vec![]
    };
    Some(ScanPlan {
        name: b.name.into(),
        // When the band is channelized, the channels define coverage —
        // resolve() packs windows around them. Also passing the raw range
        // would make it emit a second, overlapping set of blind windows.
        windows: if channels.is_empty() {
            vec![Window { f0: b.f0, f1: b.f1 }]
        } else {
            vec![]
        },
        channels,
        demod: b.demod,
        step_khz: b.step_khz,
        squelch_db: 8.0,
        hang_ms: 2000,
        dwell_ms: 40,
        priority: b.priority.to_vec(),
        lockout: vec![],
        ctcss_hz: None,
        source: "rules".into(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::resolve::resolve;

    #[test]
    fn parses_the_common_bands() {
        for (utterance, expect) in [
            ("listen to air traffic", "Airband"),
            ("show me marine", "Marine VHF"),
            ("what's the weather radio doing", "Weather radio"),
            ("scan the 2m band", "2 m amateur"),
            ("70cm repeaters", "70 cm amateur"),
            ("any frs chatter", "FRS / GMRS"),
            ("just radio stations", "FM broadcast"),
        ] {
            let p = parse(utterance).unwrap_or_else(|| panic!("no match for {utterance:?}"));
            assert_eq!(p.name, expect, "for {utterance:?}");
            assert!(p.validate(false).is_ok(), "invalid plan for {utterance:?}");
        }
    }

    #[test]
    fn aviation_is_am_with_guard_priority() {
        let p = parse("airband").unwrap();
        assert_eq!(p.demod, Demod::Am);
        assert_eq!(p.priority, vec![121.5]);
    }

    #[test]
    fn a_typed_frequency_wins_and_is_attributed_to_the_user() {
        let p = parse("go to 146.940").unwrap();
        assert_eq!(p.channels.len(), 1);
        assert!((p.channels[0].freq_mhz - 146.94).abs() < 1e-9);
        assert_eq!(p.source, "user");
        assert_eq!(Provenance::parse(&p.source), Provenance::User);
    }

    #[test]
    fn understands_khz() {
        let p = parse("tune 162550 kHz").unwrap();
        assert!((p.channels[0].freq_mhz - 162.55).abs() < 1e-6);
    }

    #[test]
    fn picks_demodulation_from_the_frequency() {
        assert_eq!(parse("101.1 MHz").unwrap().demod, Demod::Wfm);
        assert_eq!(parse("118.8 MHz").unwrap().demod, Demod::Am);
        assert_eq!(parse("146.52 MHz").unwrap().demod, Demod::Nfm);
    }

    #[test]
    fn a_typed_frequency_needs_no_retuning() {
        let p = parse("118.8 MHz").unwrap();
        let rp = resolve(&p, false).unwrap();
        assert!(rp.is_single_window());
        assert_eq!(rp.revisit_ms(), 0);
    }

    #[test]
    fn rejects_a_frequency_the_tuner_cannot_reach() {
        // 2.4 GHz is outside the R820T2 range: no plan, fall through.
        assert!(parse("2400.0 MHz").is_none());
    }

    #[test]
    fn returns_none_for_something_it_does_not_know() {
        assert!(parse("what is my neighbour's doorbell doing").is_none());
        assert!(parse("").is_none());
    }

    #[test]
    fn every_rule_produces_a_valid_resolvable_plan() {
        for b in BANDS {
            let p = parse(b.keys[0]).unwrap();
            p.validate(false)
                .unwrap_or_else(|e| panic!("{} invalid: {e}", b.name));
            let rp = resolve(&p, false).unwrap();
            assert!(!rp.windows.is_empty(), "{} produced no windows", b.name);
        }
    }
}
