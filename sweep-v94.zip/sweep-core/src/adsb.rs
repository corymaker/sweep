//! ADS-B — Automatic Dependent Surveillance–Broadcast, on 1090 MHz.
//!
//! Aircraft broadcast their identity, position, altitude and velocity in the
//! clear, twice a second, with no request from the ground. This module turns
//! raw IQ into that data.
//!
//! Why this path is separate from everything else in the crate: ADS-B is
//! pulse-position modulation at 1 Mbit/s, not a voice channel. There is no
//! carrier to squelch on, no filter bandwidth to choose, and no audio. The
//! scanner's sweep/park machinery would be actively wrong here — the radio
//! has to sit on 1090 MHz and stay there, because transmissions are
//! unscheduled bursts a few hundred microseconds long and anything you miss
//! is gone.
//!
//! ```text
//!   IQ @ 2 MS/s ──► magnitude ──► preamble correlate ──► PPM slice
//!                                                             │
//!                                     112 bits ──► CRC-24 ──► ME decode
//!                                                             │
//!                                       ident / position / velocity
//! ```
//!
//! The sample rate matters. At exactly 2 MS/s each half-bit of the 1 µs
//! PPM symbol is one sample, so slicing is a comparison between adjacent
//! samples with no interpolation and no fractional indexing. That is why
//! the worker retunes the dongle to 2 MS/s for this mode and back to
//! 2.4 MS/s on the way out.
//!
//! What is *not* here: a Mode S error-correcting decoder. dump1090 and
//! friends will flip one or two bits to force a CRC match, which recovers
//! more frames but also manufactures aircraft that do not exist. Frames
//! here are accepted only when the parity is already correct.

use std::collections::HashMap;
use std::time::{Duration, Instant};

/// Sample rate this decoder expects. Not a suggestion — the bit slicer
/// assumes exactly two samples per microsecond.
pub const ADSB_RATE: u32 = 2_000_000;
/// The one frequency ADS-B lives on.
pub const ADSB_FREQ_HZ: f64 = 1_090_000_000.0;

const PREAMBLE_SAMPLES: usize = 16; // 8 µs
const LONG_BITS: usize = 112;
const SHORT_BITS: usize = 56;
const LONG_SAMPLES: usize = LONG_BITS * 2;

/// Below this difference between the two halves of a bit period, the symbol
/// is too weak to call and we reuse the previous bit rather than guess.
/// Scaled for magnitudes in roughly 0..1.4 (unit-normalised I/Q).
const WEAK_BIT: f32 = 0.006;

// ---------------------------------------------------------------------------
// CRC
// ---------------------------------------------------------------------------

/// Mode S parity generator, x^24 + x^23 + x^22 + x^21 + x^20 + x^19 + x^18 +
/// x^17 + x^16 + x^15 + x^14 + x^13 + x^12 + x^10 + x^3 + 1, without its
/// leading term.
const POLY: u32 = 0x00FF_F409;

/// Remainder of `data · x^24` modulo the Mode S generator.
///
/// Feeding the message's data bytes (everything but the trailing three
/// parity bytes) gives a value that equals the parity field exactly when
/// the frame arrived intact.
pub fn crc24(data: &[u8]) -> u32 {
    let mut rem: u32 = 0;
    for &b in data {
        rem ^= (b as u32) << 16;
        for _ in 0..8 {
            rem = if rem & 0x0080_0000 != 0 {
                (rem << 1) ^ POLY
            } else {
                rem << 1
            };
            rem &= 0x00FF_FFFF;
        }
    }
    rem
}

/// Parity field carried in the last three bytes of a frame.
fn parity_of(msg: &[u8]) -> u32 {
    let n = msg.len();
    ((msg[n - 3] as u32) << 16) | ((msg[n - 2] as u32) << 8) | msg[n - 1] as u32
}

/// `true` when the frame's own parity matches what its data implies.
///
/// This is only meaningful for the downlink formats whose parity is plain
/// CRC — DF11 with interrogator identifier zero, and the DF17/DF18 extended
/// squitters we care about. In DF4/5/20/21 the parity is XORed with the
/// aircraft address, so a mismatch there is expected, not an error.
pub fn crc_ok(msg: &[u8]) -> bool {
    if msg.len() < 7 {
        return false;
    }
    crc24(&msg[..msg.len() - 3]) == parity_of(msg)
}

// ---------------------------------------------------------------------------
// Demodulator
// ---------------------------------------------------------------------------

/// Turns a stream of IQ samples into raw Mode S frames.
///
/// Holds a small tail between calls so a burst straddling two capture
/// buffers is not lost.
pub struct AdsbDemod {
    mag: Vec<f32>,
    /// Frames whose CRC checked out, plus the ones that did not, so the UI
    /// can show a real signal-quality figure rather than a silent filter.
    pub frames_ok: u64,
    pub frames_bad: u64,
    pub preambles: u64,
}

impl Default for AdsbDemod {
    fn default() -> Self {
        Self::new()
    }
}

impl AdsbDemod {
    pub fn new() -> Self {
        AdsbDemod {
            mag: Vec::with_capacity(1 << 20),
            frames_ok: 0,
            frames_bad: 0,
            preambles: 0,
        }
    }

    /// Feed raw unsigned-8-bit IQ exactly as the dongle produces it and
    /// collect whatever complete, valid frames fall out.
    pub fn process_u8(&mut self, raw: &[u8], out: &mut Vec<Frame>) {
        self.mag.reserve(raw.len() / 2);
        for pair in raw.chunks_exact(2) {
            let i = (pair[0] as f32 - 127.5) * (1.0 / 127.5);
            let q = (pair[1] as f32 - 127.5) * (1.0 / 127.5);
            self.mag.push((i * i + q * q).sqrt());
        }
        self.scan(out);
    }

    fn scan(&mut self, out: &mut Vec<Frame>) {
        let m = &self.mag[..];
        if m.len() < PREAMBLE_SAMPLES + LONG_SAMPLES {
            return;
        }
        let end = m.len() - (PREAMBLE_SAMPLES + LONG_SAMPLES);
        let mut bits = [0u8; LONG_BITS];
        let mut j = 0usize;
        while j < end {
            // The 8 µs preamble is pulses at 0.0, 1.0, 3.5 and 4.5 µs, then
            // silence. At two samples per microsecond that is highs at
            // offsets 0, 2, 7, 9 with the rest low — a shape distinctive
            // enough that testing it directly is cheaper and more selective
            // than correlating.
            if !(m[j] > m[j + 1]
                && m[j + 1] < m[j + 2]
                && m[j + 2] > m[j + 3]
                && m[j + 3] < m[j]
                && m[j + 4] < m[j]
                && m[j + 5] < m[j]
                && m[j + 6] < m[j]
                && m[j + 7] > m[j + 8]
                && m[j + 8] < m[j + 9]
                && m[j + 9] > m[j + 6])
            {
                j += 1;
                continue;
            }

            // Mean of the four pulse tops, deliberately divided by six
            // rather than four: a threshold set at the true average rejects
            // real frames whose pulses are uneven, which is most of them.
            let high = (m[j] + m[j + 2] + m[j + 7] + m[j + 9]) / 6.0;

            // The gaps inside and after the preamble must actually be quiet.
            // Without this, the tail of one frame reads as the start of
            // another and the decoder spends its time on garbage.
            if m[j + 4] >= high || m[j + 5] >= high {
                j += 1;
                continue;
            }
            if m[j + 11] >= high || m[j + 12] >= high || m[j + 13] >= high || m[j + 14] >= high {
                j += 1;
                continue;
            }
            self.preambles += 1;

            let base = j + PREAMBLE_SAMPLES;
            let mut errors = 0u32;
            let mut signal = 0.0f32;
            for i in 0..LONG_BITS {
                let a = m[base + i * 2];
                let b = m[base + i * 2 + 1];
                signal += a.max(b);
                let delta = (a - b).abs();
                bits[i] = if i > 0 && delta < WEAK_BIT {
                    errors += 1;
                    bits[i - 1]
                } else if a > b {
                    1
                } else {
                    0
                };
            }

            let mut msg = [0u8; 14];
            for i in 0..LONG_BITS {
                if bits[i] != 0 {
                    msg[i / 8] |= 1 << (7 - (i % 8));
                }
            }

            let df = msg[0] >> 3;
            let len = if df & 0x10 != 0 { 14 } else { 7 };
            let nbits = if len == 14 { LONG_BITS } else { SHORT_BITS };

            // A frame that needed guesses on more than a handful of bits is
            // not worth the CRC's time.
            if errors > (nbits as u32) / 8 {
                j += 1;
                continue;
            }

            if crc_ok(&msg[..len]) {
                self.frames_ok += 1;
                out.push(Frame {
                    bytes: msg,
                    len,
                    // Mean pulse height over the frame, as dB relative to
                    // full scale. Not calibrated to anything absolute — the
                    // dongle has no reference — but comparable between
                    // aircraft, which is what makes it useful.
                    rssi_db: 20.0 * (signal / nbits as f32).max(1e-6).log10(),
                });
                // Skip the whole frame: its own bit transitions would
                // otherwise generate spurious preamble hits.
                j += PREAMBLE_SAMPLES + nbits * 2;
                continue;
            }
            self.frames_bad += 1;
            j += 1;
        }

        // Keep exactly the tail that was too short to hold a whole frame,
        // so the next buffer resumes where this scan stopped. Keeping more
        // would re-examine samples already scanned and report the same
        // frame twice; keeping less would lose any burst landing on the
        // seam between two captures.
        const KEEP: usize = PREAMBLE_SAMPLES + LONG_SAMPLES;
        let keep = KEEP.min(self.mag.len());
        let drop_n = self.mag.len() - keep;
        self.mag.drain(..drop_n);
    }
}

/// A frame that passed parity. `len` is 7 or 14 bytes.
#[derive(Clone, Copy, Debug)]
pub struct Frame {
    pub bytes: [u8; 14],
    pub len: usize,
    pub rssi_db: f32,
}

impl Frame {
    pub fn df(&self) -> u8 {
        self.bytes[0] >> 3
    }

    /// Transmitting aircraft's 24-bit ICAO address, for the formats that
    /// state it outright. DF11 and DF17/18 do; the interrogation replies
    /// only carry it XORed into the parity.
    pub fn icao(&self) -> Option<u32> {
        match self.df() {
            11 | 17 | 18 => Some(
                ((self.bytes[1] as u32) << 16)
                    | ((self.bytes[2] as u32) << 8)
                    | self.bytes[3] as u32,
            ),
            _ => None,
        }
    }

    /// The 56-bit ME field of an extended squitter.
    pub fn me(&self) -> Option<[u8; 7]> {
        if self.len != 14 || !matches!(self.df(), 17 | 18) {
            return None;
        }
        let mut me = [0u8; 7];
        me.copy_from_slice(&self.bytes[4..11]);
        Some(me)
    }

    pub fn hex(&self) -> String {
        self.bytes[..self.len]
            .iter()
            .map(|b| format!("{b:02X}"))
            .collect()
    }
}

// ---------------------------------------------------------------------------
// ME field decoding
// ---------------------------------------------------------------------------

/// Read `n` bits from `me` starting at bit `off`, counting from the first
/// bit of the ME field.
fn bits(me: &[u8; 7], off: usize, n: usize) -> u32 {
    let mut v = 0u32;
    for k in 0..n {
        let b = off + k;
        let bit = (me[b / 8] >> (7 - (b % 8))) & 1;
        v = (v << 1) | bit as u32;
    }
    v
}

const CALLSIGN_CHARS: &[u8; 64] = b"#ABCDEFGHIJKLMNOPQRSTUVWXYZ#####_###############0123456789######";

/// What one extended squitter told us.
#[derive(Clone, Debug)]
pub enum Message {
    /// Flight number / tail, as the crew entered it.
    Identity { callsign: String, category: u8 },
    /// Half of a position. Useless alone — see [`CprPair`].
    AirbornePosition {
        odd: bool,
        lat_cpr: u32,
        lon_cpr: u32,
        alt_ft: Option<i32>,
    },
    SurfacePosition {
        odd: bool,
        lat_cpr: u32,
        lon_cpr: u32,
    },
    /// Ground track and speed, already resolved out of the N/S–E/W pair.
    Velocity {
        ground_speed_kt: Option<f32>,
        heading_deg: Option<f32>,
        vert_rate_fpm: Option<i32>,
    },
    /// A type code we parse the header of but not the body.
    Other { type_code: u8 },
}

pub fn decode_me(me: &[u8; 7]) -> Message {
    let tc = bits(me, 0, 5) as u8;
    match tc {
        1..=4 => {
            let category = bits(me, 5, 3) as u8;
            let mut callsign = String::with_capacity(8);
            for k in 0..8 {
                let c = bits(me, 8 + k * 6, 6) as usize;
                let ch = CALLSIGN_CHARS[c] as char;
                if ch != '#' {
                    callsign.push(ch);
                }
            }
            Message::Identity {
                callsign: callsign.trim_end_matches('_').trim().to_string(),
                category,
            }
        }
        5..=8 => Message::SurfacePosition {
            odd: bits(me, 21, 1) == 1,
            lat_cpr: bits(me, 22, 17),
            lon_cpr: bits(me, 39, 17),
        },
        9..=18 | 20..=22 => Message::AirbornePosition {
            odd: bits(me, 21, 1) == 1,
            lat_cpr: bits(me, 22, 17),
            lon_cpr: bits(me, 39, 17),
            alt_ft: decode_altitude(bits(me, 8, 12) as u16),
        },
        19 => decode_velocity(me),
        _ => Message::Other { type_code: tc },
    }
}

/// The 12-bit altitude field of an airborne position message.
///
/// Bit 8 of the field ("Q") picks the encoding. Set means plain 25-foot
/// steps; clear means the old 100-foot Gillham/Gray code, which we do not
/// attempt — above 50,000 ft it is rare enough that a wrong number would be
/// worse than none.
fn decode_altitude(field: u16) -> Option<i32> {
    if field == 0 {
        return None;
    }
    let q = (field >> 4) & 1;
    if q == 1 {
        let n = (((field & 0x0FE0) >> 1) | (field & 0x000F)) as i32;
        Some(n * 25 - 1000)
    } else {
        None
    }
}

fn decode_velocity(me: &[u8; 7]) -> Message {
    let subtype = bits(me, 5, 3);
    let vr_sign = bits(me, 36, 1);
    let vr_raw = bits(me, 37, 9);
    let vert_rate_fpm = if vr_raw == 0 {
        None
    } else {
        let v = (vr_raw as i32 - 1) * 64;
        Some(if vr_sign == 1 { -v } else { v })
    };

    match subtype {
        1 | 2 => {
            // Subtype 2 is the supersonic scale. Four knots per count
            // instead of one — an aircraft that fast reporting on the
            // subsonic scale would read a quarter of its real speed.
            let scale = if subtype == 2 { 4.0 } else { 1.0 };
            let ew_dir = bits(me, 13, 1);
            let ew_raw = bits(me, 14, 10);
            let ns_dir = bits(me, 24, 1);
            let ns_raw = bits(me, 25, 10);
            if ew_raw == 0 || ns_raw == 0 {
                return Message::Velocity {
                    ground_speed_kt: None,
                    heading_deg: None,
                    vert_rate_fpm,
                };
            }
            let mut vew = (ew_raw as f32 - 1.0) * scale;
            let mut vns = (ns_raw as f32 - 1.0) * scale;
            if ew_dir == 1 {
                vew = -vew;
            }
            if ns_dir == 1 {
                vns = -vns;
            }
            let speed = (vew * vew + vns * vns).sqrt();
            let heading = (vew.atan2(vns).to_degrees() + 360.0) % 360.0;
            Message::Velocity {
                ground_speed_kt: Some(speed),
                heading_deg: Some(heading),
                vert_rate_fpm,
            }
        }
        3 | 4 => {
            // Airspeed-and-heading form, used when the aircraft has no
            // valid ground-referenced velocity.
            let hdg_valid = bits(me, 13, 1) == 1;
            let hdg = bits(me, 14, 10);
            let as_raw = bits(me, 25, 10);
            let scale = if subtype == 4 { 4.0 } else { 1.0 };
            Message::Velocity {
                ground_speed_kt: if as_raw == 0 {
                    None
                } else {
                    Some((as_raw as f32 - 1.0) * scale)
                },
                heading_deg: if hdg_valid {
                    Some(hdg as f32 * 360.0 / 1024.0)
                } else {
                    None
                },
                vert_rate_fpm,
            }
        }
        _ => Message::Other { type_code: 19 },
    }
}

// ---------------------------------------------------------------------------
// CPR
// ---------------------------------------------------------------------------

/// Number of longitude zones at a given latitude.
///
/// Compact Position Reporting divides the globe into zones so that 17 bits
/// can carry a position to a few metres; the count shrinks toward the poles
/// where the zones would otherwise be unusably narrow.
pub fn nl(lat: f64) -> i32 {
    let lat = lat.abs();
    if lat >= 87.0 {
        return 1;
    }
    if lat == 0.0 {
        return 59;
    }
    const NZ: f64 = 15.0;
    let a = 1.0 - (std::f64::consts::PI / (2.0 * NZ)).cos();
    let b = (lat.to_radians()).cos().powi(2);
    let x = 1.0 - a / b;
    (2.0 * std::f64::consts::PI / x.acos()).floor() as i32
}

/// The most recent even and odd halves of a position, kept until they can
/// be combined. Each is the raw 17-bit latitude and longitude as
/// transmitted — meaningless on its own.
#[derive(Clone, Copy, Default)]
pub struct CprPair {
    pub even: Option<(u32, u32)>,
    pub odd: Option<(u32, u32)>,
}

/// Combine an even/odd CPR pair into a latitude and longitude.
///
/// `even_newer` says which of the two arrived last; the position is
/// reported in that message's frame of reference.
///
/// Returns `None` when the two halves straddle a zone boundary, which makes
/// them unusable together — the next message pair will resolve it.
pub fn cpr_global(
    even: (u32, u32),
    odd: (u32, u32),
    even_newer: bool,
    surface: bool,
) -> Option<(f64, f64)> {
    let span = if surface { 90.0 } else { 360.0 };
    let dlat0 = span / 60.0;
    let dlat1 = span / 59.0;

    let lat_even = even.0 as f64 / 131072.0;
    let lat_odd = odd.0 as f64 / 131072.0;
    let lon_even = even.1 as f64 / 131072.0;
    let lon_odd = odd.1 as f64 / 131072.0;

    let j = (59.0 * lat_even - 60.0 * lat_odd + 0.5).floor();

    let mut rlat0 = dlat0 * (modulo(j, 60.0) + lat_even);
    let mut rlat1 = dlat1 * (modulo(j, 59.0) + lat_odd);
    if !surface {
        if rlat0 >= 270.0 {
            rlat0 -= 360.0;
        }
        if rlat1 >= 270.0 {
            rlat1 -= 360.0;
        }
    }
    if !(-90.0..=90.0).contains(&rlat0) || !(-90.0..=90.0).contains(&rlat1) {
        return None;
    }
    // Both halves have to land in the same longitude zone, or the zone
    // widths differ and the longitude arithmetic below is meaningless.
    if nl(rlat0) != nl(rlat1) {
        return None;
    }

    let (lat, lon_cpr, nl_v) = if even_newer {
        (rlat0, lon_even, nl(rlat0))
    } else {
        (rlat1, lon_odd, nl(rlat1))
    };
    let ni = if even_newer {
        nl_v.max(1)
    } else {
        (nl_v - 1).max(1)
    };
    let m = (lon_even * (nl_v - 1) as f64 - lon_odd * nl_v as f64 + 0.5).floor();
    let mut lon = (span / ni as f64) * (modulo(m, ni as f64) + lon_cpr);
    if lon >= 180.0 {
        lon -= 360.0;
    }
    Some((lat, lon))
}

fn modulo(a: f64, b: f64) -> f64 {
    let r = a - b * (a / b).floor();
    if r < 0.0 {
        r + b
    } else {
        r
    }
}

// ---------------------------------------------------------------------------
// Aircraft tracking
// ---------------------------------------------------------------------------

/// Everything currently known about one aircraft.
#[derive(Clone)]
pub struct Aircraft {
    pub icao: u32,
    pub callsign: Option<String>,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub alt_ft: Option<i32>,
    pub speed_kt: Option<f32>,
    pub heading_deg: Option<f32>,
    pub vert_rate_fpm: Option<i32>,
    pub rssi_db: f32,
    pub messages: u32,
    pub first_seen: Instant,
    pub last_seen: Instant,
    cpr: CprPair,
    cpr_even_at: Option<Instant>,
    cpr_odd_at: Option<Instant>,
}

impl Aircraft {
    fn new(icao: u32) -> Self {
        let now = Instant::now();
        Aircraft {
            icao,
            callsign: None,
            lat: None,
            lon: None,
            alt_ft: None,
            speed_kt: None,
            heading_deg: None,
            vert_rate_fpm: None,
            rssi_db: -100.0,
            messages: 0,
            first_seen: now,
            last_seen: now,
            cpr: CprPair::default(),
            cpr_even_at: None,
            cpr_odd_at: None,
        }
    }

    /// ICAO address as the six hex digits everyone actually quotes.
    pub fn hex_id(&self) -> String {
        format!("{:06X}", self.icao)
    }

    pub fn age(&self) -> Duration {
        self.last_seen.elapsed()
    }
}

/// The live picture: every aircraft heard recently, updated frame by frame.
pub struct AircraftTable {
    map: HashMap<u32, Aircraft>,
    /// How long an aircraft stays on the list after its last message.
    pub timeout: Duration,
}

impl Default for AircraftTable {
    fn default() -> Self {
        Self::new()
    }
}

impl AircraftTable {
    pub fn new() -> Self {
        AircraftTable {
            map: HashMap::new(),
            timeout: Duration::from_secs(60),
        }
    }

    /// Fold one verified frame into the picture. Returns the ICAO address
    /// it belonged to, when the frame carried one.
    pub fn ingest(&mut self, frame: &Frame) -> Option<u32> {
        let icao = frame.icao()?;
        let now = Instant::now();
        let ac = self.map.entry(icao).or_insert_with(|| Aircraft::new(icao));
        ac.last_seen = now;
        ac.messages += 1;
        // Smooth the level rather than take the latest frame: single-frame
        // RSSI swings several dB on fuselage shadowing alone.
        ac.rssi_db = if ac.messages == 1 {
            frame.rssi_db
        } else {
            ac.rssi_db * 0.8 + frame.rssi_db * 0.2
        };

        let me = match frame.me() {
            Some(m) => m,
            // DF11 is an all-call reply: it proves the aircraft is there
            // and gives its address, but carries nothing else.
            None => return Some(icao),
        };

        match decode_me(&me) {
            Message::Identity { callsign, .. } => {
                if !callsign.is_empty() {
                    ac.callsign = Some(callsign);
                }
            }
            Message::AirbornePosition {
                odd,
                lat_cpr,
                lon_cpr,
                alt_ft,
            } => {
                if alt_ft.is_some() {
                    ac.alt_ft = alt_ft;
                }
                Self::apply_cpr(ac, odd, lat_cpr, lon_cpr, now, false);
            }
            Message::SurfacePosition {
                odd,
                lat_cpr,
                lon_cpr,
            } => {
                ac.alt_ft = Some(0);
                Self::apply_cpr(ac, odd, lat_cpr, lon_cpr, now, true);
            }
            Message::Velocity {
                ground_speed_kt,
                heading_deg,
                vert_rate_fpm,
            } => {
                if ground_speed_kt.is_some() {
                    ac.speed_kt = ground_speed_kt;
                }
                if heading_deg.is_some() {
                    ac.heading_deg = heading_deg;
                }
                if vert_rate_fpm.is_some() {
                    ac.vert_rate_fpm = vert_rate_fpm;
                }
            }
            Message::Other { .. } => {}
        }
        Some(icao)
    }

    fn apply_cpr(
        ac: &mut Aircraft,
        odd: bool,
        lat_cpr: u32,
        lon_cpr: u32,
        now: Instant,
        surface: bool,
    ) {
        if odd {
            ac.cpr.odd = Some((lat_cpr, lon_cpr));
            ac.cpr_odd_at = Some(now);
        } else {
            ac.cpr.even = Some((lat_cpr, lon_cpr));
            ac.cpr_even_at = Some(now);
        }
        let (e, o) = match (ac.cpr.even, ac.cpr.odd) {
            (Some(e), Some(o)) => (e, o),
            _ => return,
        };
        let (te, to) = match (ac.cpr_even_at, ac.cpr_odd_at) {
            (Some(a), Some(b)) => (a, b),
            _ => return,
        };
        // An aircraft covers ground between the two halves. Beyond about
        // ten seconds the pair no longer describes one place and the
        // decoded position can be hundreds of kilometres out.
        let gap = if te > to {
            te.duration_since(to)
        } else {
            to.duration_since(te)
        };
        if gap > Duration::from_secs(10) {
            return;
        }
        if let Some((lat, lon)) = cpr_global(e, o, te >= to, surface) {
            ac.lat = Some(lat);
            ac.lon = Some(lon);
        }
    }

    /// Drop aircraft that have gone quiet.
    pub fn expire(&mut self) {
        let t = self.timeout;
        self.map.retain(|_, a| a.last_seen.elapsed() < t);
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    /// Aircraft with a resolved position.
    pub fn positioned(&self) -> usize {
        self.map.values().filter(|a| a.lat.is_some()).count()
    }

    /// Everything currently tracked, newest contact first.
    pub fn snapshot(&self) -> Vec<Aircraft> {
        let mut v: Vec<Aircraft> = self.map.values().cloned().collect();
        v.sort_by(|a, b| a.last_seen.cmp(&b.last_seen).reverse());
        v
    }

    pub fn clear(&mut self) {
        self.map.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn from_hex(s: &str) -> [u8; 14] {
        let mut out = [0u8; 14];
        for (i, c) in s.as_bytes().chunks(2).enumerate() {
            if i >= 14 {
                break;
            }
            out[i] = u8::from_str_radix(std::str::from_utf8(c).unwrap(), 16).unwrap();
        }
        out
    }

    // A real extended squitter, from the ICAO Annex 10 / mode-s.org worked
    // example. If the polynomial or the bit order were wrong this would not
    // close.
    const IDENT: &str = "8D4840D6202CC371C32CE0576098";

    #[test]
    fn parity_closes_on_a_real_frame() {
        let m = from_hex(IDENT);
        assert!(crc_ok(&m[..14]), "computed {:06X}", crc24(&m[..11]));
    }

    #[test]
    fn a_flipped_bit_is_rejected() {
        let mut m = from_hex(IDENT);
        m[5] ^= 0x08;
        assert!(!crc_ok(&m[..14]));
    }

    #[test]
    fn reads_the_address_and_callsign() {
        let m = from_hex(IDENT);
        let f = Frame {
            bytes: m,
            len: 14,
            rssi_db: 0.0,
        };
        assert_eq!(f.df(), 17);
        assert_eq!(f.icao(), Some(0x4840D6));
        match decode_me(&f.me().unwrap()) {
            Message::Identity { callsign, .. } => assert_eq!(callsign, "KLM1023"),
            other => panic!("expected identity, got {other:?}"),
        }
    }

    // Even/odd airborne position pair for the same aircraft, from the same
    // worked example. The published answer is 52.2572° N, 3.9192° E.
    const POS_EVEN: &str = "8D40621D58C382D690C8AC2863A7";
    const POS_ODD: &str = "8D40621D58C386435CC412692AD6";

    #[test]
    fn resolves_a_position_from_an_even_odd_pair() {
        let e = Frame {
            bytes: from_hex(POS_EVEN),
            len: 14,
            rssi_db: 0.0,
        };
        let o = Frame {
            bytes: from_hex(POS_ODD),
            len: 14,
            rssi_db: 0.0,
        };
        assert!(crc_ok(&e.bytes[..14]));
        assert!(crc_ok(&o.bytes[..14]));

        let (ec, oc) = match (decode_me(&e.me().unwrap()), decode_me(&o.me().unwrap())) {
            (
                Message::AirbornePosition {
                    lat_cpr: el,
                    lon_cpr: eo,
                    odd: false,
                    alt_ft,
                },
                Message::AirbornePosition {
                    lat_cpr: ol,
                    lon_cpr: oo,
                    odd: true,
                    ..
                },
            ) => {
                assert_eq!(alt_ft, Some(38000));
                ((el, eo), (ol, oo))
            }
            other => panic!("expected two airborne positions, got {other:?}"),
        };

        // Referenced to the even frame, which is the published answer.
        let (lat, lon) = cpr_global(ec, oc, true, false).expect("pair should resolve");
        assert!((lat - 52.2572).abs() < 0.001, "lat was {lat}");
        assert!((lon - 3.9194).abs() < 0.001, "lon was {lon}");

        // Referenced to the odd frame instead, the same pair lands a
        // kilometre away — which is what makes it worth tracking which
        // half arrived last rather than picking one arbitrarily.
        let (lat_o, _) = cpr_global(ec, oc, false, false).expect("pair should resolve");
        assert!((lat_o - 52.2658).abs() < 0.001, "lat was {lat_o}");
    }

    #[test]
    fn velocity_comes_out_in_knots_and_degrees() {
        // Same source: ground speed 159 kt, track 182.88°, climbing.
        let f = Frame {
            bytes: from_hex("8D485020994409940838175B284F"),
            len: 14,
            rssi_db: 0.0,
        };
        assert!(crc_ok(&f.bytes[..14]));
        match decode_me(&f.me().unwrap()) {
            Message::Velocity {
                ground_speed_kt,
                heading_deg,
                vert_rate_fpm,
            } => {
                assert!((ground_speed_kt.unwrap() - 159.20).abs() < 0.5);
                assert!((heading_deg.unwrap() - 182.88).abs() < 0.1);
                assert_eq!(vert_rate_fpm, Some(-832));
            }
            other => panic!("expected velocity, got {other:?}"),
        }
    }

    #[test]
    fn longitude_zones_match_the_published_table() {
        assert_eq!(nl(0.0), 59);
        assert_eq!(nl(52.0), 36);
        assert_eq!(nl(-52.0), 36);
        assert_eq!(nl(86.0), 3);
        assert_eq!(nl(88.0), 1);
    }

    #[test]
    fn synthesised_frame_survives_the_demodulator() {
        // Build the IQ a transmitter would have produced for a known frame,
        // push it through, and require the same bytes back. This is the
        // only test that exercises preamble detection and bit slicing.
        let msg = from_hex(IDENT);
        let mut raw: Vec<u8> = Vec::new();
        let noise = |v: &mut Vec<u8>, n: usize| {
            for _ in 0..n {
                v.push(127);
                v.push(127);
            }
        };
        let pulse = |v: &mut Vec<u8>, on: bool| {
            // One half-bit = one sample at 2 MS/s.
            if on {
                v.push(220);
                v.push(127);
            } else {
                v.push(129);
                v.push(127);
            }
        };
        noise(&mut raw, 40);
        // Preamble: highs at half-bit slots 0, 2, 7, 9.
        for k in 0..16 {
            pulse(&mut raw, matches!(k, 0 | 2 | 7 | 9));
        }
        for i in 0..112 {
            let bit = (msg[i / 8] >> (7 - (i % 8))) & 1;
            pulse(&mut raw, bit == 1);
            pulse(&mut raw, bit == 0);
        }
        noise(&mut raw, 600);

        let mut d = AdsbDemod::new();
        let mut out = Vec::new();
        d.process_u8(&raw, &mut out);
        assert_eq!(out.len(), 1, "expected exactly one frame, got {}", out.len());
        assert_eq!(out[0].hex(), IDENT);
    }

    #[test]
    fn a_burst_split_across_two_captures_is_decoded_once() {
        // Real captures arrive in fixed-size blocks and a transmission
        // lands wherever it lands. Both failure modes matter: lose the
        // frame, or count it twice and inflate the message rate.
        let raw = synth_frame(IDENT);
        for split in [50usize, 120, 300, 480] {
            let mut d = AdsbDemod::new();
            let mut out = Vec::new();
            d.process_u8(&raw[..split * 2], &mut out);
            d.process_u8(&raw[split * 2..], &mut out);
            assert_eq!(
                out.len(),
                1,
                "split at sample {split}: expected one frame, got {}",
                out.len()
            );
            assert_eq!(out[0].hex(), IDENT);
        }
    }

    #[test]
    fn a_quiet_capture_produces_nothing() {
        let mut d = AdsbDemod::new();
        let mut out = Vec::new();
        let mut rng: u32 = 0x1234_5678;
        let mut raw = Vec::new();
        for _ in 0..200_000 {
            // Cheap LCG, only needs to be uncorrelated enough to not
            // accidentally spell a preamble.
            rng = rng.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
            raw.push(120u8.wrapping_add((rng >> 24) as u8 % 16));
            rng = rng.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
            raw.push(120u8.wrapping_add((rng >> 24) as u8 % 16));
        }
        d.process_u8(&raw, &mut out);
        assert!(out.is_empty(), "noise decoded as {} frames", out.len());
    }

    /// The IQ a transmitter would have produced for `hex`, at 2 MS/s.
    fn synth_frame(hex: &str) -> Vec<u8> {
        let msg = from_hex(hex);
        let mut raw: Vec<u8> = Vec::new();
        let mut push = |v: u8| {
            raw.push(v);
            raw.push(127);
        };
        for _ in 0..40 {
            push(127);
        }
        for k in 0..16 {
            push(if matches!(k, 0 | 2 | 7 | 9) { 220 } else { 129 });
        }
        for i in 0..112 {
            let bit = (msg[i / 8] >> (7 - (i % 8))) & 1;
            push(if bit == 1 { 220 } else { 129 });
            push(if bit == 1 { 129 } else { 220 });
        }
        for _ in 0..600 {
            push(127);
        }
        raw
    }
}
