//! Drone-band survey: where the energy is, how wide it is, and how often
//! it is there.
//!
//! # What this is not
//!
//! This does not identify drones. It cannot. The thing that would — FAA
//! Part 89 Remote ID — broadcasts over Bluetooth 4/5 and Wi-Fi NAN at
//! 2.4 GHz and 5.8 GHz, and the R828D tuner in an RTL-SDR Blog V4 stops at
//! 1766 MHz. That is a hardware ceiling. No amount of code reaches above
//! it, so there is no serial number, no operator position and no takeoff
//! point available here, and anything claiming otherwise from this hardware
//! is wrong.
//!
//! What is reachable are the links that *some* drones use below 1766 MHz:
//! long-range control and telemetry in the ISM bands, and analogue FPV
//! video at 1.2/1.3 GHz. Even there, the control protocols (ExpressLRS,
//! Crossfire and friends) are proprietary frequency-hopping schemes whose
//! hop sequence comes from a binding phrase we do not have, so the payload
//! is out of reach as well.
//!
//! So what is left is the *shape* of a signal: how wide it is, how often it
//! is on, whether it sits still or moves. That is genuinely diagnostic —
//! an analogue video carrier looks nothing like a telemetry packet — but it
//! is a signature, not an identification. Every label this module produces
//! is phrased as "consistent with", and [`Kind::consistent_with`] is the
//! sentence the UI should show rather than the short label.

/// One band worth sweeping, and why.
pub struct Band {
    /// Stable key for settings and commands.
    pub key: &'static str,
    pub name: &'static str,
    pub f0_mhz: f64,
    pub f1_mhz: f64,
    /// What actually lives here. Not a promise that a drone does.
    pub what: &'static str,
}

impl Band {
    pub fn span_mhz(&self) -> f64 {
        self.f1_mhz - self.f0_mhz
    }

    /// Tuner centre frequencies, in Hz, that cover this band in windows of
    /// `span_hz` usable width. The first and last windows hang over the
    /// band edges by half a window, which is fine — the overhang is
    /// discarded when the spectrum is written into the band map.
    pub fn windows(&self, span_hz: f64) -> Vec<f64> {
        let f0 = self.f0_mhz * 1e6;
        let f1 = self.f1_mhz * 1e6;
        if span_hz <= 0.0 || f1 <= f0 {
            return vec![(f0 + f1) / 2.0];
        }
        let n = (((f1 - f0) / span_hz).ceil() as usize).max(1);
        // Spread the windows evenly rather than packing from the bottom, so
        // the overlap lands inside the band instead of outside it.
        let step = (f1 - f0) / n as f64;
        (0..n).map(|i| f0 + step * (i as f64 + 0.5)).collect()
    }
}

/// The bands an R828D can actually tune, in sweep order.
///
/// Every figure here is an allocation, not a measurement: these are where
/// the relevant services are permitted to operate, which is where it is
/// worth looking.
pub const BANDS: &[Band] = &[
    Band {
        key: "ism433",
        name: "433 MHz ISM",
        f0_mhz: 433.05,
        f1_mhz: 434.79,
        what: "Long-range control and telemetry links, plus a great deal of \
               unrelated traffic — car remotes, weather stations, doorbells, \
               tyre sensors. Expect this band to be busy with things that are \
               not drones.",
    },
    Band {
        key: "srd868",
        name: "868 MHz SRD",
        f0_mhz: 863.0,
        f1_mhz: 870.0,
        what: "European short-range device band. Crossfire and ExpressLRS \
               have 868 MHz variants that operate here. In North America the \
               equivalent traffic is at 915 MHz instead, so this band is \
               usually quiet here — worth leaving off unless you are \
               elsewhere.",
    },
    Band {
        key: "ism915",
        name: "902–928 MHz ISM",
        f0_mhz: 902.0,
        f1_mhz: 928.0,
        what: "The North American long-range band: ExpressLRS 900, TBS \
               Crossfire, SiK/3DR telemetry radios at 915 MHz, and some \
               digital video links. Also smart meters, pagers and cordless \
               phones, which hop and burst in much the same way.",
    },
    Band {
        key: "fpv12",
        name: "1.2/1.3 GHz FPV video",
        f0_mhz: 1080.0,
        f1_mhz: 1360.0,
        what: "Analogue FPV video. A wide FM carrier, several MHz across, on \
               all the time while the aircraft is flying — the single most \
               recognisable drone signature reachable by this hardware. Part \
               of this range (1240–1300 MHz) is the 23 cm amateur band, so \
               not everything wide here is video.",
    },
];

pub fn band(key: &str) -> Option<&'static Band> {
    BANDS.iter().find(|b| b.key == key)
}

/// Bands that matter for drones and cannot be reached, with the reason.
///
/// This is in the library rather than the UI on purpose: the limitation is
/// a property of the radio, and it should be impossible to ship a drone
/// screen that forgets to mention it.
pub const UNREACHABLE: &[(&str, &str, &str)] = &[
    (
        "Remote ID",
        "2.4 GHz / 5.8 GHz",
        "Broadcast over Bluetooth 4/5 and Wi-Fi NAN. This is the only signal \
         that carries a drone's identity, serial number, position and \
         takeoff point — and it is above the tuner's 1766 MHz ceiling. A \
         phone running an app that reads Remote ID will do what this radio \
         cannot.",
    ),
    (
        "Most control links",
        "2.400–2.4835 GHz",
        "DJI OcuSync/O3, ExpressLRS 2.4, FrSky ACCST and ACCESS, and every \
         Wi-Fi-controlled drone. Above the tuner's range.",
    ),
    (
        "Most FPV video",
        "5.725–5.875 GHz",
        "The dominant analogue and digital FPV video band by a wide margin. \
         Far above the tuner's range.",
    ),
];

/// Hardware ceiling of the R828D tuner, in MHz. Anything above this is a
/// hardware problem, not a software one.
pub const TUNER_CEILING_MHZ: f64 = 1766.0;

/// Occupied bandwidth at or above which a signal is called wide. Analogue
/// FPV video at 1.2 GHz typically occupies well over this; nothing narrow
/// does.
pub const WIDE_KHZ: f64 = 4_000.0;
/// Below [`WIDE_KHZ`] and at or above this, a signal is a channel rather
/// than a packet — a digital link holding a slot.
pub const CHANNEL_KHZ: f64 = 500.0;
/// Occupancy at or above which a signal counts as continuously present.
pub const CONTINUOUS: f32 = 0.75;
/// How many separate looks a bin needs before its occupancy means anything.
/// A wide sweep revisits a given frequency every few seconds, so a handful
/// of looks cannot distinguish "rarely on" from "we rarely looked".
pub const MIN_LOOKS: u32 = 8;

/// What a signal's shape is consistent with.
///
/// The `Unmeasured` variants are not a failure — they are the honest state
/// of a signal seen by a sweep that has not yet looked at it often enough
/// to say how often it is on. A stare resolves them.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    /// Wide, and measured to be on continuously.
    AnalogVideo,
    /// Wide, and measured to come and go.
    WideKeyed,
    /// Wide, but not looked at often enough to say how often it is on.
    WideUnmeasured,
    /// Half a MHz to a few MHz: a held channel.
    Digital,
    /// Narrow, and measured to come and go.
    NarrowBurst,
    /// Narrow, and measured to be on continuously.
    NarrowSteady,
    /// Narrow, but not looked at often enough to say.
    NarrowUnmeasured,
}

impl Kind {
    /// Short label for a table cell.
    pub fn label(self) -> &'static str {
        match self {
            Kind::AnalogVideo => "WIDE, CONTINUOUS",
            Kind::WideKeyed => "WIDE, KEYED",
            Kind::WideUnmeasured => "WIDE",
            Kind::Digital => "CHANNEL",
            Kind::NarrowBurst => "NARROW, BURSTY",
            Kind::NarrowSteady => "NARROW, STEADY",
            Kind::NarrowUnmeasured => "NARROW",
        }
    }

    /// The sentence to show the person. Deliberately longer than the label
    /// and deliberately hedged, because the hedge is the truth.
    pub fn consistent_with(self) -> &'static str {
        match self {
            Kind::AnalogVideo => {
                "Several MHz wide and on the whole time — the shape of an \
                 analogue FM video downlink. In the 1.2 GHz band that is \
                 consistent with FPV video; a 23 cm amateur transmission can \
                 look similar."
            }
            Kind::WideKeyed => {
                "Wide, but switching on and off. Consistent with a digital \
                 video link, or with a wide transmitter being keyed by hand."
            }
            Kind::WideUnmeasured => {
                "Wide enough to be a video carrier, but the sweep has not \
                 looked here often enough to say whether it is on \
                 continuously. Stare at it to find out."
            }
            Kind::Digital => {
                "Under a few MHz and holding a channel. Consistent with a \
                 digital data or video link. Also what a great many things \
                 that are not drones look like."
            }
            Kind::NarrowBurst => {
                "Narrow and intermittent — packets. Consistent with a \
                 telemetry or control link, and equally consistent with a \
                 weather station, a smart meter, or a tyre-pressure sensor."
            }
            Kind::NarrowSteady => {
                "Narrow and never off. That is a beacon or an unmodulated \
                 carrier, not a control link — control links transmit in \
                 bursts."
            }
            Kind::NarrowUnmeasured => {
                "Narrow, and not yet looked at often enough to say how often \
                 it transmits. Stare at it to find out."
            }
        }
    }

    /// Whether this shape is one a drone link actually has. Used for
    /// ordering the list, not for making a claim.
    pub fn drone_shaped(self) -> bool {
        matches!(
            self,
            Kind::AnalogVideo | Kind::WideKeyed | Kind::Digital | Kind::NarrowBurst
        )
    }
}

/// Decide a shape from an occupied bandwidth and, when it is known, how
/// often the signal was present.
///
/// `occupancy` is `None` when the sweep has not visited the frequency
/// enough times for the fraction to mean anything — see [`MIN_LOOKS`].
pub fn classify(bw_khz: f64, occupancy: Option<f32>) -> Kind {
    let continuous = occupancy.map(|o| o >= CONTINUOUS);
    if bw_khz >= WIDE_KHZ {
        match continuous {
            Some(true) => Kind::AnalogVideo,
            Some(false) => Kind::WideKeyed,
            None => Kind::WideUnmeasured,
        }
    } else if bw_khz >= CHANNEL_KHZ {
        Kind::Digital
    } else {
        match continuous {
            Some(true) => Kind::NarrowSteady,
            Some(false) => Kind::NarrowBurst,
            None => Kind::NarrowUnmeasured,
        }
    }
}

/// One run of occupied bins, pulled out of a band map.
#[derive(Clone, Debug)]
pub struct Signature {
    pub band_key: &'static str,
    pub center_mhz: f64,
    pub bw_khz: f64,
    /// Strongest level seen anywhere in the run, dBFS.
    pub peak_db: f32,
    /// How far that peak sits above the local noise estimate.
    pub snr_db: f32,
    /// Fraction of looks in which the run was above threshold, if the sweep
    /// has looked often enough for that to mean anything.
    pub occupancy: Option<f32>,
    /// Fewest looks any bin in the run has had.
    pub looks: u32,
    pub kind: Kind,
}

/// Running picture of one band: what has been seen at each frequency.
///
/// The map is wider than any one tuner window, so it is filled in a window
/// at a time as the sweep steps across the band. Peaks decay, and the
/// look/hit counters halve when they fill up, so a signal that stops being
/// transmitted fades out of the picture instead of being remembered
/// forever.
pub struct BandMap {
    pub key: &'static str,
    pub f0_hz: f64,
    pub f1_hz: f64,
    pub bin_hz: f64,
    /// Strongest level seen in each bin, decayed.
    pub peak_db: Vec<f32>,
    /// Level in each bin on the most recent visit.
    pub now_db: Vec<f32>,
    /// Noise estimate for each bin, from the median of the window it was
    /// measured in.
    pub floor_db: Vec<f32>,
    pub hits: Vec<u32>,
    pub looks: Vec<u32>,
    /// The band's noise floor, in dBFS, tracked across every window.
    ///
    /// This is deliberately *not* per-window, and that is the single most
    /// important decision in this file. A window's own median is a fine
    /// noise estimate for a mostly-empty window and a disastrous one for a
    /// window that a signal fills completely — the median then sits on the
    /// signal, the signal measures 0 dB above its own level, and a wide
    /// carrier becomes invisible precisely because it is wide. An 8 MHz
    /// analogue FPV video downlink fills four consecutive 1.8 MHz windows,
    /// so a per-window floor would hide the one thing this survey is best
    /// at finding.
    ///
    /// Instead the quiet windows in the band say where the noise is, which
    /// works because the survey runs at a fixed gain and levels are
    /// therefore comparable from one end of a band to the other. The
    /// tracker is asymmetric: it follows a lower reading quickly and drifts
    /// upward very slowly, so it latches onto the quietest part of the band
    /// and stays there. `NaN` until the first window arrives.
    ///
    /// The limitation this leaves, stated rather than hidden: a band that
    /// is occupied end to end has no quiet part, so the floor latches onto
    /// the traffic and little is detected. A power-measuring receiver with
    /// no absolute calibration cannot do better than that.
    pub floor_est: f32,
    /// Fraction of a bin's height above the noise floor kept on each visit.
    /// The decay is proportional rather than a fixed number of dB because a
    /// fixed step takes forever to forget a very strong transient: 80 dB at
    /// half a dB a visit is well over a hundred passes. At 0.88 anything
    /// fades below a 10 dB threshold in something like twenty visits,
    /// whatever height it started from.
    pub decay_keep: f32,
    /// Completed passes across this band.
    pub passes: u32,
}

/// Look counters are halved when any bin reaches this, which keeps
/// occupancy a recent measure rather than a lifetime average.
const LOOK_CAP: u32 = 64;

/// How many consecutive unmeasured bins a signature may step over.
///
/// Sized for the DC-spur guard band the receiver needs blanked — about
/// thirty kHz, or thirteen bins at the scanner's resolution — with room to
/// spare, and nowhere near wide enough to join two carriers separated by
/// measured quiet spectrum.
pub const BRIDGE_BINS: usize = 24;

impl BandMap {
    pub fn new(b: &Band, bin_hz: f64) -> Self {
        let f0 = b.f0_mhz * 1e6;
        let f1 = b.f1_mhz * 1e6;
        let n = (((f1 - f0) / bin_hz).ceil() as usize).max(1);
        BandMap {
            key: b.key,
            f0_hz: f0,
            f1_hz: f1,
            bin_hz,
            peak_db: vec![f32::NEG_INFINITY; n],
            now_db: vec![f32::NEG_INFINITY; n],
            floor_db: vec![-110.0; n],
            hits: vec![0; n],
            looks: vec![0; n],
            floor_est: f32::NAN,
            decay_keep: 0.88,
            passes: 0,
        }
    }

    pub fn len(&self) -> usize {
        self.peak_db.len()
    }

    pub fn is_empty(&self) -> bool {
        self.peak_db.is_empty()
    }

    /// Centre frequency of bin `i`, in Hz.
    pub fn bin_hz_at(&self, i: usize) -> f64 {
        self.f0_hz + (i as f64 + 0.5) * self.bin_hz
    }

    pub fn clear(&mut self) {
        self.peak_db.iter_mut().for_each(|v| *v = f32::NEG_INFINITY);
        self.now_db.iter_mut().for_each(|v| *v = f32::NEG_INFINITY);
        self.floor_db.iter_mut().for_each(|v| *v = -110.0);
        self.hits.iter_mut().for_each(|v| *v = 0);
        self.looks.iter_mut().for_each(|v| *v = 0);
        self.floor_est = f32::NAN;
        self.passes = 0;
    }

    /// Write one tuner window's spectrum into the band.
    ///
    /// `bins` spans `center_hz ± span_hz/2` in ascending frequency order.
    /// `snr_db` is how far above the window's own median a bin must be to
    /// count as occupied.
    ///
    /// Iteration is over the *map's* bins rather than the spectrum's, so
    /// every map bin inside the window gets exactly one look however the
    /// two bin widths compare. Doing it the other way round gives bins
    /// several looks each when the spectrum is finer than the map, and
    /// silently skips them when it is coarser.
    ///
    /// A non-finite level in `bins` means "no measurement here" — the
    /// caller blanks the receiver's DC spur that way — and those bins get
    /// no look and no write at all. Writing a floor value instead would
    /// record a hole in the middle of every window as an *absence* of
    /// signal, which is a different claim and a false one.
    pub fn ingest(&mut self, center_hz: f64, span_hz: f64, bins: &[f32], snr_db: f32) {
        if bins.is_empty() || span_hz <= 0.0 {
            return;
        }
        // The median skips blanked bins, so a wide guard band around DC
        // cannot drag the noise estimate down.
        let med = median_finite(bins);
        // Follow a quieter window quickly, a louder one barely at all. See
        // `floor_est` for why this is a band-wide figure and not this
        // window's own median.
        self.floor_est = if !self.floor_est.is_finite() {
            med
        } else if med < self.floor_est {
            self.floor_est * 0.7 + med * 0.3
        } else {
            self.floor_est * 0.998 + med * 0.002
        };
        let floor = self.floor_est;
        let lo = center_hz - span_hz / 2.0;
        let hi = center_hz + span_hz / 2.0;
        let n = self.len();
        // First and last map bins fully inside the window.
        let j0 = (((lo - self.f0_hz) / self.bin_hz).ceil().max(0.0) as usize).min(n);
        let j1 = (((hi - self.f0_hz) / self.bin_hz).floor().max(0.0) as usize).min(n);
        for j in j0..j1 {
            let f = self.bin_hz_at(j);
            let frac = (f - lo) / span_hz;
            if !(0.0..1.0).contains(&frac) {
                continue;
            }
            let i = ((frac * bins.len() as f64) as usize).min(bins.len() - 1);
            let db = bins[i];
            if !db.is_finite() {
                continue;
            }
            self.now_db[j] = db;
            self.floor_db[j] = floor;
            let occupied = db >= floor + snr_db;
            // Decay the remembered peak towards the noise floor on every
            // visit, then take the new level. A signal that is still there
            // holds its own peak up through the `max`; one that has stopped
            // slides back down and eventually stops being a contact.
            let f = self.floor_db[j];
            let decayed = if self.peak_db[j].is_finite() {
                f + (self.peak_db[j] - f) * self.decay_keep
            } else {
                f32::NEG_INFINITY
            };
            self.peak_db[j] = decayed.max(db);
            self.looks[j] = self.looks[j].saturating_add(1);
            if occupied {
                self.hits[j] = self.hits[j].saturating_add(1);
            }
            if self.looks[j] >= LOOK_CAP {
                self.looks[j] /= 2;
                self.hits[j] /= 2;
            }
        }
    }

    /// Occupancy of one bin, or `None` when it has not been looked at often
    /// enough to say.
    pub fn occupancy(&self, i: usize) -> Option<f32> {
        let looks = *self.looks.get(i)?;
        if looks < MIN_LOOKS {
            return None;
        }
        Some(self.hits[i] as f32 / looks as f32)
    }

    /// Pull contiguous runs of occupied bins out of the map.
    ///
    /// `min_run` is the shortest run taken seriously; 2 bins keeps a single
    /// noisy bin from becoming a contact. A run is occupied if its peak
    /// stands `snr_db` above the local noise estimate.
    ///
    /// A short stretch of *unmeasured* bins inside a run does not end it.
    /// This matters more than it sounds: the receiver's DC spur has to be
    /// blanked at the centre of every tuner window, which leaves a small
    /// gap with no data every window-width right across the band. Treating
    /// those gaps as the end of a signal chops an 8 MHz video carrier into
    /// five separate 1.8 MHz "signals", each then classified as a channel
    /// rather than as video. A gap with no data is not an absence of
    /// signal, and is not allowed to behave like one.
    pub fn signatures(&self, snr_db: f32, min_run: usize) -> Vec<Signature> {
        let mut out = Vec::new();
        let n = self.len();
        let mut j = 0usize;
        while j < n {
            if !self.occupied(j, snr_db) {
                j += 1;
                continue;
            }
            let start = j;
            let mut last_occupied = j;
            while j < n {
                if self.occupied(j, snr_db) {
                    last_occupied = j;
                    j += 1;
                    continue;
                }
                // An unmeasured stretch is skipped over as long as it is
                // short and the signal resumes on the far side. A measured
                // quiet bin ends the run immediately — that is a real gap.
                if self.looks[j] == 0 {
                    let gap_start = j;
                    let mut k = j;
                    while k < n && self.looks[k] == 0 && k - gap_start < BRIDGE_BINS {
                        k += 1;
                    }
                    if k < n && k - gap_start < BRIDGE_BINS && self.occupied(k, snr_db) {
                        j = k;
                        continue;
                    }
                }
                break;
            }
            // Trailing unmeasured bins are not part of the signal.
            j = last_occupied + 1;
            let run = start..j;
            if run.len() < min_run.max(1) {
                continue;
            }
            let bw_khz = run.len() as f64 * self.bin_hz / 1e3;
            let center_mhz = (self.bin_hz_at(start) + self.bin_hz_at(j - 1)) / 2.0 / 1e6;
            let mut peak = f32::NEG_INFINITY;
            let mut floor_sum = 0.0f32;
            let mut hits = 0u64;
            let mut looks = 0u64;
            let mut min_looks = u32::MAX;
            let mut measured = 0u32;
            for k in run.clone() {
                // Bridged bins have no data; they widen the signal but must
                // not drag its level, noise estimate or look count around.
                if self.looks[k] == 0 {
                    continue;
                }
                if self.peak_db[k] > peak {
                    peak = self.peak_db[k];
                }
                floor_sum += self.floor_db[k];
                hits += self.hits[k] as u64;
                looks += self.looks[k] as u64;
                min_looks = min_looks.min(self.looks[k]);
                measured += 1;
            }
            let floor = floor_sum / measured.max(1) as f32;
            let occupancy = if min_looks >= MIN_LOOKS && looks > 0 {
                Some(hits as f32 / looks as f32)
            } else {
                None
            };
            out.push(Signature {
                band_key: self.key,
                center_mhz,
                bw_khz,
                peak_db: peak,
                snr_db: peak - floor,
                occupancy,
                looks: if min_looks == u32::MAX { 0 } else { min_looks },
                kind: classify(bw_khz, occupancy),
            });
        }
        out
    }

    fn occupied(&self, i: usize, snr_db: f32) -> bool {
        self.looks[i] > 0 && self.peak_db[i].is_finite() && self.peak_db[i] >= self.floor_db[i] + snr_db
    }
}

/// Evidence that something in a band is hopping.
///
/// A frequency-hopping link looks like many narrow bursts scattered across
/// a band, each one rarely present. That pattern is worth naming, but it is
/// also what a band full of unrelated burst devices looks like, so this
/// reports the count and the spread and leaves the conclusion hedged.
#[derive(Clone, Debug, PartialEq)]
pub struct HopEvidence {
    pub bursts: usize,
    pub spread_mhz: f64,
    pub lowest_mhz: f64,
    pub highest_mhz: f64,
}

/// Fewest scattered bursts before the pattern is worth mentioning.
pub const HOP_MIN_BURSTS: usize = 4;
/// Narrowest spread, in MHz, that counts as spread out rather than one
/// signal measured twice.
pub const HOP_MIN_SPREAD_MHZ: f64 = 1.0;

pub fn hop_evidence(sigs: &[Signature]) -> Option<HopEvidence> {
    let mut freqs: Vec<f64> = sigs
        .iter()
        .filter(|s| s.kind == Kind::NarrowBurst)
        .map(|s| s.center_mhz)
        .collect();
    if freqs.len() < HOP_MIN_BURSTS {
        return None;
    }
    freqs.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let lowest = freqs[0];
    let highest = freqs[freqs.len() - 1];
    let spread = highest - lowest;
    if spread < HOP_MIN_SPREAD_MHZ {
        return None;
    }
    Some(HopEvidence {
        bursts: freqs.len(),
        spread_mhz: spread,
        lowest_mhz: lowest,
        highest_mhz: highest,
    })
}

/// A measurement of one tuner window, with the radio sitting still.
///
/// This is where duty cycle and burst timing come from. A sweep cannot
/// measure them: it revisits a frequency every few seconds, so a 5 ms
/// packet is almost always missed and a low hit rate says more about the
/// sweep than the signal. Parked, frames arrive every fraction of a
/// millisecond and the timing is real.
pub struct Stare {
    pub center_hz: f64,
    pub bin_hz: f64,
    /// Seconds of capture each frame represents.
    pub frame_s: f32,
    pub peak_db: Vec<f32>,
    pub now_db: Vec<f32>,
    pub hits: Vec<u32>,
    pub frames: u32,
    pub on_frames: u32,
    /// Bin range being timed. Set by [`Stare::set_target`].
    pub lo_bin: usize,
    pub hi_bin: usize,
    /// The noise floor to measure against, supplied by the caller.
    ///
    /// Not derived from the window, for the same reason `BandMap::floor_est`
    /// is not: a measurement is usually pointed at the strongest thing in
    /// sight, and the strongest thing in sight is often wide enough to fill
    /// the window. A median taken here would sit on the signal and report a
    /// duty cycle of zero for a carrier that never stops — the exact
    /// opposite of the truth. The sweep already measured where the band's
    /// noise sits; that number comes in here.
    pub floor_db: f32,
    on_run: u32,
    off_run: u32,
    on_runs: Vec<u32>,
    off_runs: Vec<u32>,
}

/// How many on/off run lengths to keep. Enough for a stable median,
/// bounded so a long stare does not grow without limit.
const RUN_HISTORY: usize = 256;

impl Stare {
    /// `floor_db` is the band's noise floor in dBFS — normally
    /// `BandMap::floor_est` for the band the target sits in.
    pub fn new(
        center_hz: f64,
        bin_hz: f64,
        bins: usize,
        frame_s: f32,
        floor_db: f32,
    ) -> Self {
        Stare {
            center_hz,
            bin_hz,
            frame_s,
            peak_db: vec![f32::NEG_INFINITY; bins],
            now_db: vec![f32::NEG_INFINITY; bins],
            hits: vec![0; bins],
            frames: 0,
            on_frames: 0,
            lo_bin: 0,
            hi_bin: bins,
            floor_db: if floor_db.is_finite() { floor_db } else { -110.0 },
            on_run: 0,
            off_run: 0,
            on_runs: Vec::new(),
            off_runs: Vec::new(),
        }
    }

    /// Time only the part of the window between these two frequencies.
    /// Without this the whole 1.8 MHz is timed, and any one strong signal
    /// anywhere in it reads as 100% duty cycle.
    pub fn set_target(&mut self, lo_hz: f64, hi_hz: f64) {
        let n = self.peak_db.len();
        let span = self.bin_hz * n as f64;
        let lo_edge = self.center_hz - span / 2.0;
        let to_bin = |f: f64| {
            let b = ((f - lo_edge) / self.bin_hz).floor();
            b.clamp(0.0, n as f64 - 1.0) as usize
        };
        let a = to_bin(lo_hz.min(hi_hz));
        let b = to_bin(lo_hz.max(hi_hz));
        self.lo_bin = a;
        self.hi_bin = (b + 1).min(n);
        if self.hi_bin <= self.lo_bin {
            self.hi_bin = (self.lo_bin + 1).min(n);
        }
    }

    /// Centre frequency of bin `i`, in Hz.
    pub fn bin_hz_at(&self, i: usize) -> f64 {
        let span = self.bin_hz * self.peak_db.len() as f64;
        self.center_hz - span / 2.0 + (i as f64 + 0.5) * self.bin_hz
    }

    /// Feed one spectrum frame.
    pub fn frame(&mut self, bins: &[f32], snr_db: f32) {
        if bins.len() != self.peak_db.len() {
            return;
        }
        let thresh = self.floor_db + snr_db;
        let mut on = false;
        for (i, &db) in bins.iter().enumerate() {
            // A blanked bin carries no measurement, so it neither raises a
            // peak nor counts as quiet.
            if !db.is_finite() {
                continue;
            }
            self.now_db[i] = db;
            if db > self.peak_db[i] || !self.peak_db[i].is_finite() {
                self.peak_db[i] = db;
            }
            if db >= thresh {
                self.hits[i] = self.hits[i].saturating_add(1);
                if i >= self.lo_bin && i < self.hi_bin {
                    on = true;
                }
            }
        }
        self.frames = self.frames.saturating_add(1);
        if on {
            self.on_frames = self.on_frames.saturating_add(1);
            if self.off_run > 0 {
                push_run(&mut self.off_runs, self.off_run);
                self.off_run = 0;
            }
            self.on_run += 1;
        } else {
            if self.on_run > 0 {
                push_run(&mut self.on_runs, self.on_run);
                self.on_run = 0;
            }
            self.off_run += 1;
        }
    }

    /// Fraction of frames in which the target was above threshold.
    pub fn duty(&self) -> f32 {
        if self.frames == 0 {
            return 0.0;
        }
        self.on_frames as f32 / self.frames as f32
    }

    /// Typical length of a transmission, in ms. `None` until at least one
    /// burst has both started and finished — a signal that is on the whole
    /// time has no burst length, which is itself the answer.
    pub fn burst_ms(&self) -> Option<f32> {
        median_run(&self.on_runs).map(|r| r * self.frame_s * 1000.0)
    }

    /// Typical gap between transmissions, in ms.
    pub fn gap_ms(&self) -> Option<f32> {
        median_run(&self.off_runs).map(|r| r * self.frame_s * 1000.0)
    }

    /// Transmissions per second, from the median burst and gap.
    pub fn rate_hz(&self) -> Option<f32> {
        let on = median_run(&self.on_runs)?;
        let off = median_run(&self.off_runs)?;
        let period = (on + off) * self.frame_s;
        if period <= 0.0 {
            return None;
        }
        Some(1.0 / period)
    }

    /// Occupied bandwidth of the signal the target sits on, in kHz.
    ///
    /// Measured by finding an occupied bin inside the target and walking
    /// outward through occupied bins across the *whole* window, not just
    /// the target range. Counting only bins inside the target would make a
    /// stare report a narrower signal than the sweep already found, which
    /// reads as the measurement contradicting the survey when in fact it
    /// was looking through a smaller hole.
    ///
    /// A window is 1.8 MHz, so a wider signal still runs off both edges —
    /// see [`Stare::bw_is_lower_bound`].
    pub fn bw_khz(&self, snr_db: f32) -> f64 {
        match self.occupied_run(snr_db) {
            Some((lo, hi)) => (hi - lo + 1) as f64 * self.bin_hz / 1e3,
            None => 0.0,
        }
    }

    /// Whether the signal reaches an edge of the window, which makes
    /// [`Stare::bw_khz`] a floor rather than a figure. The sweep is what
    /// measures the true width of anything wider than one window.
    pub fn bw_is_lower_bound(&self, snr_db: f32) -> bool {
        match self.occupied_run(snr_db) {
            Some((lo, hi)) => lo == 0 || hi + 1 >= self.peak_db.len(),
            None => false,
        }
    }

    fn occupied_run(&self, snr_db: f32) -> Option<(usize, usize)> {
        let thresh = self.floor_db + snr_db;
        let occ = |i: usize| self.peak_db[i].is_finite() && self.peak_db[i] >= thresh;
        let anchor = (self.lo_bin..self.hi_bin).find(|&i| occ(i))?;
        let mut lo = anchor;
        while lo > 0 && occ(lo - 1) {
            lo -= 1;
        }
        let mut hi = anchor;
        while hi + 1 < self.peak_db.len() && occ(hi + 1) {
            hi += 1;
        }
        Some((lo, hi))
    }

    /// The shape this measurement supports. Unlike a sweep's verdict, the
    /// occupancy here is real, so this never returns an `Unmeasured` kind
    /// once a few hundred frames are in.
    pub fn kind(&self, snr_db: f32) -> Kind {
        let occ = if self.frames >= 64 {
            Some(self.duty())
        } else {
            None
        };
        classify(self.bw_khz(snr_db), occ)
    }

    /// Centre of the occupied part of the target, in MHz — where to tune to
    /// listen to it, which is not necessarily where the sweep said it was.
    pub fn peak_mhz(&self) -> Option<f64> {
        let mut best = f32::NEG_INFINITY;
        let mut at = None;
        for i in self.lo_bin..self.hi_bin {
            if self.peak_db[i].is_finite() && self.peak_db[i] > best {
                best = self.peak_db[i];
                at = Some(i);
            }
        }
        at.map(|i| self.bin_hz_at(i) / 1e6)
    }
}

fn push_run(v: &mut Vec<u32>, run: u32) {
    if v.len() >= RUN_HISTORY {
        v.remove(0);
    }
    v.push(run);
}

fn median_run(v: &[u32]) -> Option<f32> {
    if v.is_empty() {
        return None;
    }
    let mut s: Vec<u32> = v.to_vec();
    s.sort_unstable();
    Some(s[s.len() / 2] as f32)
}

/// Median level of one spectrum, ignoring blanked bins.
///
/// A fallback floor estimate, for a measurement started before any sweep
/// has established where the band's noise sits. It is the per-window median
/// that `BandMap::floor_est` exists to avoid relying on, so it is only
/// right when the window is mostly empty — which is why it is a fallback
/// and not the normal path.
pub fn window_floor(bins: &[f32]) -> f32 {
    median_finite(bins)
}

/// Median of the bins that actually hold a measurement. Blanked bins carry
/// a non-finite level and are left out rather than counted as very quiet.
fn median_finite(v: &[f32]) -> f32 {
    let mut s: Vec<f32> = v.iter().copied().filter(|x| x.is_finite()).collect();
    if s.is_empty() {
        return -110.0;
    }
    s.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    s[s.len() / 2]
}

#[cfg(test)]
mod tests {
    use super::*;

    const BIN: f64 = 2_400_000.0 / 1024.0;

    fn test_band() -> Band {
        Band {
            key: "t",
            name: "test",
            f0_mhz: 900.0,
            f1_mhz: 902.0,
            what: "",
        }
    }

    #[test]
    fn windows_cover_the_band() {
        let b = &BANDS[2]; // 902-928
        let w = b.windows(1_800_000.0);
        assert!(w.len() >= 14, "got {} windows", w.len());
        // Every window centre inside the band, and the union covers it.
        let lo = w.iter().cloned().fold(f64::INFINITY, f64::min) - 900_000.0;
        let hi = w.iter().cloned().fold(f64::NEG_INFINITY, f64::max) + 900_000.0;
        assert!(lo <= 902e6 + 1.0, "low edge {lo}");
        assert!(hi >= 928e6 - 1.0, "high edge {hi}");
    }

    #[test]
    fn a_narrow_band_gets_one_window_centred_on_it() {
        let b = &BANDS[0]; // 433.05-434.79, 1.74 MHz
        let w = b.windows(1_800_000.0);
        assert_eq!(w.len(), 1);
        assert!((w[0] - 433_920_000.0).abs() < 1000.0, "{}", w[0]);
    }

    /// The ceiling is the whole reason this module is shaped the way it is,
    /// so assert that nothing reachable was listed above it.
    #[test]
    fn no_band_is_above_the_tuner_ceiling() {
        for b in BANDS {
            assert!(
                b.f1_mhz <= TUNER_CEILING_MHZ,
                "{} ends at {} MHz, above the {} MHz ceiling",
                b.name,
                b.f1_mhz,
                TUNER_CEILING_MHZ
            );
            assert!(b.f0_mhz >= 24.0, "{} starts below the tuner floor", b.name);
            assert!(b.f1_mhz > b.f0_mhz, "{} has no span", b.name);
        }
        assert!(!UNREACHABLE.is_empty(), "the limits must be stated");
    }

    #[test]
    fn classification_follows_width_then_how_often() {
        // Wide and always on: video.
        assert_eq!(classify(8_000.0, Some(1.0)), Kind::AnalogVideo);
        // Wide and intermittent: not video.
        assert_eq!(classify(8_000.0, Some(0.2)), Kind::WideKeyed);
        // Wide and unknown: say so rather than guess video.
        assert_eq!(classify(8_000.0, None), Kind::WideUnmeasured);
        // A held channel, whatever its duty cycle.
        assert_eq!(classify(1_000.0, Some(1.0)), Kind::Digital);
        assert_eq!(classify(1_000.0, None), Kind::Digital);
        // Narrow.
        assert_eq!(classify(25.0, Some(0.05)), Kind::NarrowBurst);
        assert_eq!(classify(25.0, Some(0.99)), Kind::NarrowSteady);
        assert_eq!(classify(25.0, None), Kind::NarrowUnmeasured);
        // A narrow steady carrier is not a drone shape; a burst is.
        assert!(!Kind::NarrowSteady.drone_shaped());
        assert!(Kind::NarrowBurst.drone_shaped());
        assert!(!Kind::WideUnmeasured.drone_shaped());
    }

    /// Every map bin inside a window must get exactly one look per visit,
    /// however the map and spectrum bin widths compare. Getting this wrong
    /// inflates occupancy denominators and quietly skips frequencies.
    #[test]
    fn one_look_per_bin_per_visit() {
        let b = test_band();
        let mut m = BandMap::new(&b, BIN);
        let bins = vec![-100.0f32; 768];
        let span = BIN * 768.0;
        m.ingest(901_000_000.0, span, &bins, 10.0);
        let looked: Vec<usize> = (0..m.len()).filter(|&i| m.looks[i] > 0).collect();
        assert!(!looked.is_empty());
        for i in looked {
            assert_eq!(m.looks[i], 1, "bin {i} looked at {} times", m.looks[i]);
        }
        // A second visit to the same place gives exactly two.
        m.ingest(901_000_000.0, span, &bins, 10.0);
        let two = (0..m.len()).filter(|&i| m.looks[i] == 2).count();
        assert!(two > 700, "only {two} bins reached two looks");
    }

    /// A coarse spectrum written into a fine map must still leave no gaps.
    #[test]
    fn a_coarse_spectrum_leaves_no_unlooked_bins() {
        let b = test_band();
        let mut m = BandMap::new(&b, 1_000.0); // 1 kHz map bins
        let bins = vec![-100.0f32; 64]; // very coarse spectrum
        let span = 1_000_000.0;
        m.ingest(901_000_000.0, span, &bins, 10.0);
        // Bins from 900.5 to 901.5 MHz should all have been looked at.
        let lo = ((900_500_000.0 - m.f0_hz) / m.bin_hz) as usize + 1;
        let hi = ((901_500_000.0 - m.f0_hz) / m.bin_hz) as usize - 1;
        for i in lo..hi {
            assert!(m.looks[i] > 0, "bin {i} never looked at");
        }
    }

    #[test]
    fn a_wide_continuous_carrier_reads_as_video() {
        let b = Band {
            key: "t",
            name: "test",
            f0_mhz: 1200.0,
            f1_mhz: 1202.0,
            what: "",
        };
        let mut m = BandMap::new(&b, BIN);
        let span = BIN * 768.0;
        // 8 MHz is wider than this test band, so use 1 MHz of carrier and
        // check the width that comes back rather than the label.
        let mut bins = vec![-100.0f32; 768];
        let center = 1_201_000_000.0;
        let lo = center - span / 2.0;
        for (i, v) in bins.iter_mut().enumerate() {
            let f = lo + span * (i as f64 + 0.5) / 768.0;
            if (1_200_600_000.0..1_201_400_000.0).contains(&f) {
                *v = -40.0;
            }
        }
        for _ in 0..MIN_LOOKS + 2 {
            m.ingest(center, span, &bins, 10.0);
        }
        let sigs = m.signatures(10.0, 2);
        assert_eq!(sigs.len(), 1, "{sigs:?}");
        let s = &sigs[0];
        assert!((s.center_mhz - 1201.0).abs() < 0.02, "{}", s.center_mhz);
        assert!(
            (s.bw_khz - 800.0).abs() < 30.0,
            "width came back as {} kHz",
            s.bw_khz
        );
        assert_eq!(s.occupancy, Some(1.0));
        assert_eq!(s.kind, Kind::Digital); // 800 kHz is a channel, not video
        assert!(s.snr_db > 50.0, "snr {}", s.snr_db);
    }

    /// Occupancy must stay `None` until the sweep has looked often enough,
    /// because the alternative is reporting "on 12% of the time" about a
    /// frequency visited once.
    #[test]
    fn occupancy_is_withheld_until_there_are_enough_looks() {
        let b = test_band();
        let mut m = BandMap::new(&b, BIN);
        let span = BIN * 768.0;
        let mut bins = vec![-100.0f32; 768];
        for v in bins[300..320].iter_mut() {
            *v = -40.0;
        }
        m.ingest(901_000_000.0, span, &bins, 10.0);
        let s = m.signatures(10.0, 2);
        assert_eq!(s.len(), 1);
        assert_eq!(s[0].occupancy, None, "one look is not a duty cycle");
        assert!(matches!(
            s[0].kind,
            Kind::NarrowUnmeasured | Kind::Digital | Kind::WideUnmeasured
        ));
        for _ in 0..MIN_LOOKS {
            m.ingest(901_000_000.0, span, &bins, 10.0);
        }
        let s = m.signatures(10.0, 2);
        assert!(s[0].occupancy.is_some(), "still withheld after enough looks");
    }

    /// A signal that stops must fade out of the map rather than being
    /// remembered as a contact forever.
    #[test]
    fn a_peak_decays_once_the_signal_stops() {
        let b = test_band();
        let mut m = BandMap::new(&b, BIN);
        let span = BIN * 768.0;
        let mut loud = vec![-100.0f32; 768];
        for v in loud[300..320].iter_mut() {
            *v = -40.0;
        }
        let quiet = vec![-100.0f32; 768];
        for _ in 0..4 {
            m.ingest(901_000_000.0, span, &loud, 10.0);
        }
        assert_eq!(m.signatures(10.0, 2).len(), 1);
        // Now it goes away. 60 dB above the floor, kept at 0.88 a visit,
        // should be under a 10 dB threshold inside twenty-odd visits.
        let mut gone_after = None;
        for v in 1..=60 {
            m.ingest(901_000_000.0, span, &quiet, 10.0);
            if m.signatures(10.0, 2).is_empty() && gone_after.is_none() {
                gone_after = Some(v);
            }
        }
        let v = gone_after.expect("stale peak never faded");
        assert!(v <= 30, "took {v} visits to forget a signal that stopped");
    }

    /// A very strong transient must fade in the same number of visits as a
    /// weak one — that is the point of a proportional decay.
    #[test]
    fn a_huge_transient_fades_as_fast_as_a_small_one() {
        let b = test_band();
        let span = BIN * 768.0;
        let quiet = vec![-100.0f32; 768];
        let visits_to_forget = |level: f32| {
            let mut m = BandMap::new(&b, BIN);
            let mut loud = vec![-100.0f32; 768];
            for v in loud[300..320].iter_mut() {
                *v = level;
            }
            m.ingest(901_000_000.0, span, &loud, 10.0);
            assert_eq!(m.signatures(10.0, 2).len(), 1, "level {level} not seen");
            for v in 1..=200 {
                m.ingest(901_000_000.0, span, &quiet, 10.0);
                if m.signatures(10.0, 2).is_empty() {
                    return v;
                }
            }
            panic!("level {level} never faded");
        };
        let small = visits_to_forget(-70.0); // 30 dB up
        let huge = visits_to_forget(-5.0); // 95 dB up
        assert!(
            huge <= small + 12,
            "a 95 dB transient took {huge} visits against {small} for 30 dB"
        );
    }

    #[test]
    fn a_single_noisy_bin_is_not_a_contact() {
        let b = test_band();
        let mut m = BandMap::new(&b, BIN);
        let span = BIN * 768.0;
        let mut bins = vec![-100.0f32; 768];
        bins[400] = -40.0;
        m.ingest(901_000_000.0, span, &bins, 10.0);
        assert!(m.signatures(10.0, 2).is_empty(), "one bin became a contact");
        assert_eq!(m.signatures(10.0, 1).len(), 1, "min_run 1 should allow it");
    }

    /// The bug this guards: the DC spur has to be blanked at the centre of
    /// every tuner window, so a wide carrier spanning several windows
    /// arrives with small gaps punched through it. Those gaps must not turn
    /// one signal into several.
    #[test]
    fn a_blanked_dc_gap_does_not_split_a_carrier() {
        let b = Band {
            key: "t",
            name: "test",
            f0_mhz: 1200.0,
            f1_mhz: 1210.0,
            what: "",
        };
        let span = BIN * 768.0;
        let mut m = BandMap::new(&b, BIN);
        // Four windows across the band, each with a 13-bin hole at its own
        // centre, and an 8 MHz carrier underneath all of them.
        let centers: Vec<f64> = (0..5)
            .map(|i| 1_200_000_000.0 + span * (i as f64 + 0.5))
            .collect();
        for _ in 0..MIN_LOOKS + 2 {
            for &c in centers.iter() {
                let lo = c - span / 2.0;
                let mut bins = vec![-100.0f32; 768];
                for (i, v) in bins.iter_mut().enumerate() {
                    let f = lo + span * (i as f64 + 0.5) / 768.0;
                    if (1_201_000_000.0..1_209_000_000.0).contains(&f) {
                        *v = -40.0;
                    }
                }
                // The DC blank, exactly as the worker applies it.
                for v in bins[768 / 2 - 6..=768 / 2 + 6].iter_mut() {
                    *v = f32::NEG_INFINITY;
                }
                m.ingest(c, span, &bins, 10.0);
            }
        }
        let sigs = m.signatures(10.0, 2);
        assert_eq!(
            sigs.len(),
            1,
            "a carrier with blanked gaps came back as {} signals: {:?}",
            sigs.len(),
            sigs.iter().map(|s| (s.center_mhz, s.bw_khz)).collect::<Vec<_>>()
        );
        let s = &sigs[0];
        assert!(
            (s.bw_khz - 8_000.0).abs() < 60.0,
            "width {} kHz, expected about 8000",
            s.bw_khz
        );
        // And it is still recognised for what that width means.
        assert_eq!(s.kind, Kind::AnalogVideo, "{s:?}");
        // The blanked bins must not have dragged the noise estimate down.
        assert!(s.snr_db > 40.0 && s.snr_db < 80.0, "snr {}", s.snr_db);
    }

    /// The other half of that: a gap must only be bridged when it has no
    /// data. Two real carriers with measured quiet spectrum between them
    /// stay two carriers, however narrow the gap.
    #[test]
    fn measured_quiet_spectrum_still_separates_two_carriers() {
        let b = test_band();
        let span = BIN * 768.0;
        let mut m = BandMap::new(&b, BIN);
        let mut bins = vec![-100.0f32; 768];
        for v in bins[300..320].iter_mut() {
            *v = -40.0;
        }
        // Four quiet bins — well inside the bridge limit, but measured.
        for v in bins[324..344].iter_mut() {
            *v = -40.0;
        }
        for _ in 0..MIN_LOOKS + 2 {
            m.ingest(901_000_000.0, span, &bins, 10.0);
        }
        let sigs = m.signatures(10.0, 2);
        assert_eq!(sigs.len(), 2, "{sigs:?}");
    }

    /// A gap wider than the bridge limit does end a run, so an unmeasured
    /// band edge cannot swallow the whole band into one signature.
    #[test]
    fn a_wide_unmeasured_gap_is_not_bridged() {
        let b = test_band();
        let span = BIN * 768.0;
        let mut m = BandMap::new(&b, BIN);
        let mut bins = vec![-100.0f32; 768];
        for v in bins[300..320].iter_mut() {
            *v = -40.0;
        }
        for v in bins[420..440].iter_mut() {
            *v = -40.0;
        }
        // Everything between the two, blanked: a 100-bin hole, far wider
        // than BRIDGE_BINS.
        for v in bins[320..420].iter_mut() {
            *v = f32::NEG_INFINITY;
        }
        for _ in 0..MIN_LOOKS + 2 {
            m.ingest(901_000_000.0, span, &bins, 10.0);
        }
        let sigs = m.signatures(10.0, 2);
        assert_eq!(sigs.len(), 2, "{sigs:?}");
    }

    /// Blanked bins must not be recorded as looks, or the occupancy
    /// denominator counts measurements that never happened.
    #[test]
    fn blanked_bins_get_no_look() {
        let b = test_band();
        let span = BIN * 768.0;
        let mut m = BandMap::new(&b, BIN);
        let mut bins = vec![-100.0f32; 768];
        for v in bins[380..390].iter_mut() {
            *v = f32::NEG_INFINITY;
        }
        m.ingest(901_000_000.0, span, &bins, 10.0);
        // Find the map bins the blanked spectrum bins landed on.
        let lo = 901_000_000.0 - span / 2.0;
        let f_lo = lo + span * 381.0 / 768.0;
        let f_hi = lo + span * 389.0 / 768.0;
        let j_lo = ((f_lo - m.f0_hz) / m.bin_hz).ceil() as usize;
        let j_hi = ((f_hi - m.f0_hz) / m.bin_hz).floor() as usize;
        assert!(j_hi > j_lo);
        for j in j_lo..j_hi {
            assert_eq!(m.looks[j], 0, "blanked map bin {j} was given a look");
        }
        // Their neighbours were measured.
        assert!(m.looks[j_lo.saturating_sub(4)] > 0);
        assert!(m.looks[j_hi + 4] > 0);
    }

    /// A window that is mostly blanked must not report a collapsed noise
    /// floor — the median has to ignore the blanked bins.
    #[test]
    fn the_noise_estimate_ignores_blanked_bins() {
        let b = test_band();
        let span = BIN * 768.0;
        let mut m = BandMap::new(&b, BIN);
        let mut bins = vec![-100.0f32; 768];
        // Blank well over half the window.
        for v in bins[0..500].iter_mut() {
            *v = f32::NEG_INFINITY;
        }
        for v in bins[600..620].iter_mut() {
            *v = -40.0;
        }
        for _ in 0..MIN_LOOKS + 2 {
            m.ingest(901_000_000.0, span, &bins, 10.0);
        }
        let sigs = m.signatures(10.0, 2);
        assert_eq!(sigs.len(), 1, "{sigs:?}");
        // Floor should sit at -100, not at negative infinity, so SNR is a
        // real 60 dB rather than something meaningless.
        assert!(
            (sigs[0].snr_db - 60.0).abs() < 2.0,
            "snr came back as {}",
            sigs[0].snr_db
        );
    }

    #[test]
    fn hop_evidence_needs_several_bursts_spread_out() {
        let narrow = |mhz: f64| Signature {
            band_key: "t",
            center_mhz: mhz,
            bw_khz: 25.0,
            peak_db: -60.0,
            snr_db: 20.0,
            occupancy: Some(0.05),
            looks: 30,
            kind: Kind::NarrowBurst,
        };
        // Three is not enough.
        assert!(hop_evidence(&[narrow(903.0), narrow(910.0), narrow(920.0)]).is_none());
        // Four bunched together is one signal, not a hopper.
        assert!(hop_evidence(&[
            narrow(903.0),
            narrow(903.1),
            narrow(903.2),
            narrow(903.3)
        ])
        .is_none());
        let e = hop_evidence(&[
            narrow(903.0),
            narrow(909.0),
            narrow(915.5),
            narrow(921.0),
            narrow(927.0),
        ])
        .expect("five bursts over 24 MHz is the pattern");
        assert_eq!(e.bursts, 5);
        assert!((e.spread_mhz - 24.0).abs() < 0.01);
        assert!((e.lowest_mhz - 903.0).abs() < 0.01);
        assert!((e.highest_mhz - 927.0).abs() < 0.01);
        // A steady carrier is not a hop, however many there are.
        let steady = |mhz: f64| Signature {
            kind: Kind::NarrowSteady,
            ..narrow(mhz)
        };
        assert!(hop_evidence(&[
            steady(903.0),
            steady(909.0),
            steady(915.0),
            steady(921.0),
            steady(927.0)
        ])
        .is_none());
    }

    /// The whole point of a stare: real burst timing. 10 frames on, 90
    /// frames off, at 1 ms a frame, is a 10 ms burst every 100 ms.
    #[test]
    fn a_stare_measures_burst_timing() {
        let mut s = Stare::new(915_000_000.0, BIN, 768, 0.001, -100.0);
        s.set_target(914_900_000.0, 915_100_000.0);
        let quiet = vec![-100.0f32; 768];
        let mut loud = vec![-100.0f32; 768];
        // Target bins are around the middle of the window.
        for v in loud[380..388].iter_mut() {
            *v = -45.0;
        }
        for _ in 0..20 {
            for _ in 0..10 {
                s.frame(&loud, 10.0);
            }
            for _ in 0..90 {
                s.frame(&quiet, 10.0);
            }
        }
        assert_eq!(s.frames, 2000);
        assert!((s.duty() - 0.1).abs() < 0.01, "duty {}", s.duty());
        let burst = s.burst_ms().expect("bursts were seen to end");
        assert!((burst - 10.0).abs() < 1.5, "burst {burst} ms");
        let gap = s.gap_ms().expect("gaps were seen to end");
        assert!((gap - 90.0).abs() < 2.0, "gap {gap} ms");
        let rate = s.rate_hz().expect("rate");
        assert!((rate - 10.0).abs() < 0.5, "rate {rate} Hz");
        // 8 bins of 2343.75 Hz, with quiet spectrum either side, so this
        // width is exact rather than a lower bound.
        let bw = s.bw_khz(10.0);
        assert!((bw - 18.75).abs() < 3.0, "bw {bw} kHz");
        assert!(!s.bw_is_lower_bound(10.0));
        assert_eq!(s.kind(10.0), Kind::NarrowBurst);
        let at = s.peak_mhz().expect("peak");
        assert!((at - 915.0).abs() < 0.05, "peak at {at}");
    }

    /// A signal somewhere else in the window must not be counted as the
    /// target's duty cycle.
    #[test]
    fn a_stare_only_times_its_target() {
        let mut s = Stare::new(915_000_000.0, BIN, 768, 0.001, -100.0);
        s.set_target(914_900_000.0, 915_100_000.0);
        let mut elsewhere = vec![-100.0f32; 768];
        for v in elsewhere[20..40].iter_mut() {
            *v = -30.0;
        }
        for _ in 0..500 {
            s.frame(&elsewhere, 10.0);
        }
        assert_eq!(s.duty(), 0.0, "an off-target signal was timed as the target");
        assert_eq!(s.burst_ms(), None);
    }

    /// A carrier that never stops has no burst length, and must say so
    /// rather than inventing one.
    #[test]
    fn a_continuous_carrier_has_no_burst_length() {
        let mut s = Stare::new(1_200_000_000.0, BIN, 768, 0.001, -100.0);
        s.set_target(1_199_000_000.0, 1_201_000_000.0);
        let mut loud = vec![-100.0f32; 768];
        for v in loud[200..560].iter_mut() {
            *v = -40.0;
        }
        for _ in 0..300 {
            s.frame(&loud, 10.0);
        }
        assert!((s.duty() - 1.0).abs() < 1e-6);
        assert_eq!(s.burst_ms(), None, "a burst that never ended was measured");
        assert_eq!(s.rate_hz(), None);
        // 360 bins of 2343.75 Hz is about 844 kHz: a channel.
        assert_eq!(s.kind(10.0), Kind::Digital);
    }

    /// The case a per-window median gets catastrophically wrong: a carrier
    /// wide enough to fill the entire window. Measured against the band's
    /// floor it reads as continuous and wide; measured against its own
    /// median it would read as 0% on, which is the opposite of the truth.
    #[test]
    fn a_carrier_filling_the_window_still_measures_as_continuous() {
        let mut s = Stare::new(1_240_000_000.0, BIN, 768, 0.001, -100.0);
        s.set_target(1_239_500_000.0, 1_240_500_000.0);
        // Every bin loud: an 8 MHz video carrier seen through a 1.8 MHz
        // window looks exactly like this.
        let loud = vec![-45.0f32; 768];
        for _ in 0..300 {
            s.frame(&loud, 10.0);
        }
        assert!(
            (s.duty() - 1.0).abs() < 1e-6,
            "duty came back as {} — the floor climbed onto the signal",
            s.duty()
        );
        assert_eq!(s.burst_ms(), None);
        // The whole window is occupied, so the width reads as the window —
        // and must be reported as a lower bound, not as the answer.
        let bw = s.bw_khz(10.0);
        assert!((bw - 1_800.0).abs() < 20.0, "bw {bw} kHz");
        assert!(
            s.bw_is_lower_bound(10.0),
            "a signal running off both window edges was reported as an exact width"
        );
        // 1.8 MHz is as much as a 1.8 MHz window can say. The sweep is what
        // establishes the true width of anything wider.
        assert_eq!(s.kind(10.0), Kind::Digital);
    }

    /// And the floor really is the caller's, not the window's.
    #[test]
    fn a_stare_uses_the_floor_it_was_given() {
        let quiet_floor = Stare::new(915_000_000.0, BIN, 768, 0.001, -100.0);
        assert!((quiet_floor.floor_db - -100.0).abs() < 1e-6);
        // A nonsense floor falls back to something usable rather than
        // poisoning every comparison with NaN.
        let bad = Stare::new(915_000_000.0, BIN, 768, 0.001, f32::NAN);
        assert!(bad.floor_db.is_finite());
    }

    #[test]
    fn set_target_clamps_to_the_window() {
        let mut s = Stare::new(915_000_000.0, BIN, 768, 0.001, -100.0);
        s.set_target(0.0, 2_000_000_000.0);
        assert_eq!(s.lo_bin, 0);
        assert_eq!(s.hi_bin, 768);
        // A target narrower than one bin still gives a usable range.
        s.set_target(915_000_000.0, 915_000_001.0);
        assert!(s.hi_bin > s.lo_bin);
    }
}
