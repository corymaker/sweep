//! Is this audio someone talking, or just a carrier, a data burst, or
//! noise?
//!
//! No machine learning involved — speech has a statistical signature that
//! separates it from the alternatives well enough for a scanner:
//!
//! 1. **Envelope modulation.** Syllables make the loudness rise and fall
//!    roughly 2-8 times a second. An unmodulated carrier is flat; a data
//!    burst is flat-ish at a much higher rate; noise wanders randomly
//!    without that rhythm. This is the strongest single cue.
//! 2. **Zero-crossing rate.** Voiced speech is dominated by low
//!    frequencies (pitch and its harmonics, mostly under 1 kHz), so it
//!    crosses zero far less often than hiss does. Digital modes and static
//!    both sit up high.
//! 3. **Silence ratio.** Real speech has gaps — between words, between
//!    sentences. Continuous energy with no gaps at all is usually a
//!    carrier or a machine.
//!
//! What this can't do: distinguish speech from music (music also modulates
//! and has low-frequency energy), or recognize a very short utterance
//! inside one analysis window. It's a "worth stopping on?" filter, not a
//! transcriber.

/// A rolling verdict over the most recent audio.
pub struct VoiceDetector {
    sample_rate: f32,
    /// Short-term energy envelope, one entry per ~10 ms frame.
    envelope: Vec<f32>,
    /// Zero crossings counted per frame.
    zcr: Vec<f32>,
    frame_len: usize,
    acc: Vec<f32>,
    max_frames: usize,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct VoiceVerdict {
    /// 0.0 = definitely not speech, 1.0 = strongly speech-like.
    pub score: f32,
    pub is_voice: bool,
    /// Envelope modulation rate in Hz — speech lands around 2-8.
    pub syllable_rate_hz: f32,
}

impl VoiceDetector {
    pub fn new(sample_rate: f32) -> Self {
        let frame_len = (sample_rate * 0.010).max(1.0) as usize; // 10 ms
        VoiceDetector {
            sample_rate,
            envelope: Vec::new(),
            zcr: Vec::new(),
            frame_len,
            acc: Vec::new(),
            // ~1.5 s of history: long enough to see several syllables,
            // short enough to react before the scanner has moved on.
            max_frames: 150,
        }
    }

    pub fn reset(&mut self) {
        self.envelope.clear();
        self.zcr.clear();
        self.acc.clear();
    }

    /// Feed demodulated audio. Call [`verdict`](Self::verdict) after.
    pub fn push(&mut self, audio: &[f32]) {
        self.acc.extend_from_slice(audio);
        while self.acc.len() >= self.frame_len {
            let frame: Vec<f32> = self.acc.drain(..self.frame_len).collect();
            let rms = (frame.iter().map(|s| s * s).sum::<f32>() / frame.len() as f32).sqrt();
            let crossings = frame
                .windows(2)
                .filter(|w| (w[0] >= 0.0) != (w[1] >= 0.0))
                .count() as f32;
            self.envelope.push(rms);
            self.zcr.push(crossings / frame.len() as f32);
            if self.envelope.len() > self.max_frames {
                self.envelope.remove(0);
                self.zcr.remove(0);
            }
        }
    }

    pub fn verdict(&self) -> VoiceVerdict {
        // Need a reasonable stretch before judging.
        if self.envelope.len() < 40 {
            return VoiceVerdict {
                score: 0.0,
                is_voice: false,
                syllable_rate_hz: 0.0,
            };
        }

        let mean: f32 = self.envelope.iter().sum::<f32>() / self.envelope.len() as f32;
        if mean < 1e-4 {
            // Effectively silent — nothing to judge.
            return VoiceVerdict {
                score: 0.0,
                is_voice: false,
                syllable_rate_hz: 0.0,
            };
        }

        // 1. Envelope modulation depth. Speech swings widely around its
        //    mean; a steady carrier barely moves.
        let var: f32 = self
            .envelope
            .iter()
            .map(|e| (e - mean) * (e - mean))
            .sum::<f32>()
            / self.envelope.len() as f32;
        let modulation = (var.sqrt() / mean).clamp(0.0, 2.0);

        // 2. Syllable rate: how often the envelope crosses its own mean.
        //    Each syllable contributes about two crossings.
        let env_crossings = self
            .envelope
            .windows(2)
            .filter(|w| (w[0] >= mean) != (w[1] >= mean))
            .count() as f32;
        let seconds = self.envelope.len() as f32 * 0.010;
        let syllable_rate = env_crossings / 2.0 / seconds;
        // Speech sits around 2-8 Hz. Score peaks in that band and falls off
        // outside it, which is what rejects both steady carriers (near 0)
        // and data/noise (high).
        let rate_score = if (1.5..=10.0).contains(&syllable_rate) {
            1.0 - ((syllable_rate - 4.5).abs() / 5.5).min(1.0)
        } else {
            0.0
        };

        // 3. Zero-crossing rate. Voiced speech is low-frequency dominated.
        //    Normalized so ~0.1 (about 5 kHz at 48 kHz) and below is
        //    speech-like, and hiss/data sit well above.
        let mean_zcr: f32 = self.zcr.iter().sum::<f32>() / self.zcr.len() as f32;
        let zcr_score = (1.0 - (mean_zcr / 0.15).min(1.0)).clamp(0.0, 1.0);

        // 4. Silence ratio: speech pauses, machines usually don't.
        let quiet = self.envelope.iter().filter(|&&e| e < mean * 0.35).count() as f32;
        let silence_ratio = quiet / self.envelope.len() as f32;
        let silence_score = if (0.05..=0.6).contains(&silence_ratio) {
            1.0
        } else {
            0.3
        };

        // Weighted: the syllable rate is the most discriminating cue, so it
        // carries the most weight.
        let score = (rate_score * 0.45
            + (modulation / 1.2).min(1.0) * 0.25
            + zcr_score * 0.20
            + silence_score * 0.10)
            .clamp(0.0, 1.0);

        VoiceVerdict {
            score,
            is_voice: score >= 0.55,
            syllable_rate_hz: syllable_rate,
        }
    }

    pub fn sample_rate(&self) -> f32 {
        self.sample_rate
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f32::consts::TAU;

    fn feed(det: &mut VoiceDetector, samples: Vec<f32>) -> VoiceVerdict {
        det.push(&samples);
        det.verdict()
    }

    /// A steady unmodulated tone is the classic false positive a scanner
    /// must reject — it's loud and clears squelch easily, but nobody is
    /// talking.
    #[test]
    fn rejects_steady_tone() {
        let sr = 48_000.0;
        let mut d = VoiceDetector::new(sr);
        let n = (sr * 1.5) as usize;
        let s: Vec<f32> = (0..n).map(|i| (i as f32 / sr * 1000.0 * TAU).sin() * 0.5).collect();
        let v = feed(&mut d, s);
        assert!(!v.is_voice, "steady tone scored {} as voice", v.score);
    }

    /// White-ish noise should also be rejected — it's what an open squelch
    /// on an empty channel sounds like.
    #[test]
    fn rejects_noise() {
        let sr = 48_000.0;
        let mut d = VoiceDetector::new(sr);
        let n = (sr * 1.5) as usize;
        // Deterministic pseudo-noise so the test can't flake.
        let mut x: u32 = 12345;
        let s: Vec<f32> = (0..n)
            .map(|_| {
                x = x.wrapping_mul(1664525).wrapping_add(1013904223);
                (x >> 16) as f32 / 32768.0 - 1.0
            })
            .collect();
        let v = feed(&mut d, s);
        assert!(!v.is_voice, "noise scored {} as voice", v.score);
    }

    /// Speech-like: a low-frequency carrier whose amplitude is modulated at
    /// a syllable rate, with pauses. Not real speech, but it carries the
    /// same statistical signature this detector keys on.
    #[test]
    fn accepts_syllable_modulated_audio() {
        let sr = 48_000.0;
        let mut d = VoiceDetector::new(sr);
        let n = (sr * 1.5) as usize;
        let s: Vec<f32> = (0..n)
            .map(|i| {
                let t = i as f32 / sr;
                // 4 Hz syllable envelope, gated to create pauses.
                let env = (t * 4.0 * TAU).sin().max(0.0);
                let gate = if (t * 0.7) % 1.0 < 0.75 { 1.0 } else { 0.0 };
                (t * 220.0 * TAU).sin() * env * gate * 0.6
            })
            .collect();
        let v = feed(&mut d, s);
        assert!(
            v.is_voice,
            "syllable-modulated audio scored only {} (rate {} Hz)",
            v.score, v.syllable_rate_hz
        );
    }

    #[test]
    fn silence_is_not_voice() {
        let mut d = VoiceDetector::new(48_000.0);
        let v = feed(&mut d, vec![0.0; 48_000]);
        assert!(!v.is_voice);
    }
}
