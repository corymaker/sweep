//! AIS — Automatic Identification System, on 161.975 and 162.025 MHz.
//!
//! Ships broadcast their identity, position, course and speed in the clear,
//! continuously. Same idea as ADS-B but a completely different radio:
//! where ADS-B is pulse-position modulation decoded straight off the
//! envelope, AIS is GMSK at 9600 bits per second wrapped in HDLC — so this
//! works on the *output* of an FM discriminator rather than on raw IQ.
//!
//! ```text
//!   IQ ──► mix to channel ──► decimate ──► FM discriminator
//!                                                 │
//!                          bit slice ──► NRZI ──► HDLC ──► CRC-16
//!                                                            │
//!                                            MMSI / position / name
//! ```
//!
//! The timing recovery deserves a note, because the usual approaches
//! (Gardner, Mueller–Müller) need tuning against real signals and there is
//! no way to tune them honestly without those signals in hand. Instead this
//! runs one independent HDLC decoder per sample phase — five of them at
//! 48 kHz, since 48000/9600 is exactly 5. Only a decoder sampling near the
//! centre of each symbol produces frames whose checksum closes, so the
//! correct phase identifies itself and the wrong ones cost a shift register
//! each. It is brute force, and it is the kind of brute force that cannot
//! quietly be slightly wrong.
//!
//! Frames are accepted only on a correct CRC. No error correction.

use std::collections::HashMap;
use std::time::{Duration, Instant};

/// The two international AIS channels, A and B. Ships alternate between
/// them, so listening to only one halves what you hear.
pub const AIS_A_HZ: f64 = 161_975_000.0;
pub const AIS_B_HZ: f64 = 162_025_000.0;

/// Bits per second on the air.
pub const BAUD: f32 = 9600.0;

use crate::hdlc::{crc16, fcs_ok, pack, Hdlc, FLAG};

// ---------------------------------------------------------------------------
// Demodulator
// ---------------------------------------------------------------------------

/// Turns FM-discriminated audio into AIS frames.
///
/// Expects the output of an FM discriminator — instantaneous frequency,
/// roughly ±1 for a ±2400 Hz deviation — at a sample rate that is a whole
/// multiple of 9600.
pub struct AisDemod {
    /// One decoder per sample phase; see the module note on timing.
    phases: Vec<PhaseState>,
    /// Slow average of the discriminator output, subtracted before slicing.
    /// Without it, any tuning error becomes a DC offset and every bit
    /// decides the same way.
    dc: f32,
    counter: usize,
    oversample: usize,
    /// Frames emitted recently, to suppress the duplicates the phase search
    /// produces. A clean burst is decoded by every phase that lands inside
    /// the symbol, so without this one transmission is reported several
    /// times and every count is inflated.
    recent: Vec<(Vec<u8>, usize)>,
    pub frames_ok: u64,
}

struct PhaseState {
    hdlc: Hdlc,
    last: u8,
}

impl AisDemod {
    /// `rate` must divide evenly by 9600 — 48000 gives five phases.
    pub fn new(rate: f32) -> Self {
        let oversample = (rate / BAUD).round().max(1.0) as usize;
        AisDemod {
            phases: (0..oversample)
                .map(|_| PhaseState {
                    hdlc: Hdlc::new(),
                    last: 0,
                })
                .collect(),
            dc: 0.0,
            counter: 0,
            oversample,
            recent: Vec::new(),
            frames_ok: 0,
        }
    }

    pub fn process(&mut self, disc: &[f32], out: &mut Vec<Frame>) {
        for &s in disc {
            // Time constant of roughly a thousand bits: slow enough not to
            // follow the data, fast enough to track drift.
            self.dc += (s - self.dc) * 0.0002;
            let level: u8 = if s > self.dc { 1 } else { 0 };

            let phase = self.counter % self.oversample;
            self.counter = self.counter.wrapping_add(1);
            let ps = &mut self.phases[phase];

            // NRZI: a transmitted zero is sent as a transition, a one as no
            // transition. Decoding is therefore the opposite of the usual
            // XOR, which is an easy sign error to make and a hard one to
            // spot — every frame simply fails its checksum.
            let bit = if level == ps.last { 1 } else { 0 };
            ps.last = level;

            if let Some(bytes) = ps.hdlc.push(bit) {
                let now = self.counter;
                // A frame cannot legitimately repeat within its own
                // duration, so anything identical this close is the same
                // transmission seen from another sample phase.
                let window = self.oversample * 64;
                self.recent.retain(|(_, t)| now.saturating_sub(*t) < window);
                if self.recent.iter().any(|(b, _)| *b == bytes) {
                    continue;
                }
                self.recent.push((bytes.clone(), now));
                self.frames_ok += 1;
                out.push(Frame { bytes });
            }
        }
    }
}

/// A frame whose checksum closed. The trailing two bytes are the checksum
/// itself and are not part of the message.
#[derive(Clone, Debug)]
pub struct Frame {
    pub bytes: Vec<u8>,
}

impl Frame {
    pub fn payload(&self) -> &[u8] {
        &self.bytes[..self.bytes.len().saturating_sub(2)]
    }
}

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------

/// Read `n` bits starting at `off`, most significant first.
fn bits(d: &[u8], off: usize, n: usize) -> u64 {
    let mut v = 0u64;
    for k in 0..n {
        let b = off + k;
        let byte = b / 8;
        let bit = if byte < d.len() {
            (d[byte] >> (7 - (b % 8))) & 1
        } else {
            0
        };
        v = (v << 1) | bit as u64;
    }
    v
}

/// Two's-complement read, for latitude, longitude and rate of turn.
fn bits_signed(d: &[u8], off: usize, n: usize) -> i64 {
    let v = bits(d, off, n);
    let sign = 1u64 << (n - 1);
    if v & sign != 0 {
        (v as i64) - (1i64 << n)
    } else {
        v as i64
    }
}

/// AIS packs text six bits per character in its own alphabet.
fn text(d: &[u8], off: usize, chars: usize) -> String {
    let mut s = String::with_capacity(chars);
    for i in 0..chars {
        let c = bits(d, off + i * 6, 6) as u8;
        let ch = match c {
            0 => break,
            1..=26 => (b'A' + c - 1) as char,
            27 => '[',
            28 => '\\',
            29 => ']',
            30 => '^',
            31 => '_',
            32 => ' ',
            33..=63 => (c) as char,
            _ => ' ',
        };
        s.push(ch);
    }
    s.trim_end_matches(['@', ' ']).trim().to_string()
}

#[derive(Clone, Debug)]
pub enum Message {
    /// Where a vessel is, how fast and which way. Types 1, 2, 3 (class A)
    /// and 18 (class B).
    Position {
        mmsi: u32,
        lat: Option<f64>,
        lon: Option<f64>,
        sog_kt: Option<f32>,
        cog_deg: Option<f32>,
        heading_deg: Option<f32>,
        nav_status: Option<u8>,
        class_b: bool,
    },
    /// Who a vessel is. Type 5 (class A) and 24 (class B, in two parts).
    Static {
        mmsi: u32,
        name: String,
        callsign: String,
        ship_type: u8,
        destination: String,
    },
    Other {
        mmsi: u32,
        msg_type: u8,
    },
}

/// What the numbers mean, for the handful worth naming.
pub fn nav_status_text(s: u8) -> &'static str {
    match s {
        0 => "under way",
        1 => "at anchor",
        2 => "not under command",
        3 => "restricted manoeuvrability",
        4 => "constrained by draught",
        5 => "moored",
        6 => "aground",
        7 => "fishing",
        8 => "under sail",
        _ => "",
    }
}

pub fn ship_type_text(t: u8) -> &'static str {
    match t {
        20..=29 => "wing in ground",
        30 => "fishing",
        31 | 32 => "towing",
        33 => "dredging",
        34 => "diving",
        35 => "military",
        36 => "sailing",
        37 => "pleasure craft",
        40..=49 => "high speed craft",
        50 => "pilot",
        51 => "search and rescue",
        52 => "tug",
        53 => "port tender",
        55 => "law enforcement",
        58 => "medical transport",
        60..=69 => "passenger",
        70..=79 => "cargo",
        80..=89 => "tanker",
        _ => "",
    }
}

pub fn decode(payload: &[u8]) -> Option<Message> {
    if payload.len() < 8 {
        return None;
    }
    let msg_type = bits(payload, 0, 6) as u8;
    let mmsi = bits(payload, 8, 30) as u32;

    match msg_type {
        1 | 2 | 3 => {
            let nav = bits(payload, 38, 4) as u8;
            let sog = bits(payload, 50, 10);
            let lon = bits_signed(payload, 61, 28);
            let lat = bits_signed(payload, 89, 27);
            let cog = bits(payload, 116, 12);
            let hdg = bits(payload, 128, 9);
            Some(Message::Position {
                mmsi,
                // 181 degrees and 91 degrees are the documented "not
                // available" values, not real places in the Pacific.
                lon: (lon != 0x6791AC0).then(|| lon as f64 / 600_000.0),
                lat: (lat != 0x3412140).then(|| lat as f64 / 600_000.0),
                sog_kt: (sog != 1023).then(|| sog as f32 / 10.0),
                cog_deg: (cog != 3600).then(|| cog as f32 / 10.0),
                heading_deg: (hdg != 511).then(|| hdg as f32),
                nav_status: (nav != 15).then_some(nav),
                class_b: false,
            })
        }
        18 => {
            let sog = bits(payload, 46, 10);
            let lon = bits_signed(payload, 57, 28);
            let lat = bits_signed(payload, 85, 27);
            let cog = bits(payload, 112, 12);
            let hdg = bits(payload, 124, 9);
            Some(Message::Position {
                mmsi,
                lon: (lon != 0x6791AC0).then(|| lon as f64 / 600_000.0),
                lat: (lat != 0x3412140).then(|| lat as f64 / 600_000.0),
                sog_kt: (sog != 1023).then(|| sog as f32 / 10.0),
                cog_deg: (cog != 3600).then(|| cog as f32 / 10.0),
                heading_deg: (hdg != 511).then(|| hdg as f32),
                nav_status: None,
                class_b: true,
            })
        }
        5 => Some(Message::Static {
            mmsi,
            callsign: text(payload, 70, 7),
            name: text(payload, 112, 20),
            ship_type: bits(payload, 232, 8) as u8,
            destination: text(payload, 302, 20),
        }),
        24 => {
            // Part A carries the name; part B the callsign and type.
            let part = bits(payload, 38, 2);
            if part == 0 {
                Some(Message::Static {
                    mmsi,
                    name: text(payload, 40, 20),
                    callsign: String::new(),
                    ship_type: 0,
                    destination: String::new(),
                })
            } else {
                Some(Message::Static {
                    mmsi,
                    name: String::new(),
                    callsign: text(payload, 90, 7),
                    ship_type: bits(payload, 40, 8) as u8,
                    destination: String::new(),
                })
            }
        }
        _ => Some(Message::Other { mmsi, msg_type }),
    }
}

// ---------------------------------------------------------------------------
// Tracking
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct Vessel {
    pub mmsi: u32,
    pub name: Option<String>,
    pub callsign: Option<String>,
    pub ship_type: u8,
    pub destination: Option<String>,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub sog_kt: Option<f32>,
    pub cog_deg: Option<f32>,
    pub heading_deg: Option<f32>,
    pub nav_status: Option<u8>,
    pub class_b: bool,
    pub messages: u32,
    pub last_seen: Instant,
}

impl Vessel {
    fn new(mmsi: u32) -> Self {
        Vessel {
            mmsi,
            name: None,
            callsign: None,
            ship_type: 0,
            destination: None,
            lat: None,
            lon: None,
            sog_kt: None,
            cog_deg: None,
            heading_deg: None,
            nav_status: None,
            class_b: false,
            messages: 0,
            last_seen: Instant::now(),
        }
    }

    /// The first three digits of an MMSI are the country that issued it.
    /// Worth showing: it is the only identity a vessel has until its name
    /// message happens to arrive, which can take minutes.
    pub fn flag(&self) -> &'static str {
        match self.mmsi / 1_000_000 {
            316 => "Canada",
            338 | 366..=369 => "United States",
            232..=235 => "United Kingdom",
            244..=246 => "Netherlands",
            211 | 218 => "Germany",
            227..=228 => "France",
            247 => "Italy",
            257..=259 => "Norway",
            209 | 210 | 212 => "Cyprus",
            248..=249 => "Malta",
            351 | 352..=357 | 370..=373 => "Panama",
            538 => "Marshall Islands",
            563..=565 => "Singapore",
            477 | 412 | 413 => "China",
            431 | 432 => "Japan",
            _ => "",
        }
    }

    pub fn age(&self) -> Duration {
        self.last_seen.elapsed()
    }

    pub fn label(&self) -> String {
        match &self.name {
            Some(n) if !n.is_empty() => n.clone(),
            _ => format!("{}", self.mmsi),
        }
    }
}

pub struct VesselTable {
    map: HashMap<u32, Vessel>,
    /// Ships report far less often than aircraft — a vessel at anchor can
    /// be minutes between messages — so this is generous.
    pub timeout: Duration,
}

impl Default for VesselTable {
    fn default() -> Self {
        Self::new()
    }
}

impl VesselTable {
    pub fn new() -> Self {
        VesselTable {
            map: HashMap::new(),
            timeout: Duration::from_secs(900),
        }
    }

    pub fn ingest(&mut self, msg: &Message) -> u32 {
        let mmsi = match msg {
            Message::Position { mmsi, .. }
            | Message::Static { mmsi, .. }
            | Message::Other { mmsi, .. } => *mmsi,
        };
        let v = self.map.entry(mmsi).or_insert_with(|| Vessel::new(mmsi));
        v.last_seen = Instant::now();
        v.messages += 1;
        match msg {
            Message::Position {
                lat,
                lon,
                sog_kt,
                cog_deg,
                heading_deg,
                nav_status,
                class_b,
                ..
            } => {
                if lat.is_some() && lon.is_some() {
                    v.lat = *lat;
                    v.lon = *lon;
                }
                if sog_kt.is_some() {
                    v.sog_kt = *sog_kt;
                }
                if cog_deg.is_some() {
                    v.cog_deg = *cog_deg;
                }
                if heading_deg.is_some() {
                    v.heading_deg = *heading_deg;
                }
                if nav_status.is_some() {
                    v.nav_status = *nav_status;
                }
                v.class_b = *class_b;
            }
            Message::Static {
                name,
                callsign,
                ship_type,
                destination,
                ..
            } => {
                if !name.is_empty() {
                    v.name = Some(name.clone());
                }
                if !callsign.is_empty() {
                    v.callsign = Some(callsign.clone());
                }
                if *ship_type != 0 {
                    v.ship_type = *ship_type;
                }
                if !destination.is_empty() {
                    v.destination = Some(destination.clone());
                }
            }
            Message::Other { .. } => {}
        }
        mmsi
    }

    pub fn expire(&mut self) {
        let t = self.timeout;
        self.map.retain(|_, v| v.last_seen.elapsed() < t);
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    pub fn positioned(&self) -> usize {
        self.map.values().filter(|v| v.lat.is_some()).count()
    }

    pub fn snapshot(&self) -> Vec<Vessel> {
        let mut v: Vec<Vessel> = self.map.values().cloned().collect();
        v.sort_by(|a, b| a.last_seen.cmp(&b.last_seen).reverse());
        v
    }

    pub fn clear(&mut self) {
        self.map.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The checksum's own documented behaviour: running a correct frame
    /// including its FCS through the register leaves a fixed residue.
    #[test]
    fn checksum_matches_the_x25_definition() {
        // "123456789" is the standard CRC check string; X-25 gives 0x906E.
        assert_eq!(crc16(b"123456789"), 0x906E);
    }

    #[test]
    fn a_frame_with_its_own_checksum_verifies() {
        let mut f = b"HELLO AIS".to_vec();
        let c = crc16(&f);
        f.extend_from_slice(&c.to_le_bytes());
        assert!(fcs_ok(&f));
        // Any single-bit change must break it.
        let mut bad = f.clone();
        bad[3] ^= 0x10;
        assert!(!fcs_ok(&bad));
    }

    /// Build the bitstream a transmitter would send, then require the
    /// demodulator to give the same bytes back. This exercises stuffing,
    /// NRZI, flag detection, phase search and the checksum together.
    fn frame_bits(payload: &[u8]) -> Vec<u8> {
        let mut body = payload.to_vec();
        body.extend_from_slice(&crc16(payload).to_le_bytes());

        let mut bits: Vec<u8> = Vec::new();
        // Training sequence, then the opening flag.
        for i in 0..24 {
            bits.push((i % 2) as u8);
        }
        let push_flag = |b: &mut Vec<u8>| {
            for k in 0..8 {
                b.push((FLAG >> (7 - k)) & 1);
            }
        };
        push_flag(&mut bits);
        let mut ones = 0;
        for &byte in &body {
            for k in 0..8 {
                let bit = (byte >> (7 - k)) & 1;
                bits.push(bit);
                if bit == 1 {
                    ones += 1;
                    if ones == 5 {
                        bits.push(0); // stuffed
                        ones = 0;
                    }
                } else {
                    ones = 0;
                }
            }
        }
        push_flag(&mut bits);
        for _ in 0..24 {
            bits.push(1);
        }
        bits
    }

    /// NRZI-encode and expand to `oversample` samples per bit.
    fn to_samples(bits: &[u8], oversample: usize) -> Vec<f32> {
        let mut level = 0u8;
        let mut out = Vec::with_capacity(bits.len() * oversample);
        for &b in bits {
            if b == 0 {
                level ^= 1; // a zero is a transition
            }
            for _ in 0..oversample {
                out.push(if level == 1 { 0.8 } else { -0.8 });
            }
        }
        out
    }

    #[test]
    fn a_synthesised_burst_decodes_back_to_its_payload() {
        // A type 1 position report is 168 bits.
        let payload: Vec<u8> = (0..21).map(|i| (i as u8).wrapping_mul(37) ^ 0x5A).collect();
        let bits = frame_bits(&payload);
        let samples = to_samples(&bits, 5);

        let mut d = AisDemod::new(48_000.0);
        let mut out = Vec::new();
        // Lead-in, so the phase search has to find the burst rather than
        // start conveniently aligned with it.
        d.process(&vec![-0.8f32; 37], &mut out);
        d.process(&samples, &mut out);
        assert!(!out.is_empty(), "no frame decoded");
        assert_eq!(out[0].payload(), &payload[..]);
    }

    #[test]
    fn stuffed_data_that_imitates_a_flag_survives() {
        // Six consecutive ones in the data is exactly what stuffing exists
        // to prevent from looking like a frame delimiter.
        let payload = vec![0xFF, 0x7E, 0x7E, 0xFF, 0x00, 0x3F, 0xFC, 0x01];
        let bits = frame_bits(&payload);
        let samples = to_samples(&bits, 5);
        let mut d = AisDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&samples, &mut out);
        // Exactly one: a synthesised square burst decodes cleanly at every
        // sample phase, so this also pins the duplicate suppression.
        assert_eq!(out.len(), 1, "expected one frame, got {}", out.len());
        assert_eq!(out[0].payload(), &payload[..]);
    }

    #[test]
    fn noise_decodes_to_nothing() {
        let mut rng: u32 = 12345;
        let noise: Vec<f32> = (0..200_000)
            .map(|_| {
                rng = rng.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
                (rng >> 8) as f32 / 8_388_608.0 - 1.0
            })
            .collect();
        let mut d = AisDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&noise, &mut out);
        assert!(out.is_empty(), "noise produced {} frames", out.len());
    }

    /// A real type 1 report: the payload from the widely published example
    /// sentence `!AIVDM,1,1,,B,15M67FC000G?ufbE`oFcwqLn068r,0*1A`. It
    /// decodes to a vessel in San Francisco Bay, stopped, heading 302°.
    #[test]
    fn decodes_a_real_position_report() {
        // The six-bit ASCII payload above, unpacked to bytes.
        let armored = "15M67FC000G?ufbE`oFcwqLn068r";
        let mut bits: Vec<u8> = Vec::new();
        for ch in armored.chars() {
            let mut v = ch as u8 - 48;
            if v > 40 {
                v -= 8;
            }
            for k in (0..6).rev() {
                bits.push((v >> k) & 1);
            }
        }
        let payload = pack(&bits[..bits.len() / 8 * 8]);

        match decode(&payload).expect("should decode") {
            Message::Position {
                mmsi,
                lat,
                lon,
                sog_kt,
                class_b,
                ..
            } => {
                assert_eq!(mmsi, 366_053_209);
                assert!(!class_b);
                let (la, lo) = (lat.expect("lat"), lon.expect("lon"));
                assert!((la - 37.8160).abs() < 0.001, "lat was {la}");
                assert!((lo + 122.3416).abs() < 0.001, "lon was {lo}");
                assert_eq!(sog_kt, Some(0.0));
            }
            other => panic!("expected a position, got {other:?}"),
        }
    }

    #[test]
    fn six_bit_text_reads_as_words() {
        // "SWEEP" packed six bits per character.
        let mut bits = Vec::new();
        for c in [19u8, 23, 5, 5, 16] {
            for k in (0..6).rev() {
                bits.push((c >> k) & 1);
            }
        }
        while bits.len() % 8 != 0 {
            bits.push(0);
        }
        let d = pack(&bits);
        assert_eq!(text(&d, 0, 5), "SWEEP");
    }
}
