//! The scheduler: what the tuner does next.
//!
//! This is where the one-tuner constraint actually lives. Sweeping and
//! listening cannot happen at once, so every decision here is a trade of one
//! against the other, and the trade should be visible rather than implicit.

use crate::detect::{Squelch, SquelchState};
use crate::resolve::{RunPlan, RETUNE_MS};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    /// Walk every window in order. Nothing is demodulated.
    Sweep,
    /// Sit on one channel. Audio is continuous, the rest of the plan is dark.
    Park(usize),
    /// Alternate. Both jobs degrade; the point is that neither stops.
    Interleave,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Task {
    /// Collect a dwell's worth of spectrum from one window.
    Observe {
        window: usize,
        center_mhz: f64,
        retune_ms: u32,
        dwell_ms: u32,
    },
    /// Demodulate one channel for a slice of time.
    Listen {
        channel: usize,
        window: usize,
        center_mhz: f64,
        retune_ms: u32,
        ms: u32,
    },
}

impl Task {
    pub fn total_ms(&self) -> u32 {
        match self {
            Task::Observe {
                retune_ms, dwell_ms, ..
            } => retune_ms + dwell_ms,
            Task::Listen { retune_ms, ms, .. } => retune_ms + ms,
        }
    }
    pub fn center_mhz(&self) -> f64 {
        match self {
            Task::Observe { center_mhz, .. } | Task::Listen { center_mhz, .. } => *center_mhz,
        }
    }
    pub fn window(&self) -> usize {
        match self {
            Task::Observe { window, .. } | Task::Listen { window, .. } => *window,
        }
    }
}

/// How long a single Listen slice runs before the scheduler gets to reconsider.
/// Short enough that a priority check feels immediate, long enough not to
/// thrash the audio pipeline.
pub const LISTEN_SLICE_MS: u32 = 100;

pub struct Scheduler {
    plan: RunPlan,
    mode: Mode,
    /// Next window to visit when sweeping.
    cursor: usize,
    /// Where to pick the sweep back up after a stop-and-listen ends.
    resume_at: usize,
    parked: Option<usize>,
    squelch: Squelch,
    current_center: Option<f64>,
    elapsed_ms: u64,
    last_priority_ms: u64,
    pub priority_interval_ms: u32,
    /// Interleave: how long to sweep before returning to the parked channel.
    pub interleave_sweep_ms: u32,
    pub interleave_listen_ms: u32,
    interleave_phase_ms: u32,
    interleave_sweeping: bool,
    /// Which window holds each channel.
    channel_window: Vec<usize>,
}

impl Scheduler {
    pub fn new(plan: RunPlan) -> Self {
        let mut channel_window = vec![usize::MAX; plan.channels.len()];
        for (wi, w) in plan.windows.iter().enumerate() {
            for &ci in &w.channels {
                channel_window[ci] = wi;
            }
        }
        let squelch = Squelch::new(plan.squelch_db as f32, plan.hang_ms);
        Scheduler {
            plan,
            mode: Mode::Sweep,
            cursor: 0,
            resume_at: 0,
            parked: None,
            squelch,
            current_center: None,
            elapsed_ms: 0,
            last_priority_ms: 0,
            priority_interval_ms: 2000,
            interleave_sweep_ms: 3000,
            interleave_listen_ms: 3000,
            interleave_phase_ms: 0,
            interleave_sweeping: false,
            channel_window,
        }
    }

    pub fn plan(&self) -> &RunPlan {
        &self.plan
    }
    pub fn mode(&self) -> Mode {
        self.mode
    }
    pub fn elapsed_ms(&self) -> u64 {
        self.elapsed_ms
    }
    pub fn parked_channel(&self) -> Option<usize> {
        self.parked
    }
    pub fn squelch_state(&self) -> SquelchState {
        self.squelch.state()
    }

    pub fn set_mode(&mut self, mode: Mode) {
        self.mode = mode;
        match mode {
            Mode::Park(ch) => {
                self.parked = Some(ch);
                self.squelch = Squelch::new(self.plan.squelch_db as f32, self.plan.hang_ms);
            }
            Mode::Sweep => {
                self.parked = None;
            }
            Mode::Interleave => {
                self.interleave_sweeping = false;
                self.interleave_phase_ms = 0;
            }
        }
    }

    /// Stop the sweep and listen to `channel`. The sweep resumes from where it
    /// left off, not from the start — otherwise the first window in the plan
    /// gets checked far more often than the last.
    pub fn stop_and_listen(&mut self, channel: usize) {
        if self.plan.channels[channel].locked_out {
            return;
        }
        self.resume_at = self.cursor;
        self.parked = Some(channel);
        self.squelch = Squelch::new(self.plan.squelch_db as f32, self.plan.hang_ms);
        // Assume the carrier that triggered this is present.
        self.squelch.update(self.plan.squelch_db as f32 + 1.0, 0);
    }

    /// Feed the measured signal-over-floor for the channel being listened to.
    /// When squelch finally closes, the sweep resumes on its own.
    pub fn report_snr(&mut self, snr_db: f32, dt_ms: u32) {
        if self.parked.is_none() || self.mode == Mode::Park(self.parked.unwrap()) {
            // Explicit parking is manual: squelch gates audio but never resumes.
            if let Some(_) = self.parked {
                self.squelch.update(snr_db, dt_ms);
            }
            return;
        }
        if self.squelch.update(snr_db, dt_ms) == SquelchState::Closed {
            self.parked = None;
            self.cursor = self.resume_at;
        }
    }

    fn window_center(&self, w: usize) -> f64 {
        self.plan.windows[w].center_mhz
    }

    fn retune_for(&self, center: f64) -> u32 {
        match self.current_center {
            Some(c) if (c - center).abs() < 1e-9 => 0,
            _ => RETUNE_MS,
        }
    }

    fn observe(&mut self, window: usize) -> Task {
        let center = self.window_center(window);
        let t = Task::Observe {
            window,
            center_mhz: center,
            retune_ms: self.retune_for(center),
            dwell_ms: self.plan.dwell_ms,
        };
        self.current_center = Some(center);
        t
    }

    fn listen(&mut self, channel: usize, ms: u32) -> Task {
        let window = self.channel_window[channel];
        let center = self.window_center(window);
        let t = Task::Listen {
            channel,
            window,
            center_mhz: center,
            retune_ms: self.retune_for(center),
            ms,
        };
        self.current_center = Some(center);
        t
    }

    /// The next thing the tuner should do. Advances the scheduler's clock by
    /// the task's duration, so tests are deterministic and need no wall clock.
    pub fn next(&mut self) -> Task {
        let task = self.decide();
        self.elapsed_ms += task.total_ms() as u64;
        task
    }

    fn decide(&mut self) -> Task {
        // A priority channel gets checked on a fixed interval no matter what
        // else is happening. This is the whole reason to have one.
        if let Some(p) = self.due_priority() {
            self.last_priority_ms = self.elapsed_ms;
            return self.observe(self.channel_window[p]);
        }

        match self.mode {
            Mode::Park(ch) => self.listen(ch, LISTEN_SLICE_MS),
            Mode::Interleave => {
                let ch = self.parked;
                let flip = if self.interleave_sweeping {
                    self.interleave_phase_ms >= self.interleave_sweep_ms
                } else {
                    self.interleave_phase_ms >= self.interleave_listen_ms
                };
                if flip {
                    self.interleave_sweeping = !self.interleave_sweeping;
                    self.interleave_phase_ms = 0;
                }
                if self.interleave_sweeping || ch.is_none() {
                    let w = self.cursor;
                    self.cursor = (self.cursor + 1) % self.plan.windows.len();
                    let t = self.observe(w);
                    self.interleave_phase_ms += t.total_ms();
                    t
                } else {
                    let t = self.listen(ch.unwrap(), LISTEN_SLICE_MS);
                    self.interleave_phase_ms += t.total_ms();
                    t
                }
            }
            Mode::Sweep => {
                if let Some(ch) = self.parked {
                    return self.listen(ch, LISTEN_SLICE_MS);
                }
                let w = self.cursor;
                self.cursor = (self.cursor + 1) % self.plan.windows.len();
                self.observe(w)
            }
        }
    }

    fn due_priority(&self) -> Option<usize> {
        if self.elapsed_ms.saturating_sub(self.last_priority_ms)
            < self.priority_interval_ms as u64
        {
            return None;
        }
        self.plan
            .channels
            .iter()
            .position(|c| c.priority && !c.locked_out)
            .filter(|&p| self.channel_window[p] != usize::MAX)
            // No point interrupting a listen to check the channel we're on.
            .filter(|&p| self.parked != Some(p))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::plan::*;
    use crate::resolve::resolve;

    fn sched(channels: Vec<Channel>, priority: Vec<f64>) -> Scheduler {
        let p = ScanPlan {
            name: "t".into(),
            windows: vec![],
            channels,
            demod: Demod::Nfm,
            step_khz: 12.5,
            squelch_db: 8.0,
            hang_ms: 500,
            dwell_ms: 40,
            priority,
            lockout: vec![],
            ctcss_hz: None,
            source: "user".into(),
        };
        Scheduler::new(resolve(&p, false).unwrap())
    }

    fn spread() -> Scheduler {
        sched(
            vec![
                Channel::new(118.8, "a"),
                Channel::new(126.0, "b"),
                Channel::new(133.0, "c"),
            ],
            vec![],
        )
    }

    #[test]
    fn sweep_visits_every_window_in_order_then_wraps() {
        let mut s = spread();
        let n = s.plan().windows.len();
        assert_eq!(n, 3);
        let seen: Vec<usize> = (0..n * 2).map(|_| s.next().window()).collect();
        assert_eq!(seen, vec![0, 1, 2, 0, 1, 2]);
    }

    #[test]
    fn a_single_window_plan_never_pays_retune_cost_twice() {
        let mut s = sched(vec![Channel::new(146.94, "a")], vec![]);
        let first = s.next();
        let second = s.next();
        assert_eq!(first.total_ms(), RETUNE_MS + 40);
        assert_eq!(second.total_ms(), 40, "already on frequency; no retune");
    }

    #[test]
    fn stop_and_listen_holds_the_channel_until_squelch_closes() {
        let mut s = spread();
        s.next();
        s.next(); // cursor now at window 2
        s.stop_and_listen(1);

        for _ in 0..5 {
            let t = s.next();
            assert!(matches!(t, Task::Listen { channel: 1, .. }), "got {t:?}");
            s.report_snr(20.0, LISTEN_SLICE_MS);
        }
        // Carrier drops. Hang is 500 ms, so it holds a little longer.
        s.report_snr(0.0, LISTEN_SLICE_MS);
        assert!(matches!(s.next(), Task::Listen { .. }), "hang must hold audio");
        for _ in 0..6 {
            s.report_snr(0.0, LISTEN_SLICE_MS);
        }
        assert!(matches!(s.next(), Task::Observe { .. }), "sweep should resume");
    }

    #[test]
    fn sweep_resumes_where_it_left_off_not_at_the_start() {
        let mut s = spread();
        s.next(); // window 0
        s.next(); // window 1, cursor -> 2
        s.stop_and_listen(0);
        s.report_snr(20.0, 100);
        s.next();
        for _ in 0..10 {
            s.report_snr(0.0, 200);
        }
        let t = s.next();
        assert_eq!(
            t.window(),
            2,
            "resuming at window 0 would starve the end of the plan"
        );
    }

    #[test]
    fn a_locked_out_channel_is_never_parked_on() {
        let p = ScanPlan {
            name: "t".into(),
            windows: vec![],
            channels: vec![Channel::new(462.5625, "a"), Channel::new(462.5875, "b")],
            demod: Demod::Nfm,
            step_khz: 12.5,
            squelch_db: 8.0,
            hang_ms: 500,
            dwell_ms: 40,
            priority: vec![],
            lockout: vec![462.5875],
            ctcss_hz: None,
            source: "user".into(),
        };
        let mut s = Scheduler::new(resolve(&p, false).unwrap());
        s.stop_and_listen(1);
        assert!(s.parked_channel().is_none());
        assert!(matches!(s.next(), Task::Observe { .. }));
    }

    #[test]
    fn priority_channel_is_checked_on_schedule_while_listening() {
        let mut s = sched(
            vec![
                Channel::new(118.8, "tower"),
                Channel::new(133.0, "guard"),
            ],
            vec![133.0],
        );
        s.priority_interval_ms = 500;
        let guard_window = s.plan().windows.iter().position(|w| w.contains(133.0)).unwrap();

        s.next();
        s.stop_and_listen(0);
        let mut checked = false;
        for _ in 0..30 {
            let t = s.next();
            s.report_snr(20.0, LISTEN_SLICE_MS);
            if matches!(t, Task::Observe { window, .. } if window == guard_window) {
                checked = true;
                break;
            }
        }
        assert!(checked, "priority channel was never revisited");
    }

    #[test]
    fn priority_does_not_interrupt_listening_to_itself() {
        let mut s = sched(vec![Channel::new(121.5, "guard")], vec![121.5]);
        s.priority_interval_ms = 100;
        s.set_mode(Mode::Park(0));
        for _ in 0..10 {
            let t = s.next();
            assert!(
                matches!(t, Task::Listen { channel: 0, .. }),
                "no point checking the channel we are already on: {t:?}"
            );
            s.report_snr(20.0, LISTEN_SLICE_MS);
        }
    }

    #[test]
    fn park_mode_stays_parked_even_when_the_channel_goes_quiet() {
        let mut s = spread();
        s.set_mode(Mode::Park(2));
        for _ in 0..20 {
            let t = s.next();
            assert!(matches!(t, Task::Listen { channel: 2, .. }), "{t:?}");
            s.report_snr(0.0, LISTEN_SLICE_MS);
        }
        assert_eq!(s.squelch_state(), SquelchState::Closed, "audio muted");
        assert_eq!(s.mode(), Mode::Park(2), "but the tuner stays put");
    }

    #[test]
    fn interleave_alternates_between_both_jobs() {
        let mut s = spread();
        s.stop_and_listen(0);
        s.set_mode(Mode::Interleave);
        s.interleave_sweep_ms = 300;
        s.interleave_listen_ms = 300;

        let mut observed = 0;
        let mut listened = 0;
        for _ in 0..40 {
            match s.next() {
                Task::Observe { .. } => observed += 1,
                Task::Listen { .. } => listened += 1,
            }
            s.report_snr(20.0, LISTEN_SLICE_MS);
        }
        assert!(observed > 3, "interleave stopped sweeping ({observed})");
        assert!(listened > 3, "interleave stopped listening ({listened})");
    }

    #[test]
    fn the_clock_advances_by_real_task_durations() {
        let mut s = spread();
        let mut expected = 0u64;
        for _ in 0..10 {
            expected += s.next().total_ms() as u64;
        }
        assert_eq!(s.elapsed_ms(), expected);
        // Three windows at 12 ms retune + 40 ms dwell: ~156 ms per full cycle.
        assert!((520..=530).contains(&expected), "{expected} ms for 10 tasks");
    }
}
