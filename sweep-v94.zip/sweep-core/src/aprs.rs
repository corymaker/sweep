//! APRS — the amateur position and messaging network, on 144.390 MHz in
//! North America.
//!
//! Three layers, and only the bottom one is new here:
//!
//! ```text
//!   FM audio ──► AFSK 1200 ──► NRZI ──► HDLC ──► AX.25 ──► APRS text
//! ```
//!
//! The framing is the same HDLC that carries AIS, so it comes from
//! [`crate::hdlc`] rather than being written twice. What differs is how
//! bits arrive: AIS shifts the carrier directly, while APRS sends audio
//! tones through an ordinary FM radio — 1200 Hz for a one, 2200 Hz for a
//! zero, the Bell 202 modem from the 1970s, still in use because every
//! handheld already has the audio path for it.
//!
//! Above that, AX.25 gives every frame a source and destination callsign
//! and the list of digipeaters that relayed it, which is why an APRS
//! packet can tell you not just where a station is but how its signal got
//! to you.
//!
//! What this does not decode: MIC-E, which smuggles position into the
//! destination callsign field using a substitution table. It is common
//! traffic and it is better to say so than to half-decode it into
//! plausible, wrong coordinates.

use crate::hdlc::{fcs_ok, Hdlc, FLAG};
use crate::tone::ToneDemod;
use std::collections::HashMap;
use std::f32::consts::TAU;
use std::time::{Duration, Instant};

/// The North American APRS channel.
pub const APRS_HZ: f64 = 144_390_000.0;

/// Bell 202: a one is 1200 Hz, a zero 2200 Hz.
pub const MARK_HZ: f32 = 1200.0;
pub const SPACE_HZ: f32 = 2200.0;
pub const BAUD: f32 = 1200.0;

// ---------------------------------------------------------------------------
// AFSK demodulator
// ---------------------------------------------------------------------------

/// Bell 202 receiver: audio in, AX.25 frames out.
///
/// Tone decision is a pair of correlators one bit long — the window is
/// compared against 1200 Hz and against 2200 Hz, and whichever matches
/// better wins. Bit timing is a digital PLL nudged by every transition in
/// that decision, which is what keeps it locked through a long run of
/// identical bits where there is nothing to synchronise on.
pub struct Afsk1200 {
    tone: ToneDemod,
    nrzi_last: u8,
    hdlc: Hdlc,
    rate: f32,
    pub frames_ok: u64,
}

impl Afsk1200 {
    pub fn new(rate: f32) -> Self {
        Afsk1200 {
            tone: ToneDemod::new(rate, MARK_HZ, SPACE_HZ, BAUD),
            nrzi_last: 0,
            hdlc: Hdlc::new(),
            rate,
            frames_ok: 0,
        }
    }

    pub fn sample_rate(&self) -> f32 {
        self.rate
    }

    pub fn process(&mut self, audio: &[f32], out: &mut Vec<Frame>) {
        let hdlc = &mut self.hdlc;
        let nrzi_last = &mut self.nrzi_last;
        let n = &mut self.frames_ok;
        self.tone.process(audio, &mut |level| {
            // NRZI, as in AIS: no transition is a one.
            let bit = if level == *nrzi_last { 1 } else { 0 };
            *nrzi_last = level;
            if let Some(bytes) = hdlc.push(bit) {
                *n += 1;
                out.push(Frame { bytes });
            }
        });
    }
}

/// An AX.25 frame whose checksum closed.
#[derive(Clone, Debug)]
pub struct Frame {
    pub bytes: Vec<u8>,
}

// ---------------------------------------------------------------------------
// AX.25
// ---------------------------------------------------------------------------

/// A callsign with its SSID, e.g. `VE3ABC-9`.
#[derive(Clone, Debug, PartialEq)]
pub struct Call {
    pub call: String,
    pub ssid: u8,
}

impl std::fmt::Display for Call {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if self.ssid == 0 {
            write!(f, "{}", self.call)
        } else {
            write!(f, "{}-{}", self.call, self.ssid)
        }
    }
}

#[derive(Clone, Debug)]
pub struct Packet {
    pub source: Call,
    pub destination: Call,
    pub path: Vec<Call>,
    pub info: String,
}

/// Split an AX.25 UI frame into its callsigns and payload.
///
/// Addresses are six characters shifted up one bit, so the low bit of each
/// byte is free to mark the end of the address list — which is how a
/// receiver knows where the digipeater path stops without a length field.
pub fn parse_ax25(frame: &[u8]) -> Option<Packet> {
    let body = &frame[..frame.len().checked_sub(2)?];
    if body.len() < 16 {
        return None;
    }
    let mut calls: Vec<Call> = Vec::new();
    let mut i = 0usize;
    loop {
        if i + 7 > body.len() || calls.len() > 10 {
            return None;
        }
        let mut c = String::new();
        for k in 0..6 {
            let ch = (body[i + k] >> 1) as char;
            if ch != ' ' {
                c.push(ch);
            }
        }
        let ssid_byte = body[i + 6];
        calls.push(Call {
            call: c,
            ssid: (ssid_byte >> 1) & 0x0F,
        });
        i += 7;
        if ssid_byte & 1 == 1 {
            break;
        }
    }
    if calls.len() < 2 {
        return None;
    }
    // Control byte 0x03 is an unnumbered-information frame; PID 0xF0 means
    // no layer-3 protocol. Everything APRS sends looks like this, and
    // anything else is a different conversation on a shared channel.
    if i + 2 > body.len() || body[i] != 0x03 || body[i + 1] != 0xF0 {
        return None;
    }
    let info = String::from_utf8_lossy(&body[i + 2..]).to_string();
    let destination = calls[0].clone();
    let source = calls[1].clone();
    Some(Packet {
        source,
        destination,
        path: calls[2..].to_vec(),
        info,
    })
}

// ---------------------------------------------------------------------------
// APRS payload
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, Default)]
pub struct Report {
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub course_deg: Option<f32>,
    pub speed_kt: Option<f32>,
    pub altitude_ft: Option<i32>,
    pub symbol: char,
    pub comment: String,
    /// Set when the payload is a format this does not decode, so the UI can
    /// say "heard but not understood" rather than silently dropping it.
    pub undecoded: Option<&'static str>,
}

/// Degrees from the `DDMM.mmN` form APRS inherited from NMEA.
fn dm_to_deg(d: f64, m: f64, neg: bool) -> f64 {
    let v = d + m / 60.0;
    if neg {
        -v
    } else {
        v
    }
}

fn parse_uncompressed(s: &str) -> Option<(f64, f64, char, usize)> {
    let b = s.as_bytes();
    if b.len() < 19 {
        return None;
    }
    let lat_d: f64 = s.get(0..2)?.trim().parse().ok()?;
    let lat_m: f64 = s.get(2..7)?.trim().parse().ok()?;
    let ns = b[7] as char;
    let lon_d: f64 = s.get(9..12)?.trim().parse().ok()?;
    let lon_m: f64 = s.get(12..17)?.trim().parse().ok()?;
    let ew = b[17] as char;
    if !matches!(ns, 'N' | 'S') || !matches!(ew, 'E' | 'W') {
        return None;
    }
    Some((
        dm_to_deg(lat_d, lat_m, ns == 'S'),
        dm_to_deg(lon_d, lon_m, ew == 'W'),
        b[18] as char,
        19,
    ))
}

/// The base-91 compressed form: four characters of latitude, four of
/// longitude, each digit offset by 33.
fn parse_compressed(s: &str) -> Option<(f64, f64, char, usize)> {
    let b = s.as_bytes();
    if b.len() < 13 {
        return None;
    }
    let v = |r: &[u8]| -> f64 {
        r.iter()
            .fold(0.0, |acc, &c| acc * 91.0 + (c as f64 - 33.0))
    };
    let lat = 90.0 - v(&b[1..5]) / 380_926.0;
    let lon = -180.0 + v(&b[5..9]) / 190_463.0;
    if !(-90.0..=90.0).contains(&lat) || !(-180.0..=180.0).contains(&lon) {
        return None;
    }
    Some((lat, lon, b[9] as char, 13))
}

/// Pull whatever position and extras an APRS payload carries.
pub fn parse_report(info: &str) -> Report {
    let mut r = Report::default();
    if info.is_empty() {
        r.undecoded = Some("empty");
        return r;
    }
    let kind = info.as_bytes()[0] as char;
    // '!' and '=' are positions; '/' and '@' are positions with a seven
    // character timestamp in front of them.
    let body = match kind {
        '!' | '=' => &info[1..],
        '/' | '@' => {
            if info.len() < 9 {
                r.undecoded = Some("truncated");
                return r;
            }
            &info[8..]
        }
        ':' => {
            r.comment = info[1..].trim().to_string();
            r.undecoded = Some("message");
            return r;
        }
        ';' => {
            r.undecoded = Some("object");
            return r;
        }
        '>' => {
            r.comment = info[1..].trim().to_string();
            r.undecoded = Some("status");
            return r;
        }
        'T' | '_' => {
            r.undecoded = Some("telemetry or weather");
            return r;
        }
        '`' | '\'' => {
            // MIC-E hides position in the destination callsign using a
            // substitution table. Decoding it wrong would put a station in
            // the wrong place with full confidence, so it is reported as
            // heard and left at that.
            r.undecoded = Some("MIC-E, not decoded");
            return r;
        }
        _ => {
            r.undecoded = Some("unrecognised format");
            return r;
        }
    };

    let first = body.as_bytes().first().copied().unwrap_or(b' ');
    let parsed = if first.is_ascii_digit() {
        parse_uncompressed(body)
    } else {
        parse_compressed(body)
    };

    let Some((lat, lon, symbol, used)) = parsed else {
        r.undecoded = Some("position unreadable");
        return r;
    };
    r.lat = Some(lat);
    r.lon = Some(lon);
    r.symbol = symbol;

    let rest = &body[used.min(body.len())..];
    // Course and speed ride in the comment as `CSE/SPD`, degrees over
    // knots.
    if rest.len() >= 7 && rest.as_bytes()[3] == b'/' {
        if let (Ok(c), Ok(sp)) = (rest[0..3].parse::<f32>(), rest[4..7].parse::<f32>()) {
            if c > 0.0 {
                r.course_deg = Some(c);
            }
            r.speed_kt = Some(sp);
        }
    }
    if let Some(p) = rest.find("/A=") {
        if let Ok(a) = rest[p + 3..].chars().take(6).collect::<String>().parse::<i32>() {
            r.altitude_ft = Some(a);
        }
    }
    r.comment = rest.trim().to_string();
    r
}

// ---------------------------------------------------------------------------
// Tracking
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct Station {
    pub call: String,
    pub lat: Option<f64>,
    pub lon: Option<f64>,
    pub course_deg: Option<f32>,
    pub speed_kt: Option<f32>,
    pub altitude_ft: Option<i32>,
    pub symbol: char,
    pub comment: String,
    /// How the packet reached us: direct, or via which digipeaters.
    pub via: String,
    pub packets: u32,
    pub last_seen: Instant,
}

impl Station {
    /// APRS symbols are two characters; these are the ones worth naming.
    pub fn kind(&self) -> &'static str {
        match self.symbol {
            '>' => "car",
            'k' => "truck",
            'j' => "jeep",
            'v' => "van",
            'U' => "bus",
            '*' => "snowmobile",
            'b' => "bicycle",
            '<' => "motorcycle",
            '^' => "aircraft",
            'Y' => "yacht",
            's' => "boat",
            '_' => "weather station",
            '#' => "digipeater",
            '-' => "home station",
            'I' => "gateway",
            'O' => "balloon",
            '[' => "person",
            _ => "",
        }
    }

    pub fn age(&self) -> Duration {
        self.last_seen.elapsed()
    }
}

pub struct StationTable {
    map: HashMap<String, Station>,
    /// APRS stations beacon every few minutes at best, and a fixed station
    /// may be much slower, so this keeps them a long time.
    pub timeout: Duration,
}

impl Default for StationTable {
    fn default() -> Self {
        Self::new()
    }
}

impl StationTable {
    pub fn new() -> Self {
        StationTable {
            map: HashMap::new(),
            timeout: Duration::from_secs(3600),
        }
    }

    pub fn ingest(&mut self, p: &Packet) -> String {
        let key = p.source.to_string();
        let r = parse_report(&p.info);
        let via = if p.path.is_empty() {
            "direct".to_string()
        } else {
            p.path
                .iter()
                .map(|c| c.to_string())
                .collect::<Vec<_>>()
                .join(" ")
        };
        let s = self.map.entry(key.clone()).or_insert_with(|| Station {
            call: key.clone(),
            lat: None,
            lon: None,
            course_deg: None,
            speed_kt: None,
            altitude_ft: None,
            symbol: ' ',
            comment: String::new(),
            via: String::new(),
            packets: 0,
            last_seen: Instant::now(),
        });
        s.last_seen = Instant::now();
        s.packets += 1;
        s.via = via;
        if r.lat.is_some() {
            s.lat = r.lat;
            s.lon = r.lon;
            s.symbol = r.symbol;
        }
        if r.course_deg.is_some() {
            s.course_deg = r.course_deg;
        }
        if r.speed_kt.is_some() {
            s.speed_kt = r.speed_kt;
        }
        if r.altitude_ft.is_some() {
            s.altitude_ft = r.altitude_ft;
        }
        if !r.comment.is_empty() {
            s.comment = r.comment;
        }
        key
    }

    pub fn expire(&mut self) {
        let t = self.timeout;
        self.map.retain(|_, s| s.last_seen.elapsed() < t);
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    pub fn positioned(&self) -> usize {
        self.map.values().filter(|s| s.lat.is_some()).count()
    }

    pub fn snapshot(&self) -> Vec<Station> {
        let mut v: Vec<Station> = self.map.values().cloned().collect();
        v.sort_by(|a, b| a.last_seen.cmp(&b.last_seen).reverse());
        v
    }

    pub fn clear(&mut self) {
        self.map.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::hdlc::crc16;

    /// Build an AX.25 UI frame the way a transmitter would.
    fn ax25(dest: &str, src: &str, path: &[&str], info: &str) -> Vec<u8> {
        let mut out = Vec::new();
        let mut addrs: Vec<&str> = vec![dest, src];
        addrs.extend_from_slice(path);
        let last = addrs.len() - 1;
        for (i, a) in addrs.iter().enumerate() {
            let (call, ssid) = match a.split_once('-') {
                Some((c, s)) => (c, s.parse::<u8>().unwrap_or(0)),
                None => (*a, 0),
            };
            for k in 0..6 {
                let ch = call.as_bytes().get(k).copied().unwrap_or(b' ');
                out.push(ch << 1);
            }
            let mut b = 0x60 | (ssid << 1);
            if i == last {
                b |= 1;
            }
            out.push(b);
        }
        out.push(0x03);
        out.push(0xF0);
        out.extend_from_slice(info.as_bytes());
        let c = crc16(&out);
        out.extend_from_slice(&c.to_le_bytes());
        out
    }

    #[test]
    fn callsigns_and_path_come_out_of_an_ax25_frame() {
        let f = ax25("APRS", "VE3ABC-9", &["WIDE1-1", "WIDE2-2"], "!4330.00N/07935.00W>test");
        let p = parse_ax25(&f).expect("should parse");
        assert_eq!(p.destination.to_string(), "APRS");
        assert_eq!(p.source.to_string(), "VE3ABC-9");
        assert_eq!(
            p.path.iter().map(|c| c.to_string()).collect::<Vec<_>>(),
            vec!["WIDE1-1", "WIDE2-2"]
        );
        assert!(p.info.starts_with('!'));
    }

    #[test]
    fn an_uncompressed_position_lands_where_it_should() {
        // 43°30.00' N, 79°35.00' W — just west of Toronto.
        let r = parse_report("!4330.00N/07935.00W>Mobile");
        assert!((r.lat.unwrap() - 43.5).abs() < 1e-6, "lat {:?}", r.lat);
        assert!((r.lon.unwrap() + 79.5833).abs() < 1e-3, "lon {:?}", r.lon);
        assert_eq!(r.symbol, '>');
        assert!(r.undecoded.is_none());
    }

    #[test]
    fn southern_and_eastern_hemispheres_get_the_right_sign() {
        let r = parse_report("!3351.70S/15112.60E-Sydney");
        assert!((r.lat.unwrap() + 33.8617).abs() < 1e-3, "lat {:?}", r.lat);
        assert!((r.lon.unwrap() - 151.2100).abs() < 1e-3, "lon {:?}", r.lon);
    }

    #[test]
    fn course_speed_and_altitude_are_read_from_the_comment() {
        let r = parse_report("!4330.00N/07935.00W>088/036/A=001234Rolling");
        assert_eq!(r.course_deg, Some(88.0));
        assert_eq!(r.speed_kt, Some(36.0));
        assert_eq!(r.altitude_ft, Some(1234));
    }

    #[test]
    fn mic_e_is_reported_rather_than_guessed() {
        let r = parse_report("`cO(l!_>/\"4T}");
        assert!(r.lat.is_none());
        assert_eq!(r.undecoded, Some("MIC-E, not decoded"));
    }

    /// Synthesise Bell 202 audio for a real frame and require the same
    /// bytes back. This is the only test that exercises the correlators,
    /// the bit-timing loop, NRZI and framing together.
    fn to_audio(frame: &[u8], rate: f32) -> Vec<f32> {
        // Flags, data with stuffing, flags — the transmitter's job.
        let mut bits: Vec<u8> = Vec::new();
        let push_flag = |b: &mut Vec<u8>| {
            for k in 0..8 {
                b.push((FLAG >> (7 - k)) & 1);
            }
        };
        for _ in 0..8 {
            push_flag(&mut bits);
        }
        let mut ones = 0;
        for &byte in frame {
            for k in 0..8 {
                let bit = (byte >> (7 - k)) & 1;
                bits.push(bit);
                if bit == 1 {
                    ones += 1;
                    if ones == 5 {
                        bits.push(0);
                        ones = 0;
                    }
                } else {
                    ones = 0;
                }
            }
        }
        push_flag(&mut bits);
        push_flag(&mut bits);

        // NRZI, then tones at continuous phase.
        let spb = (rate / BAUD).round() as usize;
        let mut level = 0u8;
        let mut phase = 0.0f32;
        let mut out = Vec::with_capacity(bits.len() * spb);
        for &b in &bits {
            if b == 0 {
                level ^= 1;
            }
            let f = if level == 1 { MARK_HZ } else { SPACE_HZ };
            for _ in 0..spb {
                out.push((phase).sin());
                phase += TAU * f / rate;
                if phase > TAU {
                    phase -= TAU;
                }
            }
        }
        out
    }

    #[test]
    fn a_synthesised_packet_decodes_back_to_its_callsigns() {
        let frame = ax25(
            "APRS",
            "VE3XYZ-7",
            &["WIDE1-1"],
            "!4339.00N/07923.00W-Sweep test",
        );
        let audio = to_audio(&frame, 48_000.0);

        let mut d = Afsk1200::new(48_000.0);
        let mut out = Vec::new();
        d.process(&vec![0.0f32; 500], &mut out);
        d.process(&audio, &mut out);
        assert!(!out.is_empty(), "no frame decoded");

        let p = parse_ax25(&out[0].bytes).expect("frame should parse as AX.25");
        assert_eq!(p.source.to_string(), "VE3XYZ-7");
        assert_eq!(p.destination.to_string(), "APRS");
        let r = parse_report(&p.info);
        assert!((r.lat.unwrap() - 43.65).abs() < 1e-3, "lat {:?}", r.lat);
        assert!((r.lon.unwrap() + 79.3833).abs() < 1e-3, "lon {:?}", r.lon);
    }

    #[test]
    fn silence_and_noise_produce_no_packets() {
        let mut rng: u32 = 99;
        let noise: Vec<f32> = (0..300_000)
            .map(|_| {
                rng = rng.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
                (rng >> 8) as f32 / 8_388_608.0 - 1.0
            })
            .collect();
        let mut d = Afsk1200::new(48_000.0);
        let mut out = Vec::new();
        d.process(&noise, &mut out);
        assert!(out.is_empty(), "noise produced {} frames", out.len());
    }

    #[test]
    fn a_corrupted_packet_is_rejected() {
        let mut frame = ax25("APRS", "VE3XYZ-7", &[], "!4339.00N/07923.00W-x");
        let n = frame.len();
        frame[n / 2] ^= 0x20;
        assert!(!fcs_ok(&frame));
        let audio = to_audio(&frame, 48_000.0);
        let mut d = Afsk1200::new(48_000.0);
        let mut out = Vec::new();
        d.process(&audio, &mut out);
        assert!(out.is_empty(), "a bad checksum was accepted");
    }
}
