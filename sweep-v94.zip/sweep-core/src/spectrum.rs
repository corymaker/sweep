//! One capture in, one power spectrum out.
//!
//! Everything downstream — waterfall, persistence, detection, channel
//! activity — reads this. There is no second pipeline.

use rustfft::{num_complex::Complex32, Fft, FftPlanner};
use std::sync::Arc;

/// Hann window. Good sidelobe suppression, cheap, and the right default for
/// spotting narrow carriers next to strong ones.
pub fn hann(n: usize) -> Vec<f32> {
    (0..n)
        .map(|i| {
            let x = std::f32::consts::PI * 2.0 * i as f32 / n as f32;
            0.5 - 0.5 * x.cos()
        })
        .collect()
}

pub struct Spectrum {
    fft: Arc<dyn Fft<f32>>,
    window: Vec<f32>,
    /// Coherent gain of the window, used to keep levels calibrated.
    win_gain: f32,
    buf: Vec<Complex32>,
    size: usize,
}

impl Spectrum {
    pub fn new(size: usize) -> Self {
        assert!(size.is_power_of_two(), "FFT size must be a power of two");
        let window = hann(size);
        let win_gain = window.iter().sum::<f32>() / size as f32;
        Spectrum {
            fft: FftPlanner::new().plan_fft_forward(size),
            window,
            win_gain,
            buf: vec![Complex32::new(0.0, 0.0); size],
            size,
        }
    }

    pub fn size(&self) -> usize {
        self.size
    }

    /// Convert one frame of interleaved unsigned-8 IQ (as the RTL2832U
    /// delivers it) into dBFS, in ascending frequency order.
    ///
    /// `out.len()` must equal `size()`.
    pub fn process_u8(&mut self, iq: &[u8], out: &mut [f32]) {
        assert_eq!(iq.len(), self.size * 2);
        for i in 0..self.size {
            let re = (iq[i * 2] as f32 - 127.4) / 127.5;
            let im = (iq[i * 2 + 1] as f32 - 127.4) / 127.5;
            self.buf[i] = Complex32::new(re * self.window[i], im * self.window[i]);
        }
        self.finish(out);
    }

    /// Same, for callers that already have complex samples.
    pub fn process(&mut self, iq: &[Complex32], out: &mut [f32]) {
        assert_eq!(iq.len(), self.size);
        for i in 0..self.size {
            self.buf[i] = iq[i] * self.window[i];
        }
        self.finish(out);
    }

    fn finish(&mut self, out: &mut [f32]) {
        assert_eq!(out.len(), self.size);
        self.fft.process(&mut self.buf);
        let norm = 1.0 / (self.size as f32 * self.win_gain);
        let half = self.size / 2;
        // fftshift as we go: negative frequencies first, so `out` is ascending.
        for i in 0..self.size {
            let src = (i + half) % self.size;
            let c = self.buf[src] * norm;
            let p = c.re * c.re + c.im * c.im;
            out[i] = 10.0 * (p.max(1e-20)).log10();
        }
    }

    /// The bins worth keeping: the outer quarter is filter rolloff and lies.
    pub fn usable(&self) -> std::ops::Range<usize> {
        let drop = self.size / 8; // 12.5% each side => keep the middle 75%
        drop..(self.size - drop)
    }

    /// Bins within `guard_hz` of centre carry the DC spike and the worst of
    /// the IQ imbalance image. Blank them rather than let them raise detections.
    pub fn blank_dc(&self, out: &mut [f32], sample_rate: u32, guard_hz: f64, floor_db: f32) {
        let bin_hz = sample_rate as f64 / self.size as f64;
        let half = (guard_hz / bin_hz).ceil() as usize;
        let c = self.size / 2;
        for i in c.saturating_sub(half)..=(c + half).min(self.size - 1) {
            out[i] = floor_db;
        }
    }

    /// Frequency of bin `i` for a capture centred at `center_hz`.
    pub fn bin_hz(&self, i: usize, center_hz: f64, sample_rate: u32) -> f64 {
        let step = sample_rate as f64 / self.size as f64;
        center_hz + (i as f64 - self.size as f64 / 2.0) * step
    }
}

/// Averages several FFT frames before anything downstream sees them.
///
/// This is not an optimisation, it is a correctness requirement. Noise in a
/// single FFT frame is Rayleigh distributed: individual bins land 8-11 dB
/// above the mean all the time, so any fixed threshold against one frame
/// produces a storm of false detections. Averaging `n` frames in the power
/// domain cuts the standard deviation by sqrt(n) — 16 frames takes it from
/// about 5.6 dB to about 1.4 dB, at which point a +8 dB gate means something.
///
/// The cost is dwell time. 16 frames at 1024 points and 2.4 MS/s is ~7 ms,
/// which sets the floor on how fast a window can be swept.
pub struct Integrator {
    acc: Vec<f64>,
    have: u32,
    n: u32,
}

impl Integrator {
    pub fn new(bins: usize, n: u32) -> Self {
        assert!(n >= 1);
        Integrator {
            acc: vec![0.0; bins],
            have: 0,
            n,
        }
    }

    pub fn frames(&self) -> u32 {
        self.n
    }

    /// Expected noise standard deviation in dB after integration.
    pub fn noise_sigma_db(&self) -> f32 {
        5.57 / (self.n as f32).sqrt()
    }

    /// Feed one frame of dB values. Returns `true` when a full average is ready.
    pub fn push_db(&mut self, frame: &[f32]) -> bool {
        assert_eq!(frame.len(), self.acc.len());
        for (a, &v) in self.acc.iter_mut().zip(frame) {
            *a += 10f64.powf(v as f64 / 10.0);
        }
        self.have += 1;
        self.have >= self.n
    }

    /// Write the averaged spectrum in dB and start a new accumulation.
    pub fn take(&mut self, out: &mut [f32]) {
        assert_eq!(out.len(), self.acc.len());
        let k = self.have.max(1) as f64;
        for (o, a) in out.iter_mut().zip(self.acc.iter_mut()) {
            *o = (10.0 * (*a / k).max(1e-20).log10()) as f32;
            *a = 0.0;
        }
        self.have = 0;
    }

    pub fn reset(&mut self) {
        self.acc.iter_mut().for_each(|a| *a = 0.0);
        self.have = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f32::consts::TAU;

    fn tone(size: usize, cycles: f32, amp: f32) -> Vec<Complex32> {
        (0..size)
            .map(|i| {
                let ph = TAU * cycles * i as f32 / size as f32;
                Complex32::new(amp * ph.cos(), amp * ph.sin())
            })
            .collect()
    }

    #[test]
    fn tone_lands_in_the_right_bin() {
        let n = 1024;
        let mut s = Spectrum::new(n);
        let mut out = vec![0.0; n];
        // +64 cycles per frame => 64 bins above centre.
        s.process(&tone(n, 64.0, 0.5), &mut out);
        let peak = out
            .iter()
            .enumerate()
            .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
            .unwrap()
            .0;
        assert_eq!(peak, n / 2 + 64, "peak bin was {peak}");
    }

    #[test]
    fn output_is_in_ascending_frequency_order() {
        let n = 512;
        let mut s = Spectrum::new(n);
        let mut lo = vec![0.0; n];
        let mut hi = vec![0.0; n];
        s.process(&tone(n, -100.0, 0.5), &mut lo);
        s.process(&tone(n, 100.0, 0.5), &mut hi);
        let arg = |v: &[f32]| {
            v.iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
                .unwrap()
                .0
        };
        assert!(arg(&lo) < n / 2, "negative frequency should sit left of centre");
        assert!(arg(&hi) > n / 2, "positive frequency should sit right of centre");
    }

    #[test]
    fn amplitude_is_calibrated_within_half_a_db() {
        let n = 2048;
        let mut s = Spectrum::new(n);
        let mut out = vec![0.0; n];
        // Bin-centred tone at half scale: -6.02 dBFS.
        s.process(&tone(n, 100.0, 0.5), &mut out);
        let peak = out.iter().cloned().fold(f32::MIN, f32::max);
        assert!(
            (peak - -6.02).abs() < 0.5,
            "expected about -6 dBFS, got {peak}"
        );
    }

    #[test]
    fn usable_range_keeps_three_quarters() {
        let s = Spectrum::new(1024);
        let u = s.usable();
        assert_eq!(u.len(), 768);
    }

    #[test]
    fn dc_blanking_removes_the_centre_spike() {
        let n = 1024;
        let mut s = Spectrum::new(n);
        let mut out = vec![0.0; n];
        // A pure DC offset is exactly the artefact the tuner produces.
        let dc: Vec<Complex32> = (0..n).map(|_| Complex32::new(0.5, 0.0)).collect();
        s.process(&dc, &mut out);
        assert!(out[n / 2] > -20.0, "DC spike should be present before blanking");
        s.blank_dc(&mut out, 2_400_000, 30_000.0, -120.0);
        assert!(out[n / 2] <= -120.0);
    }

    #[test]
    fn bin_frequencies_bracket_the_centre() {
        let s = Spectrum::new(1024);
        let sr = 2_400_000;
        let c = 462_562_500.0;
        assert!((s.bin_hz(512, c, sr) - c).abs() < 1.0);
        let span = s.bin_hz(1023, c, sr) - s.bin_hz(0, c, sr);
        assert!((span - sr as f64 * 1023.0 / 1024.0).abs() < 1.0);
    }

    /// Deterministic complex Gaussian-ish noise, so the test cannot flake.
    fn noise_frame(n: usize, seed: u64, amp: f32) -> Vec<Complex32> {
        let mut s = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
        let mut next = || {
            s = s
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            // Sum of three uniforms approximates a normal well enough here.
            let u = |x: u64| (x >> 33) as f32 / (1u64 << 31) as f32 - 0.5;
            (u(s) + u(s.rotate_left(17)) + u(s.rotate_left(41))) * amp
        };
        (0..n).map(|_| Complex32::new(next(), next())).collect()
    }

    fn spread_db(v: &[f32]) -> f32 {
        let m = v.iter().sum::<f32>() / v.len() as f32;
        (v.iter().map(|x| (x - m) * (x - m)).sum::<f32>() / v.len() as f32).sqrt()
    }

    #[test]
    fn one_frame_of_noise_is_far_too_spiky_to_threshold() {
        let n = 1024;
        let mut s = Spectrum::new(n);
        let mut out = vec![0.0; n];
        s.process(&noise_frame(n, 1, 0.01), &mut out);
        assert!(
            spread_db(&out) > 4.0,
            "single-frame noise spread was only {} dB",
            spread_db(&out)
        );
    }

    #[test]
    fn integration_collapses_the_noise_spread() {
        let n = 1024;
        let mut s = Spectrum::new(n);
        let mut frame = vec![0.0; n];
        let mut avg = vec![0.0; n];
        let mut it = Integrator::new(n, 16);
        for f in 0..16u64 {
            s.process(&noise_frame(n, f + 100, 0.01), &mut frame);
            it.push_db(&frame);
        }
        it.take(&mut avg);
        let spread = spread_db(&avg);
        assert!(spread < 2.0, "16-frame spread was {spread} dB");
        assert!(spread < spread_db(&frame) / 2.0, "integration should halve it");
    }

    #[test]
    fn integration_preserves_signal_level() {
        let n = 1024;
        let mut s = Spectrum::new(n);
        let mut frame = vec![0.0; n];
        let mut avg = vec![0.0; n];
        let mut it = Integrator::new(n, 8);
        for _ in 0..8 {
            s.process(&tone(n, 64.0, 0.5), &mut frame);
            it.push_db(&frame);
        }
        it.take(&mut avg);
        let a = avg.iter().cloned().fold(f32::MIN, f32::max);
        let b = frame.iter().cloned().fold(f32::MIN, f32::max);
        assert!((a - b).abs() < 0.2, "signal moved from {b} to {a}");
    }

    #[test]
    fn sigma_estimate_matches_reality() {
        let n = 1024;
        let mut s = Spectrum::new(n);
        let mut frame = vec![0.0; n];
        let mut avg = vec![0.0; n];
        let mut it = Integrator::new(n, 16);
        for f in 0..16u64 {
            s.process(&noise_frame(n, f + 900, 0.01), &mut frame);
            it.push_db(&frame);
        }
        it.take(&mut avg);
        let measured = spread_db(&avg);
        let predicted = it.noise_sigma_db();
        assert!(
            (measured - predicted).abs() < 1.0,
            "predicted {predicted} dB, measured {measured} dB"
        );
    }

    #[test]
    fn u8_path_matches_the_complex_path() {
        let n = 256;
        let mut s = Spectrum::new(n);
        let t = tone(n, 32.0, 0.4);
        let bytes: Vec<u8> = t
            .iter()
            .flat_map(|c| {
                [
                    (c.re * 127.5 + 127.4).round() as u8,
                    (c.im * 127.5 + 127.4).round() as u8,
                ]
            })
            .collect();
        let mut a = vec![0.0; n];
        let mut b = vec![0.0; n];
        s.process(&t, &mut a);
        s.process_u8(&bytes, &mut b);
        let pa = a.iter().cloned().fold(f32::MIN, f32::max);
        let pb = b.iter().cloned().fold(f32::MIN, f32::max);
        assert!((pa - pb).abs() < 0.2, "{pa} vs {pb}");
    }
}
