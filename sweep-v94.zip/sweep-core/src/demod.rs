//! Turns IQ into audio.
//!
//! Three stages, always in this order:
//!
//! ```text
//! IQ @ 2.4 MS/s ─► LowpassDecimator ─► Discriminator ─► LowpassDecimator ─► Deemphasis ─► audio
//!                  (to ~240 kS/s)      (FM → raw audio)  (to 48 kS/s)
//! ```
//!
//! The two decimators are not optional detail — skipping the low-pass filter
//! before dropping samples aliases everything above the new Nyquist rate
//! straight into the audible band as noise. That's a correctness requirement,
//! not a quality knob, and it's what the aliasing test below exists to catch.

use rustfft::num_complex::Complex32;
use std::collections::VecDeque;

/// Windowed-sinc low-pass FIR, Hamming window, unity DC gain.
///
/// `cutoff_hz` should sit comfortably below the *new* Nyquist rate after
/// decimation, not the input rate — leave headroom for the filter's own
/// rolloff or you alias anyway, just less of it.
pub fn design_lowpass(cutoff_hz: f32, sample_rate: f32, num_taps: usize) -> Vec<f32> {
    assert!(num_taps % 2 == 1, "use an odd tap count for a symmetric filter");
    let fc = cutoff_hz / sample_rate; // normalized, 0..0.5
    let m = num_taps as isize - 1;
    let mut taps: Vec<f32> = (0..num_taps)
        .map(|i| {
            let k = i as isize - m / 2;
            let sinc = if k == 0 {
                2.0 * fc
            } else {
                (2.0 * std::f32::consts::PI * fc * k as f32).sin() / (std::f32::consts::PI * k as f32)
            };
            let w = 0.54 - 0.46 * (2.0 * std::f32::consts::PI * i as f32 / m as f32).cos();
            sinc * w
        })
        .collect();
    let sum: f32 = taps.iter().sum();
    for t in taps.iter_mut() {
        *t /= sum;
    }
    taps
}

/// FIR low-pass filter combined with decimation, applied to complex baseband.
///
/// Keeps its own history across calls, so streaming chunk-by-chunk from a USB
/// read loop gives the same result as one long call.
pub struct LowpassDecimator {
    taps: Vec<f32>,
    factor: usize,
    history: VecDeque<Complex32>,
    /// Samples consumed so far, modulo `factor`, so decimation phase is
    /// continuous across calls instead of resetting every buffer.
    phase: usize,
}

impl LowpassDecimator {
    pub fn new(cutoff_hz: f32, input_rate: f32, factor: usize, num_taps: usize) -> Self {
        let taps = design_lowpass(cutoff_hz, input_rate, num_taps);
        let mut history = VecDeque::with_capacity(num_taps);
        history.extend(std::iter::repeat(Complex32::new(0.0, 0.0)).take(num_taps - 1));
        LowpassDecimator {
            taps,
            factor,
            history,
            phase: 0,
        }
    }

    pub fn factor(&self) -> usize {
        self.factor
    }

    /// Appends the filtered, decimated output for `input` onto `out`.
    pub fn process(&mut self, input: &[Complex32], out: &mut Vec<Complex32>) {
        for &x in input {
            self.history.push_back(x);
            if self.history.len() > self.taps.len() {
                self.history.pop_front();
            }
            if self.phase == 0 && self.history.len() == self.taps.len() {
                let mut acc = Complex32::new(0.0, 0.0);
                for (h, &t) in self.history.iter().zip(&self.taps) {
                    acc += h * t;
                }
                out.push(acc);
            }
            self.phase = (self.phase + 1) % self.factor;
        }
    }
}

/// Quadrature FM discriminator: instantaneous frequency from the phase
/// change between consecutive samples, normalized so full deviation maps to
/// roughly ±1.0.
pub struct Discriminator {
    prev: Complex32,
    /// Rate of `Hz per unit output` — full peak deviation of the mode.
    deviation_hz: f32,
    sample_rate: f32,
}

impl Discriminator {
    /// `deviation_hz` is the mode's peak frequency deviation: about 2.5 kHz
    /// for NFM voice, about 75 kHz for broadcast WFM.
    pub fn new(deviation_hz: f32, sample_rate: f32) -> Self {
        Discriminator {
            prev: Complex32::new(1.0, 0.0),
            deviation_hz,
            sample_rate,
        }
    }

    pub fn process(&mut self, input: &[Complex32], out: &mut Vec<f32>) {
        let scale = self.sample_rate / (2.0 * std::f32::consts::PI * self.deviation_hz);
        for &x in input {
            // conj(prev) * x: phase of the product is the phase step.
            let d = x * self.prev.conj();
            let freq = d.im.atan2(d.re);
            out.push((freq * scale).clamp(-1.5, 1.5));
            self.prev = x;
        }
    }
}

/// Single-pole de-emphasis. FM transmitters pre-emphasize (boost) high audio
/// frequencies before modulating so they ride above the noise floor; this
/// undoes it. NFM voice channels are usually only lightly pre-emphasized —
/// use a short time constant, or leave this stage out, if voice sounds dull.
pub struct Deemphasis {
    alpha: f32,
    state: f32,
}

impl Deemphasis {
    /// `tau_us` around 530 (Canada/US NFM convention) or 50 (Europe, WFM).
    pub fn new(tau_us: f32, sample_rate: f32) -> Self {
        let dt = 1.0 / sample_rate;
        let tau = tau_us * 1e-6;
        Deemphasis {
            alpha: dt / (tau + dt),
            state: 0.0,
        }
    }

    pub fn process_in_place(&mut self, buf: &mut [f32]) {
        for s in buf.iter_mut() {
            self.state += self.alpha * (*s - self.state);
            *s = self.state;
        }
    }
}

/// The full IF-to-audio chain for one channel. Owns all filter state, so a
/// caller just keeps feeding IQ chunks and draining audio.
pub struct NfmChannel {
    stage1: LowpassDecimator,
    disc: Discriminator,
    stage2: LowpassDecimator,
    deemph: Option<Deemphasis>,
    scratch1: Vec<Complex32>,
    scratch2: Vec<f32>,
}

/// Taps needed for a windowed-sinc low-pass to get from `cutoff_hz` down to
/// the stopband by `stop_hz`, at `rate`. The transition width of a Hamming
/// window is about `3.3 * rate / taps`, so invert that. Clamped: too few
/// taps aliases, too many is just wasted CPU, and the result is forced odd
/// so the filter stays linear-phase.
fn taps_for(rate: f32, stop_hz: f32, cutoff_hz: f32) -> usize {
    let transition = (stop_hz - cutoff_hz).max(rate * 0.002);
    let n = (3.3 * rate / transition).ceil() as usize;
    let n = n.clamp(31, 401);
    if n % 2 == 0 {
        n + 1
    } else {
        n
    }
}

impl NfmChannel {
    /// `if_rate` is the incoming IQ rate (e.g. 2.4e6). `audio_rate` is
    /// typically 48000. `channel_bw_hz` is the occupied bandwidth — about
    /// 12500 for NFM, 200000 for broadcast FM.
    ///
    /// The decimation split matters more than it looks. Dropping samples
    /// without filtering out everything above the *new* Nyquist rate folds
    /// that energy straight into the audio band — which sounds exactly
    /// like static. A windowed-sinc filter's transition width is roughly
    /// `3.3 * rate / taps`, so the taps needed grow with the decimation
    /// factor. An earlier version used a fixed 31 taps for stage 2 while
    /// decimating WFM by 17, which would have needed ~1368 to be clean.
    ///
    /// So: pick the intermediate rate to keep stage 2's factor small, and
    /// size both filters from the transition width they actually have to
    /// achieve rather than a hardcoded guess.
    pub fn new(if_rate: f32, audio_rate: f32, channel_bw_hz: f32, deviation_hz: f32) -> Self {
        // Broadcast FM carries audio to 15 kHz; narrowband is speech. No
        // point asking the filter to pass more than the mode actually has.
        let audio_cutoff = if channel_bw_hz > 50_000.0 {
            15_000.0_f32.min(audio_rate / 2.0 * 0.9)
        } else {
            audio_rate / 2.0 * 0.9
        };

        // Total decimation lands exactly on audio_rate where possible, so
        // the output doesn't drift against the sound card's clock.
        let total = (if_rate / audio_rate).round().max(1.0) as usize;

        // Split that total between the two stages. Both extremes are bad:
        // a small stage-2 factor forces stage 1 to filter very sharply
        // (hundreds of taps at a high rate), a large one does the same to
        // stage 2. Cost is roughly rate × taps per stage, so evaluate the
        // valid splits and take the cheapest — with the constraint that
        // the intermediate rate still has to clear the channel bandwidth.
        let mut best: Option<(usize, usize, f32)> = None;
        for f2 in 1..=total {
            if total % f2 != 0 {
                continue;
            }
            let f1 = total / f2;
            let mid = if_rate / f1 as f32;
            if mid < 1.2 * channel_bw_hz {
                continue;
            }
            let t1 = taps_for(if_rate, (mid / 2.0).min(channel_bw_hz), channel_bw_hz / 2.0);
            let t2 = taps_for(mid, mid / (2.0 * f2 as f32), audio_cutoff);
            let cost = mid * t1 as f32 + audio_rate * t2 as f32;
            if best.map_or(true, |(_, _, c)| cost < c) {
                best = Some((f1, f2, cost));
            }
        }
        let (factor1, factor2) = best.map(|(a, b, _)| (a, b)).unwrap_or((1, 1));
        let mid_rate = if_rate / factor1 as f32;

        NfmChannel {
            stage1: LowpassDecimator::new(
                channel_bw_hz / 2.0,
                if_rate,
                factor1,
                // Two jobs, and the stricter one wins. Anti-aliasing only
                // demands rejection by the new Nyquist rate, but the
                // adjacent channel sits one channel-width away and leaks
                // straight into the demodulator if the skirt is still open
                // there — audible as roughness and hash on an otherwise
                // strong signal. Size for whichever needs the sharper
                // filter.
                taps_for(if_rate, (mid_rate / 2.0).min(channel_bw_hz), channel_bw_hz / 2.0),
            ),
            disc: Discriminator::new(deviation_hz, mid_rate),
            stage2: LowpassDecimator::new(
                audio_cutoff,
                mid_rate,
                factor2,
                taps_for(mid_rate, mid_rate / (2.0 * factor2 as f32), audio_cutoff),
            ),
            deemph: Some(Deemphasis::new(530.0, audio_rate)),
            scratch1: Vec::new(),
            scratch2: Vec::new(),
        }
    }

    pub fn without_deemphasis(mut self) -> Self {
        self.deemph = None;
        self
    }

    /// Sets the de-emphasis time constant. The default (530 µs) is the
    /// narrowband convention; North American broadcast FM uses 75 µs and
    /// Europe 50 µs. Using the NFM value on WFM rolls the treble off from
    /// a few hundred Hz up, which sounds muffled and much quieter than it
    /// should.
    pub fn with_deemphasis_us(mut self, tau_us: f32, audio_rate: f32) -> Self {
        self.deemph = Some(Deemphasis::new(tau_us, audio_rate));
        self
    }

    /// Feed one chunk of IQ, append the resulting audio samples to `out`.
    pub fn process(&mut self, iq: &[Complex32], out: &mut Vec<f32>) {
        self.scratch1.clear();
        self.stage1.process(iq, &mut self.scratch1);

        self.scratch2.clear();
        self.disc.process(&self.scratch1, &mut self.scratch2);

        // Real-valued decimation reuses the complex decimator by riding the
        // signal on the real part; the filter design and history logic are
        // identical either way.
        let complex: Vec<Complex32> = self.scratch2.iter().map(|&v| Complex32::new(v, 0.0)).collect();
        let start = out.len();
        let mut audio_c = Vec::new();
        self.stage2.process(&complex, &mut audio_c);
        out.extend(audio_c.iter().map(|c| c.re));

        if let Some(d) = &mut self.deemph {
            d.process_in_place(&mut out[start..]);
        }
    }
}

/// Envelope detector: audio is the magnitude of the baseband IQ, with the
/// carrier's average level removed by a slow DC blocker so what's left is
/// just the modulation. This is what AM actually needs — running an AM
/// signal through the FM discriminator instead (as if it were narrowband
/// FM) does not degrade gracefully, it just produces noise.
pub struct EnvelopeDetector {
    dc: f32,
    alpha: f32,
}

impl EnvelopeDetector {
    pub fn new(sample_rate: f32) -> Self {
        // Single-pole DC blocker, well below any audio content — tracks and
        // removes the carrier's average envelope level, nothing faster.
        let tau_s = 0.05;
        let dt = 1.0 / sample_rate;
        EnvelopeDetector {
            dc: 0.0,
            alpha: dt / (tau_s + dt),
        }
    }

    pub fn process(&mut self, input: &[Complex32], out: &mut Vec<f32>) {
        for &x in input {
            let mag = (x.re * x.re + x.im * x.im).sqrt();
            self.dc += self.alpha * (mag - self.dc);
            out.push(mag - self.dc);
        }
    }
}

/// The full IF-to-audio chain for one AM channel. Same two-stage
/// decimate-then-detect shape as [`NfmChannel`], swapping the discriminator
/// for an envelope detector and dropping de-emphasis, which AM doesn't use.
pub struct AmChannel {
    stage1: LowpassDecimator,
    env: EnvelopeDetector,
    stage2: LowpassDecimator,
    scratch1: Vec<Complex32>,
    scratch2: Vec<f32>,
}

impl AmChannel {
    /// `channel_bw_hz` is the occupied bandwidth — about 8.33 kHz for
    /// narrow aviation AM, wider for broadcast AM.
    pub fn new(if_rate: f32, audio_rate: f32, channel_bw_hz: f32) -> Self {
        let mid_rate = (channel_bw_hz * 4.0).max(audio_rate * 2.0);
        let factor1 = (if_rate / mid_rate).round().max(1.0) as usize;
        let actual_mid_rate = if_rate / factor1 as f32;
        let factor2 = (actual_mid_rate / audio_rate).round().max(1.0) as usize;

        AmChannel {
            stage1: LowpassDecimator::new(channel_bw_hz / 2.0, if_rate, factor1, 63),
            env: EnvelopeDetector::new(actual_mid_rate),
            stage2: LowpassDecimator::new(audio_rate / 2.0 * 0.9, actual_mid_rate, factor2, 31),
            scratch1: Vec::new(),
            scratch2: Vec::new(),
        }
    }

    pub fn process(&mut self, iq: &[Complex32], out: &mut Vec<f32>) {
        self.scratch1.clear();
        self.stage1.process(iq, &mut self.scratch1);

        self.scratch2.clear();
        self.env.process(&self.scratch1, &mut self.scratch2);

        let complex: Vec<Complex32> = self.scratch2.iter().map(|&v| Complex32::new(v, 0.0)).collect();
        let mut audio_c = Vec::new();
        self.stage2.process(&complex, &mut audio_c);
        out.extend(audio_c.iter().map(|c| c.re));
    }
}

/// FIR filter with complex-valued taps, combined with decimation.
///
/// A real lowpass prototype has a symmetric passband around 0 Hz — no way
/// to keep one sideband and reject the other. Multiplying its taps by a
/// complex exponential shifts that passband off-center, to an *asymmetric*
/// range, which is exactly what separates upper sideband from lower
/// sideband in a zero-IF complex baseband. That's the whole trick behind
/// the "phasing method" of SSB demod — no Hilbert transform needed, because
/// I/Q already carries the phase information a Hilbert transform would
/// otherwise have to reconstruct.
pub struct ComplexBandpassDecimator {
    taps: Vec<Complex32>,
    factor: usize,
    history: VecDeque<Complex32>,
    phase: usize,
}

impl ComplexBandpassDecimator {
    /// `half_bw_hz` is the prototype lowpass's cutoff before shifting.
    /// `center_hz` is where that passband gets moved to — the resulting
    /// passband is `[center_hz - half_bw_hz, center_hz + half_bw_hz]`.
    pub fn new(
        half_bw_hz: f32,
        center_hz: f32,
        input_rate: f32,
        factor: usize,
        num_taps: usize,
    ) -> Self {
        let real_taps = design_lowpass(half_bw_hz, input_rate, num_taps);
        let mid = (num_taps as f32 - 1.0) / 2.0;
        let taps: Vec<Complex32> = real_taps
            .iter()
            .enumerate()
            .map(|(i, &t)| {
                let n = i as f32 - mid;
                let ph = 2.0 * std::f32::consts::PI * center_hz * n / input_rate;
                Complex32::new(t * ph.cos(), t * ph.sin())
            })
            .collect();
        let mut history = VecDeque::with_capacity(num_taps);
        history.extend(std::iter::repeat(Complex32::new(0.0, 0.0)).take(num_taps - 1));
        ComplexBandpassDecimator {
            taps,
            factor,
            history,
            phase: 0,
        }
    }

    pub fn process(&mut self, input: &[Complex32], out: &mut Vec<Complex32>) {
        for &x in input {
            self.history.push_back(x);
            if self.history.len() > self.taps.len() {
                self.history.pop_front();
            }
            if self.phase == 0 && self.history.len() == self.taps.len() {
                let mut acc = Complex32::new(0.0, 0.0);
                for (h, t) in self.history.iter().zip(&self.taps) {
                    acc += h * t;
                }
                out.push(acc);
            }
            self.phase = (self.phase + 1) % self.factor;
        }
    }
}

/// SSB demod: select one sideband with [`ComplexBandpassDecimator`], then
/// take the real part. For a signal that's genuinely single-sideband after
/// filtering, the real part alone recovers the audio — no discriminator or
/// envelope detector involved, the filtering *is* the demodulation.
pub struct SsbChannel {
    stage1: ComplexBandpassDecimator,
    stage2: LowpassDecimator,
    scratch1: Vec<Complex32>,
    scratch2: Vec<Complex32>,
}

impl SsbChannel {
    /// `bw_hz` is the occupied bandwidth (about 2800 for SSB voice).
    /// `usb`: true keeps the passband above the suppressed carrier, false
    /// keeps it below.
    pub fn new(if_rate: f32, audio_rate: f32, bw_hz: f32, usb: bool) -> Self {
        let half_bw = bw_hz / 2.0;
        let mid_rate = (bw_hz * 4.0).max(audio_rate * 2.0);
        let factor1 = (if_rate / mid_rate).round().max(1.0) as usize;
        let actual_mid_rate = if_rate / factor1 as f32;
        let factor2 = (actual_mid_rate / audio_rate).round().max(1.0) as usize;
        let center = if usb { half_bw } else { -half_bw };

        SsbChannel {
            stage1: ComplexBandpassDecimator::new(half_bw, center, if_rate, factor1, 127),
            stage2: LowpassDecimator::new(audio_rate / 2.0 * 0.9, actual_mid_rate, factor2, 31),
            scratch1: Vec::new(),
            scratch2: Vec::new(),
        }
    }

    pub fn process(&mut self, iq: &[Complex32], out: &mut Vec<f32>) {
        self.scratch1.clear();
        self.stage1.process(iq, &mut self.scratch1);
        self.scratch2.clear();
        self.stage2.process(&self.scratch1, &mut self.scratch2);
        out.extend(self.scratch2.iter().map(|c| c.re));
    }
}

/// CW (Morse) demod: an unmodulated carrier is inaudible on its own — what
/// makes it a tone is beating it against a local oscillator. Narrow-filter
/// around the expected carrier position to cut noise bandwidth, then
/// heterodyne by `bfo_hz` and take the real part; a steady carrier becomes
/// a steady `bfo_hz` tone, silence stays silence.
pub struct CwChannel {
    stage1: LowpassDecimator,
    stage2: LowpassDecimator,
    bfo_phase: f32,
    bfo_step: f32,
    scratch1: Vec<Complex32>,
    scratch2: Vec<Complex32>,
}

impl CwChannel {
    /// `bw_hz` is the noise-reduction filter width around the expected
    /// carrier position (baseband zero); `bfo_hz` is the resulting pitch,
    /// conventionally around 600-800 Hz.
    pub fn new(if_rate: f32, audio_rate: f32, bw_hz: f32, bfo_hz: f32) -> Self {
        let mid_rate = (bw_hz * 4.0).max(audio_rate * 2.0);
        let factor1 = (if_rate / mid_rate).round().max(1.0) as usize;
        let actual_mid_rate = if_rate / factor1 as f32;
        let factor2 = (actual_mid_rate / audio_rate).round().max(1.0) as usize;
        let actual_audio_rate = actual_mid_rate / factor2 as f32;

        CwChannel {
            stage1: LowpassDecimator::new(bw_hz / 2.0, if_rate, factor1, 63),
            stage2: LowpassDecimator::new(audio_rate / 2.0 * 0.9, actual_mid_rate, factor2, 31),
            bfo_phase: 0.0,
            bfo_step: 2.0 * std::f32::consts::PI * bfo_hz / actual_audio_rate,
            scratch1: Vec::new(),
            scratch2: Vec::new(),
        }
    }

    pub fn process(&mut self, iq: &[Complex32], out: &mut Vec<f32>) {
        self.scratch1.clear();
        self.stage1.process(iq, &mut self.scratch1);
        self.scratch2.clear();
        self.stage2.process(&self.scratch1, &mut self.scratch2);
        for &c in &self.scratch2 {
            let (s, cos) = self.bfo_phase.sin_cos();
            out.push(c.re * cos - c.im * s);
            self.bfo_phase += self.bfo_step;
            if self.bfo_phase > std::f32::consts::TAU {
                self.bfo_phase -= std::f32::consts::TAU;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f32::consts::TAU;

    fn tone(n: usize, rate: f32, freq: f32, amp: f32) -> Vec<Complex32> {
        (0..n)
            .map(|i| {
                let ph = TAU * freq * i as f32 / rate;
                Complex32::new(amp * ph.cos(), amp * ph.sin())
            })
            .collect()
    }

    /// Synthesize an FM signal: carrier whose instantaneous frequency swings
    /// with a modulating tone at `mod_freq`, peak deviation `dev`.
    fn fm_modulate(n: usize, rate: f32, mod_freq: f32, dev: f32) -> Vec<Complex32> {
        let mut phase = 0.0f32;
        (0..n)
            .map(|i| {
                let t = i as f32 / rate;
                let inst_freq = dev * (TAU * mod_freq * t).sin();
                phase += TAU * inst_freq / rate;
                Complex32::new(phase.cos(), phase.sin())
            })
            .collect()
    }

    #[test]
    fn lowpass_passes_a_tone_below_cutoff_near_unity_gain() {
        let rate = 48_000.0;
        let n = 4096;
        let mut lp = LowpassDecimator::new(4000.0, rate, 1, 127);
        let mut out = Vec::new();
        lp.process(&tone(n, rate, 500.0, 1.0), &mut out);
        let settled = &out[out.len() / 2..];
        let peak = settled.iter().map(|c| c.norm()).fold(0.0f32, f32::max);
        assert!((peak - 1.0).abs() < 0.15, "passband gain was {peak}");
    }

    #[test]
    fn decimation_without_aliasing_kills_content_above_new_nyquist() {
        // This is the bug that matters: decimating by 10 without filtering
        // would fold a 20 kHz tone straight into the audio band.
        let rate = 240_000.0;
        let n = 8192;
        let factor = 10;
        let mut dec = LowpassDecimator::new(4000.0, rate, factor, 127);
        let mut out = Vec::new();
        // A tone that would alias hard into low frequency if unfiltered.
        dec.process(&tone(n, rate, 20_000.0, 1.0), &mut out);
        let settled = &out[out.len() / 2..];
        let peak = settled.iter().map(|c| c.norm()).fold(0.0f32, f32::max);
        assert!(peak < 0.1, "20 kHz tone leaked through at {peak}, aliasing filter is broken");
    }

    #[test]
    fn decimated_output_length_matches_the_factor() {
        let rate = 100_000.0;
        let n = 5000;
        let mut dec = LowpassDecimator::new(2000.0, rate, 5, 63);
        let mut out = Vec::new();
        dec.process(&tone(n, rate, 100.0, 1.0), &mut out);
        // Off by the filter's group delay at the very start/end only.
        assert!((out.len() as i64 - (n / 5) as i64).abs() <= 2, "{}", out.len());
    }

    #[test]
    fn discriminator_recovers_a_static_offset_frequency() {
        // A carrier offset by a fixed amount from centre is a constant
        // "tone" out of the discriminator — the simplest possible check.
        let rate = 240_000.0;
        let dev = 2500.0;
        let offset = 1000.0; // Hz off centre
        let mut disc = Discriminator::new(dev, rate);
        let mut out = Vec::new();
        disc.process(&tone(4000, rate, offset, 1.0), &mut out);
        let settled = &out[100..];
        let mean = settled.iter().sum::<f32>() / settled.len() as f32;
        let expected = offset / dev;
        assert!((mean - expected).abs() < 0.05, "expected {expected}, got {mean}");
    }

    #[test]
    fn full_chain_recovers_the_modulating_tone_frequency() {
        let if_rate = 240_000.0;
        let audio_rate = 48_000.0;
        let mod_freq = 400.0;
        let dev = 2500.0;
        let n = 48_000; // 0.2 s

        let iq = fm_modulate(n, if_rate, mod_freq, dev);
        let mut ch = NfmChannel::new(if_rate, audio_rate, 12_500.0, dev).without_deemphasis();
        let mut audio = Vec::new();
        ch.process(&iq, &mut audio);

        assert!(!audio.is_empty());
        let settled = &audio[audio.len() / 4..];

        // Count zero crossings as a robust, filter-agnostic way to recover
        // frequency without needing a second FFT dependency in tests.
        let crossings = settled.windows(2).filter(|w| w[0].signum() != w[1].signum()).count();
        let seconds = settled.len() as f32 / audio_rate;
        let measured_freq = crossings as f32 / 2.0 / seconds;

        assert!(
            (measured_freq - mod_freq).abs() < mod_freq * 0.25,
            "expected about {mod_freq} Hz, measured {measured_freq} Hz"
        );
    }

    #[test]
    fn deemphasis_attenuates_high_frequencies_more_than_low() {
        let rate = 48_000.0;
        let n = 4096;
        let mut lo = tone(n, rate, 300.0, 1.0).iter().map(|c| c.re).collect::<Vec<_>>();
        let mut hi = tone(n, rate, 3000.0, 1.0).iter().map(|c| c.re).collect::<Vec<_>>();

        Deemphasis::new(530.0, rate).process_in_place(&mut lo);
        Deemphasis::new(530.0, rate).process_in_place(&mut hi);

        let rms = |v: &[f32]| (v.iter().map(|x| x * x).sum::<f32>() / v.len() as f32).sqrt();
        let settled_lo = rms(&lo[n / 2..]);
        let settled_hi = rms(&hi[n / 2..]);
        assert!(settled_hi < settled_lo * 0.8, "hi={settled_hi} lo={settled_lo}");
    }

    #[test]
    fn history_carries_across_chunked_calls() {
        // Streaming in small pieces (as a USB read loop does) must give the
        // same result as one big call — otherwise every buffer boundary is
        // an audible click.
        let rate = 48_000.0;
        let n = 2000;
        let sig = tone(n, rate, 300.0, 1.0);

        let mut whole = LowpassDecimator::new(4000.0, rate, 2, 63);
        let mut out_whole = Vec::new();
        whole.process(&sig, &mut out_whole);

        let mut chunked = LowpassDecimator::new(4000.0, rate, 2, 63);
        let mut out_chunked = Vec::new();
        for chunk in sig.chunks(37) {
            chunked.process(chunk, &mut out_chunked);
        }

        assert_eq!(out_whole.len(), out_chunked.len());
        for (a, b) in out_whole.iter().zip(&out_chunked).skip(20) {
            assert!((a - b).norm() < 1e-4, "{a} vs {b}");
        }
    }
}
