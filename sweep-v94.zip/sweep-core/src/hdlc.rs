//! HDLC framing — the layer AIS and AX.25 both sit on.
//!
//! Two completely different radios (GMSK at 9600 baud on marine VHF, audio
//! tones at 1200 baud on the 2 m amateur band) carry exactly the same
//! frames: a 01111110 delimiter, data with a zero stuffed in after every
//! five ones so it can never imitate that delimiter, and a 16-bit checksum.
//! Writing it once means a bug found in one decoder is fixed in both — and
//! both of the bugs this code had were subtle enough to be worth that.

/// The HDLC frame delimiter, 01111110.
pub const FLAG: u8 = 0x7E;

/// Longest frame worth keeping. AIS runs to 1008 bits and an AX.25 frame
/// with a full digipeater path and a long comment is comparable; past this
/// the decoder has lost its place rather than found a long message.
pub const MAX_FRAME_BITS: usize = 2400;

/// CRC-16/X-25, the HDLC frame check sequence: polynomial 0x1021 applied
/// least-significant-bit first (so 0x8408 reversed), initialised to all
/// ones and complemented at the end.
pub fn crc16(data: &[u8]) -> u16 {
    !crc_ccitt_lsb(0xFFFF, data)
}

/// The bare reflected CRC-16/CCITT engine: polynomial 0x1021 applied
/// least-significant-bit first, which is 0x8408 written out.
///
/// Exposed separately because the same engine appears with different
/// dressing elsewhere — HDLC starts it at all ones and complements the
/// result, ACARS starts it at zero and checks for a zero residue. Sharing
/// the loop means the part that is easy to get subtly wrong exists once.
pub fn crc_ccitt_lsb(init: u16, data: &[u8]) -> u16 {
    let mut crc = init;
    for &b in data {
        crc ^= b as u16;
        for _ in 0..8 {
            if crc & 1 != 0 {
                crc = (crc >> 1) ^ 0x8408;
            } else {
                crc >>= 1;
            }
        }
    }
    crc
}

/// `true` when a frame's trailing two bytes match the checksum of
/// everything before them. The FCS travels least-significant byte first.
pub fn fcs_ok(frame: &[u8]) -> bool {
    if frame.len() < 3 {
        return false;
    }
    let n = frame.len() - 2;
    let want = u16::from_le_bytes([frame[n], frame[n + 1]]);
    crc16(&frame[..n]) == want
}

// ---------------------------------------------------------------------------
// HDLC
// ---------------------------------------------------------------------------

/// One sample phase's worth of framing state.
///
/// Fed one bit at a time, it watches for flags, and when one arrives it
/// removes the stuffed zeros HDLC inserts to stop data imitating a flag,
/// then checks the frame's checksum.
///
/// The de-stuffing happens *after* a flag is found, not as bits arrive.
/// That ordering is the whole trick: a flag is six consecutive ones, which
/// is exactly the pattern a greedy de-stuffer treats as a protocol error —
/// run it live and every frame is destroyed by its own closing delimiter.
pub struct Hdlc {
    /// Last eight raw bits, for spotting the flag pattern.
    window: u8,
    /// Raw bits since the opening flag, stuffing still in place.
    raw: Vec<u8>,
    collecting: bool,
}

impl Hdlc {
    pub fn new() -> Self {
        Hdlc {
            window: 0,
            raw: Vec::with_capacity(MAX_FRAME_BITS),
            collecting: false,
        }
    }

    /// Returns the frame's bytes when one completes.
    pub fn push(&mut self, bit: u8) -> Option<Vec<u8>> {
        self.window = (self.window << 1) | (bit & 1);

        if self.window == FLAG {
            // A flag both closes any frame in progress and opens the next.
            // Seven of its eight bits are already in `raw`, since only the
            // last one completed the pattern.
            let done = if self.collecting && self.raw.len() > 7 {
                let n = self.raw.len() - 7;
                destuff(&self.raw[..n]).and_then(|body| {
                    if body.len() >= 32 && body.len() % 8 == 0 {
                        let bytes = pack(&body);
                        fcs_ok(&bytes).then_some(bytes)
                    } else {
                        None
                    }
                })
            } else {
                None
            };
            self.raw.clear();
            self.collecting = true;
            return done;
        }

        if !self.collecting {
            return None;
        }
        self.raw.push(bit);
        if self.raw.len() > MAX_FRAME_BITS {
            self.collecting = false;
            self.raw.clear();
        }
        None
    }
}

/// Remove the zero HDLC inserts after every five consecutive ones.
///
/// `None` when six ones appear with no stuffed zero after them, which
/// cannot occur inside a valid frame and means this phase is slicing
/// noise.
pub fn destuff(raw: &[u8]) -> Option<Vec<u8>> {
    let mut out = Vec::with_capacity(raw.len());
    let mut ones = 0u8;
    let mut i = 0usize;
    while i < raw.len() {
        let b = raw[i];
        if ones == 5 {
            if b != 0 {
                return None;
            }
            // Drop the stuffed zero and carry on.
            ones = 0;
            i += 1;
            continue;
        }
        if b == 1 {
            ones += 1;
        } else {
            ones = 0;
        }
        out.push(b);
        i += 1;
    }
    Some(out)
}

/// Bits to bytes, most significant bit first.
pub fn pack(bits: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(bits.len() / 8);
    for chunk in bits.chunks(8) {
        let mut b = 0u8;
        for (i, &v) in chunk.iter().enumerate() {
            if v != 0 {
                b |= 1 << (7 - i);
            }
        }
        out.push(b);
    }
    out
}

