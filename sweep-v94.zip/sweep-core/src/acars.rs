//! ACARS — the aircraft datalink, on 131.550 MHz and neighbours.
//!
//! The text side of aviation. Where ADS-B broadcasts where an aircraft is,
//! ACARS carries what the aircraft and the airline are *saying* to each
//! other: position reports, fuel and engine data, gate assignments,
//! free-text messages between the crew and dispatch. Every message is
//! stamped with the aircraft's registration, so a decoded burst names a
//! specific airframe.
//!
//! ```text
//!   AM envelope ──► 1200/2400 Hz tones ──► bytes ──► SYN SYN SOH frame
//!                                                           │
//!                                        registration / label / text
//! ```
//!
//! Two details make this different from the other decoders here. It rides
//! on **amplitude** modulation, so the front end is an envelope detector
//! rather than a discriminator — the same reason the aviation voice band is
//! AM. And every character carries **odd parity** in its top bit, which
//! turns out to matter more than the checksum: a frame whose every
//! character has correct parity, bracketed by the right control bytes, is
//! already most unlikely to be noise.
//!
//! On the checksum. The algorithm is confirmed — reflected CRC-16/CCITT,
//! polynomial 0x1021 as 0x8408, started at zero, with the two transmitted
//! bytes fed in after the message so a good frame leaves a zero residue.
//! What could not be confirmed without a real off-air capture is the exact
//! span it covers. So the checksum is computed and *reported*, but
//! acceptance rests on parity and structure. A message is never shown as
//! verified when it is not, and a wrong guess about the span cannot make
//! this decoder silently useless.

use crate::hdlc::crc_ccitt_lsb;
use crate::tone::ToneDemod;
use std::collections::HashMap;
use std::time::{Duration, Instant};

/// The busiest North American ACARS channel. The others are in
/// [`CHANNELS`].
pub const ACARS_HZ: f64 = 131_550_000.0;

/// Published VHF ACARS channels for North America, busiest first. Only one
/// can be received at a time.
pub const CHANNELS: &[(f64, &str)] = &[
    (131_550_000.0, "primary"),
    (130_025_000.0, "secondary"),
    (129_125_000.0, "secondary"),
    (131_725_000.0, "Air France / SITA"),
    (136_900_000.0, "additional"),
];

/// Minimum-shift keying at 2400 bits per second puts the two tones half a
/// baud apart, which lands them on 1200 and 2400 Hz.
pub const MARK_HZ: f32 = 1200.0;
pub const SPACE_HZ: f32 = 2400.0;
pub const BAUD: f32 = 2400.0;

const SYN: u8 = 0x16;
const SOH: u8 = 0x01;
const STX: u8 = 0x02;
const ETX: u8 = 0x03;
const ETB: u8 = 0x17;
const DEL: u8 = 0x7F;

/// Longest message worth assembling. ACARS blocks cap out around 220
/// characters; past this the decoder has lost sync rather than found a
/// long message.
const MAX_CHARS: usize = 300;

/// Odd parity: every transmitted character has an odd number of ones.
fn parity_ok(b: u8) -> bool {
    b.count_ones() % 2 == 1
}

// ---------------------------------------------------------------------------
// Demodulator
// ---------------------------------------------------------------------------

#[derive(PartialEq, Clone, Copy)]
enum State {
    Hunting,
    Collecting,
}

pub struct AcarsDemod {
    tone: ToneDemod,
    /// Last sixteen bits, for finding the two SYN characters that mark the
    /// start of a block.
    reg: u16,
    state: State,
    /// Bits of the character being assembled, and how many so far.
    byte: u8,
    nbits: u8,
    /// Characters since SOH, parity bit still attached.
    chars: Vec<u8>,
    /// Bytes still expected after the terminator. The two checksum bytes
    /// are not characters: they carry no parity, so they must bypass the
    /// parity check that guards everything before them.
    after_term: u8,
    /// True when the tone decision is inverted relative to the transmitter.
    /// Rather than work out the differential convention, both polarities
    /// are searched for the sync pattern and whichever matches wins — the
    /// frame itself settles the question.
    inverted: bool,
    pub frames_ok: u64,
    pub bad_parity: u64,
}

impl AcarsDemod {
    pub fn new(rate: f32) -> Self {
        AcarsDemod {
            tone: ToneDemod::new(rate, MARK_HZ, SPACE_HZ, BAUD),
            reg: 0,
            state: State::Hunting,
            byte: 0,
            nbits: 0,
            chars: Vec::with_capacity(MAX_CHARS),
            after_term: 0,
            inverted: false,
            frames_ok: 0,
            bad_parity: 0,
        }
    }

    pub fn process(&mut self, audio: &[f32], out: &mut Vec<Block>) {
        // Everything the bit handler touches, lifted out so the closure
        // does not borrow all of `self` while `self.tone` is running.
        let reg = &mut self.reg;
        let state = &mut self.state;
        let byte = &mut self.byte;
        let nbits = &mut self.nbits;
        let chars = &mut self.chars;
        let after_term = &mut self.after_term;
        let inverted = &mut self.inverted;
        let frames_ok = &mut self.frames_ok;
        let bad_parity = &mut self.bad_parity;

        self.tone.process(audio, &mut |level| {
            let bit = if *inverted { level ^ 1 } else { level };

            match *state {
                State::Hunting => {
                    // Characters go out least significant bit first, so a
                    // bit shifted in at the top arrives at its own position
                    // once sixteen have passed.
                    *reg = (*reg >> 1) | ((level as u16) << 15);
                    const SYNC: u16 = ((SYN as u16) << 8) | SYN as u16;
                    if *reg == SYNC {
                        *inverted = false;
                    } else if *reg == !SYNC {
                        *inverted = true;
                    } else {
                        return;
                    }
                    *state = State::Collecting;
                    *byte = 0;
                    *nbits = 0;
                    *after_term = 0;
                    chars.clear();
                }
                State::Collecting => {
                    *byte = (*byte >> 1) | (bit << 7);
                    *nbits += 1;
                    if *nbits < 8 {
                        return;
                    }
                    let c = *byte;
                    *byte = 0;
                    *nbits = 0;

                    // The checksum bytes follow the terminator and are
                    // raw, not characters — no parity to check, and they
                    // must not be stripped either.
                    if *after_term > 0 {
                        chars.push(c);
                        *after_term -= 1;
                        if *after_term == 0 {
                            if let Some(b) = Block::assemble(chars) {
                                *frames_ok += 1;
                                out.push(b);
                            }
                            *state = State::Hunting;
                            *reg = 0;
                            chars.clear();
                        }
                        return;
                    }

                    // Leading SYNs and the SOH are preamble, not content.
                    if chars.is_empty() && (c == SYN || c == SOH) {
                        return;
                    }
                    if !parity_ok(c) {
                        *bad_parity += 1;
                        *state = State::Hunting;
                        *reg = 0;
                        chars.clear();
                        return;
                    }
                    chars.push(c);

                    let stripped = c & 0x7F;
                    if stripped == ETX || stripped == ETB {
                        *after_term = 2;
                        return;
                    }
                    if chars.len() > MAX_CHARS {
                        *state = State::Hunting;
                        *reg = 0;
                        chars.clear();
                    }
                }
            }
        });
    }
}

// ---------------------------------------------------------------------------
// Block
// ---------------------------------------------------------------------------

/// One decoded ACARS block.
#[derive(Clone, Debug)]
pub struct Block {
    /// Single character identifying the ground network and category.
    pub mode: char,
    /// Aircraft registration, as the airframe reports it, e.g. `C-FGKN`.
    pub registration: String,
    /// Whether the ground station acknowledged, or NAK for not.
    pub ack: char,
    /// Two characters saying what kind of message this is. See
    /// [`label_text`].
    pub label: String,
    pub block_id: char,
    /// Message sequence number, on downlinks that carry one.
    pub sequence: Option<String>,
    /// Flight number, on downlinks that carry one.
    pub flight: Option<String>,
    pub text: String,
    /// Whether this block ends a multi-block message.
    pub more_to_come: bool,
    /// Whether the transmitted checksum agreed with the computed one. See
    /// the note at the top of this module about why a block can be shown
    /// with this false.
    pub crc_ok: bool,
}

impl Block {
    fn assemble(chars: &[u8]) -> Option<Block> {
        // mode(1) + registration(7) + ack(1) + label(2) + block id(1) is
        // twelve characters before the STX, and there must be a terminator
        // and two checksum bytes after it.
        if chars.len() < 16 {
            return None;
        }
        let n = chars.len();
        // Characters lose their parity bit; the two checksum bytes keep
        // every bit they arrived with.
        let mut a: Vec<u8> = chars[..n - 2].iter().map(|c| c & 0x7F).collect();
        a.push(chars[n - 2]);
        a.push(chars[n - 1]);
        let term = a[n - 3];
        if term != ETX && term != ETB {
            return None;
        }

        let txt = |r: std::ops::Range<usize>| -> String {
            a[r].iter()
                .map(|&c| if (0x20..0x7F).contains(&c) { c as char } else { ' ' })
                .collect::<String>()
                .trim()
                .trim_matches('.')
                .trim()
                .to_string()
        };

        let mode = a[0] as char;
        let registration = txt(1..8);
        let ack = a[8] as char;
        let label = txt(9..11);
        let block_id = a[11] as char;

        // The payload sits between STX and the terminator. Some blocks
        // carry no STX at all — a bare acknowledgement, for instance.
        let body_start = if a.get(12) == Some(&STX) { 13 } else { 12 };
        let body_end = n - 3;
        if body_start > body_end {
            return None;
        }
        let body: Vec<u8> = a[body_start..body_end].to_vec();

        // Downlinks begin with a four-character sequence number and a
        // six-character flight number. Uplinks do not, and nothing in the
        // block says which this is, so the shape of the field decides:
        // both are alphanumeric, and anything else means this is not one.
        let printable = |s: &[u8]| {
            s.iter()
                .all(|&c| c.is_ascii_alphanumeric() || c == b' ')
        };
        let (sequence, flight, text) = if body.len() >= 10
            && printable(&body[0..4])
            && printable(&body[4..10])
        {
            (
                Some(String::from_utf8_lossy(&body[0..4]).trim().to_string()),
                Some(String::from_utf8_lossy(&body[4..10]).trim().to_string()),
                String::from_utf8_lossy(&body[10..]).to_string(),
            )
        } else {
            (None, None, String::from_utf8_lossy(&body).to_string())
        };

        // Computed over the message characters, then the two transmitted
        // checksum bytes; a good block leaves nothing behind. The span —
        // which characters the transmitter included — is the part that
        // could not be confirmed without a real capture, which is why a
        // mismatch flags the block rather than discarding it.
        let residue = crc_ccitt_lsb(crc_ccitt_lsb(0, &a[..n - 2]), &a[n - 2..n]);

        Some(Block {
            mode,
            registration,
            ack,
            label,
            block_id,
            sequence,
            flight,
            text: text
                .chars()
                .map(|c| if c == '\r' { '\n' } else { c })
                .collect::<String>()
                .trim_end()
                .to_string(),
            more_to_come: term == ETB,
            crc_ok: residue == 0,
        })
    }

    /// A one-line summary for a list.
    pub fn summary(&self) -> String {
        let what = label_text(&self.label);
        let who = self
            .flight
            .clone()
            .filter(|f| !f.is_empty())
            .unwrap_or_else(|| self.registration.clone());
        let first = self.text.lines().next().unwrap_or("").trim();
        if first.is_empty() {
            format!("{who}  {what}")
        } else {
            format!("{who}  {what}  {first}")
        }
    }
}

/// What a label means, for the ones that are standard across airlines.
///
/// Most of the two-character space is airline-defined and means nothing
/// without that airline's manual, so those are reported as what they are
/// rather than guessed at.
pub fn label_text(label: &str) -> &'static str {
    match label {
        "_d" => "link squitter",
        "Q0" => "link test",
        "Q1" | "Q2" => "departure or arrival report",
        "Q3" => "fuel",
        "Q4" | "Q5" | "Q6" => "operations report",
        "QA" | "QB" => "out or off report",
        "QC" | "QD" => "on or in report",
        "H1" => "message to or from the crew",
        "10" | "11" | "12" | "13" => "airline operational",
        "14" | "15" | "16" => "position report",
        "20" => "groundstation request",
        "21" => "position report",
        "22" => "weather request",
        "30" => "flight plan",
        "80" => "airline defined",
        "5Z" => "airline defined",
        "SA" => "media advisory",
        "B9" => "request for air traffic clearance",
        "A6" | "A7" | "A8" | "A9" => "air traffic service",
        ":;" => "position report",
        _ => "airline defined",
    }
}

// ---------------------------------------------------------------------------
// Tracking
// ---------------------------------------------------------------------------

/// What has been heard from one airframe.
#[derive(Clone)]
pub struct Airframe {
    pub registration: String,
    pub flight: Option<String>,
    pub last_label: String,
    pub last_text: String,
    pub blocks: u32,
    pub last_seen: Instant,
}

impl Airframe {
    pub fn age(&self) -> Duration {
        self.last_seen.elapsed()
    }
}

pub struct AcarsLog {
    seen: HashMap<String, Airframe>,
    /// Every block in order, newest last, capped so a long session cannot
    /// grow without limit.
    messages: Vec<(Instant, Block)>,
    pub timeout: Duration,
}

impl Default for AcarsLog {
    fn default() -> Self {
        Self::new()
    }
}

impl AcarsLog {
    pub fn new() -> Self {
        AcarsLog {
            seen: HashMap::new(),
            messages: Vec::new(),
            timeout: Duration::from_secs(3600),
        }
    }

    pub fn ingest(&mut self, b: &Block) {
        let now = Instant::now();
        let key = if b.registration.is_empty() {
            "(unknown)".to_string()
        } else {
            b.registration.clone()
        };
        let e = self.seen.entry(key.clone()).or_insert_with(|| Airframe {
            registration: key,
            flight: None,
            last_label: String::new(),
            last_text: String::new(),
            blocks: 0,
            last_seen: now,
        });
        e.last_seen = now;
        e.blocks += 1;
        if let Some(f) = &b.flight {
            if !f.is_empty() {
                e.flight = Some(f.clone());
            }
        }
        e.last_label = b.label.clone();
        if !b.text.is_empty() {
            e.last_text = b.text.clone();
        }

        self.messages.push((now, b.clone()));
        if self.messages.len() > 500 {
            let drop_n = self.messages.len() - 500;
            self.messages.drain(..drop_n);
        }
    }

    pub fn expire(&mut self) {
        let t = self.timeout;
        self.seen.retain(|_, a| a.last_seen.elapsed() < t);
    }

    pub fn aircraft(&self) -> Vec<Airframe> {
        let mut v: Vec<Airframe> = self.seen.values().cloned().collect();
        v.sort_by(|a, b| a.last_seen.cmp(&b.last_seen).reverse());
        v
    }

    /// Most recent first.
    pub fn recent(&self, n: usize) -> Vec<(f32, Block)> {
        self.messages
            .iter()
            .rev()
            .take(n)
            .map(|(t, b)| (t.elapsed().as_secs_f32(), b.clone()))
            .collect()
    }

    pub fn len(&self) -> usize {
        self.seen.len()
    }

    pub fn is_empty(&self) -> bool {
        self.seen.is_empty()
    }

    pub fn clear(&mut self) {
        self.seen.clear();
        self.messages.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f32::consts::TAU;

    /// Attach odd parity to a seven-bit character.
    fn par(c: u8) -> u8 {
        if c.count_ones() % 2 == 1 {
            c
        } else {
            c | 0x80
        }
    }

    #[test]
    fn parity_matches_the_known_control_characters() {
        // acarsdec reports ETX on the wire as 0x83 and ETB as 0x97, which
        // is exactly odd parity in the top bit.
        assert_eq!(par(ETX), 0x83);
        assert_eq!(par(ETB), 0x97);
        // SYN and SOH already have an odd number of ones, so they travel
        // unchanged — which is what makes the sync word 0x16 0x16.
        assert_eq!(par(SYN), 0x16);
        assert_eq!(par(SOH), 0x01);
        assert_eq!(par(DEL), 0x7F);
    }

    #[test]
    fn the_crc_engine_matches_the_published_table() {
        // acarsdec's table starts 0x0000, 0x1189, 0x2312, 0x329b. Each
        // entry is the engine run over that single byte from zero.
        for (i, want) in [0x0000u16, 0x1189, 0x2312, 0x329B].iter().enumerate() {
            assert_eq!(crc_ccitt_lsb(0, &[i as u8]), *want, "table[{i}]");
        }
    }

    /// Build the characters of a block, the way a transmitter would.
    fn block_chars(reg: &str, label: &str, body: &str, good_crc: bool) -> Vec<u8> {
        let mut a: Vec<u8> = Vec::new();
        a.push(b'2'); // mode
        let r = format!("{:.>7}", reg);
        a.extend(r.bytes().take(7));
        a.push(0x15); // NAK: not acknowledged
        a.extend(label.bytes().take(2));
        a.push(b'1'); // block id
        a.push(STX);
        a.extend(body.bytes());
        a.push(ETX);
        let mut crc = crc_ccitt_lsb(0, &a);
        if !good_crc {
            crc ^= 0x0001;
        }
        a.extend_from_slice(&crc.to_le_bytes());
        a
    }

    /// Characters to the bit stream, then to 1200/2400 Hz tones.
    /// Append one character, least significant bit first.
    fn push_bits(bits: &mut Vec<u8>, c: u8, add_parity: bool) {
        let c = if add_parity { par(c & 0x7F) } else { c };
        for k in 0..8 {
            bits.push((c >> k) & 1);
        }
    }

    fn to_audio(chars: &[u8], rate: f32) -> Vec<f32> {
        let mut bits: Vec<u8> = Vec::new();
        // Preamble, then the sync characters and SOH.
        for _ in 0..16 {
            bits.push(0);
            bits.push(1);
        }
        push_bits(&mut bits, SYN, true);
        push_bits(&mut bits, SYN, true);
        push_bits(&mut bits, SOH, true);
        let n = chars.len();
        for (i, &c) in chars.iter().enumerate() {
            // Everything but the last two is a character and carries
            // parity; the two checksum bytes are raw.
            push_bits(&mut bits, c, i + 2 < n);
        }
        push_bits(&mut bits, DEL, true);

        let spb = (rate / BAUD).round() as usize;
        let mut phase = 0.0f32;
        let mut out = Vec::with_capacity(bits.len() * spb);
        for &b in &bits {
            let f = if b == 1 { MARK_HZ } else { SPACE_HZ };
            for _ in 0..spb {
                out.push(phase.sin());
                phase += TAU * f / rate;
                if phase > TAU {
                    phase -= TAU;
                }
            }
        }
        out
    }

    #[test]
    fn a_synthesised_block_decodes_to_its_fields() {
        let chars = block_chars("C-FGKN", "H1", "0001AC0123MESSAGE FROM DISPATCH", true);
        let audio = to_audio(&chars, 48_000.0);
        let mut d = AcarsDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&vec![0.0f32; 400], &mut out);
        d.process(&audio, &mut out);

        assert_eq!(out.len(), 1, "expected one block, got {}", out.len());
        let b = &out[0];
        assert_eq!(b.registration, "C-FGKN");
        assert_eq!(b.label, "H1");
        assert_eq!(b.mode, '2');
        assert_eq!(b.sequence.as_deref(), Some("0001"));
        assert_eq!(b.flight.as_deref(), Some("AC0123"));
        assert_eq!(b.text, "MESSAGE FROM DISPATCH");
        assert!(b.crc_ok, "checksum should verify on a clean frame");
        assert!(!b.more_to_come);
    }

    #[test]
    fn a_block_with_a_bad_checksum_is_flagged_not_hidden() {
        // The design choice this pins: parity and structure decide whether
        // a block is real, the checksum decides whether it is trusted.
        let chars = block_chars("C-GITS", "Q0", "0002AC0456", false);
        let audio = to_audio(&chars, 48_000.0);
        let mut d = AcarsDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&audio, &mut out);
        assert_eq!(out.len(), 1);
        assert_eq!(out[0].registration, "C-GITS");
        assert!(!out[0].crc_ok, "a corrupted checksum must not read as ok");
    }

    #[test]
    fn a_character_with_broken_parity_abandons_the_block() {
        let chars = block_chars("C-FGKN", "H1", "0001AC0123HELLO", true);
        // Corrupt one character's parity bit. Flipping a data bit would
        // not do: half the time it leaves the count odd and the character
        // still looks valid, which is exactly what parity cannot catch.
        // Flipping the parity bit itself always fails, every time.
        let mut bits: Vec<u8> = Vec::new();
        for _ in 0..16 {
            bits.push(0);
            bits.push(1);
        }
        push_bits(&mut bits, SYN, true);
        push_bits(&mut bits, SYN, true);
        push_bits(&mut bits, SOH, true);
        let n = chars.len();
        for (i, &c) in chars.iter().enumerate() {
            if i == 3 {
                push_bits(&mut bits, par(c & 0x7F) ^ 0x80, false);
            } else {
                push_bits(&mut bits, c, i + 2 < n);
            }
        }
        let spb = (48_000.0f32 / BAUD).round() as usize;
        let mut phase = 0.0f32;
        let mut audio = Vec::new();
        for &b in &bits {
            let f = if b == 1 { MARK_HZ } else { SPACE_HZ };
            for _ in 0..spb {
                audio.push(phase.sin());
                phase += TAU * f / 48_000.0;
                if phase > TAU {
                    phase -= TAU;
                }
            }
        }
        let mut d = AcarsDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&audio, &mut out);
        assert!(out.is_empty(), "a parity failure must drop the block");
        assert!(d.bad_parity > 0);
    }

    #[test]
    fn an_uplink_without_sequence_and_flight_keeps_its_whole_text() {
        // Uplinks have no sequence or flight number, and reading the first
        // ten characters of the text as those fields would eat the message.
        let chars = block_chars("C-FGKN", "SA", "0#MSG/FTO AC123", true);
        let audio = to_audio(&chars, 48_000.0);
        let mut d = AcarsDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&audio, &mut out);
        assert_eq!(out.len(), 1);
        assert!(out[0].sequence.is_none(), "should not invent a sequence");
        assert!(out[0].text.contains("MSG/FTO"));
    }

    #[test]
    fn noise_produces_no_blocks() {
        let mut rng: u32 = 7;
        let noise: Vec<f32> = (0..400_000)
            .map(|_| {
                rng = rng.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
                (rng >> 8) as f32 / 8_388_608.0 - 1.0
            })
            .collect();
        let mut d = AcarsDemod::new(48_000.0);
        let mut out = Vec::new();
        d.process(&noise, &mut out);
        assert!(out.is_empty(), "noise produced {} blocks", out.len());
    }

    #[test]
    fn labels_that_are_not_standard_say_so() {
        assert_eq!(label_text("Q0"), "link test");
        assert_eq!(label_text("ZZ"), "airline defined");
    }
}
