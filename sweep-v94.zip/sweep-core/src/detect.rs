//! Noise floor, detection, squelch.
//!
//! All three key off the same idea: a signal is not "loud", it is "louder than
//! this bin usually is". Absolute thresholds break the moment you change
//! antenna, gain, or band.

use std::collections::HashMap;

/// Per-bin rolling noise floor.
///
/// The asymmetry is the point: it drifts up slowly and follows down quickly,
/// so a transmission that lasts a minute does not get absorbed into the floor
/// and stop being a detection.
#[derive(Debug, Clone)]
pub struct NoiseFloor {
    est: Vec<f32>,
    alpha: f32,
    climb_db: f32,
    /// A bin this far above the current estimate is treated as signal and
    /// excluded from the noise estimate. Keep it below the detector's open
    /// threshold, so signals are frozen out before they would be reported.
    freeze_db: f32,
    primed: bool,
}

impl NoiseFloor {
    pub fn new(bins: usize) -> Self {
        NoiseFloor {
            est: vec![-100.0; bins],
            alpha: 0.06,
            climb_db: 3.0,
            freeze_db: 6.0,
            primed: false,
        }
    }

    pub fn with_alpha(mut self, alpha: f32) -> Self {
        self.alpha = alpha;
        self
    }

    pub fn with_freeze(mut self, freeze_db: f32) -> Self {
        self.freeze_db = freeze_db;
        self
    }

    pub fn update(&mut self, spectrum: &[f32]) {
        assert_eq!(spectrum.len(), self.est.len());
        if !self.primed {
            // Do NOT copy the frame. Any carrier already transmitting when the
            // scanner starts would become part of the floor and never be
            // detected again. The median is a robust estimate of the noise
            // level even when a third of the band is occupied, so clamp every
            // bin to it and let the real floor shape emerge over a few frames.
            let mut sorted = spectrum.to_vec();
            sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let ceiling = sorted[sorted.len() / 2] + 3.0;
            for (e, &v) in self.est.iter_mut().zip(spectrum) {
                *e = v.min(ceiling);
            }
            self.primed = true;
            return;
        }
        for (e, &v) in self.est.iter_mut().zip(spectrum) {
            if v > *e + self.freeze_db {
                // This bin looks like signal, not noise. Excluding it is the
                // whole point: otherwise a repeater that idles for ten minutes
                // becomes part of the floor and stops being a detection.
                // A slow creep remains so a genuine band-noise rise (gain
                // change, new interferer) still registers, over ~15 minutes
                // rather than ~10 seconds.
                *e += self.alpha * 0.02 * self.climb_db;
            } else {
                *e += (v - *e) * self.alpha;
            }
        }
    }

    pub fn get(&self) -> &[f32] {
        &self.est
    }

    /// Median of the current estimate: a single number for "how quiet is it".
    pub fn median(&self) -> f32 {
        let mut v = self.est.clone();
        v.sort_by(|a, b| a.partial_cmp(b).unwrap());
        v[v.len() / 2]
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Detection {
    pub center_hz: f64,
    pub bw_hz: f64,
    pub peak_db: f32,
    pub snr_db: f32,
}

/// Threshold, cluster, and track. Hysteresis on the trailing edge stops one
/// carrier from fragmenting into three detections as it wobbles.
#[derive(Debug, Clone)]
pub struct Detector {
    pub open_db: f32,
    pub close_db: f32,
    pub min_bins: usize,
}

impl Default for Detector {
    fn default() -> Self {
        Detector {
            open_db: 8.0,
            close_db: 5.0,
            // A real narrowband carrier spans several bins. Requiring three
            // rejects the single-bin flukes that survive integration.
            min_bins: 3,
        }
    }
}

impl Detector {
    /// `bin_hz` is the width of one bin; `f0_hz` the frequency of bin 0.
    pub fn scan(
        &self,
        spectrum: &[f32],
        floor: &[f32],
        f0_hz: f64,
        bin_hz: f64,
    ) -> Vec<Detection> {
        let mut out = Vec::new();
        let n = spectrum.len();
        let mut i = 0;
        while i < n {
            if spectrum[i] - floor[i] < self.open_db {
                i += 1;
                continue;
            }
            // Walk outward while we stay above the *close* threshold.
            let mut a = i;
            while a > 0 && spectrum[a - 1] - floor[a - 1] >= self.close_db {
                a -= 1;
            }
            let mut b = i;
            while b + 1 < n && spectrum[b + 1] - floor[b + 1] >= self.close_db {
                b += 1;
            }
            if b - a + 1 >= self.min_bins {
                let (mut peak, mut pi) = (f32::MIN, a);
                for k in a..=b {
                    if spectrum[k] > peak {
                        peak = spectrum[k];
                        pi = k;
                    }
                }
                out.push(Detection {
                    center_hz: f0_hz + pi as f64 * bin_hz,
                    bw_hz: (b - a + 1) as f64 * bin_hz,
                    peak_db: peak,
                    snr_db: peak - floor[pi],
                });
            }
            i = b + 1;
        }
        out
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Track {
    pub center_hz: f64,
    pub bw_hz: f64,
    pub peak_db: f32,
    pub hits: u32,
    pub first_sweep: u64,
    pub last_sweep: u64,
}

impl Track {
    /// Fraction of sweeps since first contact in which this was present.
    pub fn duty(&self) -> f32 {
        let span = (self.last_sweep - self.first_sweep + 1) as f32;
        self.hits as f32 / span
    }
}

/// Accumulates detections into persistent tracks, keyed by rounded frequency.
#[derive(Debug, Clone)]
pub struct Tracker {
    tracks: HashMap<i64, Track>,
    bucket_hz: f64,
    expire_sweeps: u64,
}

impl Tracker {
    pub fn new(bucket_hz: f64, expire_sweeps: u64) -> Self {
        Tracker {
            tracks: HashMap::new(),
            bucket_hz,
            expire_sweeps,
        }
    }

    fn key(&self, hz: f64) -> i64 {
        (hz / self.bucket_hz).round() as i64
    }

    pub fn ingest(&mut self, dets: &[Detection], sweep: u64) {
        for d in dets {
            let k = self.key(d.center_hz);
            let t = self.tracks.entry(k).or_insert(Track {
                center_hz: d.center_hz,
                bw_hz: d.bw_hz,
                peak_db: d.peak_db,
                hits: 0,
                first_sweep: sweep,
                last_sweep: sweep,
            });
            t.hits += 1;
            t.last_sweep = sweep;
            t.peak_db = t.peak_db.max(d.peak_db);
            t.bw_hz = t.bw_hz.max(d.bw_hz);
        }
        self.tracks
            .retain(|_, t| sweep.saturating_sub(t.last_sweep) <= self.expire_sweeps);
    }

    /// Tracks seen at least `min_hits` times, strongest first.
    pub fn confirmed(&self, min_hits: u32) -> Vec<&Track> {
        let mut v: Vec<&Track> = self.tracks.values().filter(|t| t.hits >= min_hits).collect();
        v.sort_by(|a, b| b.peak_db.partial_cmp(&a.peak_db).unwrap());
        v
    }

    pub fn len(&self) -> usize {
        self.tracks.len()
    }

    pub fn is_empty(&self) -> bool {
        self.tracks.is_empty()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SquelchState {
    Closed,
    Open,
    /// Carrier has dropped but we are holding the channel open, waiting to see
    /// whether this is a gap between overs or the end of the conversation.
    Hang,
}

/// Carrier-operated squelch with hysteresis and hang.
///
/// Hang is what stops the scanner bailing out of a conversation the instant
/// someone unkeys, and then missing the reply.
#[derive(Debug, Clone)]
pub struct Squelch {
    pub open_db: f32,
    pub close_db: f32,
    pub hang_ms: u32,
    state: SquelchState,
    hang_left: u32,
}

impl Squelch {
    pub fn new(open_db: f32, hang_ms: u32) -> Self {
        Squelch {
            open_db,
            close_db: (open_db - 3.0).max(1.0),
            hang_ms,
            state: SquelchState::Closed,
            hang_left: 0,
        }
    }

    pub fn state(&self) -> SquelchState {
        self.state
    }

    /// True when audio should be passed to the speaker.
    pub fn audio_open(&self) -> bool {
        matches!(self.state, SquelchState::Open | SquelchState::Hang)
    }

    /// Advance by `dt_ms` with the current signal-over-floor reading.
    pub fn update(&mut self, snr_db: f32, dt_ms: u32) -> SquelchState {
        match self.state {
            SquelchState::Closed => {
                if snr_db >= self.open_db {
                    self.state = SquelchState::Open;
                }
            }
            SquelchState::Open => {
                if snr_db < self.close_db {
                    self.state = SquelchState::Hang;
                    self.hang_left = self.hang_ms;
                }
            }
            SquelchState::Hang => {
                if snr_db >= self.open_db {
                    self.state = SquelchState::Open;
                } else {
                    self.hang_left = self.hang_left.saturating_sub(dt_ms);
                    if self.hang_left == 0 {
                        self.state = SquelchState::Closed;
                    }
                }
            }
        }
        self.state
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn flat(n: usize, v: f32) -> Vec<f32> {
        vec![v; n]
    }

    #[test]
    fn floor_primes_from_the_first_frame() {
        let mut nf = NoiseFloor::new(8);
        nf.update(&flat(8, -92.0));
        assert!(nf.get().iter().all(|&v| (v - -92.0).abs() < 1e-6));
    }

    #[test]
    fn a_carrier_already_transmitting_at_startup_is_still_found() {
        // The scanner starts while someone is mid-transmission. Naive priming
        // copies the frame and swallows them permanently.
        let n = 64;
        let mut spec = flat(n, -100.0);
        for i in 30..34 {
            spec[i] = -60.0;
        }
        let mut nf = NoiseFloor::new(n);
        for _ in 0..50 {
            nf.update(&spec);
        }
        let d = Detector::default().scan(&spec, nf.get(), 100e6, 1000.0);
        assert_eq!(d.len(), 1, "carrier present from frame zero must still detect");
        assert!(d[0].snr_db > 30.0, "snr was only {}", d[0].snr_db);
    }

    #[test]
    fn floor_resists_a_strong_carrier() {
        let mut nf = NoiseFloor::new(4);
        nf.update(&flat(4, -95.0));
        // A loud signal parks on one bin for 100 frames.
        for _ in 0..100 {
            nf.update(&[-95.0, -95.0, -40.0, -95.0]);
        }
        let e = nf.get();
        assert!(
            e[2] < -70.0,
            "floor was dragged to {} by a persistent carrier",
            e[2]
        );
        assert!((e[0] - -95.0).abs() < 1.0);
    }

    #[test]
    fn floor_follows_a_genuine_band_change_downward() {
        let mut nf = NoiseFloor::new(4);
        nf.update(&flat(4, -80.0));
        for _ in 0..200 {
            nf.update(&flat(4, -110.0));
        }
        assert!(nf.median() < -105.0);
    }

    #[test]
    fn finds_a_single_carrier_with_the_right_width() {
        let n = 64;
        let floor = flat(n, -100.0);
        let mut spec = floor.clone();
        for i in 30..34 {
            spec[i] = -70.0;
        }
        let d = Detector::default().scan(&spec, &floor, 100e6, 1000.0);
        assert_eq!(d.len(), 1);
        assert!((d[0].bw_hz - 4000.0).abs() < 1.0);
        assert!((d[0].snr_db - 30.0).abs() < 0.1);
    }

    #[test]
    fn hysteresis_keeps_one_carrier_from_splitting() {
        let n = 32;
        let floor = flat(n, -100.0);
        let mut spec = floor.clone();
        // Peak, dip that stays above close_db, peak. One signal, not two.
        spec[10] = -90.0;
        spec[11] = -94.0;
        spec[12] = -90.0;
        let d = Detector::default().scan(&spec, &floor, 0.0, 1000.0);
        assert_eq!(d.len(), 1, "hysteresis should bridge the dip");
        assert!((d[0].bw_hz - 3000.0).abs() < 1.0);
    }

    #[test]
    fn ignores_noise_below_threshold() {
        let n = 128;
        let floor = flat(n, -100.0);
        let mut spec = floor.clone();
        for (i, s) in spec.iter_mut().enumerate() {
            *s += (i % 5) as f32; // up to +4 dB, under the +8 dB gate
        }
        assert!(Detector::default().scan(&spec, &floor, 0.0, 1000.0).is_empty());
    }

    #[test]
    fn separate_carriers_stay_separate() {
        let n = 64;
        let floor = flat(n, -100.0);
        let mut spec = floor.clone();
        for i in 9..12 { spec[i] = -60.0; }
        for i in 39..42 { spec[i] = -65.0; }
        let d = Detector::default().scan(&spec, &floor, 0.0, 1000.0);
        assert_eq!(d.len(), 2);
    }

    #[test]
    fn tracker_accumulates_duty_cycle() {
        let mut tr = Tracker::new(12_500.0, 100);
        let d = Detection {
            center_hz: 146_940_000.0,
            bw_hz: 12_500.0,
            peak_db: -70.0,
            snr_db: 25.0,
        };
        // Present on half the sweeps.
        for s in 0..20 {
            if s % 2 == 0 {
                tr.ingest(std::slice::from_ref(&d), s);
            } else {
                tr.ingest(&[], s);
            }
        }
        let c = tr.confirmed(3);
        assert_eq!(c.len(), 1);
        assert!((c[0].duty() - 0.526).abs() < 0.05, "duty {}", c[0].duty());
    }

    #[test]
    fn tracker_expires_a_silent_channel() {
        let mut tr = Tracker::new(12_500.0, 10);
        tr.ingest(
            &[Detection {
                center_hz: 155e6,
                bw_hz: 12_500.0,
                peak_db: -70.0,
                snr_db: 20.0,
            }],
            0,
        );
        assert_eq!(tr.len(), 1);
        tr.ingest(&[], 50);
        assert!(tr.is_empty());
    }

    #[test]
    fn squelch_opens_and_holds_through_a_gap() {
        let mut sq = Squelch::new(8.0, 2000);
        assert_eq!(sq.update(2.0, 20), SquelchState::Closed);
        assert_eq!(sq.update(12.0, 20), SquelchState::Open);
        // Unkey: audio stays live during hang.
        assert_eq!(sq.update(1.0, 20), SquelchState::Hang);
        assert!(sq.audio_open(), "must not cut audio during hang");
        // Reply comes back before hang expires.
        assert_eq!(sq.update(15.0, 500), SquelchState::Open);
    }

    #[test]
    fn squelch_closes_once_hang_expires() {
        let mut sq = Squelch::new(8.0, 1000);
        sq.update(20.0, 20);
        sq.update(0.0, 20);
        for _ in 0..5 {
            sq.update(0.0, 250);
        }
        assert_eq!(sq.state(), SquelchState::Closed);
        assert!(!sq.audio_open());
    }

    #[test]
    fn squelch_hysteresis_stops_chatter_at_the_threshold() {
        let mut sq = Squelch::new(8.0, 0);
        sq.update(9.0, 10);
        assert_eq!(sq.state(), SquelchState::Open);
        // Sitting at 6 dB: below open, above close. Should stay open.
        for _ in 0..10 {
            sq.update(6.0, 10);
        }
        assert_eq!(sq.state(), SquelchState::Open);
    }
}
