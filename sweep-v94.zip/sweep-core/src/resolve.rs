//! Turning a [`ScanPlan`] into something the tuner can actually execute.
//!
//! The goal is the fewest possible windows, because window count is blind
//! time. One window means the scanner never retunes and misses nothing —
//! that case is worth surfacing in the UI, not burying.

use crate::plan::*;

/// Retune cost: USB control transfer, PLL settle, and flushing stale buffers.
/// Measured on desktop; budget more on Android, where bulk timing is looser.
pub const RETUNE_MS: u32 = 12;

#[derive(Debug, Clone, PartialEq)]
pub struct TunerWindow {
    pub center_mhz: f64,
    pub sample_rate: u32,
    /// Indices into [`RunPlan::channels`] that live inside this window.
    pub channels: Vec<usize>,
    /// True when this window came from a swept range rather than a channel list.
    pub swept: bool,
}

impl TunerWindow {
    pub fn low_mhz(&self) -> f64 {
        self.center_mhz - WINDOW_MHZ / 2.0
    }
    pub fn high_mhz(&self) -> f64 {
        self.center_mhz + WINDOW_MHZ / 2.0
    }
    pub fn contains(&self, freq_mhz: f64) -> bool {
        freq_mhz >= self.low_mhz() - 1e-9 && freq_mhz <= self.high_mhz() + 1e-9
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ResolvedChannel {
    pub freq_mhz: f64,
    pub label: String,
    pub demod: Demod,
    pub bw_khz: f64,
    pub ctcss_hz: Option<f32>,
    pub priority: bool,
    pub locked_out: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RunPlan {
    pub name: String,
    pub windows: Vec<TunerWindow>,
    pub channels: Vec<ResolvedChannel>,
    pub squelch_db: f64,
    pub hang_ms: u32,
    pub dwell_ms: u32,
}

impl RunPlan {
    /// True when the whole plan fits in one capture: no retuning, no blind time.
    pub fn is_single_window(&self) -> bool {
        self.windows.len() == 1
    }

    /// How long between successive looks at any given window.
    pub fn revisit_ms(&self) -> u32 {
        if self.is_single_window() {
            0
        } else {
            self.windows.len() as u32 * (RETUNE_MS + self.dwell_ms)
        }
    }

    /// Fraction of wall-clock time any one window is *not* being observed.
    pub fn blind_fraction(&self) -> f64 {
        if self.windows.len() <= 1 {
            0.0
        } else {
            1.0 - 1.0 / self.windows.len() as f64
        }
    }
}

/// Pick a centre frequency that keeps every channel clear of the DC spike
/// while still fitting them all inside the window.
fn avoid_dc(ideal: f64, freqs: &[f64]) -> f64 {
    let clear = |c: f64| {
        freqs.iter().all(|f| {
            (f - c).abs() >= DC_GUARD_MHZ - 1e-9 && (f - c).abs() <= WINDOW_MHZ / 2.0 + 1e-9
        })
    };
    if clear(ideal) {
        return ideal;
    }
    // Nudge in increasing steps, alternating direction, until the spike lands
    // in a gap. Bounded: the window has slack unless it is completely full.
    let step = DC_GUARD_MHZ / 2.0;
    for i in 1..=64 {
        for cand in [ideal + step * i as f64, ideal - step * i as f64] {
            if clear(cand) {
                return cand;
            }
        }
    }
    ideal
}

/// Greedy first-fit over sorted frequencies. For covering points with
/// fixed-width intervals this is optimal, so the window count is minimal.
fn pack(freqs: &[(usize, f64)]) -> Vec<TunerWindow> {
    let mut sorted = freqs.to_vec();
    sorted.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
    let mut out = Vec::new();
    let mut i = 0;
    while i < sorted.len() {
        let start = sorted[i].1;
        let mut j = i;
        while j < sorted.len() && sorted[j].1 - start <= WINDOW_MHZ {
            j += 1;
        }
        let group: Vec<f64> = sorted[i..j].iter().map(|(_, f)| *f).collect();
        let ideal = (group[0] + group[group.len() - 1]) / 2.0;
        out.push(TunerWindow {
            center_mhz: avoid_dc(ideal, &group),
            sample_rate: SAMPLE_RATE,
            channels: sorted[i..j].iter().map(|(idx, _)| *idx).collect(),
            swept: false,
        });
        i = j;
    }
    out
}

/// Split a swept range into equal sub-windows, each no wider than [`WINDOW_MHZ`].
fn split_range(w: &Window) -> Vec<TunerWindow> {
    let n = (w.width() / WINDOW_MHZ).ceil().max(1.0) as usize;
    let each = w.width() / n as f64;
    (0..n)
        .map(|k| TunerWindow {
            center_mhz: w.f0 + each * (k as f64 + 0.5),
            sample_rate: SAMPLE_RATE,
            channels: Vec::new(),
            swept: true,
        })
        .collect()
}

pub fn resolve(plan: &ScanPlan, direct_sampling: bool) -> Result<RunPlan, PlanError> {
    plan.validate(direct_sampling)?;

    let channels: Vec<ResolvedChannel> = plan
        .channels
        .iter()
        .map(|c| {
            let demod = c.demod.unwrap_or(plan.demod);
            ResolvedChannel {
                freq_mhz: c.freq_mhz,
                label: c.label.clone(),
                demod,
                bw_khz: demod.default_bw_khz(),
                ctcss_hz: c.ctcss_hz.or(plan.ctcss_hz),
                priority: c.priority || plan.priority.iter().any(|p| near(*p, c.freq_mhz)),
                locked_out: plan.lockout.iter().any(|l| near(*l, c.freq_mhz)),
            }
        })
        .collect();

    let live: Vec<(usize, f64)> = channels
        .iter()
        .enumerate()
        .filter(|(_, c)| !c.locked_out)
        .map(|(i, c)| (i, c.freq_mhz))
        .collect();

    let mut windows = pack(&live);
    for w in &plan.windows {
        windows.extend(split_range(w));
    }
    windows.sort_by(|a, b| a.center_mhz.partial_cmp(&b.center_mhz).unwrap());

    Ok(RunPlan {
        name: plan.name.clone(),
        windows,
        channels,
        squelch_db: plan.squelch_db,
        hang_ms: plan.hang_ms,
        dwell_ms: plan.dwell_ms,
    })
}

fn near(a: f64, b: f64) -> bool {
    (a - b).abs() < 1e-6
}

#[cfg(test)]
mod tests {
    use super::*;

    fn plan_with(channels: Vec<Channel>) -> ScanPlan {
        ScanPlan {
            name: "t".into(),
            windows: vec![],
            channels,
            demod: Demod::Nfm,
            step_khz: 12.5,
            squelch_db: 8.0,
            hang_ms: 2000,
            dwell_ms: 40,
            priority: vec![],
            lockout: vec![],
            ctcss_hz: None,
            source: "user".into(),
        }
    }

    #[test]
    fn one_channel_is_one_window_and_never_blind() {
        let rp = resolve(&plan_with(vec![Channel::new(118.8, "Tower")]), false).unwrap();
        assert!(rp.is_single_window());
        assert_eq!(rp.revisit_ms(), 0);
        assert_eq!(rp.blind_fraction(), 0.0);
    }

    #[test]
    fn nearby_channels_share_a_window() {
        // The seven FRS simplex channels span 175 kHz — comfortably one window.
        let ch: Vec<Channel> = (0..7)
            .map(|i| Channel::new(462.5625 + i as f64 * 0.025, &format!("FRS {}", i + 1)))
            .collect();
        let rp = resolve(&plan_with(ch), false).unwrap();
        assert_eq!(rp.windows.len(), 1);
        assert_eq!(rp.windows[0].channels.len(), 7);
    }

    #[test]
    fn spread_channels_need_multiple_windows_and_report_blind_time() {
        let ch = vec![
            Channel::new(118.8, "Tower"),
            Channel::new(121.9, "Ground"),
            Channel::new(128.175, "Terminal"),
        ];
        let rp = resolve(&plan_with(ch), false).unwrap();
        assert!(rp.windows.len() >= 3, "9.4 MHz cannot fit in 1.8 MHz windows");
        assert!(rp.revisit_ms() > 0);
        assert!(rp.blind_fraction() > 0.6);
    }

    #[test]
    fn every_channel_lands_inside_its_window() {
        let ch: Vec<Channel> = (0..40)
            .map(|i| Channel::new(144.0 + i as f64 * 0.1, &format!("c{i}")))
            .collect();
        let rp = resolve(&plan_with(ch), false).unwrap();
        for w in &rp.windows {
            for &i in &w.channels {
                let f = rp.channels[i].freq_mhz;
                assert!(w.contains(f), "{f} MHz escaped its window at {}", w.center_mhz);
            }
        }
        let placed: usize = rp.windows.iter().map(|w| w.channels.len()).sum();
        assert_eq!(placed, 40, "every channel must be scheduled exactly once");
    }

    #[test]
    fn no_channel_sits_on_the_dc_spike() {
        // A single channel would naively be centred on itself — straight onto DC.
        let rp = resolve(&plan_with(vec![Channel::new(162.55, "WX")]), false).unwrap();
        let off = (rp.windows[0].center_mhz - 162.55).abs();
        assert!(off >= DC_GUARD_MHZ - 1e-9, "offset was only {off} MHz");
        assert!(rp.windows[0].contains(162.55));
    }

    #[test]
    fn dc_avoidance_survives_a_dense_channel_group() {
        let ch: Vec<Channel> = (0..7)
            .map(|i| Channel::new(162.400 + i as f64 * 0.025, &format!("wx{i}")))
            .collect();
        let rp = resolve(&plan_with(ch), false).unwrap();
        let c = rp.windows[0].center_mhz;
        for r in &rp.channels {
            assert!((r.freq_mhz - c).abs() >= DC_GUARD_MHZ - 1e-9);
            assert!(rp.windows[0].contains(r.freq_mhz));
        }
    }

    #[test]
    fn a_swept_range_splits_into_covering_windows() {
        let mut p = plan_with(vec![]);
        p.windows = vec![Window { f0: 118.0, f1: 137.0 }];
        p.demod = Demod::Am;
        p.step_khz = 25.0;
        let rp = resolve(&p, false).unwrap();
        assert_eq!(rp.windows.len(), 11, "19 MHz / 1.8 MHz rounds up to 11");
        // Coverage must be continuous, with no gap between adjacent windows.
        for pair in rp.windows.windows(2) {
            assert!(pair[0].high_mhz() >= pair[1].low_mhz() - 1e-9, "gap in coverage");
        }
        assert!(rp.windows[0].low_mhz() <= 118.0 + 1e-9);
        assert!(rp.windows[10].high_mhz() >= 137.0 - 1e-9);
    }

    #[test]
    fn lockout_removes_a_channel_from_the_schedule() {
        let mut p = plan_with(vec![
            Channel::new(462.5625, "FRS 1"),
            Channel::new(462.5875, "FRS 2"),
        ]);
        p.lockout = vec![462.5875];
        let rp = resolve(&p, false).unwrap();
        let placed: usize = rp.windows.iter().map(|w| w.channels.len()).sum();
        assert_eq!(placed, 1);
        assert!(rp.channels[1].locked_out);
    }

    #[test]
    fn plan_level_priority_marks_the_channel() {
        let mut p = plan_with(vec![Channel::new(121.5, "Emergency")]);
        p.priority = vec![121.5];
        let rp = resolve(&p, false).unwrap();
        assert!(rp.channels[0].priority);
    }

    #[test]
    fn packing_is_minimal_for_a_known_layout() {
        // Three clusters, each far apart: the answer is exactly three windows.
        let ch = vec![
            Channel::new(146.0, "a"),
            Channel::new(146.5, "b"),
            Channel::new(400.0, "c"),
            Channel::new(400.9, "d"),
            Channel::new(900.0, "e"),
        ];
        let rp = resolve(&plan_with(ch), false).unwrap();
        assert_eq!(rp.windows.len(), 3);
    }
}
