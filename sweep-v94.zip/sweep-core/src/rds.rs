//! RDS (Radio Data System) — the station name and scrolling text that shows
//! on car radios, decoded from the 57 kHz subcarrier riding on FM
//! broadcast's composite (MPX) signal.
//!
//! This needs the *wideband* FM discriminator output, before the normal
//! audio chain's lowpass/de-emphasis — 57 kHz sits well above the ~15 kHz
//! audio band that chain filters down to, so RDS is a genuinely separate
//! tap on the signal, not something layered onto the demodulated audio.
//!
//! The block-sync constants and CRC below are checked against PiFmRds
//! (github.com/ChristopheJacquet/PiFmRds), a well-established open source
//! RDS *encoder* — a transmitter's encoder and a receiver's decoder have to
//! agree on identical constants or nothing will ever sync, which makes an
//! encoder exactly the right reference to verify a decoder's constants
//! against. Following that project's example, offset word C' (used by some
//! Open Data Applications) isn't handled — only the standard A/B/C/D
//! sequence every group uses.
//!
//! Deliberately not attempted: Alternate Frequency lists, TMC (traffic),
//! clock-time groups. What's implemented — Program Identification (PI),
//! Program Type (PTY), Program Service name (PS, group 0), and RadioText
//! (RT, group 2) — is what actually shows up as station name/text.
//!
//! Honest caveat: the block-sync/CRC logic below is unit-tested against a
//! synthetic bitstream, so that layer is verified. The analog front end —
//! recovering a clean bit clock from a real, noisy, drifting FM capture —
//! isn't something I can fully validate without an actual broadcast to test
//! against, and may need a tuning pass once there's real signal to check it
//! with.

use rustfft::num_complex::Complex32;
use std::f32::consts::TAU;

const POLY: u16 = 0x1B9;
const POLY_DEG: u32 = 10;
const OFFSET_A: u16 = 0x0FC;
const OFFSET_B: u16 = 0x198;
const OFFSET_C: u16 = 0x168;
const OFFSET_D: u16 = 0x1B4;
const SYMBOL_RATE_HZ: f32 = 1187.5;

/// The (10,16) cyclic code check value for a 16-bit info word — the same
/// computation PiFmRds's encoder uses, which a decoder must replicate
/// exactly to recognize a valid block.
fn crc10(info: u16) -> u16 {
    let mut block = info;
    let mut crc: u16 = 0;
    for _ in 0..16 {
        let bit = (block & 0x8000) != 0;
        block <<= 1;
        let msb = (crc >> (POLY_DEG - 1)) & 1 != 0;
        crc <<= 1;
        if msb ^ bit {
            crc ^= POLY;
        }
    }
    crc & ((1 << POLY_DEG) - 1)
}

/// True if `info` (16 bits) with `check` (10 bits) as its checkword is a
/// valid, error-free block of the given offset type.
fn block_matches(info: u16, check: u16, offset: u16) -> bool {
    (crc10(info) ^ check) == offset
}

/// `#[derive(Default)]` only covers arrays up to 32 elements, and the
/// RadioText buffers are 64 — so this is written out by hand.
#[derive(Clone)]
pub struct RdsData {
    pub pi_code: Option<u16>,
    pub pty: Option<u8>,
    pub ps_name: [u8; 8],
    ps_seen: [bool; 8],
    pub radiotext: [u8; 64],
    rt_seen: [bool; 64],
}

impl Default for RdsData {
    fn default() -> Self {
        RdsData {
            pi_code: None,
            pty: None,
            ps_name: [0; 8],
            ps_seen: [false; 8],
            radiotext: [0; 64],
            rt_seen: [false; 64],
        }
    }
}

impl RdsData {
    /// Only returns characters actually received — an unfilled slot shows
    /// as a space rather than a stale or zero byte, so a half-arrived name
    /// doesn't render as garbage.
    pub fn ps_string(&self) -> String {
        self.ps_name
            .iter()
            .zip(self.ps_seen.iter())
            .map(|(&b, &seen)| if seen && b != 0 { b as char } else { ' ' })
            .collect::<String>()
            .trim()
            .to_string()
    }

    pub fn radiotext_string(&self) -> String {
        self.radiotext
            .iter()
            .zip(self.rt_seen.iter())
            .map(|(&b, &seen)| if seen && b != 0 { b as char } else { ' ' })
            .collect::<String>()
            .trim()
            .to_string()
    }

    /// Groups 0A/0B carry the 8-character station name, 2 characters at a
    /// time; groups 2A/2B carry up to 64 characters of RadioText, 4 at a
    /// time. Both repeat continuously, so a receiver just fills in
    /// whichever slot each group names until it has the whole string.
    fn apply_group(&mut self, blocks: [u16; 4], has_c: bool, has_d: bool) {
        let pi = blocks[0];
        self.pi_code = Some(pi);

        let group_type = (blocks[1] >> 12) & 0xF;
        let version_b = (blocks[1] >> 11) & 1 == 1;
        self.pty = Some(((blocks[1] >> 5) & 0x1F) as u8);

        if group_type == 0 && has_d {
            let segment = (blocks[1] & 0x3) as usize;
            let d = blocks[3];
            let c0 = (d >> 8) as u8;
            let c1 = (d & 0xFF) as u8;
            let idx = segment * 2;
            if idx + 1 < 8 {
                self.ps_name[idx] = c0;
                self.ps_name[idx + 1] = c1;
                self.ps_seen[idx] = true;
                self.ps_seen[idx + 1] = true;
            }
        } else if group_type == 2 && has_d {
            let segment = (blocks[1] & 0xF) as usize;
            if version_b {
                // Version B: only block D carries text, 2 chars/segment.
                let d = blocks[3];
                let idx = segment * 2;
                if idx + 1 < 64 {
                    self.radiotext[idx] = (d >> 8) as u8;
                    self.radiotext[idx + 1] = (d & 0xFF) as u8;
                    self.rt_seen[idx] = true;
                    self.rt_seen[idx + 1] = true;
                }
            } else if has_c {
                // Version A: blocks C and D together, 4 chars/segment.
                let c = blocks[2];
                let d = blocks[3];
                let idx = segment * 4;
                if idx + 3 < 64 {
                    self.radiotext[idx] = (c >> 8) as u8;
                    self.radiotext[idx + 1] = (c & 0xFF) as u8;
                    self.radiotext[idx + 2] = (d >> 8) as u8;
                    self.radiotext[idx + 3] = (d & 0xFF) as u8;
                    for k in 0..4 {
                        self.rt_seen[idx + k] = true;
                    }
                }
            }
        }
    }
}

/// Extracts the 57 kHz RDS subcarrier from a wideband FM composite (MPX)
/// signal, recovers the 1187.5 baud biphase bitstream differentially (no
/// pilot-locked PLL — sidesteps needing one by only ever caring about
/// phase *changes* between symbols, not absolute carrier phase, which is
/// robust to a free-running local mixer), and assembles/parses groups.
pub struct RdsDecoder {
    mix_phase: f32,
    mix_step: f32,
    lp: crate::demod::LowpassDecimator,
    // Symbol-rate differential phase tracking.
    samples_per_symbol: f32,
    sym_accum_i: f32,
    sym_accum_q: f32,
    sym_count: f32,
    prev_symbol_phase: f32,
    prev_bit: u8,
    // Block/group sync.
    shift: u64, // most recent 26 bits, LSB = most recently received
    bit_pos: u32,
    block_bits: [u16; 4],
    block_have: [bool; 4],
    expect: usize, // 0=A,1=B,2=C,3=D
    pub data: RdsData,
    pub locked: bool,
}

impl RdsDecoder {
    /// `mpx_rate` is the sample rate of the wideband FM discriminator
    /// output feeding this decoder (must be well above 2×59.4 kHz to
    /// satisfy Nyquist for the 57 kHz subcarrier).
    pub fn new(mpx_rate: f32) -> Self {
        let decim_rate = (SYMBOL_RATE_HZ * 4.0).max(4000.0); // ~4 samples/symbol
        let factor = (mpx_rate / decim_rate).round().max(1.0) as usize;
        let actual_rate = mpx_rate / factor as f32;
        RdsDecoder {
            mix_phase: 0.0,
            mix_step: TAU * 57_000.0 / mpx_rate,
            lp: crate::demod::LowpassDecimator::new(2_400.0, mpx_rate, factor, 63),
            samples_per_symbol: actual_rate / SYMBOL_RATE_HZ,
            sym_accum_i: 0.0,
            sym_accum_q: 0.0,
            sym_count: 0.0,
            prev_symbol_phase: 0.0,
            prev_bit: 0,
            shift: 0,
            bit_pos: 0,
            block_bits: [0; 4],
            block_have: [false; 4],
            expect: 0,
            data: RdsData::default(),
            locked: false,
        }
    }

    /// `mpx` is the wideband FM discriminator output (real-valued).
    pub fn process(&mut self, mpx: &[f32]) {
        let mut mixed = Vec::with_capacity(mpx.len());
        for &s in mpx {
            let (sin, cos) = self.mix_phase.sin_cos();
            mixed.push(Complex32::new(s * cos, s * sin));
            self.mix_phase += self.mix_step;
            if self.mix_phase > TAU {
                self.mix_phase -= TAU;
            }
        }
        let mut baseband = Vec::new();
        self.lp.process(&mixed, &mut baseband);

        for c in baseband {
            self.sym_accum_i += c.re;
            self.sym_accum_q += c.im;
            self.sym_count += 1.0;
            if self.sym_count >= self.samples_per_symbol {
                self.sym_count -= self.samples_per_symbol;
                let phase = self.sym_accum_i.atan2(self.sym_accum_q);
                self.sym_accum_i = 0.0;
                self.sym_accum_q = 0.0;

                // Differential: a transition of roughly half a turn from
                // the previous symbol is a 1, a small change is a 0. This
                // is what makes an unlocked, free-running 57 kHz mixer
                // workable at all — only the *change* matters.
                let mut dphase = phase - self.prev_symbol_phase;
                while dphase > std::f32::consts::PI {
                    dphase -= TAU;
                }
                while dphase < -std::f32::consts::PI {
                    dphase += TAU;
                }
                self.prev_symbol_phase = phase;
                let symbol_bit = if dphase.abs() > std::f32::consts::FRAC_PI_2 {
                    1
                } else {
                    0
                };
                let bit = symbol_bit ^ self.prev_bit;
                self.prev_bit = symbol_bit;
                self.push_bit(bit);
            }
        }
    }

    fn push_bit(&mut self, bit: u8) {
        self.shift = (self.shift << 1) | bit as u64;
        self.bit_pos += 1;
        if self.bit_pos < 26 {
            return;
        }
        let word = (self.shift & 0x3FF_FFFF) as u32; // 26 bits
        let info = (word >> 10) as u16;
        let check = (word & 0x3FF) as u16;

        let offset = [OFFSET_A, OFFSET_B, OFFSET_C, OFFSET_D][self.expect];
        if block_matches(info, check, offset) {
            self.block_bits[self.expect] = info;
            self.block_have[self.expect] = true;
            self.bit_pos = 0;
            if self.expect == 3 {
                self.locked = true;
                self.data.apply_group(
                    self.block_bits,
                    self.block_have[2],
                    self.block_have[3],
                );
                self.block_have = [false; 4];
                self.expect = 0;
            } else {
                self.expect += 1;
            }
        } else if self.bit_pos > 26 * 4 {
            // No sync found in a reasonable span — drop back to hunting
            // for block A from scratch rather than staying stuck.
            self.locked = false;
            self.expect = 0;
            self.block_have = [false; 4];
            self.bit_pos = 0;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The block-sync/CRC layer is exactly verifiable without any live
    /// signal: build a block the same way the encoder would, confirm the
    /// decoder recognizes it, and confirm it rejects a corrupted one. This
    /// is the layer where a wrong constant means nothing ever syncs, so
    /// it's the one worth pinning down with a test.
    #[test]
    fn recognizes_valid_block_a() {
        let info: u16 = 0x1234;
        let check = crc10(info) ^ OFFSET_A;
        assert!(block_matches(info, check, OFFSET_A));
    }

    #[test]
    fn rejects_corrupted_block() {
        let info: u16 = 0x1234;
        let mut check = crc10(info) ^ OFFSET_A;
        check ^= 0x001; // flip one bit
        assert!(!block_matches(info, check, OFFSET_A));
    }

    #[test]
    fn full_group_sync_from_bitstream() {
        // Build four blocks (PI, then a group-0A segment 0 with "AB" as
        // the first two PS characters) and feed them through push_bit one
        // bit at a time, the same way the real bit recovery would.
        let pi: u16 = 0xABCD;
        // group_type=0 (bits 15-12), version_b=0 (bit 11), PTY=0 (bits 9-5),
        // segment=0 (bits 1-0) — all zero, spelled out rather than shifted
        // for clarity since every field here is deliberately zero.
        let block_b: u16 = 0;
        let block_d: u16 = ((b'A' as u16) << 8) | (b'B' as u16);
        let block_c: u16 = 0x0000;

        let blocks_info = [pi, block_b, block_c, block_d];
        let offsets = [OFFSET_A, OFFSET_B, OFFSET_C, OFFSET_D];

        let mut dec = RdsDecoder::new(240_000.0);
        for (info, off) in blocks_info.iter().zip(offsets.iter()) {
            let check = crc10(*info) ^ off;
            let word: u32 = ((*info as u32) << 10) | check as u32;
            for i in (0..26).rev() {
                let bit = ((word >> i) & 1) as u8;
                dec.push_bit(bit);
            }
        }

        assert!(dec.locked, "decoder should have locked onto the group");
        assert_eq!(dec.data.pi_code, Some(pi));
        assert_eq!(&dec.data.ps_name[0..2], b"AB");
    }
}
