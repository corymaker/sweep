# Sweep

RTL-SDR wideband scanner: one radio that picks up everything, on one dongle.

Voice bands tune, scan and record. Data modes decode the payload and show it —
aircraft and ships on a map, APRS stations with what they said, ACARS messages
as text. Each subject gets its own workspace: the thing itself, a switchable
instrument beside it, and the actions that belong to it.

`sweep-core` is the hardware-independent half: scan plans, window packing,
spectrum, detection, squelch, and the decoders. No USB, no libusb, no platform
code. Desktop and Android link this same crate and supply their own capture
layer, which is the only part that differs between them.

The decoders, and what each one actually is:

| mode  | where         | modulation            | payload                  |
| ----- | ------------- | --------------------- | ------------------------ |
| ADS-B | 1090 MHz      | pulse position, 1 Mb/s| aircraft positions       |
| AIS   | 161.975/162.025 | GMSK 9600, HDLC     | ship positions and names |
| APRS  | 144.390 MHz   | AFSK 1200, AX.25      | station positions, text  |
| ACARS | 131.550 MHz   | AM, MSK 2400          | airline/aircraft messages|
| SSTV  | 14.230 MHz    | FM subcarrier, VIS    | pictures                 |
| POCSAG| 931.0125-931.9875 | 2FSK, BCH(31,21)  | pager text messages      |

Two band surveys sit alongside the decoders, and are surveys rather than
decoders on purpose. `drone.rs` measures where energy sits in the reachable
drone bands. `ism.rs` analyses the structure of 433/915 MHz bursts — their
timing fingerprint, line coding, raw bits, repeats, and whether a standard
CRC-8 closes over the bytes — without ever naming a device or reporting a
sensor value. Those hundreds of undocumented device formats are what rtl_433
built from years of captures; inventing their bit layouts from nothing would
be the same fabrication the decoders refuse, so the survey stops at what the
signal itself proves and hands you the raw hex and a .cu8 recording to take
further.

POCSAG is the one decoder that needed no off-air capture to prove. Every
32-bit codeword carries a BCH(31,21) check and an overall parity bit, so the
tests encode valid batches from CCIR Recommendation 584, modulate them as
NRZ audio with a DC offset and a clock error, slice them back and compare —
and the decoder does not know the bit rate or the polarity in advance. It
runs all three standard rates in both polarities at once and lets the error
control pick the winner, which is safe precisely because a wrong lane
produces nothing rather than producing rubbish. Finding out which lane won
is also the best diagnostic the mode has: sync words climbing with no pages
means the transmitter is there and the path is losing codewords.

Two things it declines to claim. The function bits are supposed to say
whether a payload is text or digits, but published mappings of function to
type contradict each other, so the payload is read both ways and judged by
content — and when both readings are plausible the UI shows both. And the
nibble order of numeric messages is a convention this project cannot verify
without a capture, so numeric pages are labelled as a reading rather than a
fact. Alphanumeric pages carry no such doubt.

`drone.rs` is the one survey rather than a decoder: it measures where energy
sits in the drone-relevant bands an R828D can reach — 433 MHz ISM, 868 MHz SRD,
902–928 MHz ISM, and 1.2/1.3 GHz analogue FPV video — and classifies what it
finds by bandwidth and duty cycle. It identifies nothing, and says so on the
screen: Remote ID, the only broadcast carrying a drone's identity, operator
position and takeoff point, is at 2.4/5.8 GHz and the tuner stops at 1766 MHz.
The control links it *can* reach are proprietary hopping schemes keyed from a
binding phrase, so there is no payload either. What is left is shape, and every
verdict is phrased as "consistent with".

Two decisions in there are worth knowing about, because the obvious version of
each is wrong. The noise floor is tracked across the whole band rather than per
tuner window: a window's own median sits *on* any carrier wide enough to fill
it, which would hide an 8 MHz FPV video downlink precisely because it is wide.
And the DC spur, which has to be blanked at the centre of every window, is
recorded as "no measurement" rather than as quiet — recorded as quiet it punches
a hole through a wide carrier every 1.8 MHz and splits one signal into five.

AIS and APRS share `hdlc.rs`; APRS and ACARS share `tone.rs`. Writing those
once means a bug found in one decoder is fixed in both, which matters — every
bug those two layers had was subtle enough to pass a casual read and was found
only by a test.

Nothing is accepted on a guess. Every decoder checks a frame's own checksum or
parity before reporting it, and where a format could not be verified without a
real off-air capture — MIC-E in APRS, the checksum span in ACARS — it says so
rather than producing plausible, wrong output.

```
cargo test -p sweep-core
cargo run -p sweep-core --example pipeline -- "listen to air traffic"
```

177 tests, no hardware required. `sweep-rtl` needs librtlsdr to link, so it is
excluded from that command on purpose — `cargo check --workspace` type-checks
everything.

## Windows setup

1. **Zadig.** Windows binds its DVB-T TV tuner driver to the dongle by default
   and librtlsdr cannot open it through that. Options → List All Devices, pick
   **Bulk-In, Interface (Interface 0)**, install **WinUSB**. If two interfaces
   show up it is 0, not 1. Nearly every "my dongle doesn't work" thread ends here.
2. **Run `rtl_test.exe`** from the prebuilt rtl-sdr package before writing any
   code. If that doesn't run clean, nothing here will help.
3. `setx RTLSDR_LIB_DIR C:\rtl-sdr\x64`, and copy `rtlsdr.dll` and
   `libusb-1.0.dll` next to your exe. It builds without them and fails to start.
4. **Disable USB selective suspend** in Power Options. Laptop power profiles
   suspend the dongle mid-capture and the stream just stops.
5. Build natively. WSL needs usbipd-win for USB passthrough and it is not worth
   the days it costs.

## What's here

| Module | Does |
|---|---|
| `plan` | `ScanPlan` types, JSON round-trip, `validate()` |
| `resolve` | Packs a plan into the fewest 2 MHz tuner windows |
| `rules` | Utterance → plan without a model |
| `spectrum` | Windowed FFT, calibrated dB, DC blanking, frame integration |
| `detect` | Noise floor, detection clustering, tracking, squelch |
| `source` | `IqSource` trait plus a deterministic `FakeSource` |
| `scheduler` | Window walking, stop-and-listen, priority, mode arbitration |
| `demod` | IF-to-audio chain: anti-aliased decimation, FM discriminator, de-emphasis |

`sweep-rtl` implements `IqSource` over librtlsdr for Windows and Linux, loaded
at runtime via `libloading` (the prebuilt osmocom release ships a `.dll` with
no `.lib` import file, which rules out link-time linking on MSVC). It also has
two examples:

- `first_light` — opens the dongle, tunes to one frequency, confirms a real
  signal is there. No audio.
- `listen` — the real thing: dongle in, NFM demodulated, audio out through
  cpal (WASAPI on Windows). Run with `--release` — the decimators are real
  work at 2.4 MS/s and a debug build can't keep up, which shows up as
  stutter rather than a clean failure.
- `scan` — the scheduler driving real hardware and real audio together: it
  sweeps a whole band, and the moment something keys up it stops, listens,
  and hangs on the conversation, then resumes the sweep where it left off.
  This is the actual scanner, not a fixed-frequency demo.

```
cargo run --release -p sweep-rtl --example listen -- 162.550
cargo run --release -p sweep-rtl --example scan -- "listen to marine"
```

Defaults to a Canadian weather radio frequency because it's almost always
transmitting — a reliable target for confirming the whole chain without
needing to catch a repeater mid-conversation.

## GUI

`sweep-gui` is a desktop front end (eframe/egui) with a waterfall, a live
spectrum trace, and a HUD-style status panel — dark, phosphor green, amber
signal alerts, bracket-framed panels. It runs the exact same plan → scheduler
→ spectrum/demod pipeline as `sweep-rtl`'s `scan` example; the worker thread
in `sweep-gui/src/worker.rs` is that example refactored to report over a
channel instead of printing to a terminal, so the two should never drift far
apart in behavior.

```
cargo run --release -p sweep-gui
```

Type a band name or a bare frequency into the console at the top (same
vocabulary as `scan.rs` — aviation, marine, weather, 2m, 70cm, frs, fm, or a
number like `146.520`) and hit ENGAGE or Enter. The dongle opens with a retry
loop, so you can launch the GUI before plugging the RTL-SDR in.

Needs the same two DLLs as the `scan`/`listen` examples next to the built
`.exe` (or `RTLSDR_LIB_DIR` set) — see Windows setup above.

## The pipeline

```
utterance ─► rules::parse ─► ScanPlan ─► validate ─► resolve ─► RunPlan
                                                                  │
IQ ─► Spectrum ─► Integrator ─► NoiseFloor ─► Detector ─► Tracker ─┤
                                    │                              │
                                 Squelch ─► audio                 UI
```

## Five things that are load-bearing

**Provenance beats plausibility.** `validate()` rejects any plan whose `source`
isn't a database record, `"user"`, or `"rules"`. A language model that produced
a frequency from memory does not get to drive the tuner. This is check 6 in
`plan.rs` and it's the reason the natural-language layer is safe to add.

**Window count is blind time.** `resolve()` packs channels greedily over sorted
frequencies, which is optimal for fixed-width interval covering, so the window
count is minimal. `RunPlan::is_single_window()` is worth surfacing loudly in the
UI: one window means the scanner never retunes and misses nothing. Eleven
windows for the airband means each one is unobserved 91% of the time.

**Integration is correctness, not optimisation.** Noise in a single FFT frame is
Rayleigh distributed — bins land 8–11 dB above the mean constantly, so a +8 dB
threshold against one frame produces a storm of false detections. This was a
real bug, caught by running `examples/pipeline.rs`, not by reading the code.
`Integrator` averages 16 frames in the power domain, taking the spread from
~5.6 dB to ~1.4 dB. `min_bins: 3` cleans up what survives.

**The sweep resumes where it left off.** After a stop-and-listen ends, the
scheduler picks up at the window it was on, not at window zero. Restarting
means the first window in the plan gets checked several times more often than
the last, and on an eleven-window airband plan the difference is stark.

**The noise floor must estimate noise.** Two failure modes, both fixed and both
tested:

- Priming by copying the first frame bakes in any carrier that's already
  transmitting when you start. It's then part of the floor forever. Priming now
  clamps every bin to the frame median + 3 dB.
- Letting signal bins feed the average means a repeater that idles for ten
  minutes gets absorbed. Bins more than 6 dB over the estimate are frozen out,
  with a slow creep so a genuine band-noise change still registers — over about
  fifteen minutes rather than ten seconds.

**Decimation without a low-pass filter is not decimation, it's aliasing.**
`demod::LowpassDecimator` filters before it drops samples; skipping that step
folds everything above the new Nyquist rate straight into the audible band as
noise. The test that catches this plants a 20 kHz tone that would otherwise
leak straight through a 10x decimation and checks it's gone.

**Every window gets its own noise floor.** `scan.rs` keeps a `NoiseFloor` per
tuner window rather than one global one — a busy 2 m repeater sub-band and a
quiet aircraft sub-band are not equally loud, and sharing history between
them would make the squelch threshold wrong in whichever one is quieter.

## Next

- **Android capture.** `UsbManager` permission, then
  `UsbDeviceConnection.getFileDescriptor()` into `libusb_wrap_sys_device`
  (libusb ≥ 1.0.23). Add an `intent-filter` with `device_filter.xml` matching
  `0bda:2838` and `0bda:2832` or Android re-prompts on every reconnect. Use
  larger buffers than on Windows — 16 × 16384 — because bulk transfer timing is
  looser, and dropped samples show up as spurious lines in the waterfall.
- **CTCSS** via a Goertzel bank on the sub-300 Hz audio.
- **AM and WFM demodulation.** `demod::NfmChannel` covers NFM; AM is simpler
  (envelope detect, no discriminator) and WFM is the same discriminator with
  wider deviation and a 75 µs de-emphasis constant.
- **wgpu render layer**, DX12 on Windows.
- **Wire the scheduler to real audio.** `listen.rs` demodulates one fixed
  frequency continuously; the next step is driving it from `Scheduler::next()`
  so Park/Sweep/Interleave actually control what comes out of the speakers.

`RETUNE_MS` in `resolve.rs` is a desktop measurement. Re-measure it on a phone
before trusting any revisit-time number the UI shows.
