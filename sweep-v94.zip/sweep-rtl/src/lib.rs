//! librtlsdr capture layer, loaded at runtime.
//!
//! The prebuilt osmocom Windows release ships `librtlsdr.dll` with no `.lib`
//! import file, so this loads the DLL with [`libloading`] and resolves each
//! function by name instead of link-time linking. Same approach works
//! unchanged on Linux against `librtlsdr.so`.
//!
//! # Windows setup, in order
//!
//! 1. Replace the driver with **Zadig**. Windows binds its DVB-T TV tuner
//!    driver by default and librtlsdr cannot open the device through it. In
//!    Zadig: Options → List All Devices, pick **Bulk-In, Interface (Interface 0)**,
//!    install **WinUSB**. If the dongle exposes two interfaces it is 0, not 1.
//! 2. Run `rtl_test.exe` from the prebuilt rtl-sdr package. If that does not
//!    report the tuner and run clean, nothing in this file will help.
//! 3. Point `RTLSDR_LIB_DIR` at the folder holding `librtlsdr.dll` and
//!    `libusb-1.0.dll`:
//!    `setx RTLSDR_LIB_DIR "C:\path\to\extracted\rtl-sdr"`
//!    then open a fresh terminal. [`RtlSdr::open`] looks there first, then
//!    falls back to the normal DLL search path — so copying the two DLLs
//!    next to your `.exe` also works, with no env var at all.
//! 4. Turn off USB selective suspend in Power Options. Laptop power profiles
//!    suspend the dongle mid-capture and the stream simply stops.

use libloading::{Library, Symbol};
use std::os::raw::{c_char, c_int, c_void};
use std::path::PathBuf;
use std::sync::OnceLock;
use sweep_core::source::{IqSource, SourceError, TunerGain};

#[allow(non_camel_case_types)]
type rtlsdr_dev_t = c_void;

type FnDeviceCount = unsafe extern "C" fn() -> u32;
type FnDeviceName = unsafe extern "C" fn(u32) -> *const c_char;
type FnOpen = unsafe extern "C" fn(*mut *mut rtlsdr_dev_t, u32) -> c_int;
type FnClose = unsafe extern "C" fn(*mut rtlsdr_dev_t) -> c_int;
type FnSetCenterFreq = unsafe extern "C" fn(*mut rtlsdr_dev_t, u32) -> c_int;
type FnGetCenterFreq = unsafe extern "C" fn(*mut rtlsdr_dev_t) -> u32;
type FnSetSampleRate = unsafe extern "C" fn(*mut rtlsdr_dev_t, u32) -> c_int;
type FnGetSampleRate = unsafe extern "C" fn(*mut rtlsdr_dev_t) -> u32;
type FnSetTunerGainMode = unsafe extern "C" fn(*mut rtlsdr_dev_t, c_int) -> c_int;
type FnSetTunerGain = unsafe extern "C" fn(*mut rtlsdr_dev_t, c_int) -> c_int;
type FnGetTunerGains = unsafe extern "C" fn(*mut rtlsdr_dev_t, *mut c_int) -> c_int;
type FnSetAgcMode = unsafe extern "C" fn(*mut rtlsdr_dev_t, c_int) -> c_int;
type FnSetFreqCorrection = unsafe extern "C" fn(*mut rtlsdr_dev_t, c_int) -> c_int;
type FnSetBiasTee = unsafe extern "C" fn(*mut rtlsdr_dev_t, c_int) -> c_int;
type FnSetDirectSampling = unsafe extern "C" fn(*mut rtlsdr_dev_t, c_int) -> c_int;
type FnResetBuffer = unsafe extern "C" fn(*mut rtlsdr_dev_t) -> c_int;
type FnReadSync =
    unsafe extern "C" fn(*mut rtlsdr_dev_t, *mut c_void, c_int, *mut c_int) -> c_int;

/// All resolved symbols, held alongside the library that owns them. Loaded
/// once per process and cached — resolving symbols by name on every call
/// would work but there is no reason to pay for it repeatedly.
struct Api {
    _lib: Library, // must outlive every fn pointer below
    device_count: FnDeviceCount,
    device_name: FnDeviceName,
    open: FnOpen,
    close: FnClose,
    set_center_freq: FnSetCenterFreq,
    get_center_freq: FnGetCenterFreq,
    set_sample_rate: FnSetSampleRate,
    get_sample_rate: FnGetSampleRate,
    set_tuner_gain_mode: FnSetTunerGainMode,
    set_tuner_gain: FnSetTunerGain,
    get_tuner_gains: FnGetTunerGains,
    set_agc_mode: FnSetAgcMode,
    set_freq_correction: FnSetFreqCorrection,
    /// `rtlsdr_set_bias_tee` isn't in every librtlsdr build — resolved
    /// optionally so an older DLL still loads everything else fine.
    set_bias_tee: Option<FnSetBiasTee>,
    set_direct_sampling: FnSetDirectSampling,
    reset_buffer: FnResetBuffer,
    read_sync: FnReadSync,
}

// The Library and every fn pointer we hold are immutable after load and
// contain no interior mutability, so sharing the handle across threads is
// sound; librtlsdr's own device handle is a separate, single-threaded story
// handled by RtlSdr not being Sync.
unsafe impl Sync for Api {}
unsafe impl Send for Api {}

fn candidate_names() -> Vec<PathBuf> {
    let mut names = vec![];
    if let Ok(dir) = std::env::var("RTLSDR_LIB_DIR") {
        let dir = PathBuf::from(dir);
        if cfg!(target_os = "windows") {
            names.push(dir.join("librtlsdr.dll"));
            names.push(dir.join("rtlsdr.dll"));
        } else {
            names.push(dir.join("librtlsdr.so"));
        }
    }
    // Bare names resolve via the OS's normal search path, which on Windows
    // includes the executable's own directory — so copying the DLLs next to
    // the .exe works even with RTLSDR_LIB_DIR unset.
    if cfg!(target_os = "windows") {
        names.push(PathBuf::from("librtlsdr.dll"));
        names.push(PathBuf::from("rtlsdr.dll"));
    } else {
        names.push(PathBuf::from("librtlsdr.so"));
    }
    names
}

unsafe fn get_sym<T: Copy>(lib: &Library, name: &[u8]) -> Result<T, SourceError> {
    let sym: Symbol<T> = lib.get(name).map_err(|e| {
        SourceError::Io(format!(
            "missing symbol {:?}: {e}",
            String::from_utf8_lossy(name)
        ))
    })?;
    Ok(*sym)
}

fn load_api() -> Result<Api, SourceError> {
    let mut last_err = String::new();
    let mut lib = None;
    for name in candidate_names() {
        match unsafe { Library::new(&name) } {
            Ok(l) => {
                lib = Some(l);
                break;
            }
            Err(e) => last_err = e.to_string(),
        }
    }
    let lib = lib.ok_or_else(|| {
        SourceError::Io(format!(
            "could not load librtlsdr.dll ({last_err}). Set RTLSDR_LIB_DIR to the \
             folder holding librtlsdr.dll and libusb-1.0.dll, or copy both DLLs \
             next to your executable."
        ))
    })?;

    let set_bias_tee: Option<FnSetBiasTee> =
        match unsafe { lib.get::<FnSetBiasTee>(b"rtlsdr_set_bias_tee\0") } {
            Ok(sym) => Some(*sym),
            Err(_) => None,
        };

    unsafe {
        Ok(Api {
            device_count: get_sym(&lib, b"rtlsdr_get_device_count\0")?,
            device_name: get_sym(&lib, b"rtlsdr_get_device_name\0")?,
            open: get_sym(&lib, b"rtlsdr_open\0")?,
            close: get_sym(&lib, b"rtlsdr_close\0")?,
            set_center_freq: get_sym(&lib, b"rtlsdr_set_center_freq\0")?,
            get_center_freq: get_sym(&lib, b"rtlsdr_get_center_freq\0")?,
            set_sample_rate: get_sym(&lib, b"rtlsdr_set_sample_rate\0")?,
            get_sample_rate: get_sym(&lib, b"rtlsdr_get_sample_rate\0")?,
            set_tuner_gain_mode: get_sym(&lib, b"rtlsdr_set_tuner_gain_mode\0")?,
            set_tuner_gain: get_sym(&lib, b"rtlsdr_set_tuner_gain\0")?,
            get_tuner_gains: get_sym(&lib, b"rtlsdr_get_tuner_gains\0")?,
            set_agc_mode: get_sym(&lib, b"rtlsdr_set_agc_mode\0")?,
            set_freq_correction: get_sym(&lib, b"rtlsdr_set_freq_correction\0")?,
            set_bias_tee,
            set_direct_sampling: get_sym(&lib, b"rtlsdr_set_direct_sampling\0")?,
            reset_buffer: get_sym(&lib, b"rtlsdr_reset_buffer\0")?,
            read_sync: get_sym(&lib, b"rtlsdr_read_sync\0")?,
            _lib: lib,
        })
    }
}

static API: OnceLock<Result<Api, String>> = OnceLock::new();

fn api() -> Result<&'static Api, SourceError> {
    match API.get_or_init(|| load_api().map_err(|e| e.to_string())) {
        Ok(a) => Ok(a),
        Err(e) => Err(SourceError::Io(e.clone())),
    }
}

fn check(code: c_int, what: &str) -> Result<(), SourceError> {
    if code == 0 {
        Ok(())
    } else {
        Err(SourceError::Io(format!("{what} failed ({code})")))
    }
}

/// Direct sampling branch. Q is the one wired on RTL-SDR Blog v3/v4 boards.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DirectSampling {
    Off,
    IBranch,
    QBranch,
}

pub struct RtlSdr {
    dev: *mut rtlsdr_dev_t,
    center_hz: f64,
    sample_rate: u32,
}

// librtlsdr's device handle is not thread-safe; the handle can be moved to
// the thread that owns it, but sharing needs external synchronisation.
unsafe impl Send for RtlSdr {}

impl RtlSdr {
    pub fn device_count() -> u32 {
        match api() {
            Ok(a) => unsafe { (a.device_count)() },
            Err(_) => 0,
        }
    }

    pub fn device_names() -> Vec<String> {
        let a = match api() {
            Ok(a) => a,
            Err(_) => return Vec::new(),
        };
        (0..Self::device_count())
            .map(|i| unsafe {
                let p = (a.device_name)(i);
                if p.is_null() {
                    String::from("(unnamed)")
                } else {
                    std::ffi::CStr::from_ptr(p).to_string_lossy().into_owned()
                }
            })
            .collect()
    }

    /// Whether the DLL itself could be found and loaded, separate from
    /// whether a device is plugged in. Check this first when something goes
    /// wrong — it tells you which of the two problems you actually have.
    pub fn library_status() -> Result<(), SourceError> {
        api().map(|_| ())
    }

    pub fn open(index: u32) -> Result<Self, SourceError> {
        let a = api()?;
        if Self::device_count() == 0 {
            return Err(SourceError::NotFound);
        }
        let mut dev: *mut rtlsdr_dev_t = std::ptr::null_mut();
        let rc = unsafe { (a.open)(&mut dev, index) };
        if rc != 0 || dev.is_null() {
            return Err(SourceError::Io(format!(
                "rtlsdr_open failed ({rc}). On Windows this almost always means \
                 the WinUSB driver is not installed — run Zadig and replace the \
                 driver on Bulk-In, Interface (Interface 0)."
            )));
        }
        let mut s = RtlSdr {
            dev,
            center_hz: 0.0,
            sample_rate: 0,
        };
        s.set_sample_rate(2_400_000)?;
        s.set_gain(TunerGain::Auto)?;
        unsafe { check((a.set_agc_mode)(s.dev, 0), "set_agc_mode")? };
        s.reset_buffer()?;
        Ok(s)
    }

    /// Gains the tuner actually supports, in tenths of a dB. Setting anything
    /// else silently snaps to the nearest, which makes levels unreproducible.
    pub fn supported_gains(&self) -> Vec<i32> {
        let a = match api() {
            Ok(a) => a,
            Err(_) => return Vec::new(),
        };
        unsafe {
            let n = (a.get_tuner_gains)(self.dev, std::ptr::null_mut());
            if n <= 0 {
                return Vec::new();
            }
            let mut v = vec![0i32; n as usize];
            (a.get_tuner_gains)(self.dev, v.as_mut_ptr());
            v
        }
    }

    /// Crystal error in parts per million. A cheap dongle drifts several kHz
    /// as it warms up; a TCXO board (RTL-SDR Blog v3/v4) is within about 1
    /// ppm and rarely needs this set at all.
    pub fn set_ppm(&mut self, ppm: i32) -> Result<(), SourceError> {
        let a = api()?;
        unsafe { check((a.set_freq_correction)(self.dev, ppm), "set_freq_correction") }
    }

    /// Powers an external LNA over the coax (RTL-SDR Blog V3/V4 boards).
    /// Returns `Unsupported` rather than failing to load at all when the
    /// linked librtlsdr build predates this call.
    pub fn set_bias_tee(&mut self, on: bool) -> Result<(), SourceError> {
        let a = api()?;
        match a.set_bias_tee {
            Some(f) => unsafe { check(f(self.dev, if on { 1 } else { 0 }), "set_bias_tee") },
            None => Err(SourceError::Unsupported(
                "this librtlsdr build has no rtlsdr_set_bias_tee".into(),
            )),
        }
    }

    /// Enables the HF path. Only meaningful on boards wired for it.
    pub fn set_direct_sampling(&mut self, mode: DirectSampling) -> Result<(), SourceError> {
        let a = api()?;
        let v = match mode {
            DirectSampling::Off => 0,
            DirectSampling::IBranch => 1,
            DirectSampling::QBranch => 2,
        };
        unsafe { check((a.set_direct_sampling)(self.dev, v), "set_direct_sampling") }
    }

    pub fn actual_center_hz(&self) -> f64 {
        match api() {
            Ok(a) => unsafe { (a.get_center_freq)(self.dev) as f64 },
            Err(_) => 0.0,
        }
    }

    pub fn actual_sample_rate(&self) -> u32 {
        match api() {
            Ok(a) => unsafe { (a.get_sample_rate)(self.dev) },
            Err(_) => 0,
        }
    }
}

impl Drop for RtlSdr {
    fn drop(&mut self) {
        if !self.dev.is_null() {
            if let Ok(a) = api() {
                unsafe { (a.close)(self.dev) };
            }
            self.dev = std::ptr::null_mut();
        }
    }
}

impl IqSource for RtlSdr {
    fn set_center_hz(&mut self, hz: f64) -> Result<(), SourceError> {
        let a = api()?;
        unsafe { check((a.set_center_freq)(self.dev, hz as u32), "set_center_freq")? };
        self.center_hz = hz;
        Ok(())
    }

    fn set_sample_rate(&mut self, hz: u32) -> Result<(), SourceError> {
        // The RTL2832U only supports 225001-300000 and 900001-3200000 Hz, and
        // drops samples above about 2.56 MS/s on most hosts.
        if !((225_001..=300_000).contains(&hz) || (900_001..=3_200_000).contains(&hz)) {
            return Err(SourceError::Unsupported(format!(
                "{hz} Hz is outside the RTL2832U's supported rates"
            )));
        }
        let a = api()?;
        unsafe { check((a.set_sample_rate)(self.dev, hz), "set_sample_rate")? };
        self.sample_rate = hz;
        Ok(())
    }

    fn set_gain(&mut self, gain: TunerGain) -> Result<(), SourceError> {
        let a = api()?;
        match gain {
            TunerGain::Auto => unsafe {
                check((a.set_tuner_gain_mode)(self.dev, 0), "set_tuner_gain_mode")
            },
            TunerGain::Manual(tenths) => unsafe {
                check((a.set_tuner_gain_mode)(self.dev, 1), "set_tuner_gain_mode")?;
                check((a.set_tuner_gain)(self.dev, tenths), "set_tuner_gain")
            },
        }
    }

    fn reset_buffer(&mut self) -> Result<(), SourceError> {
        let a = api()?;
        unsafe { check((a.reset_buffer)(self.dev), "reset_buffer") }
    }

    fn read(&mut self, buf: &mut [u8]) -> Result<usize, SourceError> {
        let a = api()?;
        let mut n: c_int = 0;
        let rc = unsafe {
            (a.read_sync)(
                self.dev,
                buf.as_mut_ptr() as *mut c_void,
                buf.len() as c_int,
                &mut n,
            )
        };
        if rc != 0 {
            return Err(SourceError::Io(format!("read_sync failed ({rc})")));
        }
        Ok(n as usize)
    }

    fn center_hz(&self) -> f64 {
        self.center_hz
    }

    fn sample_rate(&self) -> u32 {
        self.sample_rate
    }
}

/// Retune, flush, and read one clean buffer.
///
/// The flush is not optional. Buffers already in flight when you retune still
/// hold samples from the old frequency, and they show up as a ghost signal at
/// the wrong place in the waterfall. Discarding one buffer after the flush
/// covers PLL settling too.
pub fn retune_and_read<S: IqSource>(
    src: &mut S,
    center_hz: f64,
    scratch: &mut [u8],
    out: &mut [u8],
) -> Result<usize, SourceError> {
    src.set_center_hz(center_hz)?;
    src.reset_buffer()?;
    src.read(scratch)?; // settle
    src.read(out)
}

pub mod source {
    pub use sweep_core::source::*;
}

#[cfg(test)]
mod tests {
    use super::*;
    use sweep_core::source::FakeSource;

    #[test]
    fn rejects_unsupported_sample_rates() {
        assert!(!((225_001..=300_000).contains(&500_000u32)
            || (900_001..=3_200_000).contains(&500_000u32)));
    }

    #[test]
    fn retune_helper_flushes_before_reading() {
        let mut src = FakeSource::new(2_400_000).with_carrier(101_500_000.0, 0.4);
        src.stale_after_tune = true;
        let mut scratch = vec![0u8; 4096];
        let mut out = vec![0u8; 4096];
        retune_and_read(&mut src, 101_500_000.0, &mut scratch, &mut out).unwrap();
        let swing = out.iter().map(|&b| (b as i32 - 127).abs()).max().unwrap();
        assert!(swing > 20, "expected the real carrier, got flat noise");
    }

    #[test]
    fn missing_dll_fails_informatively_instead_of_panicking() {
        // On a CI box with no librtlsdr on the search path this should return
        // an error, never panic or segfault.
        let _ = RtlSdr::library_status();
        assert_eq!(RtlSdr::device_count(), RtlSdr::device_count());
    }
}
