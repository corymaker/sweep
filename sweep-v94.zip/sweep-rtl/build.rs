//! Deliberately empty.
//!
//! The prebuilt osmocom Windows release ships `librtlsdr.dll` with no `.lib`
//! import file, and MSVC's linker cannot link directly against a bare DLL.
//! Rather than require building an import lib with `lib.exe` and a hand
//! written `.def` (fragile, and one more step to explain), `src/lib.rs` loads
//! the DLL at runtime with the `libloading` crate instead of at link time.
//! This file exists so the crate root has a `build.rs` to point to; it does
//! nothing.

fn main() {}
