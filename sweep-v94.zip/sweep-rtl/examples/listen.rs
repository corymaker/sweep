//! Real dongle, real speakers.
//!
//!     cargo run --release -p sweep-rtl --example listen -- 162.550
//!
//! Defaults to a Canadian weather radio frequency because it's almost always
//! transmitting — a reliable target for confirming the whole chain works
//! without needing to catch someone mid-conversation on a repeater.
//!
//! **Run with `--release`.** The FIR decimators do real work at 2.4 MS/t and
//! a debug build can't keep up in real time — you'll hear it stutter and
//! degrade rather than fail outright, which is worse than a clean error.

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use rustfft::num_complex::Complex32;
use std::collections::VecDeque;
use std::sync::{Arc, Mutex};
use sweep_core::demod::NfmChannel;
use sweep_core::source::{IqSource, TunerGain};
use sweep_rtl::RtlSdr;

const IF_RATE: u32 = 2_400_000;
const CHANNEL_BW_HZ: f32 = 12_500.0;
const DEVIATION_HZ: f32 = 2_500.0;

fn main() {
    let mhz: f64 = std::env::args()
        .nth(1)
        .and_then(|s| s.parse().ok())
        .unwrap_or(162.550);

    println!("opening dongle...");
    let mut dev = match RtlSdr::open(0) {
        Ok(d) => d,
        Err(e) => {
            eprintln!("could not open the dongle: {e}");
            std::process::exit(1);
        }
    };

    println!("tuning to {mhz} MHz, NFM, {CHANNEL_BW_HZ} kHz bandwidth");
    dev.set_center_hz(mhz * 1e6).expect("set frequency");
    dev.set_sample_rate(IF_RATE).expect("set sample rate");
    dev.set_gain(TunerGain::Manual(400)).expect("set gain");
    dev.reset_buffer().expect("flush");

    // Settle read: discard whatever was in flight before we tuned here.
    let mut warm = vec![0u8; 65536];
    dev.read(&mut warm).expect("settle read");

    // --- audio output setup -------------------------------------------------
    let host = cpal::default_host();
    let out_dev = host
        .default_output_device()
        .expect("no default audio output device — check Windows sound settings");
    let out_cfg = out_dev
        .default_output_config()
        .expect("no default output config");
    let audio_rate = out_cfg.sample_rate().0 as f32;
    let channels = out_cfg.channels() as usize;
    let stream_config: cpal::StreamConfig = out_cfg.config();
    println!(
        "audio out: {} @ {} Hz, {} channel(s)",
        out_dev.name().unwrap_or_default(),
        audio_rate,
        channels
    );

    // Small ring buffer between the demod thread and cpal's callback. cpal
    // calls back on its own high-priority thread; it must never block, so
    // it only ever tries the lock and gives up silently on contention.
    let ring: Arc<Mutex<VecDeque<f32>>> = Arc::new(Mutex::new(VecDeque::with_capacity(48_000)));
    let ring_cb = ring.clone();

    let stream = out_dev
        .build_output_stream(
            &stream_config,
            move |data: &mut [f32], _| {
                let mut buf = match ring_cb.try_lock() {
                    Ok(b) => b,
                    Err(_) => {
                        data.fill(0.0);
                        return;
                    }
                };
                for frame in data.chunks_mut(channels) {
                    let s = buf.pop_front().unwrap_or(0.0);
                    for out in frame.iter_mut() {
                        *out = s;
                    }
                }
            },
            move |err| eprintln!("audio stream error: {err}"),
            None,
        )
        .expect("failed to build output stream");
    stream.play().expect("failed to start audio stream");

    // --- capture + demod loop ------------------------------------------------
    let mut nfm = NfmChannel::new(IF_RATE as f32, audio_rate, CHANNEL_BW_HZ, DEVIATION_HZ);
    let mut raw = vec![0u8; 32768];
    let mut audio = Vec::new();

    println!("listening — Ctrl+C to stop\n");
    let mut level_frames = 0u32;
    loop {
        let n = match dev.read(&mut raw) {
            Ok(n) => n,
            Err(e) => {
                eprintln!("read error: {e}");
                break;
            }
        };
        let iq: Vec<Complex32> = raw[..n]
            .chunks_exact(2)
            .map(|b| {
                Complex32::new(
                    (b[0] as f32 - 127.4) / 127.5,
                    (b[1] as f32 - 127.4) / 127.5,
                )
            })
            .collect();

        audio.clear();
        nfm.process(&iq, &mut audio);

        {
            let mut buf = ring.lock().unwrap();
            // If the callback is falling behind, drop the oldest audio
            // rather than let latency grow without bound.
            while buf.len() + audio.len() > 96_000 {
                buf.pop_front();
            }
            buf.extend(audio.iter().copied());
        }

        level_frames += 1;
        if level_frames % 20 == 0 {
            let peak = audio.iter().cloned().fold(0.0f32, |a, b| a.max(b.abs()));
            print!("\raudio peak: {:>5.2}   ", peak);
            use std::io::Write;
            std::io::stdout().flush().ok();
        }
    }
}
