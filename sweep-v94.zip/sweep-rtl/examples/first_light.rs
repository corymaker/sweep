//! First light. Opens the real dongle, tunes to an FM broadcast station, and
//! prints whether it sees a real signal there.
//!
//!     cargo run -p sweep-rtl --example first_light -- 101.1
//!
//! Pick any station you know is on air in your area. FM is the easiest first
//! target because it's wide and strong — if this doesn't work, nothing built
//! on top of it will either.

use sweep_core::source::IqSource;
use sweep_core::spectrum::Spectrum;
use sweep_rtl::RtlSdr;

fn main() {
    let mhz: f64 = std::env::args()
        .nth(1)
        .and_then(|s| s.parse().ok())
        .unwrap_or(101.1);

    println!("devices found: {}", RtlSdr::device_count());
    for name in RtlSdr::device_names() {
        println!("  {name}");
    }

    let mut dev = match RtlSdr::open(0) {
        Ok(d) => d,
        Err(e) => {
            eprintln!("could not open the dongle: {e}");
            eprintln!("if this mentions WinUSB or Zadig, redo the Zadig step");
            std::process::exit(1);
        }
    };

    println!("tuning to {mhz} MHz...");
    dev.set_center_hz(mhz * 1e6).expect("set frequency");
    dev.set_gain(sweep_core::source::TunerGain::Manual(400))
        .expect("set gain");
    dev.reset_buffer().expect("flush");

    // Throw away the first buffer: it may still hold pre-tune samples.
    let n = 16384;
    let mut buf = vec![0u8; n * 2];
    dev.read(&mut buf).expect("settle read");

    dev.read(&mut buf).expect("read");

    let fft_n = 1024;
    let mut spec = Spectrum::new(fft_n);
    let mut out = vec![0.0f32; fft_n];
    spec.process_u8(&buf[..fft_n * 2], &mut out);

    let peak = out.iter().cloned().fold(f32::MIN, f32::max);
    let mean = out.iter().sum::<f32>() / out.len() as f32;

    println!("\npeak level:  {peak:.1} dB");
    println!("mean level:  {mean:.1} dB");
    println!("peak - mean: {:.1} dB", peak - mean);

    if peak - mean > 10.0 {
        println!("\nlooks like a real signal — the dongle is working end to end.");
    } else {
        println!(
            "\nflat spectrum — either nothing is broadcasting on {mhz} MHz here, \
             or the antenna isn't connected. Try a station you know is strong, \
             or run rtl_test.exe again to rule out a hardware issue."
        );
    }
}
