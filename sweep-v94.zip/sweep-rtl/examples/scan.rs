//! The real scanner: scheduler + real hardware + real audio, tied together.
//!
//!     cargo run --release -p sweep-rtl --example scan -- "listen to marine"
//!     cargo run --release -p sweep-rtl --example scan -- "146.520"
//!
//! Falls through to the rule parser only (no language model wired in yet) —
//! see `sweep-core::rules` for what phrases are understood.
//!
//! Each tuner window keeps its own noise floor, because two windows are
//! rarely equally quiet and mixing their history would make the squelch
//! threshold wrong in both.

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use rustfft::num_complex::Complex32;
use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, Mutex};
use sweep_core::demod::NfmChannel;
use sweep_core::detect::{Detector, NoiseFloor, Squelch, SquelchState};
use sweep_core::plan::Demod;
use sweep_core::resolve::resolve;
use sweep_core::rules;
use sweep_core::scheduler::{Scheduler, Task};
use sweep_core::source::{IqSource, TunerGain};
use sweep_core::spectrum::{Integrator, Spectrum};
use sweep_rtl::RtlSdr;

const IF_RATE: u32 = 2_400_000;
const FFT_N: usize = 1024;
const INTEGRATE_FRAMES: u32 = 4;
/// Every read from the dongle uses this size. Large single-shot reads (we
/// originally sized these to a requested duration, sometimes hundreds of KB)
/// are unreliable over USB on Windows and can simply hang. This size matches
/// what `listen.rs` already proved works in real time.
const READ_CHUNK: usize = 32768;

/// Read at least `min_bytes` from the dongle, looping in [`READ_CHUNK`]-sized
/// calls rather than requesting one large buffer that may never return.
fn read_at_least(dev: &mut RtlSdr, min_bytes: usize) -> Vec<u8> {
    let mut out = Vec::with_capacity(min_bytes + READ_CHUNK);
    let mut scratch = vec![0u8; READ_CHUNK];
    while out.len() < min_bytes {
        let got = dev.read(&mut scratch).unwrap_or(0);
        if got == 0 {
            break; // device stalled; return what we have rather than spin forever
        }
        out.extend_from_slice(&scratch[..got]);
    }
    out
}

/// Per-window detection state. Kept separate per window because a busy 2 m
/// repeater band and a quiet aircraft band do not share a noise floor.
struct WindowWatch {
    floor: NoiseFloor,
    integ: Integrator,
    last_spectrum: Vec<f32>,
}

impl WindowWatch {
    fn new() -> Self {
        WindowWatch {
            floor: NoiseFloor::new(FFT_N),
            integ: Integrator::new(FFT_N, INTEGRATE_FRAMES),
            last_spectrum: vec![-140.0; FFT_N],
        }
    }
}

fn main() {
    let utterance = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "listen to weather".to_string());

    let plan = match rules::parse(&utterance) {
        Some(p) => p,
        None => {
            eprintln!("didn't understand {utterance:?} — try a band name (aviation, marine, \
                       weather, 2m, 70cm, frs, fm) or a bare frequency like 146.520");
            std::process::exit(1);
        }
    };
    println!("plan: {} [{}]", plan.name, plan.source);

    let run = match resolve(&plan, false) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("plan rejected: {e}");
            std::process::exit(1);
        }
    };
    println!(
        "{} window(s), {} channel(s), revisit {} ms",
        run.windows.len(),
        run.channels.len(),
        run.revisit_ms()
    );
    if run.is_single_window() {
        println!("single window — this scanner never goes blind");
    }

    println!("opening dongle...");
    let mut dev = match RtlSdr::open(0) {
        Ok(d) => d,
        Err(e) => {
            eprintln!("could not open the dongle: {e}");
            std::process::exit(1);
        }
    };
    dev.set_sample_rate(IF_RATE).expect("set sample rate");
    dev.set_gain(TunerGain::Manual(400)).expect("set gain");

    // --- audio out, same pattern as listen.rs -------------------------------
    let host = cpal::default_host();
    let out_dev = host.default_output_device().expect("no output device");
    let out_cfg = out_dev.default_output_config().expect("no output config");
    let audio_rate = out_cfg.sample_rate().0 as f32;
    let channels_out = out_cfg.channels() as usize;
    let stream_config: cpal::StreamConfig = out_cfg.config();

    let ring: Arc<Mutex<VecDeque<f32>>> = Arc::new(Mutex::new(VecDeque::with_capacity(48_000)));
    let ring_cb = ring.clone();
    let stream = out_dev
        .build_output_stream(
            &stream_config,
            move |data: &mut [f32], _| {
                let mut buf = match ring_cb.try_lock() {
                    Ok(b) => b,
                    Err(_) => {
                        data.fill(0.0);
                        return;
                    }
                };
                for frame in data.chunks_mut(channels_out) {
                    let s = buf.pop_front().unwrap_or(0.0);
                    for out in frame.iter_mut() {
                        *out = s;
                    }
                }
            },
            move |err| eprintln!("audio stream error: {err}"),
            None,
        )
        .expect("failed to build output stream");
    stream.play().expect("failed to start audio stream");

    // --- scan state -----------------------------------------------------------
    let mut sched = Scheduler::new(run.clone());
    let mut watches: HashMap<usize, WindowWatch> = HashMap::new();
    let mut demods: HashMap<usize, NfmChannel> = HashMap::new();
    let mut sweep_demods: HashMap<i64, NfmChannel> = HashMap::new();
    let mut current_center: Option<f64> = None;
    let mut spec = Spectrum::new(FFT_N);
    let mut frame_db = vec![0.0f32; FFT_N];

    println!("\nscanning — Ctrl+C to stop\n");
    let mut last_reported_window = usize::MAX;

    loop {
        let task = sched.next();
        let center_hz = task.center_mhz() * 1e6;

        // Retune only when the frequency actually changed — retuning every
        // task even when parked would waste time and reset the PLL settle
        // unnecessarily.
        if current_center != Some(center_hz) {
            dev.set_center_hz(center_hz).expect("retune");
            dev.reset_buffer().expect("flush");
            let mut settle = vec![0u8; 16384];
            dev.read(&mut settle).ok();
            current_center = Some(center_hz);
        }

        match task {
            Task::Observe { window, dwell_ms: _, .. } => {
                if window != last_reported_window {
                    print!(
                        "\rwindow {:>2}/{}  {:>9.4} MHz                              ",
                        window + 1,
                        run.windows.len(),
                        task.center_mhz()
                    );
                    use std::io::Write;
                    std::io::stdout().flush().ok();
                    last_reported_window = window;
                }

                let watch = watches.entry(window).or_insert_with(WindowWatch::new);
                let min_bytes = FFT_N * 2 * INTEGRATE_FRAMES as usize;
                let raw = read_at_least(&mut dev, min_bytes);
                let got = raw.len();

                for chunk in raw[..got].chunks_exact(FFT_N * 2) {
                    spec.process_u8(chunk, &mut frame_db);
                    if watch.integ.push_db(&frame_db) {
                        watch.integ.take(&mut watch.last_spectrum);
                        spec.blank_dc(&mut watch.last_spectrum, IF_RATE, 30_000.0, -140.0);
                        watch.floor.update(&watch.last_spectrum);
                    }
                }

                // Any channel that lives in this window: check it directly.
                let bin_hz = IF_RATE as f64 / FFT_N as f64;
                let f0 = task.center_mhz() * 1e6 - IF_RATE as f64 / 2.0;
                let mut matched_channel = false;
                for &ci in &run.windows[window].channels {
                    let ch = &run.channels[ci];
                    let bin = (((ch.freq_mhz * 1e6) - f0) / bin_hz).round() as isize;
                    if bin < 0 || bin as usize >= FFT_N {
                        continue;
                    }
                    let bin = bin as usize;
                    let snr = watch.last_spectrum[bin] - watch.floor.get()[bin];
                    if snr >= sched.plan().squelch_db as f32 && !ch.locked_out {
                        println!(
                            "\n  >> {} ({:.4} MHz) — {:.0} dB over floor, listening",
                            ch.label, ch.freq_mhz, snr
                        );
                        sched.stop_and_listen(ci);
                        matched_channel = true;
                        break;
                    }
                }

                // A band name like "marine" or "weather" produces a pure
                // sweep with no predefined channel list — the plan doesn't
                // know in advance which exact frequencies matter. Here the
                // detector itself decides: scan the whole window and follow
                // whatever is loudest above the floor. This is a separate,
                // manual demod loop because the scheduler's Listen state only
                // knows about channels that existed when the plan was built.
                if !matched_channel && run.windows[window].channels.is_empty() {
                    let det = Detector::default();
                    let dets = det.scan(&watch.last_spectrum, watch.floor.get(), f0, bin_hz);
                    if let Some(top) = dets.iter().max_by(|a, b| {
                        a.snr_db.partial_cmp(&b.snr_db).unwrap()
                    }) {
                        if top.snr_db >= sched.plan().squelch_db as f32 {
                            println!(
                                "\n  >> signal at {:.4} MHz — {:.0} dB over floor, listening",
                                top.center_hz / 1e6,
                                top.snr_db
                            );
                            let found_hz = top.center_hz;
                            dev.set_center_hz(found_hz).expect("retune to signal");
                            dev.reset_buffer().expect("flush");
                            let mut settle = vec![0u8; 16384];
                            dev.read(&mut settle).ok();

                            let key = (found_hz / 1000.0).round() as i64;
                            let mut sq = Squelch::new(
                                sched.plan().squelch_db as f32,
                                sched.plan().hang_ms,
                            );
                            sq.update(sched.plan().squelch_db as f32 + 5.0, 0);

                            loop {
                                let ms = 100u32;
                                let min_bytes = (ms as usize * (IF_RATE as usize / 1000)) * 2;
                                let raw = read_at_least(&mut dev, min_bytes);
                                let got = raw.len();
                                let iq: Vec<Complex32> = raw[..got]
                                    .chunks_exact(2)
                                    .map(|b| {
                                        Complex32::new(
                                            (b[0] as f32 - 127.4) / 127.5,
                                            (b[1] as f32 - 127.4) / 127.5,
                                        )
                                    })
                                    .collect();

                                let demod = sweep_demods.entry(key).or_insert_with(|| {
                                    NfmChannel::new(
                                        IF_RATE as f32,
                                        audio_rate,
                                        run.channels.first().map(|c| c.bw_khz as f32 * 1000.0)
                                            .unwrap_or(12_500.0),
                                        2_500.0,
                                    )
                                });
                                let mut audio = Vec::new();
                                demod.process(&iq, &mut audio);
                                let peak = audio.iter().cloned().fold(0.0f32, |a, b| a.max(b.abs()));
                                {
                                    let mut buf = ring.lock().unwrap();
                                    while buf.len() + audio.len() > 96_000 {
                                        buf.pop_front();
                                    }
                                    buf.extend(audio.iter().copied());
                                }

                                let snr = if got >= FFT_N * 2 {
                                    spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                                    watch.floor.update(&frame_db);
                                    frame_db[FFT_N / 2] - watch.floor.get()[FFT_N / 2]
                                } else {
                                    0.0
                                };
                                print!("\raudio peak {peak:>4.2}  {:>4.0} dB over floor  ", snr);
                                use std::io::Write;
                                std::io::stdout().flush().ok();

                                if sq.update(snr, ms) == SquelchState::Closed {
                                    println!("\n  << signal ended, resuming sweep");
                                    break;
                                }
                            }
                            current_center = None; // force a retune back into the sweep
                        }
                    }
                }
            }

            Task::Listen { channel, window, ms, .. } => {
                let ch = &run.channels[channel];
                let min_bytes = (ms as usize * (IF_RATE as usize / 1000)) * 2;
                let raw = read_at_least(&mut dev, min_bytes);
                let got = raw.len();

                let iq: Vec<Complex32> = raw[..got]
                    .chunks_exact(2)
                    .map(|b| {
                        Complex32::new(
                            (b[0] as f32 - 127.4) / 127.5,
                            (b[1] as f32 - 127.4) / 127.5,
                        )
                    })
                    .collect();

                let demod = demods.entry(channel).or_insert_with(|| {
                    let bw = ch.demod.default_bw_khz() as f32 * 1000.0;
                    let dev_hz = if ch.demod == Demod::Wfm { 75_000.0 } else { 2_500.0 };
                    NfmChannel::new(IF_RATE as f32, audio_rate, bw, dev_hz)
                });
                let mut audio = Vec::new();
                demod.process(&iq, &mut audio);

                let peak = audio.iter().cloned().fold(0.0f32, |a, b| a.max(b.abs()));
                {
                    let mut buf = ring.lock().unwrap();
                    while buf.len() + audio.len() > 96_000 {
                        buf.pop_front();
                    }
                    buf.extend(audio.iter().copied());
                }

                // Re-check the carrier so the scheduler knows when to give the
                // channel back to the sweep.
                if let Some(watch) = watches.get_mut(&window) {
                    let bin_hz = IF_RATE as f64 / FFT_N as f64;
                    let f0 = task.center_mhz() * 1e6 - IF_RATE as f64 / 2.0;
                    let bin = (((ch.freq_mhz * 1e6) - f0) / bin_hz).round() as isize;
                    let snr = if got >= FFT_N * 2 && bin >= 0 && (bin as usize) < FFT_N {
                        spec.process_u8(&raw[..FFT_N * 2], &mut frame_db);
                        watch.floor.update(&frame_db);
                        frame_db[bin as usize] - watch.floor.get()[bin as usize]
                    } else {
                        0.0
                    };
                    sched.report_snr(snr, ms);
                    print!("\raudio peak {peak:>4.2}  {:>4.0} dB over floor  ", snr);
                    use std::io::Write;
                    std::io::stdout().flush().ok();
                } else {
                    sched.report_snr(0.0, ms);
                }
            }
        }
    }
}
